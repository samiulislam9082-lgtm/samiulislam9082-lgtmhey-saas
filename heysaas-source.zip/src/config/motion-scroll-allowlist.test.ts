/**
 * @vitest-environment jsdom
 */
import { describe, it, expect, beforeEach } from "vitest";
import {
  findScrollAllowlistMatch,
  scrollAllowlist,
} from "./motion-scroll-allowlist";

function mount(html: string) {
  document.body.innerHTML = html;
  return document.body.firstElementChild as HTMLElement;
}

beforeEach(() => {
  document.documentElement.removeAttribute("data-motion");
  document.body.innerHTML = "";
});

describe("findScrollAllowlistMatch", () => {
  it("matches by selector for scroll-snap kind", () => {
    const el = mount(`<div data-carousel><div class="slide"></div></div>`);
    const m = findScrollAllowlistMatch(el, "scroll-snap");
    expect(m?.rule.id).toBe("carousel-scroll-snap");
  });

  it("matches ancestor via closest() for kids inside a sanctioned container", () => {
    mount(`<div data-listing-gallery><ul><li data-snap>a</li></ul></div>`);
    const child = document.querySelector("li[data-snap]")!;
    const m = findScrollAllowlistMatch(child, "scroll-snap");
    expect(m?.rule.id).toBe("listing-gallery-snap");
  });

  it("does not match when kind differs (snap rule ≠ smooth kind)", () => {
    const el = mount(`<div data-carousel></div>`);
    expect(findScrollAllowlistMatch(el, "scroll-behavior-smooth")).toBeNull();
  });

  it("respects routes[] scoping — matches only on /dev/kpi-preview", () => {
    const el = mount(`<div data-kpi-story-track></div>`);
    expect(findScrollAllowlistMatch(el, "scroll-snap", "/explore")).toBeNull();
    expect(
      findScrollAllowlistMatch(el, "scroll-snap", "/dev/kpi-preview")?.rule.id
    ).toBe("kpi-preview-story-snap");
    expect(
      findScrollAllowlistMatch(el, "scroll-snap", "/dev/kpi-preview/sub")?.rule.id
    ).toBe("kpi-preview-story-snap");
  });

  it("respects requireHtmlAttr — opt-in smooth needs data-motion=full", () => {
    const el = mount(`<div data-allow-smooth-scroll></div>`);
    expect(findScrollAllowlistMatch(el, "scroll-behavior-smooth")).toBeNull();
    document.documentElement.setAttribute("data-motion", "full");
    expect(
      findScrollAllowlistMatch(el, "scroll-behavior-smooth")?.rule.id
    ).toBe("opt-in-smooth-anchor");
    document.documentElement.setAttribute("data-motion", "reduced");
    expect(findScrollAllowlistMatch(el, "scroll-behavior-smooth")).toBeNull();
  });

  it("returns null for unrelated elements", () => {
    const el = mount(`<section class="hero"></section>`);
    expect(findScrollAllowlistMatch(el, "scroll-snap")).toBeNull();
    expect(findScrollAllowlistMatch(el, "scroll-behavior-smooth")).toBeNull();
  });

  it("tolerates malformed selectors without throwing", () => {
    scrollAllowlist.push({
      id: "__broken",
      kind: "scroll-snap",
      selector: ":::not-a-selector",
      reason: "test",
    });
    try {
      const el = mount(`<div></div>`);
      expect(() => findScrollAllowlistMatch(el, "scroll-snap")).not.toThrow();
    } finally {
      const i = scrollAllowlist.findIndex((r) => r.id === "__broken");
      scrollAllowlist.splice(i, 1);
    }
  });
});
