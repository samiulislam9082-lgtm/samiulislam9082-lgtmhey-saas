/**
 * Sanctioned CSS scroll allowlist.
 *
 * The MotionDebugIndicator's CSS auditor (and the static motion-guard
 * scanner, when run in "config-aware" mode) reads this file to decide
 * whether an element that has `scroll-behavior: smooth` or a
 * `scroll-snap-type` other than `none` should be treated as a leak
 * under reduced motion.
 *
 * A match on ANY rule of the correct `kind` suppresses the leak and
 * records a `suppressed` event with the rule's `id` + `reason` instead.
 *
 * Rules are pure data — no code, no regex flags — so they can be
 * consumed by both the browser runtime and offline Python scanners.
 */

export type ScrollAllowlistKind = "scroll-behavior-smooth" | "scroll-snap";

export type ScrollAllowlistRule = {
  /** Stable identifier surfaced in debug events + CI reports. */
  id: string;
  /** Human-readable justification (shown in the debug panel). */
  reason: string;
  /** Which CSS pattern this rule sanctions. */
  kind: ScrollAllowlistKind;
  /**
   * CSS selector that matches sanctioned elements. Evaluated with
   * `element.matches(selector)` at runtime; the offline scanner
   * matches it against class-name / id occurrences in source files.
   */
  selector: string;
  /**
   * Optional list of route pathname prefixes this rule applies to.
   * Omit or empty = all routes.
   */
  routes?: string[];
  /**
   * Optional guard: only apply when the given data attribute is present
   * on <html> (e.g. `data-motion="full"` to allow snap only when the
   * user has explicitly opted back into motion).
   */
  requireHtmlAttr?: { name: string; value?: string };
};

export const scrollAllowlist: ScrollAllowlistRule[] = [
  {
    id: "carousel-scroll-snap",
    kind: "scroll-snap",
    selector: "[data-carousel], [data-embla]",
    reason:
      "Horizontal carousels rely on scroll-snap to align slides; snap alone " +
      "does not animate — the user drives it.",
  },
  {
    id: "listing-gallery-snap",
    kind: "scroll-snap",
    selector: "[data-listing-gallery] [data-snap]",
    reason: "Listing image gallery uses snap for touch swipe alignment.",
  },
  {
    id: "kpi-preview-story-snap",
    kind: "scroll-snap",
    selector: "[data-kpi-story-track]",
    reason:
      "/dev/kpi-preview story lanes snap between panels; scroll is user-driven.",
    routes: ["/dev/kpi-preview"],
  },
  {
    id: "opt-in-smooth-anchor",
    kind: "scroll-behavior-smooth",
    selector: "[data-allow-smooth-scroll]",
    reason:
      "Marked as an explicit opt-in smooth scroll container — only takes effect " +
      "when the user chose full motion.",
    requireHtmlAttr: { name: "data-motion", value: "full" },
  },
];

/** Runtime helpers — pure, safe to call from probe callbacks. */

function ruleRouteMatches(rule: ScrollAllowlistRule, pathname: string): boolean {
  if (!rule.routes || rule.routes.length === 0) return true;
  return rule.routes.some((p) => pathname === p || pathname.startsWith(p + "/"));
}

function ruleHtmlAttrMatches(rule: ScrollAllowlistRule): boolean {
  if (!rule.requireHtmlAttr) return true;
  if (typeof document === "undefined") return false;
  const v = document.documentElement.getAttribute(rule.requireHtmlAttr.name);
  if (rule.requireHtmlAttr.value === undefined) return v !== null;
  return v === rule.requireHtmlAttr.value;
}

export type ScrollAllowlistMatch = {
  rule: ScrollAllowlistRule;
};

export function findScrollAllowlistMatch(
  el: Element,
  kind: ScrollAllowlistKind,
  pathname: string = typeof location !== "undefined" ? location.pathname : "",
  rules: ScrollAllowlistRule[] = scrollAllowlist,
): ScrollAllowlistMatch | null {
  for (const rule of rules) {
    if (rule.kind !== kind) continue;
    if (!ruleRouteMatches(rule, pathname)) continue;
    if (!ruleHtmlAttrMatches(rule)) continue;
    try {
      if (el.matches(rule.selector) || el.closest(rule.selector)) {
        return { rule };
      }
    } catch {
      // Invalid selector — ignore rather than crash the probe.
    }
  }
  return null;
}

