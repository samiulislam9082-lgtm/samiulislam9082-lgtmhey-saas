import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Smile, Image as ImageIcon, Mic, Send, X, Play, Pause, Sticker, Loader2 } from "lucide-react";
import { toast } from "sonner";

export type ComposerAttachment = {
  kind: "image" | "audio" | "sticker";
  path?: string;
  url?: string;
  mime?: string;
  duration_ms?: number;
  name?: string;
  // client-only preview
  _localUrl?: string;
};

const EMOJIS = "😀 😂 🥰 😍 😎 🤔 😴 🙃 😅 🤯 🤗 🤩 😇 🥳 😢 😡 👍 👏 🙏 💯 🔥 ✨ ⭐ 💡 🚀 💼 💰 📈 📉 ✅ ❌ ⚡ 🎉 🎯 🛠️ 🧠 ❤️ 🩵 🖤 💚 💜".split(" ");
const STICKERS = "🎉 🚀 🔥 💯 👏 🙌 💪 🧠 💡 🏆 🎯 ⚡ ✨ 💰 📈 🤝 🥂 🎊 ⭐ 🌟 💎 🦄 🐙 🐳 🌈 ☕ 🍕 🎁".split(" ");

export function MessageComposer({
  threadId,
  onSend,
  disabled,
  onTyping,
  enterToSend = true,
}: {
  threadId: string;
  onSend: (payload: { body: string; attachments: ComposerAttachment[] }) => Promise<void>;
  disabled?: boolean;
  onTyping?: () => void;
  enterToSend?: boolean;
}) {
  const [text, setText] = useState("");

  const [attachments, setAttachments] = useState<ComposerAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);

  // voice recording
  const [recording, setRecording] = useState(false);
  const [recSeconds, setRecSeconds] = useState(0);
  const [level, setLevel] = useState(0);
  const mediaRecRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const rafRef = useRef<number | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startTsRef = useRef<number>(0);
  const speechStartedRef = useRef<boolean>(false);
  const lastLoudTsRef = useRef<number>(0);
  const secondsIntRef = useRef<number | null>(null);
  const cancelRecRef = useRef<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // File input upload
  async function handleFilesPicked(files: FileList | null) {
    if (!files || !files.length) return;
    const arr = Array.from(files).slice(0, 6);
    setUploading(true);
    try {
      const uploaded: ComposerAttachment[] = [];
      for (const f of arr) {
        if (!f.type.startsWith("image/")) {
          toast.error(`${f.name}: only images are supported here`);
          continue;
        }
        if (f.size > 8 * 1024 * 1024) {
          toast.error(`${f.name}: max 8MB`);
          continue;
        }
        const ext = (f.name.split(".").pop() || "jpg").toLowerCase();
        const path = `${threadId}/${crypto.randomUUID()}.${ext}`;
        const { error } = await supabase.storage.from("message-media").upload(path, f, { contentType: f.type, upsert: false });
        if (error) throw error;
        uploaded.push({
          kind: "image",
          path,
          mime: f.type,
          name: f.name,
          _localUrl: URL.createObjectURL(f),
        });
      }
      setAttachments((a) => [...a, ...uploaded]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  function removeAttachment(idx: number) {
    setAttachments((a) => {
      const next = [...a];
      const [rem] = next.splice(idx, 1);
      if (rem?._localUrl) URL.revokeObjectURL(rem._localUrl);
      return next;
    });
  }

  function insertEmoji(e: string) {
    const ta = textareaRef.current;
    if (!ta) { setText((t) => t + e); return; }
    const start = ta.selectionStart ?? text.length;
    const end = ta.selectionEnd ?? text.length;
    const next = text.slice(0, start) + e + text.slice(end);
    setText(next);
    requestAnimationFrame(() => {
      ta.focus();
      ta.setSelectionRange(start + e.length, start + e.length);
    });
  }

  function addSticker(s: string) {
    setAttachments((a) => [...a, { kind: "sticker", url: s }]);
  }

  // Voice recording with silence auto-stop
  async function startRecording() {
    if (recording) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      toast.error("Microphone not supported on this device");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      streamRef.current = stream;
      // Pick a supported mime
      const candidates = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus"];
      const mime = candidates.find((c) => (window as any).MediaRecorder?.isTypeSupported?.(c)) || "";
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      mediaRecRef.current = rec;
      chunksRef.current = [];
      cancelRecRef.current = false;
      speechStartedRef.current = false;
      lastLoudTsRef.current = 0;
      rec.ondataavailable = (e) => { if (e.data.size) chunksRef.current.push(e.data); };
      rec.onstop = async () => {
        cleanupAudio();
        if (cancelRecRef.current) return;
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        if (blob.size < 800) {
          toast.error("Recording too short");
          return;
        }
        await uploadVoice(blob, Date.now() - startTsRef.current);
      };
      rec.start(200);
      startTsRef.current = Date.now();
      setRecording(true);
      setRecSeconds(0);
      secondsIntRef.current = window.setInterval(() => {
        setRecSeconds(Math.round((Date.now() - startTsRef.current) / 1000));
      }, 250);

      // silence detection
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      audioCtxRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      source.connect(analyser);
      analyserRef.current = analyser;
      const data = new Uint8Array(analyser.fftSize);
      const SPEECH_RMS = 0.045;   // start-speaking threshold
      const SILENCE_RMS = 0.02;   // below = silent
      const SILENCE_MS = 1600;    // auto-stop after this much trailing silence
      const MAX_MS = 120_000;     // hard cap 2 min

      const loop = () => {
        if (!analyserRef.current) return;
        analyser.getByteTimeDomainData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) {
          const v = (data[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / data.length);
        setLevel(rms);
        const elapsed = Date.now() - startTsRef.current;
        if (rms > SPEECH_RMS) {
          speechStartedRef.current = true;
          lastLoudTsRef.current = Date.now();
        }
        if (speechStartedRef.current && rms < SILENCE_RMS && Date.now() - lastLoudTsRef.current > SILENCE_MS) {
          stopRecording(false);
          return;
        }
        if (elapsed > MAX_MS) {
          stopRecording(false);
          return;
        }
        rafRef.current = requestAnimationFrame(loop);
      };
      rafRef.current = requestAnimationFrame(loop);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Microphone permission denied");
      cleanupAudio();
    }
  }

  function cleanupAudio() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    if (secondsIntRef.current) window.clearInterval(secondsIntRef.current);
    secondsIntRef.current = null;
    analyserRef.current = null;
    if (audioCtxRef.current) { audioCtxRef.current.close().catch(() => {}); audioCtxRef.current = null; }
    if (streamRef.current) { streamRef.current.getTracks().forEach((t) => t.stop()); streamRef.current = null; }
    setRecording(false);
    setLevel(0);
  }

  function stopRecording(cancel: boolean) {
    cancelRecRef.current = cancel;
    const rec = mediaRecRef.current;
    if (rec && rec.state !== "inactive") {
      try { rec.stop(); } catch { /* noop */ }
    } else {
      cleanupAudio();
    }
  }

  async function uploadVoice(blob: Blob, durationMs: number) {
    setUploading(true);
    try {
      const ext = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
      const path = `${threadId}/voice-${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("message-media").upload(path, blob, { contentType: blob.type, upsert: false });
      if (error) throw error;
      setAttachments((a) => [...a, {
        kind: "audio",
        path,
        mime: blob.type,
        duration_ms: durationMs,
        _localUrl: URL.createObjectURL(blob),
      }]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Voice upload failed");
    } finally {
      setUploading(false);
    }
  }

  useEffect(() => () => {
    stopRecording(true);
    attachments.forEach((a) => { if (a._localUrl) URL.revokeObjectURL(a._localUrl); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function submit() {
    if (recording) { stopRecording(false); return; }
    if (sending) return;
    const body = text.trim();
    if (!body && attachments.length === 0) return;
    setSending(true);
    try {
      const payload = attachments.map(({ _localUrl, ...rest }) => rest);
      await onSend({ body, attachments: payload });
      setText("");
      attachments.forEach((a) => { if (a._localUrl) URL.revokeObjectURL(a._localUrl); });
      setAttachments([]);
    } finally {
      setSending(false);
    }
  }

  const canSend = !disabled && !sending && (text.trim().length > 0 || attachments.length > 0);

  return (
    <div className="relative rounded-2xl border border-white/10 bg-gradient-to-br from-secondary/40 via-card/60 to-secondary/30 p-2 sm:p-2.5 shadow-[0_10px_30px_-15px_rgb(0_0_0/0.6)] focus-within:border-primary/40 focus-within:shadow-[0_0_0_3px_hsl(var(--primary)/0.12)] transition-all">
      <div className="pointer-events-none absolute inset-x-4 top-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" aria-hidden />
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {attachments.map((a, i) => (
            <div key={i} className="relative group rounded-lg overflow-hidden border border-border/60 bg-secondary/40">
              {a.kind === "image" && (
                <img src={a._localUrl} alt="" className="h-20 w-20 object-cover" />
              )}
              {a.kind === "audio" && (
                <div className="h-20 w-40 flex items-center gap-2 px-3 text-xs">
                  <Mic className="h-4 w-4 text-primary" />
                  <div>
                    <div className="font-medium">Voice</div>
                    <div className="text-muted-foreground">{Math.max(1, Math.round((a.duration_ms ?? 0) / 1000))}s</div>
                  </div>
                </div>
              )}
              {a.kind === "sticker" && (
                <div className="h-20 w-20 flex items-center justify-center text-4xl">{a.url}</div>
              )}
              <button
                type="button"
                onClick={() => removeAttachment(i)}
                aria-label="Remove attachment"
                className="absolute top-1 right-1 rounded-full bg-background/90 border border-border p-0.5 opacity-0 group-hover:opacity-100 focus:opacity-100 transition"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {recording ? (
        <div className="flex items-center gap-3 px-2 py-3">
          <span className="relative flex h-3 w-3">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive/60" />
            <span className="relative inline-flex h-3 w-3 rounded-full bg-destructive" />
          </span>
          <div className="flex-1 flex items-center gap-0.5 h-8">
            {Array.from({ length: 28 }).map((_, i) => {
              const h = Math.max(4, Math.min(28, Math.round((level * 260) * (0.5 + Math.sin(i / 3 + Date.now() / 200) * 0.5))));
              return <span key={i} className="w-1 rounded-full bg-primary/70" style={{ height: h }} />;
            })}
          </div>
          <span className="text-xs tabular-nums text-muted-foreground w-12 text-right">
            {String(Math.floor(recSeconds / 60)).padStart(2, "0")}:{String(recSeconds % 60).padStart(2, "0")}
          </span>
          <Button size="sm" variant="ghost" onClick={() => stopRecording(true)}>Cancel</Button>
          <Button size="sm" onClick={() => stopRecording(false)}>Stop</Button>
        </div>
      ) : (
        <div className="flex items-end gap-2">
          <div className="flex items-center gap-0.5 pb-1">
            {/* Emoji */}
            <Popover>
              <PopoverTrigger asChild>
                <Button type="button" variant="ghost" size="icon" className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10" aria-label="Insert emoji">
                  <Smile className="h-[18px] w-[18px]" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-72 p-2">
                <div className="text-[11px] uppercase tracking-wide text-muted-foreground px-1 pb-1">Emoji</div>
                <div className="grid grid-cols-8 gap-1 max-h-48 overflow-y-auto">
                  {EMOJIS.map((e) => (
                    <button key={e} type="button" onClick={() => insertEmoji(e)} className="text-xl rounded hover:bg-secondary p-1">{e}</button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Stickers */}
            <Popover>
              <PopoverTrigger asChild>
                <Button type="button" variant="ghost" size="icon" className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10" aria-label="Send sticker">
                  <Sticker className="h-[18px] w-[18px]" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-72 p-2">
                <div className="text-[11px] uppercase tracking-wide text-muted-foreground px-1 pb-1">Stickers</div>
                <div className="grid grid-cols-6 gap-1 max-h-56 overflow-y-auto">
                  {STICKERS.map((s) => (
                    <button key={s} type="button" onClick={() => addSticker(s)} className="text-3xl rounded hover:bg-secondary p-1 aspect-square">{s}</button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Image upload */}
            <Button type="button" variant="ghost" size="icon" className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10" aria-label="Attach image" onClick={() => fileInputRef.current?.click()}>
              {uploading ? <Loader2 className="h-[18px] w-[18px] animate-spin" /> : <ImageIcon className="h-[18px] w-[18px]" />}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => handleFilesPicked(e.target.files)}
            />
          </div>

          <Textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => { setText(e.target.value); onTyping?.(); }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && enterToSend) { e.preventDefault(); submit(); }
              else if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); submit(); }
            }}
            placeholder="Type a message…"
            rows={1}
            className="flex-1 min-h-[40px] max-h-40 resize-none rounded-2xl bg-background/70 border-white/5 focus-visible:ring-0 focus-visible:border-white/10 placeholder:text-muted-foreground/70 text-[14px]"
          />

          {canSend ? (
            <Button
              type="button"
              onClick={submit}
              disabled={!canSend}
              className="h-10 w-10 rounded-full p-0 shrink-0 bg-gradient-to-br from-primary to-primary/70 hover:from-primary hover:to-primary shadow-[0_6px_20px_-6px_hsl(var(--primary)/0.7)]"
              aria-label="Send message"
            >
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          ) : (
            <Button
              type="button"
              onClick={startRecording}
              disabled={disabled}
              className="h-10 w-10 rounded-full p-0 shrink-0 bg-gradient-to-br from-primary to-primary/70 hover:from-primary hover:to-primary shadow-[0_6px_20px_-6px_hsl(var(--primary)/0.7)]"
              aria-label="Record voice message"
              title="Tap to talk — auto-stops on silence"
            >
              <Mic className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

/** Renders a saved attachment (image/audio/sticker) using a signed URL for private bucket paths. */
export function AttachmentView({ att }: { att: ComposerAttachment }) {
  const [url, setUrl] = useState<string | null>(att.url ?? null);

  useEffect(() => {
    let cancel = false;
    if (att.kind === "sticker") { setUrl(att.url ?? null); return; }
    if (!att.path) return;
    supabase.storage.from("message-media").createSignedUrl(att.path, 3600).then(({ data }) => {
      if (!cancel) setUrl(data?.signedUrl ?? null);
    });
    return () => { cancel = true; };
  }, [att.path, att.kind, att.url]);

  if (att.kind === "sticker") {
    return <div className="text-5xl leading-none py-1">{att.url}</div>;
  }
  if (att.kind === "image") {
    return url ? (
      <a href={url} target="_blank" rel="noopener noreferrer">
        <img src={url} alt="" className="max-h-64 max-w-[240px] rounded-lg object-cover" />
      </a>
    ) : <div className="h-24 w-40 bg-secondary/60 rounded-lg animate-pulse" />;
  }
  if (att.kind === "audio") {
    return (
      <VoicePlayer url={url} durationMs={att.duration_ms} />
    );
  }
  return null;
}

function VoicePlayer({ url, durationMs }: { url: string | null; durationMs?: number }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState(durationMs ? durationMs / 1000 : 0);

  function toggle() {
    const a = audioRef.current;
    if (!a || !url) return;
    if (playing) a.pause();
    else a.play().catch(() => {});
  }

  return (
    <div className="flex items-center gap-2 rounded-full bg-background/70 border border-border/60 pl-1 pr-3 py-1 min-w-[180px]">
      <button
        type="button"
        onClick={toggle}
        disabled={!url}
        className="h-8 w-8 rounded-full bg-primary text-primary-foreground grid place-items-center shrink-0"
        aria-label={playing ? "Pause voice message" : "Play voice message"}
      >
        {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
      </button>
      <div className="flex-1 h-1.5 rounded-full bg-secondary overflow-hidden">
        <div className="h-full bg-primary transition-[width]" style={{ width: dur ? `${(pos / dur) * 100}%` : "0%" }} />
      </div>
      <span className="text-[10px] tabular-nums text-muted-foreground w-9 text-right">
        {formatDur(playing || pos > 0 ? dur - pos : dur)}
      </span>
      {url && (
        <audio
          ref={audioRef}
          src={url}
          preload="metadata"
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
          onEnded={() => { setPlaying(false); setPos(0); }}
          onLoadedMetadata={(e) => {
            const d = (e.currentTarget as HTMLAudioElement).duration;
            if (isFinite(d) && d > 0) setDur(d);
          }}
          onTimeUpdate={(e) => setPos((e.currentTarget as HTMLAudioElement).currentTime)}
        />
      )}
    </div>
  );
}

function formatDur(sec: number) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const s = Math.round(sec);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
