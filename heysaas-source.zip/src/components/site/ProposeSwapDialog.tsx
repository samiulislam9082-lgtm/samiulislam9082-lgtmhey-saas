import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { createSwapProposal } from "@/lib/swaps.functions";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

type MyListing = { id: string; name: string; slug: string };

export function ProposeSwapDialog({
  open,
  onOpenChange,
  recipientListingId,
  recipientName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  recipientListingId: string;
  recipientName: string;
}) {
  const [myListings, setMyListings] = useState<MyListing[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const propose = useServerFn(createSwapProposal);

  useEffect(() => {
    if (!open) return;
    (async () => {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data } = await supabase
        .from("saas_listings")
        .select("id, name, slug")
        .eq("owner_id", user.id)
        .eq("status", "live")
        .order("created_at", { ascending: false });
      setMyListings((data ?? []) as MyListing[]);
      if (data && data[0]) setSelected(data[0].id);
      setLoading(false);
    })();
  }, [open]);

  async function submit() {
    if (!selected) return;
    setSubmitting(true);
    try {
      const res = await propose({ data: { initiator_listing_id: selected, recipient_listing_id: recipientListingId, note: note || null } });
      toast.success("Proposal sent");
      onOpenChange(false);
      navigate({ to: "/dashboard/swaps" });
      void res;
    } catch (err: any) {
      toast.error(err?.message ?? "Could not send proposal");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Propose a swap with {recipientName}</DialogTitle>
          <DialogDescription>Pick one of your live listings to offer in exchange.</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-2">
          {loading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin" /></div>
          ) : myListings.length === 0 ? (
            <div className="rounded-2xl border border-hairline bg-surface p-6 text-center text-sm text-muted-foreground">
              You need at least one live listing before you can propose a swap.
              <div className="mt-4">
                <Button onClick={() => { onOpenChange(false); navigate({ to: "/list" }); }} className="rounded-full bg-foreground text-background hover:opacity-90">
                  List your SaaS
                </Button>
              </div>
            </div>
          ) : (
            <>
              <div>
                <Label className="mb-3 block">Offer</Label>
                <RadioGroup value={selected} onValueChange={setSelected}>
                  {myListings.map((l) => (
                    <label key={l.id} className="flex items-center gap-3 rounded-xl border border-hairline bg-surface px-4 py-3 cursor-pointer hover:border-foreground/30">
                      <RadioGroupItem value={l.id} />
                      <span className="font-medium">{l.name}</span>
                    </label>
                  ))}
                </RadioGroup>
              </div>

              <div>
                <Label htmlFor="note">Note (optional)</Label>
                <Textarea
                  id="note"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Tell them why this could be a good swap…"
                  className="mt-2"
                  rows={4}
                  maxLength={2000}
                />
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} className="rounded-full">Cancel</Button>
          <Button
            onClick={submit}
            disabled={!selected || submitting || myListings.length === 0}
            className="rounded-full bg-foreground text-background hover:opacity-90"
          >
            {submitting ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Sending…</> : "Send proposal"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
