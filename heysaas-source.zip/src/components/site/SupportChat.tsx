import { useEffect, useRef, useState, useCallback } from "react";
import { LifeBuoy, X, Send, Loader2, ChevronDown, Sparkles, UserRound, ArrowLeft, CheckCircle2, MessageSquarePlus, History, Trash2, Mail, ClipboardList, ThumbsUp, ThumbsDown, Check, Paperclip, AlertTriangle, Flag, Clock } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { classifyTopic, getSupportSessionId, logSupportEvent } from "@/lib/support-analytics";
import { useServerFn } from "@tanstack/react-start";
import { checkTicketRateLimit } from "@/lib/support-tickets.functions";
import { notifyTicket } from "@/lib/support-webhooks.functions";
import { estimatedResponse, suggestedFlow, type Urgency } from "@/lib/support-routing";

type Msg = { role: "user" | "assistant"; content: string };
type Conversation = { id: string; title: string; updated_at: string };

const GREETING: Msg = {
  role: "assistant",
  content:
    "Hey — I'm the HeySaaS support assistant. Pick a quick question below or type your own.",
};

const QUICK_REPLIES = [
  "How do swaps work?",
  "What's the $19 safety fee?",
  "How do I list my SaaS?",
  "HeySaaS vs WebSwap?",
  "How do I verify my identity?",
  "Refund policy?",
];

const FAQS: { q: string; a: string }[] = [
  { q: "How does a SaaS swap actually work?", a: "Browse listings, send a swap request, chat with the founder, and once both sides agree you each pay a $19 safety fee to unlock a private Swap Room where you exchange access, contracts, and hand off ownership." },
  { q: "What is the $19 safety fee for?", a: "It's a small anti-spam and trust deposit both parties pay before entering the Swap Room. It filters non-serious founders and funds moderation." },
  { q: "How do I list my SaaS or website?", a: "Dashboard → New listing (5-step wizard). For websites go to /websites — you can auto-draft with the AI Listing Generator from your URL." },
  { q: "How do I verify my identity?", a: "Settings → Profile: connect Google, add LinkedIn, and verify domain ownership via DNS TXT. Verified founders rank higher in Explore." },
  { q: "Can I get a refund on the safety fee?", a: "Yes if the other party no-shows within 7 days or violates the terms. Open a report from the Swap Room; we review within 48 hours." },
  { q: "What's the difference between HeySaaS and WebSwap?", a: "HeySaaS is for SaaS products (MRR, code, customers). WebSwap is for websites and content businesses (traffic, SEO, ads). Same account, separate listings." },
];

function summarizeTranscript(msgs: Msg[]): string {
  const lines = msgs
    .filter((m, i) => !(i === 0 && m.role === "assistant"))
    .map((m) => `${m.role === "user" ? "Me" : "Assistant"}: ${m.content}`);
  if (!lines.length) return "";
  return `Context from my chat with the AI assistant:\n\n${lines.join("\n\n")}`.slice(0, 3800);
}

function titleFromText(text: string): string {
  const t = text.trim().replace(/\s+/g, " ");
  return t.length > 60 ? t.slice(0, 57) + "…" : t;
}

export function SupportChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([GREETING]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState<"chat" | "ticket" | "ticket_success" | "history" | "intake" | "intake_review">("chat");
  const [reviewComposed, setReviewComposed] = useState("");
  const [ticket, setTicket] = useState({ name: "", email: "", subject: "", message: "", priority: "normal" as "low" | "normal" | "high" | "urgent" });
  const [ticketSource, setTicketSource] = useState<"support_chat" | "email_follow_up">("support_chat");
  const [submittingTicket, setSubmittingTicket] = useState(false);
  const [ticketFile, setTicketFile] = useState<File | null>(null);
  const [intake, setIntake] = useState({ topic: "", urgency: "normal", account_email: "", related_url: "", details: "" });
  const [intakeCompleted, setIntakeCompleted] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  type FeedbackState = { rating: "up" | "down"; submitted: boolean; showForm: boolean; reason?: string; comment: string; isReport?: boolean; reportExplanation?: string };
  const [feedback, setFeedback] = useState<Record<number, FeedbackState>>({});
  const [showFeedbackHistory, setShowFeedbackHistory] = useState(false);
  const [routingEta, setRoutingEta] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const checkTicketLimit = useServerFn(checkTicketRateLimit);
  const sendSlackAlert = useServerFn(notifyTicket);

  // Track auth
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUserId(session?.user?.id ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading, open, view]);

  useEffect(() => {
    if (open && view === "chat") inputRef.current?.focus();
  }, [open, view]);

  useEffect(() => {
    getSupportSessionId();
    if (open) {
      void logSupportEvent({ event_type: "chat_opened" });
    } else {
      void logSupportEvent({ event_type: "chat_closed", meta: { messages: messages.length - 1 } });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Global trigger: dispatch `new CustomEvent("heysaas:open-support")` from anywhere to open the chat.
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener("heysaas:open-support", handler);
    return () => window.removeEventListener("heysaas:open-support", handler);
  }, []);


  const loadConversations = useCallback(async () => {
    if (!userId) return;
    setLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from("support_conversations")
        .select("id, title, updated_at")
        .order("updated_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      setConversations(data ?? []);
    } catch {
      // silent
    } finally {
      setLoadingHistory(false);
    }
  }, [userId]);

  // On open (signed-in): auto-resume the most recent conversation
  useEffect(() => {
    if (!open || !userId || conversationId) return;
    (async () => {
      const { data: conv } = await supabase
        .from("support_conversations")
        .select("id, title, updated_at")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (!conv) return;
      const { data: rows } = await supabase
        .from("support_messages")
        .select("role, content")
        .eq("conversation_id", conv.id)
        .order("created_at", { ascending: true });
      if (rows && rows.length) {
        setConversationId(conv.id);
        setMessages([GREETING, ...rows.map((r) => ({ role: r.role as "user" | "assistant", content: r.content }))]);
      }
    })();
  }, [open, userId, conversationId]);

  // Show a short intake as the first screen for fresh conversations
  useEffect(() => {
    if (!open || intakeCompleted) return;
    if (conversationId) return;
    if (messages.length > 1) return;
    setView((v) => (v === "chat" ? "intake" : v));
  }, [open, intakeCompleted, conversationId, messages.length]);

  async function openHistory() {
    setView("history");
    await loadConversations();
  }

  async function selectConversation(id: string) {
    const { data: rows, error } = await supabase
      .from("support_messages")
      .select("role, content")
      .eq("conversation_id", id)
      .order("created_at", { ascending: true });
    if (error) {
      toast.error("Could not load conversation.");
      return;
    }
    setConversationId(id);
    setMessages([GREETING, ...(rows ?? []).map((r) => ({ role: r.role as "user" | "assistant", content: r.content }))]);
    setFeedback({});
    setView("chat");
  }

  function newConversation() {
    setConversationId(null);
    setMessages([GREETING]);
    setInput("");
    setFeedback({});
    setIntake({ topic: "", urgency: "normal", account_email: "", related_url: "", details: "" });
    setIntakeCompleted(false);
    setView("intake");
  }

  async function deleteConversation(id: string) {
    const prev = conversations;
    setConversations((c) => c.filter((x) => x.id !== id));
    const { error } = await supabase.from("support_conversations").delete().eq("id", id);
    if (error) {
      setConversations(prev);
      toast.error("Could not delete conversation.");
      return;
    }
    if (conversationId === id) {
      setConversationId(null);
      setMessages([GREETING]);
    }
  }

  async function ensureConversation(firstUserText: string): Promise<string | null> {
    if (!userId) return null;
    if (conversationId) return conversationId;
    const { data, error } = await supabase
      .from("support_conversations")
      .insert({ user_id: userId, title: titleFromText(firstUserText) })
      .select("id")
      .single();
    if (error || !data) return null;
    setConversationId(data.id);
    return data.id;
  }

  async function persistMessage(convId: string, role: "user" | "assistant", content: string) {
    if (!userId) return;
    await supabase.from("support_messages").insert({ conversation_id: convId, user_id: userId, role, content });
    await supabase.from("support_conversations").update({ updated_at: new Date().toISOString() }).eq("id", convId);
  }

  function findPrecedingQuestion(index: number): string | null {
    for (let i = index - 1; i >= 0; i--) {
      if (messages[i]?.role === "user") return messages[i].content;
    }
    return null;
  }

  async function rateAnswer(index: number, rating: "up" | "down") {
    // If already submitted, ignore. If toggling to same rating, no-op.
    const current = feedback[index];
    if (current?.submitted) return;
    setFeedback((f) => ({
      ...f,
      [index]: {
        rating,
        submitted: false,
        showForm: true,
        reason: rating === "down" ? (f[index]?.reason ?? "inaccurate") : undefined,
        comment: f[index]?.comment ?? "",
      },
    }));
  }

  async function submitFeedback(index: number, opts?: { skipComment?: boolean }) {
    const fb = feedback[index];
    if (!fb || fb.submitted) return;
    const msg = messages[index];
    if (!msg || msg.role !== "assistant") return;
    const question = findPrecedingQuestion(index);
    const topic = classifyTopic(question ?? msg.content);
    const isReport = !!fb.isReport;
    const payload = {
      session_id: getSupportSessionId(),
      user_id: userId,
      conversation_id: conversationId,
      message_index: index,
      message_excerpt: msg.content.slice(0, 800),
      user_question: question ? question.slice(0, 500) : null,
      topic,
      rating: fb.rating,
      reason: opts?.skipComment ? null : (fb.reason ?? null),
      comment: opts?.skipComment ? null : (fb.comment.trim().slice(0, 2000) || null),
      is_report: isReport,
      report_explanation: isReport ? (fb.reportExplanation?.trim().slice(0, 2000) || null) : null,
    };
    setFeedback((f) => ({ ...f, [index]: { ...fb, submitted: true, showForm: false } }));
    try {
      const { error } = await supabase.from("support_message_feedback").insert(payload);
      if (error) throw error;
      void logSupportEvent({
        event_type: "feedback_submitted",
        topic,
        meta: { rating: fb.rating, has_comment: !!payload.comment, reason: payload.reason, is_report: isReport },
      });
      toast.success(isReport ? "Report submitted. Thanks — we'll review." : "Thanks for the feedback!");

      // Auto-escalation: repeated negative feedback OR critical reasons → suggest human follow-up.
      if (fb.rating === "down") {
        const criticalReasons = new Set(["inaccurate", "off_topic"]);
        const downVoteCount = Object.values({ ...feedback, [index]: { ...fb, submitted: true } }).filter(x => x.rating === "down" && x.submitted).length;
        if (isReport || criticalReasons.has(fb.reason ?? "") || downVoteCount >= 2) {
          setTimeout(() => {
            toast("Answer not helping?", {
              description: "We can loop in a human — reply usually within 24h.",
              action: { label: "Get email follow-up", onClick: () => startEmailFollowUp("inline") },
              duration: 8000,
            });
          }, 400);
        }
      }
    } catch {
      setFeedback((f) => ({ ...f, [index]: { ...fb, submitted: false, showForm: true } }));
      toast.error("Could not submit feedback. Try again.");
    }
  }


  useEffect(() => {
    if (!open || view !== "ticket") return;
    (async () => {
      const { data } = await supabase.auth.getUser();
      const u = data.user;
      if (u) {
        setTicket((t) => ({
          ...t,
          name: t.name || (u.user_metadata?.display_name as string) || (u.user_metadata?.full_name as string) || "",
          email: t.email || u.email || "",
          message: t.message || summarizeTranscript(messages),
        }));
      } else {
        setTicket((t) => ({ ...t, message: t.message || summarizeTranscript(messages) }));
      }
    })();
  }, [open, view, messages]);

  async function submitTicket(e: React.FormEvent) {
    e.preventDefault();
    if (submittingTicket) return;
    const name = ticket.name.trim();
    const email = ticket.email.trim();
    const subject = ticket.subject.trim();
    const message = ticket.message.trim();
    if (!name || name.length > 120) return toast.error("Please enter your name.");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return toast.error("Please enter a valid email.");
    if (subject.length < 3) return toast.error("Subject must be at least 3 characters.");
    if (message.length < 5) return toast.error("Please describe your issue (5+ characters).");
    if (ticketFile && ticketFile.size > 10 * 1024 * 1024) return toast.error("Attachment must be under 10 MB.");
    if (ticketFile) {
      const allowed = /^(image\/(png|jpeg|jpg|gif|webp)|application\/pdf|text\/plain|text\/csv|application\/json|application\/zip|application\/x-zip-compressed)$/i;
      if (ticketFile.type && !allowed.test(ticketFile.type)) return toast.error("Unsupported attachment type.");
    }
    // Anti-spam: max 3 tickets per hour for signed-in users.
    if (userId) {
      try {
        const rl = await checkTicketLimit({});
        if (rl.remaining <= 0) {
          return toast.error(`You've submitted ${rl.limit} tickets in the last hour. Please wait before submitting another.`);
        }
      } catch { /* non-fatal */ }
    }
    setSubmittingTicket(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      let attachment_path: string | null = null;
      let attachment_name: string | null = null;
      let attachment_size: number | null = null;
      let attachment_mime: string | null = null;
      if (ticketFile) {
        const safeName = ticketFile.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
        const folder = userData.user?.id ?? "anon";
        const key = `${folder}/${crypto.randomUUID()}-${safeName}`;
        const up = await supabase.storage.from("support-attachments").upload(key, ticketFile, {
          contentType: ticketFile.type || "application/octet-stream",
          upsert: false,
        });
        if (up.error) throw new Error(`Attachment upload failed: ${up.error.message}`);
        attachment_path = up.data.path;
        attachment_name = ticketFile.name;
        attachment_size = ticketFile.size;
        attachment_mime = ticketFile.type || null;
      }
      const { data: inserted, error } = await supabase.from("support_tickets").insert({
        user_id: userData.user?.id ?? null,
        name,
        email,
        subject,
        message,
        priority: ticket.priority,
        transcript: messages as unknown as never,
        source: ticketSource,
        attachment_path,
        attachment_name,
        attachment_size,
        attachment_mime,
      }).select("id").single();
      if (error) throw error;
      setView("ticket_success");
      void logSupportEvent({
        event_type: ticketSource === "email_follow_up" ? "follow_up_requested" : "ticket_submitted",
        topic: classifyTopic(subject + " " + message),
        message: subject,
        meta: { has_transcript: messages.length > 1, source: ticketSource, priority: ticket.priority, has_attachment: !!attachment_path },
      });
      // Non-fatal Slack alert (only sends if SLACK_TICKET_WEBHOOK_URL is configured).
      const transcriptText = messages.map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`).join("\n");
      void sendSlackAlert({ data: {
        ticketId: inserted?.id ?? "unknown",
        subject, name, email,
        priority: ticket.priority,
        source: ticketSource,
        message,
        transcript: transcriptText,
        hasAttachment: !!attachment_path,
      } }).catch(() => {});
      toast.success(ticketSource === "email_follow_up" ? "Follow-up requested. We'll email you soon." : "Support ticket submitted. We'll email you soon.");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Could not submit ticket.";
      toast.error(msg);
    } finally {
      setSubmittingTicket(false);
    }
  }

  function startEmailFollowUp(from: "inline" | "footer" = "inline") {
    const firstUser = messages.find((m) => m.role === "user");
    const subject = firstUser ? `Follow-up: ${titleFromText(firstUser.content)}` : "Follow-up on my support chat";
    setTicket((t) => ({
      ...t,
      subject: t.subject || subject,
      message: t.message || summarizeTranscript(messages),
    }));
    setTicketSource("email_follow_up");
    void logSupportEvent({ event_type: "escalation_started", meta: { from, mode: "email_follow_up" } });
    setView("ticket");
  }

  function submitIntake(e: React.FormEvent) {
    e.preventDefault();
    const details = intake.details.trim();
    if (details.length < 3) {
      toast.error("Please share a short description of your question.");
      return;
    }
    const topic = classifyTopic(`${intake.topic} ${details}`);
    const urgency = intake.urgency as Urgency;
    const flow = suggestedFlow(intake.topic || topic, urgency);
    // If the routing suggests a ticket (urgent/refund/verification/account/bug), jump to human form directly.
    if (flow === "ticket") {
      const subject = `[${urgency}] ${titleFromText(details)}`;
      setTicket((t) => ({ ...t, subject: t.subject || subject, message: t.message || details, priority: urgency === "urgent" ? "urgent" : urgency === "high" ? "high" : "normal" }));
      setTicketSource("support_chat");
      setIntakeCompleted(true);
      void logSupportEvent({ event_type: "intake_submitted", topic, meta: { urgency, routed: "ticket" } });
      setView("ticket");
      return;
    }
    const meta: string[] = [];
    if (intake.topic) meta.push(`Topic: ${intake.topic}`);
    meta.push(`Urgency: ${urgency}`);
    if (intake.account_email.trim()) meta.push(`Account: ${intake.account_email.trim()}`);
    if (intake.related_url.trim()) meta.push(`Related: ${intake.related_url.trim()}`);
    const composed = `${meta.join(" · ")}\n\n${details}`;
    setRoutingEta(estimatedResponse(intake.topic || topic, urgency));
    setReviewComposed(composed);
    setView("intake_review");
  }

  function confirmIntakeAndSend() {
    const composed = reviewComposed.trim();
    if (composed.length < 3) { toast.error("Message can't be empty."); return; }
    const topic = classifyTopic(composed);
    setIntakeCompleted(true);
    setView("chat");
    void logSupportEvent({
      event_type: "intake_submitted",
      topic,
      meta: { urgency: intake.urgency, has_account: !!intake.account_email.trim(), has_url: !!intake.related_url.trim(), routed: "chat", reviewed: true },
    });
    void send(composed, "intake");
  }

  function skipIntake() {
    setIntakeCompleted(true);
    setView("chat");
    void logSupportEvent({ event_type: "intake_skipped" });
    setTimeout(() => inputRef.current?.focus(), 0);
  }

  async function send(override?: string, source: "input" | "quick_reply" | "faq" | "intake" = "input") {
    const text = (override ?? input).trim();
    if (!text || loading) return;
    const topic = classifyTopic(text);
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);
    void logSupportEvent({
      event_type: source === "quick_reply" ? "quick_reply_clicked" : source === "faq" ? "faq_ask_ai" : "message_sent",
      topic,
      message: text,
      meta: { turn: next.filter((m) => m.role === "user").length },
    });

    // Persist user message (best-effort, signed-in only)
    const convId = await ensureConversation(text);
    if (convId) void persistMessage(convId, "user", text);

    try {
      const res = await fetch("/api/support-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next.filter((m, i) => !(i === 0 && m === GREETING)),
          session_id: getSupportSessionId(),
          topic,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        const errCode = res.status === 429 ? "rate_limited" : res.status === 402 ? "credits_exhausted" : "server_error";
        void logSupportEvent({ event_type: "chat_error", topic, error_code: errCode, status: res.status });
        setMessages((m) => [...m, { role: "assistant", content: data?.error ?? "Something went wrong." }]);
      } else {
        void logSupportEvent({
          event_type: "message_replied",
          topic,
          meta: { reply_len: (data.reply ?? "").length },
        });
        const reply = data.reply ?? "";
        setMessages((m) => [...m, { role: "assistant", content: reply }]);
        if (convId && reply) void persistMessage(convId, "assistant", reply);
      }
    } catch {
      void logSupportEvent({ event_type: "chat_error", topic, error_code: "network_error" });
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "Network error. Please try again in a moment." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function onKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <>
      <button
        type="button"
        aria-label={open ? "Close support chat" : "Open support chat"}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-5 right-5 z-[60] inline-flex h-14 w-14 items-center justify-center rounded-full bg-violet text-primary-foreground shadow-[0_20px_60px_-20px_oklch(0_0_0/0.6),0_0_60px_-10px_color-mix(in_oklab,var(--violet)_45%,transparent)] transition-all hover:bg-violet-glow hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
      >
        {open ? <X className="h-5 w-5" /> : <LifeBuoy className="h-5 w-5" />}
      </button>

      {open && (
        <div
          role="dialog"
          aria-label="HeySaaS support chat"
          className="fixed bottom-24 right-5 z-[60] flex w-[min(380px,calc(100vw-2.5rem))] h-[min(560px,calc(100vh-8rem))] flex-col overflow-hidden rounded-2xl border border-hairline bg-surface shadow-2xl animate-fade-up"
        >
          <div className="flex items-center gap-2 border-b border-hairline p-4">
            {(view === "ticket" || view === "ticket_success" || view === "history") && (
              <button
                type="button"
                onClick={() => { setView("chat"); setTicketSource("support_chat"); }}
                aria-label="Back to chat"
                className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted/40 hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
            )}
            <div className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-violet to-violet-glow">
              <LifeBuoy className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium truncate">
                {view === "chat" ? "Support assistant"
                  : view === "intake" ? "Quick intake"
                  : view === "intake_review" ? "Review your message"
                  : view === "ticket" ? (ticketSource === "email_follow_up" ? "Request email follow-up" : "Contact human support")
                  : view === "ticket_success" ? (ticketSource === "email_follow_up" ? "Follow-up requested" : "Ticket submitted")
                  : "Your conversations"}
              </div>
              <div className="text-[11px] text-muted-foreground flex items-center gap-1">
                {view === "chat" ? (
                  routingEta ? (<><Clock className="h-3 w-3"/> {routingEta}</>) : "Usually replies in seconds · AI-powered"
                ) : view === "intake" ? "Helps us route your question faster"
                  : view === "intake_review" ? "Edit or send when it looks right"
                  : view === "history" ? `${conversations.length} saved`
                  : "We reply by email, usually within 24h"}
              </div>
            </div>
            {view === "chat" && (
              <>
                {userId && (
                  <>
                    <button
                      type="button"
                      onClick={openHistory}
                      title="Conversation history"
                      aria-label="Conversation history"
                      className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                    >
                      <History className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={newConversation}
                      title="New conversation"
                      aria-label="New conversation"
                      className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                    >
                      <MessageSquarePlus className="h-4 w-4" />
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={() => setShowFeedbackHistory((v) => !v)}
                  title="My feedback in this chat"
                  aria-label="My feedback in this chat"
                  className={`inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-muted/40 ${showFeedbackHistory ? "text-violet" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <ClipboardList className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => { void logSupportEvent({ event_type: "escalation_started", meta: { from: "header" } }); setView("ticket"); }}
                  className="inline-flex items-center gap-1 rounded-md border border-hairline bg-background px-2 py-1 text-[11px] font-medium text-foreground hover:border-violet/60 hover:bg-violet/10"
                >
                  <UserRound className="h-3 w-3" /> Human
                </button>
              </>
            )}
          </div>

          {view === "history" && (
            <div className="flex-1 overflow-y-auto p-3">
              {loadingHistory ? (
                <div className="flex items-center justify-center py-8 text-xs text-muted-foreground">
                  <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> Loading…
                </div>
              ) : conversations.length === 0 ? (
                <div className="py-8 text-center text-xs text-muted-foreground">
                  No saved conversations yet.
                </div>
              ) : (
                <ul className="space-y-1">
                  {conversations.map((c) => (
                    <li key={c.id} className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => selectConversation(c.id)}
                        className="flex-1 min-w-0 rounded-md border border-hairline bg-background px-3 py-2 text-left hover:border-violet/60 hover:bg-violet/10"
                      >
                        <div className="truncate text-xs font-medium text-foreground">{c.title}</div>
                        <div className="text-[10px] text-muted-foreground">{new Date(c.updated_at).toLocaleString()}</div>
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteConversation(c.id)}
                        aria-label="Delete conversation"
                        className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {view === "chat" && (
            <>
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
                {!userId && (
                  <div className="rounded-md border border-hairline bg-background/60 px-3 py-2 text-[11px] text-muted-foreground">
                    Sign in to save your chat history across devices.
                  </div>
                )}
                {showFeedbackHistory && (
                  <div className="rounded-lg border border-hairline bg-background/60 p-3">
                    <div className="mb-2 flex items-center justify-between">
                      <div className="text-xs font-semibold text-foreground">Your feedback in this chat</div>
                      <button type="button" onClick={() => setShowFeedbackHistory(false)} className="text-[11px] text-muted-foreground hover:text-foreground">Close</button>
                    </div>
                    {(() => {
                      const items = Object.entries(feedback).filter(([, v]) => v.submitted);
                      if (items.length === 0) return <div className="text-[11px] text-muted-foreground">No feedback submitted yet. Use 👍 / 👎 on any answer.</div>;
                      return (
                        <ul className="space-y-2">
                          {items.map(([idx, v]) => {
                            const i = Number(idx);
                            const excerpt = messages[i]?.content.slice(0, 100) ?? "";
                            return (
                              <li key={idx} className="rounded-md border border-hairline bg-background px-2.5 py-2 text-[11px]">
                                <div className="flex items-center gap-1.5">
                                  {v.rating === "up" ? <ThumbsUp className="h-3 w-3 text-emerald-500"/> : <ThumbsDown className="h-3 w-3 text-destructive"/>}
                                  {v.reason && <span className="rounded-full border border-hairline px-1.5 py-0.5 text-[10px] text-muted-foreground">{v.reason}</span>}
                                  {v.isReport && <span className="rounded-full border border-rose-500/40 bg-rose-500/10 px-1.5 py-0.5 text-[10px] text-rose-400 inline-flex items-center gap-1"><Flag className="h-2.5 w-2.5"/>reported</span>}
                                </div>
                                <div className="mt-1 text-muted-foreground truncate">on: "{excerpt}{excerpt.length >= 100 ? "…" : ""}"</div>
                                {v.comment && <div className="mt-1 text-foreground">"{v.comment}"</div>}
                              </li>
                            );
                          })}
                        </ul>
                      );
                    })()}
                  </div>
                )}
                {messages.map((m, i) => {
                  const isAssistant = m.role === "assistant";
                  const showFeedback = isAssistant && i > 0 && messages.slice(0, i).some((x) => x.role === "user");
                  const fb = feedback[i];
                  const isLast = i === messages.length - 1;
                  const showLoadingForThis = loading && isLast;
                  return (
                    <div key={i} className={m.role === "user" ? "flex justify-end" : "flex flex-col items-start"}>
                      {m.role === "user" ? (
                        <div className="max-w-[85%] rounded-2xl rounded-br-md bg-primary px-3.5 py-2 text-sm text-primary-foreground">
                          {m.content}
                        </div>
                      ) : (
                        <>
                          <div className="max-w-[90%] text-sm text-foreground leading-relaxed prose prose-sm prose-invert prose-p:my-1 prose-ul:my-1 prose-ol:my-1 prose-headings:my-2">
                            <ReactMarkdown>{m.content}</ReactMarkdown>
                          </div>
                          {showFeedback && !showLoadingForThis && (
                            <div className="mt-1.5 w-full max-w-[90%]">
                              {fb?.submitted ? (
                                <div className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                                  <Check className="h-3 w-3 text-violet" /> Thanks for the feedback
                                </div>
                              ) : (
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => rateAnswer(i, "up")}
                                    aria-label="Helpful"
                                    title="Helpful"
                                    className={`inline-flex h-6 w-6 items-center justify-center rounded-md border transition-colors ${
                                      fb?.rating === "up"
                                        ? "border-violet/60 bg-violet/15 text-violet"
                                        : "border-hairline bg-background text-muted-foreground hover:border-violet/40 hover:text-foreground"
                                    }`}
                                  >
                                    <ThumbsUp className="h-3 w-3" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => rateAnswer(i, "down")}
                                    aria-label="Not helpful"
                                    title="Not helpful"
                                    className={`inline-flex h-6 w-6 items-center justify-center rounded-md border transition-colors ${
                                      fb?.rating === "down"
                                        ? "border-destructive/60 bg-destructive/10 text-destructive"
                                        : "border-hairline bg-background text-muted-foreground hover:border-destructive/40 hover:text-foreground"
                                    }`}
                                  >
                                    <ThumbsDown className="h-3 w-3" />
                                  </button>
                                  {!fb && (
                                    <span className="ml-1 text-[10px] text-muted-foreground">Was this helpful?</span>
                                  )}
                                </div>
                              )}

                              {fb?.showForm && !fb.submitted && (
                                <div className="mt-2 space-y-2 rounded-lg border border-hairline bg-background/60 p-2.5">
                                  {fb.rating === "down" && (
                                    <div className="flex flex-wrap gap-1">
                                      {[
                                        { v: "inaccurate", l: "Inaccurate" },
                                        { v: "unclear", l: "Unclear" },
                                        { v: "incomplete", l: "Incomplete" },
                                        { v: "off_topic", l: "Off topic" },
                                        { v: "other", l: "Other" },
                                      ].map((r) => (
                                        <button
                                          key={r.v}
                                          type="button"
                                          onClick={() => setFeedback((f) => ({ ...f, [i]: { ...f[i], reason: r.v } }))}
                                          className={`rounded-full border px-2 py-0.5 text-[10px] transition-colors ${
                                            fb.reason === r.v
                                              ? "border-violet/60 bg-violet/15 text-foreground"
                                              : "border-hairline bg-background text-muted-foreground hover:border-violet/40 hover:text-foreground"
                                          }`}
                                        >
                                          {r.l}
                                        </button>
                                      ))}
                                    </div>
                                  )}
                                  <textarea
                                    value={fb.comment}
                                    onChange={(e) => setFeedback((f) => ({ ...f, [i]: { ...f[i], comment: e.target.value.slice(0, 2000) } }))}
                                    rows={2}
                                    maxLength={2000}
                                    placeholder={fb.rating === "up" ? "What worked well? (optional)" : "How could this answer be better? (optional)"}
                                    className="w-full resize-none rounded-md border border-hairline bg-background px-2 py-1.5 text-xs text-foreground placeholder:text-muted-foreground focus:border-violet/60 focus:outline-none"
                                  />
                                  {fb.rating === "down" && (fb.reason === "inaccurate" || fb.reason === "other") && (
                                    <div className="space-y-1.5 rounded-md border border-rose-500/30 bg-rose-500/5 p-2">
                                      <label className="flex items-center gap-1.5 text-[11px] font-medium text-rose-400 cursor-pointer">
                                        <input
                                          type="checkbox"
                                          checked={!!fb.isReport}
                                          onChange={(e) => setFeedback((f) => ({ ...f, [i]: { ...f[i], isReport: e.target.checked } }))}
                                        />
                                        <Flag className="h-3 w-3" /> Report this answer as incorrect or harmful
                                      </label>
                                      {fb.isReport && (
                                        <textarea
                                          value={fb.reportExplanation ?? ""}
                                          onChange={(e) => setFeedback((f) => ({ ...f, [i]: { ...f[i], reportExplanation: e.target.value.slice(0, 2000) } }))}
                                          rows={2}
                                          placeholder="Briefly explain why this is incorrect or harmful (required for a useful report)…"
                                          className="w-full resize-none rounded-md border border-rose-500/30 bg-background px-2 py-1.5 text-[11px]"
                                        />
                                      )}
                                    </div>
                                  )}
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() => submitFeedback(i, { skipComment: true })}
                                      className="rounded-md px-2 py-1 text-[11px] font-medium text-muted-foreground hover:text-foreground"
                                    >
                                      Skip
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => submitFeedback(i)}
                                      className="inline-flex items-center gap-1 rounded-md bg-violet px-2.5 py-1 text-[11px] font-medium text-primary-foreground hover:bg-violet-glow"
                                    >
                                      <Send className="h-3 w-3" /> Send feedback
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  );
                })}
                {loading && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Thinking…
                  </div>
                )}

                {!loading && messages.length > 1 && messages[messages.length - 1].role === "assistant" && messages.some((m) => m.role === "user") && (
                  <div className="flex flex-wrap items-center gap-2 rounded-lg border border-dashed border-hairline bg-background/40 px-3 py-2">
                    <span className="text-[11px] text-muted-foreground">Didn't solve it?</span>
                    <button
                      type="button"
                      onClick={() => startEmailFollowUp("inline")}
                      className="inline-flex items-center gap-1 rounded-full border border-hairline bg-background px-2.5 py-1 text-[11px] font-medium text-foreground hover:border-violet/60 hover:bg-violet/10"
                    >
                      <Mail className="h-3 w-3" /> Get email follow-up
                    </button>
                  </div>
                )}

                {messages.length === 1 && !loading && (
                  <div className="space-y-4 pt-1">
                    <div>
                      <div className="mb-2 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                        <Sparkles className="h-3 w-3" /> Quick questions
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {QUICK_REPLIES.map((q) => (
                          <button
                            key={q}
                            type="button"
                            onClick={() => send(q, "quick_reply")}
                            className="rounded-full border border-hairline bg-background px-2.5 py-1 text-xs text-foreground/90 transition-colors hover:border-violet/60 hover:bg-violet/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          >
                            {q}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="mb-2 text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Browse FAQs</div>
                      <div className="divide-y divide-hairline overflow-hidden rounded-lg border border-hairline bg-background">
                        {FAQS.map((f, i) => (
                          <details
                            key={i}
                            className="group"
                            onToggle={(e) => {
                              if ((e.target as HTMLDetailsElement).open) {
                                void logSupportEvent({ event_type: "faq_opened", topic: classifyTopic(f.q), message: f.q });
                              }
                            }}
                          >
                            <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-3 py-2 text-xs font-medium text-foreground hover:bg-muted/40">
                              <span className="min-w-0 truncate">{f.q}</span>
                              <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform group-open:rotate-180" />
                            </summary>
                            <div className="space-y-2 border-t border-hairline px-3 py-2 text-xs text-muted-foreground">
                              <p>{f.a}</p>
                              <button
                                type="button"
                                onClick={() => send(f.q, "faq")}
                                className="text-[11px] font-medium text-violet hover:underline"
                              >
                                Ask the assistant →
                              </button>
                            </div>
                          </details>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  send();
                }}
                className="border-t border-hairline p-3"
              >
                <div className="flex items-end gap-2 rounded-xl border border-hairline bg-background px-3 py-2 focus-within:border-violet/60">
                  <textarea
                    ref={inputRef}
                    rows={1}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={onKey}
                    placeholder="Ask about swaps, fees, listings…"
                    className="min-h-[24px] max-h-32 flex-1 resize-none bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={!input.trim() || loading}
                    aria-label="Send message"
                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-violet text-primary-foreground transition-colors hover:bg-violet-glow disabled:opacity-40"
                  >
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => { setTicketSource("support_chat"); void logSupportEvent({ event_type: "escalation_started", meta: { from: "footer" } }); setView("ticket"); }}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-violet hover:underline"
                    >
                      <UserRound className="h-3 w-3" /> Talk to a human
                    </button>
                    <button
                      type="button"
                      onClick={() => startEmailFollowUp("footer")}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-violet hover:underline"
                    >
                      <Mail className="h-3 w-3" /> Email follow-up
                    </button>
                  </div>
                  <p className="text-[10px] text-muted-foreground">AI answers can be wrong.</p>
                </div>
              </form>
            </>
          )}

          {view === "intake" && (
            <form onSubmit={submitIntake} className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="flex items-start gap-2 rounded-lg border border-hairline bg-background/60 p-3">
                <div className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-violet/15 text-violet">
                  <ClipboardList className="h-4 w-4" />
                </div>
                <div className="text-xs text-muted-foreground">
                  A few quick details help us route your question and get you a faster, more accurate answer.
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="intake-topic" className="text-[11px] font-medium text-muted-foreground">Topic</label>
                <select
                  id="intake-topic"
                  value={intake.topic}
                  onChange={(e) => setIntake({ ...intake, topic: e.target.value })}
                  className="w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                >
                  <option value="">Choose a topic…</option>
                  <option value="swaps">Swaps &amp; matching</option>
                  <option value="safety_fee">Safety fee ($19)</option>
                  <option value="listing">Listing my SaaS / site</option>
                  <option value="verification">Verification (identity / domain)</option>
                  <option value="payments">Payments / invoices</option>
                  <option value="messaging">Messages &amp; inbox</option>
                  <option value="webswap">WebSwap (websites)</option>
                  <option value="account">Account / GDPR</option>
                  <option value="bug_report">Bug report</option>
                  <option value="other">Something else</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-muted-foreground">Urgency</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["low", "normal", "high"] as const).map((u) => (
                    <button
                      key={u}
                      type="button"
                      onClick={() => setIntake({ ...intake, urgency: u })}
                      className={`rounded-md border px-2 py-1.5 text-xs font-medium transition-colors ${
                        intake.urgency === u
                          ? "border-violet/60 bg-violet/15 text-foreground"
                          : "border-hairline bg-background text-muted-foreground hover:border-violet/40 hover:text-foreground"
                      }`}
                    >
                      {u === "high" ? "Blocking me" : u === "normal" ? "Normal" : "Whenever"}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="intake-account" className="text-[11px] font-medium text-muted-foreground">Account email (optional)</label>
                <input
                  id="intake-account"
                  type="email"
                  maxLength={255}
                  value={intake.account_email}
                  onChange={(e) => setIntake({ ...intake, account_email: e.target.value })}
                  placeholder="you@example.com"
                  className="w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label htmlFor="intake-url" className="text-[11px] font-medium text-muted-foreground">Related listing or link (optional)</label>
                <input
                  id="intake-url"
                  type="text"
                  maxLength={500}
                  value={intake.related_url}
                  onChange={(e) => setIntake({ ...intake, related_url: e.target.value })}
                  placeholder="Listing URL, swap ID, or invoice #"
                  className="w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label htmlFor="intake-details" className="text-[11px] font-medium text-muted-foreground">What do you need help with?</label>
                <textarea
                  id="intake-details"
                  required
                  minLength={3}
                  maxLength={2000}
                  rows={4}
                  value={intake.details}
                  onChange={(e) => setIntake({ ...intake, details: e.target.value })}
                  placeholder="Briefly describe your question or issue…"
                  className="w-full resize-y rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between gap-2 pt-1">
                <button
                  type="button"
                  onClick={skipIntake}
                  className="text-[11px] font-medium text-muted-foreground hover:text-foreground hover:underline"
                >
                  Skip and just chat →
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 rounded-lg bg-violet px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-violet-glow"
                >
                  Review →
                </button>
              </div>
            </form>
          )}

          {view === "intake_review" && (
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="rounded-lg border border-hairline bg-background/60 p-3 space-y-2">
                <div className="text-xs font-semibold text-foreground">Review your first message</div>
                <p className="text-[11px] text-muted-foreground">Edit anything below before sending. This is what the assistant will see first.</p>
                <div className="flex flex-wrap gap-1 text-[10px]">
                  {intake.topic && <span className="rounded-full border border-hairline bg-background px-2 py-0.5 text-muted-foreground">Topic: {intake.topic}</span>}
                  <span className="rounded-full border border-hairline bg-background px-2 py-0.5 text-muted-foreground">Urgency: {intake.urgency}</span>
                  {routingEta && <span className="inline-flex items-center gap-1 rounded-full border border-violet/40 bg-violet/10 px-2 py-0.5 text-violet"><Clock className="h-2.5 w-2.5"/>{routingEta}</span>}
                </div>
                <textarea
                  value={reviewComposed}
                  onChange={(e) => setReviewComposed(e.target.value.slice(0, 4000))}
                  rows={8}
                  className="w-full resize-y rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
                <div className="text-[10px] text-muted-foreground text-right">{reviewComposed.length}/4000</div>
              </div>
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setView("intake")}
                  className="inline-flex items-center gap-1 rounded-md border border-hairline bg-background px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground"
                >
                  <ArrowLeft className="h-3 w-3"/> Edit details
                </button>
                <button
                  type="button"
                  onClick={confirmIntakeAndSend}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-violet px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-violet-glow"
                >
                  <Send className="h-3.5 w-3.5" /> Send
                </button>
              </div>
            </div>
          )}

          {view === "ticket" && (
            <form onSubmit={submitTicket} className="flex-1 overflow-y-auto p-4 space-y-3">
              <p className="text-xs text-muted-foreground">
                {ticketSource === "email_follow_up"
                  ? "Leave your email and we'll follow up once a teammate can look into this. Your chat is attached for context."
                  : "Send a ticket to our human support team. We'll include your chat transcript for context and reply by email."}
              </p>
              <div className="space-y-1">
                <label htmlFor="ticket-name" className="text-[11px] font-medium text-muted-foreground">Your name</label>
                <input
                  id="ticket-name"
                  type="text"
                  required
                  maxLength={120}
                  value={ticket.name}
                  onChange={(e) => setTicket({ ...ticket, name: e.target.value })}
                  className="w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label htmlFor="ticket-email" className="text-[11px] font-medium text-muted-foreground">Email</label>
                <input
                  id="ticket-email"
                  type="email"
                  required
                  maxLength={255}
                  value={ticket.email}
                  onChange={(e) => setTicket({ ...ticket, email: e.target.value })}
                  className="w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label htmlFor="ticket-subject" className="text-[11px] font-medium text-muted-foreground">Subject</label>
                <input
                  id="ticket-subject"
                  type="text"
                  required
                  minLength={3}
                  maxLength={200}
                  value={ticket.subject}
                  onChange={(e) => setTicket({ ...ticket, subject: e.target.value })}
                  placeholder="e.g. Refund on swap #1234"
                  className="w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
              </div>
              <div className="space-y-1">
                <label htmlFor="ticket-message" className="text-[11px] font-medium text-muted-foreground">Describe your issue</label>
                <textarea
                  id="ticket-message"
                  required
                  minLength={5}
                  maxLength={4000}
                  rows={5}
                  value={ticket.message}
                  onChange={(e) => setTicket({ ...ticket, message: e.target.value })}
                  className="w-full resize-y rounded-md border border-hairline bg-background px-3 py-2 text-sm text-foreground focus:border-violet/60 focus:outline-none"
                />
                <p className="text-[10px] text-muted-foreground">Your chat transcript ({messages.length - 1} message{messages.length - 1 === 1 ? "" : "s"}) will be attached.</p>
              </div>
              <div className="space-y-1">
                <label htmlFor="ticket-priority" className="text-[11px] font-medium text-muted-foreground">Priority</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(["low", "normal", "high", "urgent"] as const).map((p) => {
                    const active = ticket.priority === p;
                    const tone =
                      p === "urgent" ? "border-red-500/60 bg-red-500/10 text-red-400"
                      : p === "high" ? "border-orange-500/60 bg-orange-500/10 text-orange-400"
                      : p === "low" ? "border-hairline bg-background text-muted-foreground"
                      : "border-violet/60 bg-violet/10 text-violet";
                    return (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setTicket({ ...ticket, priority: p })}
                        className={`inline-flex items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-medium capitalize transition-colors ${active ? tone : "border-hairline bg-background text-muted-foreground hover:border-violet/40"}`}
                        aria-pressed={active}
                      >
                        {p === "urgent" && <AlertTriangle className="h-3 w-3" />}
                        {p}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[10px] text-muted-foreground">Urgent tickets alert on-call admins immediately.</p>
              </div>
              <div className="space-y-1">
                <label htmlFor="ticket-file" className="text-[11px] font-medium text-muted-foreground">Attachment (optional)</label>
                <div className="flex items-center gap-2">
                  <label
                    htmlFor="ticket-file"
                    className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-hairline bg-background px-3 py-1.5 text-xs font-medium text-foreground hover:border-violet/60 hover:bg-violet/10"
                  >
                    <Paperclip className="h-3.5 w-3.5" />
                    {ticketFile ? "Change file" : "Add file"}
                  </label>
                  <input
                    id="ticket-file"
                    type="file"
                    accept="image/*,application/pdf,.txt,.log,.csv,.json,.zip"
                    className="sr-only"
                    onChange={(e) => {
                      const f = e.target.files?.[0] ?? null;
                      if (f && f.size > 10 * 1024 * 1024) {
                        toast.error("Attachment must be under 10 MB.");
                        e.target.value = "";
                        return;
                      }
                      setTicketFile(f);
                    }}
                  />
                  {ticketFile && (
                    <div className="flex min-w-0 flex-1 items-center gap-1 text-[11px] text-muted-foreground">
                      <span className="truncate text-foreground">{ticketFile.name}</span>
                      <span className="shrink-0">({(ticketFile.size / 1024).toFixed(0)} KB)</span>
                      <button
                        type="button"
                        onClick={() => setTicketFile(null)}
                        className="ml-auto rounded p-0.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                        aria-label="Remove attachment"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground">Screenshots, PDFs, logs, or zips up to 10 MB.</p>
              </div>
              <button
                type="submit"
                disabled={submittingTicket}
                className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-violet px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-violet-glow disabled:opacity-50"
              >
                {submittingTicket ? <Loader2 className="h-4 w-4 animate-spin" /> : ticketSource === "email_follow_up" ? <Mail className="h-4 w-4" /> : <UserRound className="h-4 w-4" />}
                {ticketSource === "email_follow_up" ? "Request email follow-up" : "Submit ticket"}
              </button>
            </form>
          )}

          {view === "ticket_success" && (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-center">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-violet/15 text-violet">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div className="text-sm font-medium text-foreground">
                {ticketSource === "email_follow_up" ? "Follow-up requested" : "Ticket submitted"}
              </div>
              <p className="text-xs text-muted-foreground">
                Thanks — we'll email <span className="text-foreground">{ticket.email}</span> {ticketSource === "email_follow_up" ? "as soon as a teammate picks this up." : "within 24 hours."}
              </p>
              <button
                type="button"
                onClick={() => {
                  setView("chat");
                  setTicket({ name: "", email: "", subject: "", message: "", priority: "normal" });
                  setTicketFile(null);
                  setTicketSource("support_chat");
                }}
                className="mt-2 rounded-md border border-hairline bg-background px-3 py-1.5 text-xs font-medium text-foreground hover:border-violet/60 hover:bg-violet/10"
              >
                Back to chat
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
}
