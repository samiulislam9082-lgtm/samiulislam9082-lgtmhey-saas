import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Bell, ArrowUpRight, Search } from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { UserMenu } from "./UserMenu";

import heysaasLogo from "@/assets/heysaas-logo.png";


const nav = [
  { to: "/explore", label: "Explore" },
  { to: "/founders", label: "Founders" },
  { to: "/how-it-works", label: "How it works" },
  { to: "/leaderboard", label: "Leaderboard" },
  { to: "/pricing", label: "Pricing" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [unread, setUnread] = useState(0);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setUser(s?.user ?? null);
      setReady(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null);
      setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!user) { setUnread(0); return; }
    async function count() {
      const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).eq("user_id", user!.id).is("read_at", null);
      setUnread(count || 0);
    }
    count();
    const ch = supabase
      .channel(`notif:${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, () => count())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);


  return (
    <header className={`hs-header sticky top-0 z-50 w-full transition-all duration-500 ${scrolled ? "hs-header-scrolled" : ""}`}>

      <div className={`hs-header-main relative border-b border-hairline transition-all duration-500 ${scrolled ? "bg-background/85 backdrop-blur-xl" : "bg-background/50 backdrop-blur-md"}`}>
        {/* violet hairline glow */}
        <span aria-hidden="true" className="hs-header-hairline pointer-events-none absolute inset-x-0 bottom-0 h-px" />

        <div className={`mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8 transition-all duration-500 ${scrolled ? "h-14" : "h-[68px]"}`}>
          <Link to="/" className="group inline-flex items-center gap-2.5">
            <img
              src={heysaasLogo}
              alt="HeySaaS"
              className="h-9 w-9 rounded-full transition-transform group-hover:scale-105"
              style={{ boxShadow: "0 0 22px -4px color-mix(in oklab, var(--violet) 60%, transparent)" }}
            />
            <span className="text-2xl tracking-tight" style={{ fontFamily: "'Pacifico', cursive" }}>HeySaaS</span>
          </Link>

          <nav className="hidden md:flex items-center gap-1 rounded-full border border-hairline bg-surface/40 backdrop-blur-md p-1">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="hs-nav-link relative rounded-full px-4 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "hs-nav-active text-foreground bg-surface" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <Link
              to="/explore"
              aria-label="Search"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-hairline text-muted-foreground hover:text-foreground hover:border-violet/40 transition-colors"
            >
              <Search className="h-4 w-4" />
            </Link>
            
            {ready && user ? (
              <>
                <Link
                  to="/dashboard/notifications"
                  aria-label="Notifications"
                  className="relative inline-flex h-9 w-9 items-center justify-center rounded-full border border-hairline text-muted-foreground hover:text-foreground hover:border-violet/40 transition-colors"
                >
                  <Bell className="h-4 w-4" />
                  {unread > 0 && (
                    <span className="absolute -top-1 -right-1 inline-flex h-4 min-w-[16px] items-center justify-center rounded-full bg-violet px-1 text-[10px] font-semibold text-primary-foreground ring-2 ring-background">
                      {unread > 9 ? "9+" : unread}
                    </span>
                  )}
                </Link>
                <Link
                  to="/list"
                  className="hs-cta-btn group inline-flex items-center gap-1.5 rounded-full bg-violet px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors"
                  style={{ boxShadow: "var(--shadow-glow)" }}
                >
                  List your SaaS
                  <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </Link>

                <UserMenu user={user} />
              </>
            ) : (
              <>
                <Link
                  to="/auth"
                  className="rounded-full px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  Sign in
                </Link>
                <Link
                  to="/auth"
                  search={{ mode: "signup" }}
                  className="hs-cta-btn group inline-flex items-center gap-1.5 rounded-full bg-violet px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors"
                  style={{ boxShadow: "var(--shadow-glow)" }}
                >
                  Get started
                  <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                </Link>
              </>
            )}
          </div>

          <button
            className="md:hidden inline-flex h-11 w-11 items-center justify-center rounded-lg text-foreground hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {open && (
          <div className="md:hidden border-t border-hairline px-4 py-4 space-y-1 bg-background/95 backdrop-blur-xl">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="block rounded-lg px-4 py-3 text-base text-foreground hover:bg-secondary"
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-3 flex flex-col gap-2">
              {ready && user ? (
                <>
                  <Link
                    to="/dashboard"
                    onClick={() => setOpen(false)}
                    className="block rounded-full border border-border px-4 py-3 text-center text-sm text-foreground"
                  >
                    Dashboard
                  </Link>
                  <Link
                    to="/list"
                    onClick={() => setOpen(false)}
                    className="block rounded-full bg-violet px-4 py-3 text-center text-sm font-semibold text-primary-foreground"
                  >
                    List your SaaS
                  </Link>
                  <button
                    onClick={async () => {
                      await supabase.auth.signOut();
                      setOpen(false);
                    }}
                    className="block w-full rounded-full px-4 py-3 text-center text-sm text-muted-foreground"
                  >
                    Sign out
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/auth"
                    onClick={() => setOpen(false)}
                    className="block rounded-full border border-border px-4 py-3 text-center text-sm text-foreground"
                  >
                    Sign in
                  </Link>
                  <Link
                    to="/auth"
                    search={{ mode: "signup" }}
                    onClick={() => setOpen(false)}
                    className="block rounded-full bg-violet px-4 py-3 text-center text-sm font-semibold text-primary-foreground"
                  >
                    Get started
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
