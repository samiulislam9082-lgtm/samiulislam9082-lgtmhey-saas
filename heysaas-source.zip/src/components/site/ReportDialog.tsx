import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { createReport } from "@/lib/reports.functions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Flag } from "lucide-react";
import { toast } from "sonner";

const REASONS = ["Spam", "Misleading", "Broken/dead product", "Inappropriate content", "Harassment", "Scam", "Other"];

export function ReportDialog({ targetType, targetId, trigger }: { targetType: "listing" | "profile" | "message" | "swap"; targetId: string; trigger?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState(REASONS[0]);
  const [details, setDetails] = useState("");
  const [busy, setBusy] = useState(false);
  const report = useServerFn(createReport);
  async function submit() {
    setBusy(true);
    try {
      await report({ data: { target_type: targetType, target_id: targetId, reason, details: details || null } });
      toast.success("Report submitted");
      setOpen(false); setDetails("");
    } catch (e: any) { toast.error(e.message); }
    setBusy(false);
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger || <Button variant="ghost" size="sm"><Flag className="h-4 w-4 mr-1" />Report</Button>}</DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Report {targetType}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-2 block">Reason</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{REASONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="mb-2 block">Details (optional)</Label>
            <Textarea value={details} onChange={(e) => setDetails(e.target.value)} rows={4} />
          </div>
        </div>
        <DialogFooter><Button onClick={submit} disabled={busy}>Submit report</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
