import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Copy, Users, Gift, Share2, Twitter, Linkedin, Mail, Facebook,
  MessageCircle, Send, Music2, Instagram, Link as LinkIcon, Globe,
  Sparkles, Trophy, Ghost, Camera, Hash, Slack, PhoneCall, MessagesSquare,
} from "lucide-react";


export function ReferralsPanel() {
  const [userId, setUserId] = useState<string | null>(null);
  const [signedIn, setSignedIn] = useState(0);
  const [listed, setListed] = useState(0);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const { count: sc } = await supabase
        .from("profiles").select("id", { count: "exact", head: true })
        .eq("referred_by" as any, user.id);
      setSignedIn(sc ?? 0);
      const referred = (await supabase.from("profiles").select("id").eq("referred_by" as any, user.id)).data?.map((p: any) => p.id) ?? [];
      if (referred.length) {
        const { count: lc } = await supabase.from("saas_listings")
          .select("id", { count: "exact", head: true })
          .in("owner_id" as any, referred);
        setListed(lc ?? 0);
      }
    })();
  }, []);

  const link = useMemo(() => {
    const base = typeof window !== "undefined" ? window.location.origin : "https://heysaas.co";
    return userId ? `${base}/?ref=${userId}` : `${base}/`;
  }, [userId]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl">Refer founders, earn credits</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Every founder who signs up with your link earns you $25 in promotion credits.
          Every SaaS they list adds another $50.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Stat icon={Users} label="Founders signed up" value={signedIn} />
        <Stat icon={Gift} label="SaaS they listed" value={listed} />
        <Stat icon={Share2} label="Credits earned" value={`$${signedIn * 25 + listed * 50}`} />
      </div>

      {/* Milestone tracker: 5-signup bonus */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Trophy className="h-4 w-4 text-primary" />
            <div className="font-medium">Milestone bonus — 5 founders</div>
          </div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground">
            {Math.min(signedIn, 5)} / 5
          </div>
        </div>
        <div className="h-2 w-full rounded-full bg-surface overflow-hidden">
          <div
            className="h-full bg-primary transition-all"
            style={{ width: `${Math.min(signedIn, 5) * 20}%` }}
          />
        </div>
        <p className="text-sm text-muted-foreground mt-3">
          When any <span className="text-foreground font-medium">5 founders</span> open a Hey SaaS
          account through your referral link, you unlock a special bonus — and each of them gets
          a small welcome bonus too. Exact rewards will be announced shortly.
        </p>
        {signedIn >= 5 && (
          <div className="mt-3 flex items-center gap-2 text-sm text-primary">
            <Sparkles className="h-4 w-4" />
            Milestone unlocked — your bonus will be credited when we announce the reward.
          </div>
        )}
      </Card>

      <Card className="p-5">
        <div className="text-sm text-muted-foreground mb-2">Your unique referral link</div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Input readOnly value={link} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
          <Button onClick={() => { navigator.clipboard.writeText(link); toast.success("Referral link copied"); }}>
            <Copy className="h-4 w-4 mr-2" /> Copy
          </Button>
        </div>
      </Card>

      <Card className="p-5">
        <div className="font-medium mb-2">How rewards work</div>
        <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
          <li>Founder signs up via your link — you get <span className="text-primary font-medium">$25</span> in Hey SaaS credit.</li>
          <li>They publish their first SaaS listing — you get an extra <span className="text-primary font-medium">$50</span>.</li>
          <li>Hit <span className="text-primary font-medium">5 referred signups</span> and both you and each new founder unlock a bonus (announced soon).</li>
          <li>Credits apply automatically to promotions and safety fees at checkout.</li>
          <li>No cap. Refer as many founders as you like — payouts compound.</li>
        </ol>
      </Card>

    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: number | string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground mb-2">
        <Icon className="h-4 w-4 text-primary" /> {label}
      </div>
      <div className="text-3xl font-display italic">{value}</div>
    </Card>
  );
}

export function WebsiteSharePanel() {
  const base = typeof window !== "undefined" ? window.location.origin : "https://heysaas.co";
  const [link, setLink] = useState(base + "/");
  const [message, setMessage] = useState(
    "Just found Hey SaaS — the marketplace where founders swap SaaS instead of paying cash. You should check it out:"
  );

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) setLink(`${base}/?ref=${user.id}`);
    })();
  }, [base]);

  const text = encodeURIComponent(message);
  const url = encodeURIComponent(link);
  const combo = encodeURIComponent(`${message} ${link}`);

  const isMobile =
    typeof navigator !== "undefined" && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

  const channels: {
    name: string;
    href: string;
    slug: string;
    color: string;
    copyOnly?: boolean;
    note?: string;
  }[] = [
    { name: "X (Twitter)", href: `https://x.com/intent/post?text=${combo}`, slug: "x", color: "#000000" },
    { name: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${url}`, slug: "facebook", color: "#1877F2" },
    {
      name: "Messenger",
      href: isMobile
        ? `fb-messenger://share/?link=${url}`
        : `https://www.facebook.com/sharer/sharer.php?u=${url}`,
      slug: "messenger",
      color: "#0084FF",
      note: isMobile ? "Opens Messenger app" : "Desktop shares via Facebook",
    },
    { name: "LinkedIn", href: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`, slug: "linkedin", color: "#0A66C2" },
    {
      name: "WhatsApp",
      href: isMobile
        ? `whatsapp://send?text=${combo}`
        : `https://web.whatsapp.com/send?text=${combo}`,
      slug: "whatsapp",
      color: "#25D366",
    },
    { name: "Telegram", href: `https://t.me/share/url?url=${url}&text=${text}`, slug: "telegram", color: "#26A5E4" },
    { name: "Reddit", href: `https://www.reddit.com/submit?url=${url}&title=${text}`, slug: "reddit", color: "#FF4500" },
    { name: "Pinterest", href: `https://pinterest.com/pin/create/button/?url=${url}&description=${text}`, slug: "pinterest", color: "#E60023" },
    { name: "Threads", href: `https://www.threads.net/intent/post?text=${combo}`, slug: "threads", color: "#000000" },
    { name: "Discord", href: `https://discord.com/channels/@me`, slug: "discord", color: "#5865F2", copyOnly: true, note: "No share URL — message copied" },
    { name: "Slack", href: `https://app.slack.com/client`, slug: "slack", color: "#4A154B", copyOnly: true, note: "No share URL — message copied" },
    {
      name: "Snapchat",
      href: isMobile ? `snapchat://` : `https://www.snapchat.com/`,
      slug: "snapchat",
      color: "#FFFC00",
      copyOnly: true,
      note: "Message copied — paste into your snap",
    },
    {
      name: "Viber",
      href: `viber://forward?text=${combo}`,
      slug: "viber",
      color: "#7360F2",
      note: "Requires the Viber app",
    },
    { name: "Line", href: `https://social-plugins.line.me/lineit/share?url=${url}&text=${text}`, slug: "line", color: "#06C755" },
    { name: "Email", href: `mailto:?subject=${encodeURIComponent("Check out Hey SaaS")}&body=${combo}`, slug: "gmail", color: "#EA4335" },
    { name: "TikTok", href: `https://www.tiktok.com/`, slug: "tiktok", color: "#EE1D52", copyOnly: true, note: "Message copied — paste in your caption" },
    { name: "Instagram", href: `https://www.instagram.com/`, slug: "instagram", color: "#E4405F", copyOnly: true, note: "Message copied — paste in your bio or story" },
  ];


  async function safeCopy(txt: string) {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(txt);
        return true;
      }
    } catch { /* fall through */ }
    try {
      const ta = document.createElement("textarea");
      ta.value = txt;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      return true;
    } catch { return false; }
  }

  async function nativeShare() {
    if (typeof navigator !== "undefined" && (navigator as any).share) {
      try {
        await (navigator as any).share({ title: "Hey SaaS", text: message, url: link });
        return;
      } catch { /* user cancelled or failed — fall back */ }
    }
    const ok = await safeCopy(`${message} ${link}`);
    toast.success(ok ? "Message copied — paste it anywhere" : "Copy failed — long-press the link");
  }

  async function copyLink() {
    const ok = await safeCopy(link);
    toast.success(ok ? "Link copied" : "Copy failed");
  }

  async function copyChannelText(c: { name: string; copyOnly?: boolean; note?: string }) {
    const ok = await safeCopy(`${message} ${link}`);
    if (c.copyOnly) {
      toast.success(ok ? c.note || `Message copied — open ${c.name} and paste.` : "Copy failed");
      return;
    }
    toast.success(ok ? `Message copied · opening ${c.name}…` : `Opening ${c.name}…`);
  }



  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl">Share Hey SaaS with your network</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Post your link on any platform — X, Facebook, WhatsApp, TikTok, Instagram and more.
          Supported platforms open in a new browser tab so blocked in-frame pages do not appear.
        </p>
      </div>

      <Card className="p-5 space-y-4">
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-1.5">Your link</div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input readOnly value={link} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
            <Button variant="outline" onClick={copyLink} className="rounded-full">
              <LinkIcon className="h-4 w-4 mr-2" /> Copy link
            </Button>
            <Button onClick={nativeShare} className="rounded-full">
              <Share2 className="h-4 w-4 mr-2" /> Share
            </Button>
          </div>
        </div>

        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground mb-1.5">Message</div>
          <Textarea rows={3} value={message} onChange={(e) => setMessage(e.target.value)} />
          <p className="text-xs text-muted-foreground mt-1">Edit the wording — it prefills every share below.</p>
        </div>
      </Card>

      <div>
        <div className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Share to a platform</div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {channels.map((c) => {
            const content = (
              <>
              <span
                className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm ring-1 ring-black/5 shrink-0"
              >
                <img
                  src={`https://cdn.simpleicons.org/${c.slug}`}
                  alt=""
                  className="h-5 w-5"
                  loading="lazy"
                />
              </span>
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{c.name}</div>
                <div className="text-[11px] text-muted-foreground truncate">
                  {c.note || `Share to ${c.name}`}
                </div>

              </div>
              </>
            );

            const className = "group flex items-center gap-3 rounded-2xl border border-hairline bg-surface px-4 py-3 text-left transition hover:border-primary/50 hover:bg-surface/70";

            return c.copyOnly ? (
              <button key={c.name} type="button" onClick={() => copyChannelText(c)} className={className}>
                {content}
              </button>
            ) : (
              <a
                key={c.name}
                href={c.href}
                target="_blank"
                rel="noopener noreferrer external"
                referrerPolicy="origin"
                onClick={() => void copyChannelText(c)}
                className={className}
              >
                {content}
              </a>
            );
          })}
        </div>
      </div>

      <Card className="p-5">
        <div className="font-medium mb-1">Tip</div>
        <p className="text-sm text-muted-foreground">
          TikTok and Instagram don't support direct share links. Tap either card to copy your
          message + link, then paste it into your caption or bio.
        </p>
      </Card>
    </div>
  );
}

export function ProfileQrPanel() {
  const [userId, setUserId] = useState<string | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState<string | null>(null);
  const [QRCode, setQRCode] = useState<any>(null);

  useEffect(() => {
    import("qrcode.react").then((m) => setQRCode(() => m.QRCodeSVG));
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const { data } = await supabase
        .from("profiles").select("username, display_name").eq("id", user.id).maybeSingle();
      setUsername((data as any)?.username ?? null);
      setDisplayName((data as any)?.display_name ?? null);
    })();
  }, []);

  const base = typeof window !== "undefined" ? window.location.origin : "https://heysaas.co";
  const profileUrl = username
    ? `${base}/u/${username}`
    : userId ? `${base}/u/${userId}` : `${base}/`;
  const qrValue = userId ? `${profileUrl}?ref=${userId}` : profileUrl;

  async function downloadPng() {
    const svg = document.getElementById("hs-profile-qr") as unknown as SVGSVGElement | null;
    if (!svg) return toast.error("QR not ready yet");
    const xml = new XMLSerializer().serializeToString(svg);
    const svg64 = btoa(unescape(encodeURIComponent(xml)));
    const img = new Image();
    img.onload = () => {
      const size = 1024;
      const canvas = document.createElement("canvas");
      canvas.width = size; canvas.height = size;
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = "#0d1f2b"; ctx.fillRect(0, 0, size, size);
      ctx.drawImage(img, 64, 64, size - 128, size - 128);
      const a = document.createElement("a");
      a.href = canvas.toDataURL("image/png");
      a.download = `heysaas-${username || userId || "profile"}.png`;
      a.click();
    };
    img.src = `data:image/svg+xml;base64,${svg64}`;
  }

  async function copyProfileUrl() {
    try {
      await navigator.clipboard.writeText(profileUrl);
      toast.success("Profile link copied");
    } catch { toast.error("Copy failed"); }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl">Your profile QR code</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Anyone who scans this with their phone camera lands on your Hey SaaS profile —
          perfect for business cards, laptop stickers, or slides at a meetup.
        </p>
      </div>

      <Card className="p-6">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="rounded-2xl bg-white p-4 shadow-inner">
            {QRCode && userId ? (
              <QRCode
                id="hs-profile-qr"
                value={qrValue}
                size={220}
                level="H"
                includeMargin={false}
                bgColor="#ffffff"
                fgColor="#0d1f2b"
              />
            ) : (
              <div className="h-[220px] w-[220px] animate-pulse rounded bg-muted" />
            )}
          </div>

          <div className="flex-1 min-w-0 space-y-3">
            <div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground">Profile</div>
              <div className="font-display text-lg truncate">
                {displayName || username || "Your Hey SaaS profile"}
              </div>
            </div>

            <div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground mb-1">Public link</div>
              <div className="flex gap-2">
                <Input readOnly value={profileUrl} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
                <Button variant="outline" onClick={copyProfileUrl} className="rounded-full">
                  <Copy className="h-4 w-4 mr-2" /> Copy
                </Button>
              </div>
            </div>

            {userId && (
              <div>
                <div className="text-xs uppercase tracking-widest text-muted-foreground mb-1">User ID</div>
                <div className="font-mono text-[11px] break-all rounded-md border border-hairline bg-surface px-2 py-1.5">
                  {userId}
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-1">
              <Button onClick={downloadPng} className="rounded-full">
                <Copy className="h-4 w-4 mr-2" /> Download PNG
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-5">
        <div className="font-medium mb-1">How it works</div>
        <ul className="list-disc pl-5 space-y-1 text-sm text-muted-foreground">
          <li>The QR encodes your profile URL with your referral tag attached.</li>
          <li>Any camera app or QR reader opens it — no Hey SaaS install needed.</li>
          <li>Signups from a scan count toward your 5-founder milestone bonus.</li>
        </ul>
      </Card>
    </div>
  );
}

