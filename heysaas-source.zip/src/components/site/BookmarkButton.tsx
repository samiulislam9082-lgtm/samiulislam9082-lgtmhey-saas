import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

export function BookmarkButton({
  listingId,
  founderId,
  variant = "icon",
}: {
  listingId?: string;
  founderId?: string;
  variant?: "icon" | "full";
}) {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!mounted) return;
      setUserId(user?.id ?? null);
      if (!user) return;
      const q = supabase.from("bookmarks").select("id").eq("user_id", user.id);
      if (listingId) q.eq("listing_id", listingId);
      if (founderId) q.eq("founder_id", founderId);
      const { data } = await q.maybeSingle();
      if (mounted) setSaved(!!data);
    })();
    return () => { mounted = false; };
  }, [listingId, founderId]);

  async function toggle(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!userId) {
      navigate({ to: "/auth" });
      return;
    }
    setBusy(true);
    try {
      if (saved) {
        const q = supabase.from("bookmarks").delete().eq("user_id", userId);
        if (listingId) q.eq("listing_id", listingId);
        if (founderId) q.eq("founder_id", founderId);
        const { error } = await q;
        if (error) throw error;
        setSaved(false);
      } else {
        const { error } = await supabase.from("bookmarks").insert({
          user_id: userId,
          listing_id: listingId ?? null,
          founder_id: founderId ?? null,
        });
        if (error) throw error;
        setSaved(true);
      }
    } catch (err) {
      console.error(err);
      toast.error("Could not update bookmark");
    } finally {
      setBusy(false);
    }
  }

  const Icon = saved ? BookmarkCheck : Bookmark;
  if (variant === "icon") {
    return (
      <Button
        variant="outline"
        size="icon"
        onClick={toggle}
        disabled={busy}
        aria-label={saved ? "Remove bookmark" : "Bookmark"}
        className="rounded-full"
      >
        <Icon className="h-4 w-4" />
      </Button>
    );
  }
  return (
    <Button variant="outline" onClick={toggle} disabled={busy} className="rounded-full">
      <Icon className="h-4 w-4 mr-2" /> {saved ? "Bookmarked" : "Bookmark"}
    </Button>
  );
}
