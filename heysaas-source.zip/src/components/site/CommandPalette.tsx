import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  Sparkles,
  Repeat,
  MessageSquare,
  Bell,
  Bookmark,
  BarChart3,
  CreditCard,
  Settings,
  Compass,
  PlusCircle,
  Globe,
  Trophy,
  LogOut,
  Users,

} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type NavItem = { to: string; label: string; icon: any; keywords?: string };

const APP_ITEMS: NavItem[] = [
  { to: "/dashboard", label: "Overview", icon: Sparkles },
  { to: "/dashboard/listings", label: "My SaaS", icon: Sparkles, keywords: "listings" },
  { to: "/dashboard/swaps", label: "Swaps", icon: Repeat },
  { to: "/dashboard/messages", label: "Messages", icon: MessageSquare, keywords: "chat inbox" },
  { to: "/dashboard/notifications", label: "Notifications", icon: Bell },
  { to: "/dashboard/bookmarks", label: "Bookmarks", icon: Bookmark, keywords: "saved" },
  { to: "/dashboard/analytics", label: "Analytics", icon: BarChart3, keywords: "stats metrics" },
  { to: "/dashboard/payments", label: "Payments", icon: CreditCard, keywords: "billing invoices" },
  { to: "/dashboard/settings", label: "Settings", icon: Settings, keywords: "account profile" },
];

const DISCOVER: NavItem[] = [
  { to: "/explore", label: "Explore SaaS", icon: Compass },
  { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/websites", label: "WebSwap (websites marketplace)", icon: Globe, keywords: "websites domains" },
  { to: "/compare", label: "Compare listings", icon: BarChart3 },
];

const ACTIONS: NavItem[] = [
  { to: "/list", label: "List a new SaaS", icon: PlusCircle, keywords: "create new listing" },
];

type LiveResult = { kind: "listing" | "founder"; to: string; label: string; sub: string | null };

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<LiveResult[]>([]);
  const [searching, setSearching] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  // Live search against real listings + founder profiles.
  useEffect(() => {
    const term = query.trim();
    if (!open || term.length < 2) { setResults([]); setSearching(false); return; }
    let cancelled = false;
    setSearching(true);
    const t = setTimeout(async () => {
      const safe = term.replace(/[%,()]/g, " ").trim();
      if (!safe) { setSearching(false); return; }
      const { data: { user } } = await supabase.auth.getUser();
      let listingQuery = supabase
        .from("saas_listings")
        .select("slug, name, tagline")
        .eq("status", "live")
        .or(`name.ilike.%${safe}%,tagline.ilike.%${safe}%`)
        .limit(6);
      if (user?.id) listingQuery = listingQuery.neq("owner_id", user.id);

      const [listings, founders] = await Promise.all([
        listingQuery,
        supabase
          .from("profiles")
          .select("username, display_name")
          .not("username", "is", null)
          .or(`username.ilike.%${safe}%,display_name.ilike.%${safe}%`)
          .limit(5),
      ]);
      if (cancelled) return;
      const rows: LiveResult[] = [
        ...((listings.data ?? []) as { slug: string; name: string; tagline: string | null }[]).map((l) => ({
          kind: "listing" as const,
          to: `/saas/${l.slug}`,
          label: l.name,
          sub: l.tagline,
        })),
        ...((founders.data ?? []) as { username: string; display_name: string | null }[]).map((p) => ({
          kind: "founder" as const,
          to: `/u/${p.username}`,
          label: p.display_name || p.username,
          sub: `@${p.username}`,
        })),
      ];
      setResults(rows);
      setSearching(false);
    }, 220);
    return () => { cancelled = true; clearTimeout(t); };
  }, [query, open]);

  const go = (to: string) => {
    setOpen(false);
    setQuery("");
    navigate({ to });
  };

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Search SaaS, founders, pages…" value={query} onValueChange={setQuery} />
      <CommandList>
        <CommandEmpty>{searching ? "Searching…" : "No results found."}</CommandEmpty>
        {results.length > 0 && (
          <>
            <CommandGroup heading="Results">
              {results.map((r) => (
                <CommandItem key={`${r.kind}-${r.to}`} value={`${r.label} ${r.sub ?? ""} ${query}`} onSelect={() => go(r.to)}>
                  {r.kind === "listing" ? <Sparkles className="mr-2 h-4 w-4" /> : <Users className="mr-2 h-4 w-4" />}
                  <span className="truncate">{r.label}</span>
                  {r.sub && <span className="ml-2 truncate text-xs text-muted-foreground">{r.sub}</span>}
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}
        <CommandGroup heading="Dashboard">

          {APP_ITEMS.map((i) => (
            <CommandItem key={i.to} value={`${i.label} ${i.keywords ?? ""}`} onSelect={() => go(i.to)}>
              <i.icon className="mr-2 h-4 w-4" />
              {i.label}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Discover">
          {DISCOVER.map((i) => (
            <CommandItem key={i.to} value={`${i.label} ${i.keywords ?? ""}`} onSelect={() => go(i.to)}>
              <i.icon className="mr-2 h-4 w-4" />
              {i.label}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Actions">
          {ACTIONS.map((i) => (
            <CommandItem key={i.to} value={`${i.label} ${i.keywords ?? ""}`} onSelect={() => go(i.to)}>
              <i.icon className="mr-2 h-4 w-4" />
              {i.label}
            </CommandItem>
          ))}
          <CommandItem
            value="sign out logout"
            onSelect={async () => {
              setOpen(false);
              await supabase.auth.signOut();
              toast.success("Signed out");
              navigate({ to: "/" });
            }}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sign out
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
