import { useEffect } from "react";
import { hydrateMotionFromServer, applyMotionPreference } from "@/lib/motion";

/**
 * Mounted once at the app root. On first load and whenever the auth state
 * changes (sign-in on any device, token refresh, tab focus), pull the
 * server-stored motion preference and reconcile it with localStorage so the
 * same setting applies on every entry point.
 */
export function MotionSync() {
  useEffect(() => {
    // Ensure the DOM attribute matches the stored value even if the inline
    // pre-hydration script was skipped (e.g. CSP, older cached HTML).
    applyMotionPreference();
    void hydrateMotionFromServer();

    let unsub: (() => void) | undefined;
    void import("@/integrations/supabase/client").then(({ supabase }) => {
      const { data } = supabase.auth.onAuthStateChange((event) => {
        if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED" || event === "INITIAL_SESSION") {
          void hydrateMotionFromServer();
        }
      });
      unsub = () => data.subscription.unsubscribe();
    });

    const onVisible = () => {
      if (document.visibilityState === "visible") void hydrateMotionFromServer();
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      unsub?.();
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);

  return null;
}
