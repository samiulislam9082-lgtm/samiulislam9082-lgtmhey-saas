/**
 * Per-page signature artifact for the dashboard hero.
 * Each variant is a small, hand-crafted SVG that gives its page a
 * distinct identity — matching the editorial "wow" of the landing page
 * without ballooning route files. Pure SVG + CSS; motion respects
 * `data-motion="reduced"` via `.hs-dash-hero::after` gating in styles.css.
 */
import type { CSSProperties } from "react";

export type DashSignatureVariant =
  | "overview"
  | "listings"
  | "swaps"
  | "messages"
  | "notifications"
  | "bookmarks"
  | "analytics"
  | "payments"
  | "audit"
  | "settings";

export function DashSignature({ variant }: { variant: DashSignatureVariant }) {
  return (
    <div className="hs-dash-sig" aria-hidden>
      <div className="hs-dash-sig-frame">
        {render(variant)}
      </div>
      <div className="hs-dash-sig-caption">
        <span className="hs-dash-sig-dot" />
        {captionOf(variant)}
      </div>
    </div>
  );
}

function captionOf(v: DashSignatureVariant): string {
  switch (v) {
    case "overview": return "Cockpit · live";
    case "listings": return "Shelf · curated";
    case "swaps": return "Term sheet · armed";
    case "messages": return "Deal room · open";
    case "notifications": return "Signal · sweeping";
    case "bookmarks": return "Vault · sealed";
    case "analytics": return "Index · rising";
    case "payments": return "Ledger · settled";
    case "audit": return "Tape · scrolling";
    case "settings": return "Movement · Cal. HS-19";
  }
}

function render(v: DashSignatureVariant) {
  switch (v) {
    case "overview": return <Overview />;
    case "listings": return <Listings />;
    case "swaps": return <Swaps />;
    case "messages": return <Messages />;
    case "notifications": return <Notifications />;
    case "bookmarks": return <Bookmarks />;
    case "analytics": return <Analytics />;
    case "payments": return <Payments />;
    case "audit": return <Audit />;
    case "settings": return <Settings />;
  }
}

const svgBase: CSSProperties = { width: "100%", height: "100%", display: "block" };

/* ---------- Variants ---------- */

function Overview() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      <defs>
        <linearGradient id="ov-g" x1="0" x2="1">
          <stop offset="0%" stopColor="var(--violet)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--violet-glow)" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((r, i) => (
        <circle key={i} cx="120" cy="140" r={140 * r} fill="none" stroke="url(#ov-g)" strokeOpacity={0.15 + i * 0.08} />
      ))}
      <g className="hs-sig-orbit">
        <circle cx="120" cy="140" r="70" fill="none" stroke="url(#ov-g)" strokeDasharray="2 6" strokeOpacity="0.5" />
      </g>
      <circle cx="120" cy="70" r="4" fill="var(--violet-glow)">
        <animate attributeName="opacity" values="1;0.3;1" dur="2.4s" repeatCount="indefinite" />
      </circle>
      <circle cx="60" cy="112" r="2.5" fill="var(--violet-glow)" opacity="0.7" />
      <circle cx="180" cy="112" r="2.5" fill="var(--violet-glow)" opacity="0.7" />
      <text x="120" y="128" textAnchor="middle" className="hs-sig-num" fontSize="22">03</text>
      <text x="120" y="138" textAnchor="middle" className="hs-sig-lbl" fontSize="7">CHECKPOINTS</text>
    </svg>
  );
}

function Listings() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      {[0, 1, 2].map((i) => (
        <g key={i} transform={`translate(${20 + i * 68}, ${18 + i * 6})`}>
          <rect width="60" height="86" rx="6" fill="color-mix(in oklab, var(--violet) 14%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 40%, transparent)" />
          <rect x="6" y="6" width="48" height="30" rx="3" fill="color-mix(in oklab, var(--violet-glow) 22%, transparent)" />
          <rect x="6" y="42" width="34" height="4" rx="2" fill="color-mix(in oklab, var(--foreground) 60%, transparent)" />
          <rect x="6" y="50" width="22" height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 30%, transparent)" />
          <circle cx="12" cy="72" r="2" fill="var(--violet-glow)" />
          <rect x="18" y="70" width="30" height="4" rx="2" fill="color-mix(in oklab, var(--foreground) 45%, transparent)" />
        </g>
      ))}
    </svg>
  );
}

function Swaps() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      <defs>
        <linearGradient id="sw-w" x1="0" x2="1">
          <stop offset="0%" stopColor="var(--violet)" />
          <stop offset="100%" stopColor="var(--violet-glow)" />
        </linearGradient>
      </defs>
      <rect x="14" y="34" width="80" height="72" rx="8" fill="color-mix(in oklab, var(--violet) 16%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 40%, transparent)" />
      <rect x="146" y="34" width="80" height="72" rx="8" fill="color-mix(in oklab, var(--violet) 16%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 40%, transparent)" />
      {[46, 58, 70, 82].map((y) => (
        <rect key={y} x="22" y={y} width={y === 46 ? 50 : y === 82 ? 30 : 60} height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 55%, transparent)" />
      ))}
      {[46, 58, 70, 82].map((y) => (
        <rect key={y} x="154" y={y} width={y === 46 ? 55 : y === 82 ? 34 : 62} height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 55%, transparent)" />
      ))}
      <path d="M96 70 C 110 70 130 70 144 70" fill="none" stroke="url(#sw-w)" strokeWidth="1.5" strokeDasharray="3 4">
        <animate attributeName="stroke-dashoffset" values="0;-14" dur="2s" repeatCount="indefinite" />
      </path>
      <circle cx="120" cy="70" r="8" fill="color-mix(in oklab, var(--violet) 30%, transparent)" stroke="var(--violet-glow)" />
      <text x="120" y="73" textAnchor="middle" fontSize="7" fill="var(--violet-glow)" className="hs-sig-num">⇄</text>
    </svg>
  );
}

function Messages() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      <g>
        <rect x="20" y="28" width="120" height="26" rx="13" fill="color-mix(in oklab, var(--violet) 22%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 35%, transparent)" />
        <rect x="30" y="38" width="72" height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 65%, transparent)" />
        <rect x="30" y="44" width="46" height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 35%, transparent)" />
      </g>
      <g>
        <rect x="100" y="66" width="120" height="26" rx="13" fill="color-mix(in oklab, var(--violet-glow) 18%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 45%, transparent)" />
        <rect x="112" y="76" width="80" height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 70%, transparent)" />
        <rect x="112" y="82" width="52" height="3" rx="1.5" fill="color-mix(in oklab, var(--foreground) 40%, transparent)" />
      </g>
      <g>
        <rect x="20" y="104" width="72" height="20" rx="10" fill="color-mix(in oklab, var(--violet) 18%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 30%, transparent)" />
        <circle cx="34" cy="114" r="1.6" fill="var(--violet-glow)"><animate attributeName="opacity" values="1;0.2;1" dur="1.2s" repeatCount="indefinite" /></circle>
        <circle cx="42" cy="114" r="1.6" fill="var(--violet-glow)"><animate attributeName="opacity" values="0.2;1;0.2" dur="1.2s" repeatCount="indefinite" /></circle>
        <circle cx="50" cy="114" r="1.6" fill="var(--violet-glow)"><animate attributeName="opacity" values="1;0.2;1" dur="1.2s" begin="0.4s" repeatCount="indefinite" /></circle>
      </g>
    </svg>
  );
}

function Notifications() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      <defs>
        <radialGradient id="rad-g">
          <stop offset="0%" stopColor="var(--violet-glow)" stopOpacity="0.7" />
          <stop offset="100%" stopColor="var(--violet-glow)" stopOpacity="0" />
        </radialGradient>
      </defs>
      {[30, 55, 80].map((r) => (
        <circle key={r} cx="120" cy="70" r={r} fill="none" stroke="color-mix(in oklab, var(--violet-glow) 40%, transparent)" strokeOpacity="0.4" />
      ))}
      <line x1="40" y1="70" x2="200" y2="70" stroke="color-mix(in oklab, var(--violet-glow) 30%, transparent)" strokeDasharray="2 4" />
      <line x1="120" y1="0" x2="120" y2="140" stroke="color-mix(in oklab, var(--violet-glow) 30%, transparent)" strokeDasharray="2 4" />
      <g className="hs-sig-sweep" style={{ transformOrigin: "120px 70px" }}>
        <path d="M120 70 L120 -10 A80 80 0 0 1 195 40 Z" fill="url(#rad-g)" opacity="0.55" />
      </g>
      <circle cx="150" cy="46" r="2.5" fill="var(--violet-glow)"><animate attributeName="opacity" values="1;0.1;1" dur="2.2s" repeatCount="indefinite" /></circle>
      <circle cx="88" cy="98" r="2" fill="var(--violet-glow)" opacity="0.7" />
      <circle cx="164" cy="94" r="2" fill="var(--violet-glow)" opacity="0.5" />
    </svg>
  );
}

function Bookmarks() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      {[0, 1, 2, 3, 4].map((i) => (
        <g key={i} transform={`translate(${20 + i * 42}, 18)`}>
          <path d={`M0 0 H32 V${86 + (i % 2) * 6} L16 ${74 + (i % 2) * 6} L0 ${86 + (i % 2) * 6} Z`}
                fill={`color-mix(in oklab, var(--violet${i % 2 ? "-glow" : ""}) ${18 + i * 4}%, transparent)`}
                stroke="color-mix(in oklab, var(--violet-glow) 35%, transparent)" />
          <line x1="8" y1="14" x2="24" y2="14" stroke="color-mix(in oklab, var(--foreground) 55%, transparent)" strokeWidth="1.5" />
          <line x1="8" y1="22" x2="20" y2="22" stroke="color-mix(in oklab, var(--foreground) 35%, transparent)" strokeWidth="1.5" />
        </g>
      ))}
    </svg>
  );
}

function Analytics() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase} preserveAspectRatio="none">
      <defs>
        <linearGradient id="an-fill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--violet-glow)" stopOpacity="0.45" />
          <stop offset="100%" stopColor="var(--violet-glow)" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[30, 60, 90, 120].map((y) => (
        <line key={y} x1="0" y1={y} x2="240" y2={y} stroke="color-mix(in oklab, var(--violet-glow) 15%, transparent)" strokeDasharray="1 5" />
      ))}
      <path d="M0 100 C 30 88, 50 96, 70 78 S 110 44, 140 52 S 190 20, 240 34 L 240 140 L 0 140 Z" fill="url(#an-fill)" />
      <path d="M0 100 C 30 88, 50 96, 70 78 S 110 44, 140 52 S 190 20, 240 34" fill="none" stroke="var(--violet-glow)" strokeWidth="1.6" />
      {[[70, 78], [140, 52], [200, 30]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i === 2 ? 3.4 : 2.2} fill="var(--violet-glow)">
          {i === 2 && <animate attributeName="r" values="3.4;5;3.4" dur="1.8s" repeatCount="indefinite" />}
        </circle>
      ))}
    </svg>
  );
}

function Payments() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      <defs>
        <radialGradient id="pv-g">
          <stop offset="0%" stopColor="var(--violet)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--violet)" stopOpacity="0.1" />
        </radialGradient>
      </defs>
      <circle cx="120" cy="70" r="56" fill="url(#pv-g)" stroke="color-mix(in oklab, var(--violet-glow) 45%, transparent)" />
      <circle cx="120" cy="70" r="46" fill="none" stroke="color-mix(in oklab, var(--violet-glow) 25%, transparent)" strokeDasharray="1 4" />
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2 - Math.PI / 2;
        const x1 = 120 + Math.cos(a) * 48; const y1 = 70 + Math.sin(a) * 48;
        const x2 = 120 + Math.cos(a) * 54; const y2 = 70 + Math.sin(a) * 54;
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="color-mix(in oklab, var(--violet-glow) 60%, transparent)" strokeWidth="1.2" />;
      })}
      <g className="hs-sig-spin" style={{ transformOrigin: "120px 70px" }}>
        <line x1="120" y1="70" x2="120" y2="30" stroke="var(--violet-glow)" strokeWidth="1.6" strokeLinecap="round" />
      </g>
      <circle cx="120" cy="70" r="4" fill="var(--violet-glow)" />
      <text x="120" y="112" textAnchor="middle" fontSize="8" fill="color-mix(in oklab, var(--foreground) 70%, transparent)" letterSpacing="0.14em">SAFETY · $19</text>
    </svg>
  );
}

function Audit() {
  const rows = [
    ["04:12", "swap.accepted", "OK"],
    ["04:07", "listing.published", "OK"],
    ["03:58", "message.sent", "OK"],
    ["03:41", "payment.captured", "$19"],
    ["03:22", "profile.updated", "OK"],
  ];
  return (
    <svg viewBox="0 0 240 140" style={svgBase} fontFamily="ui-monospace, SFMono-Regular, monospace">
      <rect x="6" y="6" width="228" height="128" rx="8" fill="color-mix(in oklab, var(--surface) 60%, transparent)" stroke="color-mix(in oklab, var(--violet-glow) 25%, transparent)" />
      {rows.map((r, i) => (
        <g key={i} transform={`translate(14, ${22 + i * 20})`}>
          <text x="0" y="0" fontSize="7" fill="color-mix(in oklab, var(--foreground) 55%, transparent)">{r[0]}</text>
          <text x="34" y="0" fontSize="7" fill="color-mix(in oklab, var(--violet-glow) 90%, var(--foreground))">{r[1]}</text>
          <text x="192" y="0" fontSize="7" fill="color-mix(in oklab, var(--foreground) 70%, transparent)" textAnchor="end">{r[2]}</text>
          <line x1="-2" y1="4" x2="214" y2="4" stroke="color-mix(in oklab, var(--violet-glow) 15%, transparent)" strokeDasharray="1 3" />
        </g>
      ))}
      <rect x="6" y="6" width="228" height="128" rx="8" fill="none" stroke="none" />
      <g>
        <line x1="14" y1="128" x2="26" y2="128" stroke="var(--violet-glow)" strokeWidth="1.5">
          <animate attributeName="x2" values="14;220;14" dur="3.6s" repeatCount="indefinite" />
        </line>
      </g>
    </svg>
  );
}

function Settings() {
  return (
    <svg viewBox="0 0 240 140" style={svgBase}>
      <defs>
        <radialGradient id="st-g">
          <stop offset="0%" stopColor="var(--violet)" stopOpacity="0.7" />
          <stop offset="100%" stopColor="var(--violet)" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="120" cy="70" r="54" fill="url(#st-g)" stroke="color-mix(in oklab, var(--violet-glow) 40%, transparent)" />
      <g className="hs-sig-spin" style={{ transformOrigin: "120px 70px" }}>
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2;
          const x1 = 120 + Math.cos(a) * 40; const y1 = 70 + Math.sin(a) * 40;
          const x2 = 120 + Math.cos(a) * 52; const y2 = 70 + Math.sin(a) * 52;
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="var(--violet-glow)" strokeWidth="2" strokeLinecap="round" opacity="0.75" />;
        })}
      </g>
      <g className="hs-sig-spin-rev" style={{ transformOrigin: "120px 70px" }}>
        <circle cx="120" cy="70" r="28" fill="none" stroke="color-mix(in oklab, var(--violet-glow) 60%, transparent)" strokeDasharray="4 3" />
      </g>
      <circle cx="120" cy="70" r="6" fill="var(--violet-glow)" />
      <circle cx="120" cy="70" r="12" fill="none" stroke="color-mix(in oklab, var(--violet-glow) 50%, transparent)" />
    </svg>
  );
}
