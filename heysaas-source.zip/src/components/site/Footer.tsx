import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { subscribeNewsletter } from "@/lib/reports.functions";
import { toast } from "sonner";
import { ArrowUpRight, Mail } from "lucide-react";
import { SiX, SiFacebook, SiInstagram, SiGmail } from "react-icons/si";

const columns = [
  {
    title: "Product",
    links: [
      { to: "/explore", label: "Explore" },
      { to: "/list", label: "List your SaaS" },
      { to: "/pricing", label: "Pricing" },
      { to: "/how-it-works", label: "How it works" },
    ],
  },
  {
    title: "Company",
    links: [
      { to: "/about", label: "About" },
      { to: "/blog", label: "Blog" },
      { to: "/leaderboard", label: "Leaderboard" },
    ],
  },
  {
    title: "Resources",
    links: [
      { to: "/guidelines", label: "Community guidelines" },
      { to: "/how-it-works", label: "Swap guide" },
      { to: "#help", label: "Help & Support" },
    ],
  },
  {
    title: "Legal",
    links: [
      { to: "/legal/terms", label: "Terms" },
      { to: "/legal/privacy", label: "Privacy" },
      { to: "/legal/safety-fee-policy", label: "Safety fee policy" },
    ],
  },
] as const;

const CONTACT_EMAIL = "heysaas12@gmail.com";
const GMAIL_COMPOSE = `https://mail.google.com/mail/?view=cm&fs=1&to=${CONTACT_EMAIL}`;

const socials = [
  { icon: SiX, label: `X — @HeySaas1`, href: "https://x.com/HeySaas1" },
  { icon: SiFacebook, label: "Facebook — Hey SaaS", href: "https://www.facebook.com/profile.php?id=61592710828229" },
  { icon: SiInstagram, label: "Instagram — @hey_saas", href: "https://www.instagram.com/hey_saas/" },
  { icon: SiGmail, label: `Email — ${CONTACT_EMAIL}`, href: GMAIL_COMPOSE },
];

export function Footer() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const sub = useServerFn(subscribeNewsletter);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return;
    setBusy(true);
    try { await sub({ data: { email, source: "footer" } }); toast.success("Subscribed 🎉"); setEmail(""); }
    catch (err: any) { toast.error(err.message || "Failed"); }
    setBusy(false);
  }
  return (
    <footer className="hs-footer relative overflow-hidden border-t border-hairline bg-background/60">
      {/* ambient background */}
      <div aria-hidden="true" className="hs-footer-glow pointer-events-none absolute inset-x-0 -top-40 h-[420px]" />
      <div aria-hidden="true" className="hs-footer-grid pointer-events-none absolute inset-0 opacity-[0.04]" />

      {/* editorial statement band */}
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-20 pb-14 border-b border-hairline">
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] lg:items-end">
          <div>
            <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground inline-flex items-center gap-2">
              <span className="hs-live-dot" aria-hidden="true" />
              Signals from the marketplace
              <span className="text-muted-foreground/60">·</span>
              <span className="font-mono tabular-nums">weekly</span>
            </div>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl md:text-5xl leading-[0.95] text-balance max-w-2xl">
              A short letter every Sunday — <span className="italic text-violet-glow">no fluff, no growth-hackery.</span>
            </h2>

            <p className="mt-4 text-muted-foreground max-w-xl">
              One editor-picked swap, one lesson from a founder who closed, and one number that moved. 5-minute read. Unsubscribe in one click.
            </p>
          </div>

          <form onSubmit={submit} className="hs-footer-form relative rounded-2xl border border-hairline bg-surface/60 p-2 flex items-center gap-2">
            <span aria-hidden="true" className="pl-3 text-muted-foreground"><Mail className="h-4 w-4" /></span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@founder.co"
              className="flex-1 bg-transparent py-3 text-sm placeholder:text-muted-foreground focus:outline-none"
            />
            <button
              type="submit"
              disabled={busy}
              className="group inline-flex items-center gap-1.5 rounded-xl bg-violet px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors disabled:opacity-50"
              style={{ boxShadow: "var(--shadow-glow)" }}
            >
              {busy ? "…" : "Subscribe"}
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </button>
          </form>
        </div>

        {/* mini ledger */}
        <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-px rounded-2xl border border-hairline overflow-hidden bg-hairline">
          {[
            { k: "1,284", v: "founders" },
            { k: "812", v: "swaps closed" },
            { k: "$0", v: "commission" },
            { k: "4.9★", v: "avg. rating" },
          ].map((s) => (
            <div key={s.v} className="bg-surface/60 px-5 py-4">
              <div className="font-display text-2xl leading-none tabular-nums">
                <span className="bg-gradient-to-br from-foreground to-violet-glow bg-clip-text text-transparent">{s.k}</span>
              </div>
              <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{s.v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* nav grid */}
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-6">
          <div className="col-span-2">
            <Link to="/" className="group inline-flex items-center gap-2.5">
              <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet to-violet-glow text-primary-foreground font-display text-xl leading-none" style={{ boxShadow: "0 0 30px -6px color-mix(in oklab, var(--violet) 55%, transparent)" }}>
                h
                <span aria-hidden="true" className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/20" />
              </span>
              <span className="font-display text-2xl tracking-tight">Hey&nbsp;SaaS</span>
            </Link>
            <p className="mt-5 text-sm text-muted-foreground max-w-xs leading-relaxed">
              The editorial marketplace where founders swap SaaS products directly. No cash between users, ever.
            </p>

            {/* socials */}
            <ul className="mt-6 flex items-center gap-2">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    aria-label={s.label}
                    title={s.label}
                    {...(s.href.startsWith("mailto:")
                      ? {}
                      : { target: "_blank", rel: "noopener noreferrer" })}
                    onClick={(e) => {
                      if (s.href.startsWith("mailto:")) return;
                      // Open only in a separate tab/window. Do not fall back to
                      // same-frame navigation, because Facebook/Instagram block
                      // embedded rendering and show an error inside previews.
                      e.preventDefault();
                      const win = window.open(s.href, "_blank", "noopener,noreferrer");
                      if (!win) {
                        toast.info(`${s.label.replace(" — ", ": ")} copied`, {
                          description: s.href,
                        });
                      }
                    }}
                    className="hs-footer-social inline-flex h-9 w-9 items-center justify-center rounded-full border border-hairline bg-surface/60 text-muted-foreground hover:text-foreground hover:border-violet/45 transition-colors"
                  >
                    <s.icon className="h-4 w-4" aria-hidden focusable={false} />
                  </a>
                </li>
              ))}
            </ul>

            <a
              href={`mailto:${CONTACT_EMAIL}`}
              className="mt-4 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <Mail className="h-4 w-4" aria-hidden />
              <span className="font-mono">{CONTACT_EMAIL}</span>
            </a>


            {/* status pill */}
            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1.5 text-[11px] text-muted-foreground">
              <span className="hs-live-dot" aria-hidden="true" />
              All systems operational
              <span className="text-muted-foreground/40">·</span>
              <span className="font-mono tabular-nums text-foreground">99.99%</span>
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="text-[11px] font-mono uppercase tracking-[0.18em] text-muted-foreground">{col.title}</h3>
              <ul className="mt-5 space-y-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    {l.to === "#help" ? (
                      <button
                        type="button"
                        onClick={() => window.dispatchEvent(new CustomEvent("heysaas:open-support"))}
                        className="hs-footer-link text-sm text-foreground/80 hover:text-foreground transition-colors"
                      >
                        {l.label}
                      </button>
                    ) : (
                      <Link
                        to={l.to}
                        className="hs-footer-link text-sm text-foreground/80 hover:text-foreground transition-colors"
                      >
                        {l.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>


        <div className="mt-8 pt-6 border-t border-hairline flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Hey SaaS. Swap your SaaS. Not your money.
          </p>
          <p className="text-xs text-muted-foreground inline-flex items-center gap-2">
            <span className="font-mono tabular-nums">v1.0</span>
            <span className="text-muted-foreground/40">·</span>
            Made for founders, by founders.
          </p>
        </div>
      </div>
    </footer>
  );
}
