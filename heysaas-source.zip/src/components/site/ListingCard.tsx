import { Link } from "@tanstack/react-router";
import { useSignedImage } from "@/hooks/useSignedImage";
import { Badge } from "@/components/ui/badge";
import { Eye, Sparkles, ArrowUpRight, TrendingUp, Users } from "lucide-react";
import { BookmarkButton } from "./BookmarkButton";

export type ListingCardData = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  logo_url: string | null;
  cover_url: string | null;
  status: string;
  mrr_range: string | null;
  views: number;
  interested_count: number;
  tag_slugs: string[] | null;
  promoted?: boolean;
};

const STATUS_LABEL: Record<string, { label: string; tone: string }> = {
  live: { label: "Open to swap", tone: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
  not_open: { label: "Not open", tone: "bg-muted text-muted-foreground border-hairline" },
  access_paused: { label: "Paused", tone: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
  access_extended: { label: "Extended access", tone: "bg-sky-500/15 text-sky-400 border-sky-500/30" },
  swapped: { label: "Swapped", tone: "bg-violet/20 text-violet border-violet/30" },
};

export function ListingCard({ listing }: { listing: ListingCardData }) {
  const logo = useSignedImage("logos", listing.logo_url);
  const cover = useSignedImage("covers", listing.cover_url);
  const status = STATUS_LABEL[listing.status] ?? { label: listing.status, tone: "bg-muted" };

  return (
    <Link
      to="/saas/$slug"
      params={{ slug: listing.slug }}
      className="group/card relative flex flex-col overflow-hidden rounded-2xl border border-hairline bg-surface transition-[transform,border-color,box-shadow] duration-300 ease-out hover:border-foreground/25 hover:-translate-y-1 hover:shadow-[0_24px_60px_-30px_color-mix(in_oklab,var(--violet)_55%,transparent)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring will-change-transform"
    >
      {/* Subtle violet glow that fades in on hover — pure CSS, no layout impact */}
      <div
        aria-hidden
        className="pointer-events-none absolute -inset-px rounded-2xl opacity-0 transition-opacity duration-300 group-hover/card:opacity-100"
        style={{
          background:
            "radial-gradient(400px circle at 50% 0%, color-mix(in oklab, var(--violet) 22%, transparent), transparent 60%)",
        }}
      />

      <div className="relative aspect-[16/10] w-full overflow-hidden bg-gradient-to-br from-violet/20 via-surface to-background">
        {cover ? (
          <img
            src={cover}
            alt=""
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition-transform duration-[600ms] ease-out group-hover/card:scale-[1.06]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <Sparkles className="h-6 w-6 opacity-30" />
          </div>
        )}

        {/* Bottom fade — sits above the image, below the KPI reveal */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-surface via-surface/60 to-transparent" />

        {/* Top-left promoted badge */}
        {listing.promoted && (
          <span className="absolute top-3 left-3 rounded-full bg-violet/90 backdrop-blur px-2.5 py-1 text-[10px] font-medium uppercase tracking-wider text-primary-foreground">
            Promoted
          </span>
        )}

        {/* Top-right actions: save + quick view — reveal on hover / focus-within */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5 opacity-0 translate-y-[-4px] transition-[opacity,transform] duration-200 group-hover/card:opacity-100 group-hover/card:translate-y-0 group-focus-within/card:opacity-100 group-focus-within/card:translate-y-0">
          <div
            className="rounded-full backdrop-blur-md bg-background/70 hairline"
            onClick={(e) => e.preventDefault()}
          >
            <BookmarkButton listingId={listing.id} />
          </div>
          <span
            aria-hidden
            className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-background/70 backdrop-blur-md hairline text-foreground"
            title="Quick view"
          >
            <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover/card:rotate-12" />
          </span>
        </div>

        {/* KPI reveal — slides up over the cover on hover; hidden by translate, no layout shift */}
        <div className="pointer-events-none absolute inset-x-3 bottom-3 flex items-center gap-2 opacity-0 translate-y-2 transition-[opacity,transform] duration-300 ease-out group-hover/card:opacity-100 group-hover/card:translate-y-0 group-focus-within/card:opacity-100 group-focus-within/card:translate-y-0">
          {listing.mrr_range && (
            <span className="inline-flex items-center gap-1 rounded-full bg-background/80 backdrop-blur-md hairline px-2.5 py-1 text-[11px] font-medium">
              <TrendingUp className="h-3 w-3 text-emerald-400" />
              {listing.mrr_range} MRR
            </span>
          )}
          <span className="inline-flex items-center gap-1 rounded-full bg-background/80 backdrop-blur-md hairline px-2.5 py-1 text-[11px] font-medium">
            <Eye className="h-3 w-3 text-muted-foreground" /> {listing.views}
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-background/80 backdrop-blur-md hairline px-2.5 py-1 text-[11px] font-medium">
            <Users className="h-3 w-3 text-violet" /> {listing.interested_count}
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 shrink-0 overflow-hidden rounded-xl border border-hairline bg-background transition-transform duration-300 group-hover/card:scale-[1.04]">
            {logo ? (
              <img src={logo} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center font-display text-sm text-muted-foreground">
                {listing.name.slice(0, 1)}
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="truncate font-display text-lg leading-tight transition-colors group-hover/card:text-foreground">
                {listing.name}
              </h3>
            </div>
            {listing.tagline && (
              <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{listing.tagline}</p>
            )}
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Badge variant="outline" className={`rounded-full px-2.5 py-0.5 text-xs ${status.tone}`}>
            {status.label}
          </Badge>
          {listing.mrr_range && (
            <Badge variant="outline" className="rounded-full px-2.5 py-0.5 text-xs">
              {listing.mrr_range} MRR
            </Badge>
          )}
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-hairline pt-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1"><Eye className="h-3 w-3" /> {listing.views}</span>
            <span className="inline-flex items-center gap-1"><Sparkles className="h-3 w-3" /> {listing.interested_count}</span>
          </div>
          <span className="inline-flex items-center gap-1 text-foreground opacity-0 -translate-x-1 transition-[opacity,transform] duration-200 group-hover/card:opacity-100 group-hover/card:translate-x-0">
            View <ArrowUpRight className="h-3 w-3" />
          </span>
        </div>
      </div>
    </Link>
  );
}
