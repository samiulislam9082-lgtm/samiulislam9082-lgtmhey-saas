import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSignedImage } from "@/hooks/useSignedImage";
import { Button } from "@/components/ui/button";
import { Loader2, Upload, X } from "lucide-react";
import { toast } from "sonner";

type Bucket = "avatars" | "covers" | "logos" | "screenshots";

interface ImageUploaderProps {
  bucket: Bucket;
  userId: string;
  value: string | null;
  onChange: (path: string | null) => void;
  label?: string;
  aspect?: "square" | "wide" | "tall";
  maxDim?: number; // longest edge in px after client resize
  maxSizeMB?: number;
  className?: string;
}

/**
 * Reusable image uploader with client-side resize (Canvas) that writes to
 * `<bucket>/<userId>/...` so per-user RLS applies.
 */
export function ImageUploader({
  bucket,
  userId,
  value,
  onChange,
  label = "Upload image",
  aspect = "square",
  maxDim = 1600,
  maxSizeMB = 4,
  className = "",
}: ImageUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const preview = useSignedImage(bucket, value);

  const aspectClass =
    aspect === "wide" ? "aspect-[3/1]" : aspect === "tall" ? "aspect-[3/4]" : "aspect-square";

  async function resizeImage(file: File): Promise<Blob> {
    const bitmap = await createImageBitmap(file);
    const ratio = Math.min(1, maxDim / Math.max(bitmap.width, bitmap.height));
    const w = Math.round(bitmap.width * ratio);
    const h = Math.round(bitmap.height * ratio);
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(bitmap, 0, 0, w, h);
    return await new Promise<Blob>((resolve) =>
      canvas.toBlob((b) => resolve(b!), "image/webp", 0.88),
    );
  }

  async function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please choose an image file.");
      return;
    }
    if (file.size > maxSizeMB * 1024 * 1024) {
      toast.error(`Image must be under ${maxSizeMB}MB.`);
      return;
    }
    setUploading(true);
    try {
      const blob = await resizeImage(file);
      const path = `${userId}/${crypto.randomUUID()}.webp`;
      const { error } = await supabase.storage
        .from(bucket)
        .upload(path, blob, { contentType: "image/webp", upsert: false });
      if (error) throw error;
      onChange(path);
      toast.success("Image uploaded");
    } catch (err) {
      console.error(err);
      toast.error("Upload failed. Try another image.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className={className}>
      <div
        className={`${aspectClass} relative overflow-hidden rounded-2xl border border-hairline bg-surface`}
      >
        {preview ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={preview} alt="" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">
            No image
          </div>
        )}
        {value && (
          <button
            type="button"
            onClick={() => onChange(null)}
            className="absolute right-2 top-2 inline-flex h-7 w-7 items-center justify-center rounded-full bg-background/80 text-foreground backdrop-blur hover:bg-background"
            aria-label="Remove image"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={onPick}
        className="hidden"
      />
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className="mt-3 rounded-full"
      >
        {uploading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Uploading…
          </>
        ) : (
          <>
            <Upload className="h-4 w-4 mr-2" /> {label}
          </>
        )}
      </Button>
    </div>
  );
}
