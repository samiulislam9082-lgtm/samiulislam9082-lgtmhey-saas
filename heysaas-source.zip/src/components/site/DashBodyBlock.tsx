/**
 * Editorial body block per dashboard page — a decorative, self-contained
 * strip that sits between the ribbon and the real page data, so the body
 * of the page reads as bespoke as the hero. Zero data dependencies:
 * illustrative placeholders only.
 */
import type { DashSignatureVariant } from "./DashSignature";

export function DashBodyBlock(_: { variant: DashSignatureVariant }) {
  return null;
}


/* ------------------------------ Overview ------------------------------ */
function CockpitStrip() {
  const items = [
    { k: "Escrow health", v: "Green", tone: "up" },
    { k: "Signal lag", v: "142 ms", tone: "up" },
    { k: "Active room", v: "1", tone: "neutral" },
    { k: "Fresh matches", v: "4", tone: "up" },
  ];
  return (
    <section className="hs-body-block hs-body-cockpit mt-6" aria-label="Cockpit">
      <BlockHeader eyebrow="Cockpit" title="Everything green, quietly." />
      <div className="grid gap-3 md:grid-cols-4">
        {items.map((it, i) => (
          <div key={i} className="hs-cockpit-cell">
            <div className="hs-cockpit-k">{it.k}</div>
            <div className="hs-cockpit-v">{it.v}</div>
            <svg viewBox="0 0 120 30" className="hs-cockpit-spark" aria-hidden>
              <path d={sparkPath(i)} fill="none" stroke="currentColor" strokeWidth="1.5" />
            </svg>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------ Listings ------------------------------ */
function Shelf() {
  return (
    <section className="hs-body-block mt-6" aria-label="Shelf">
      <BlockHeader eyebrow="Shelf" title="Your catalog, curated." />
      <div className="hs-shelf">
        {["A", "B", "C", "D", "E"].map((t, i) => (
          <div key={i} className="hs-shelf-book" style={{ ["--h" as any]: `${70 + ((i * 13) % 40)}%` }}>
            <span className="hs-shelf-spine">{t}</span>
          </div>
        ))}
        <div className="hs-shelf-plank" />
      </div>
    </section>
  );
}

/* ------------------------------ Swaps ------------------------------ */
function TermSheetStrip() {
  return (
    <section className="hs-body-block mt-6" aria-label="Term sheets">
      <BlockHeader eyebrow="Term sheets" title="Two pages, one wire." />
      <div className="hs-termsheet">
        <div className="hs-termsheet-sheet">
          <div className="hs-termsheet-line" />
          <div className="hs-termsheet-line w-2/3" />
          <div className="hs-termsheet-line w-1/2" />
          <div className="hs-termsheet-stamp">SIGNED</div>
        </div>
        <div className="hs-termsheet-wire" />
        <div className="hs-termsheet-sheet">
          <div className="hs-termsheet-line" />
          <div className="hs-termsheet-line w-2/3" />
          <div className="hs-termsheet-line w-1/2" />
          <div className="hs-termsheet-stamp">SIGNED</div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ Messages ------------------------------ */
function DealRoomPreview() {
  const bubbles = [
    { who: "them", txt: "Fee cleared on my side. You?" },
    { who: "you", txt: "Just paid. Handover doc drafted." },
    { who: "them", txt: "Received. Merging into escrow." },
  ];
  return (
    <section className="hs-body-block mt-6" aria-label="Deal room">
      <BlockHeader eyebrow="Deal room" title="A quieter kind of chat." />
      <div className="hs-dealroom">
        {bubbles.map((b, i) => (
          <div key={i} className={`hs-dealroom-row hs-dealroom-row--${b.who}`}>
            <div className={`hs-dealroom-bubble hs-dealroom-bubble--${b.who}`}>{b.txt}</div>
          </div>
        ))}
        <div className="hs-dealroom-escrow">
          <span className="hs-dealroom-dot" /> Escrow: <b className="ml-1">both fees settled</b>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ Notifications ------------------------------ */
function SonarStrip() {
  return (
    <section className="hs-body-block mt-6" aria-label="Signal sweep">
      <BlockHeader eyebrow="Sweep" title="Signal, not noise." />
      <div className="hs-sonar">
        <div className="hs-sonar-scope">
          <div className="hs-sonar-sweep" />
          <span className="hs-sonar-blip" style={{ top: "22%", left: "68%" }} />
          <span className="hs-sonar-blip" style={{ top: "58%", left: "34%" }} />
          <span className="hs-sonar-blip" style={{ top: "44%", left: "50%" }} />
        </div>
        <ul className="hs-sonar-log">
          <li><b>03:14</b> — Founder pinged your listing</li>
          <li><b>02:58</b> — Match strength rose to 82</li>
          <li><b>02:12</b> — 6 new prospects entered your band</li>
        </ul>
      </div>
    </section>
  );
}

/* ------------------------------ Bookmarks ------------------------------ */
function RibbonWall() {
  const items = ["Vertical SaaS", "Ops tools", "Dev API", "Consumer AI", "Fintech", "Creator"];
  return (
    <section className="hs-body-block mt-6" aria-label="Ribbon wall">
      <BlockHeader eyebrow="Vault" title="Pinned, tagged, quietly waiting." />
      <div className="hs-ribbon-wall">
        {items.map((t, i) => (
          <span key={i} className="hs-ribbon-tag" style={{ ["--rot" as any]: `${-3 + ((i * 2) % 6)}deg` }}>
            {t}
          </span>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------ Analytics ------------------------------ */
function SparklineStrip() {
  const rows = [
    { k: "Views", v: "2,841", d: "+12%", up: true, seed: 1 },
    { k: "Saves", v: "173", d: "+6.8%", up: true, seed: 2 },
    { k: "Offers", v: "54", d: "+0.3", up: true, seed: 3 },
    { k: "Ghosts", v: "3", d: "-0.4", up: false, seed: 4 },
  ];
  return (
    <section className="hs-body-block mt-6" aria-label="Market strip">
      <BlockHeader eyebrow="Market strip" title="The tape, at a glance." />
      <div className="grid gap-3 md:grid-cols-4">
        {rows.map((r, i) => (
          <div key={i} className="hs-spark-card">
            <div className="flex items-baseline justify-between">
              <span className="hs-spark-k">{r.k}</span>
              <span className={`hs-spark-d ${r.up ? "up" : "down"}`}>{r.d}</span>
            </div>
            <div className="hs-spark-v">{r.v}</div>
            <svg viewBox="0 0 120 36" className={`hs-spark ${r.up ? "up" : "down"}`} aria-hidden>
              <path d={sparkPath(r.seed)} fill="none" stroke="currentColor" strokeWidth="1.75" />
            </svg>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------ Payments ------------------------------ */
function ReceiptTape() {
  const rows = [
    { t: "Safety fee · Swap #A21F", v: "$19.00", s: "PAID" },
    { t: "Safety fee · Swap #M18Q", v: "$19.00", s: "PAID" },
    { t: "Refund · Swap #C09B",   v: "-$19.00", s: "REFUND" },
    { t: "Safety fee · Swap #V44E", v: "$19.00", s: "PAID" },
  ];
  return (
    <section className="hs-body-block mt-6" aria-label="Ledger tape">
      <BlockHeader eyebrow="Ledger" title="Every fee, on record." />
      <div className="hs-receipt">
        <div className="hs-receipt-head">
          <span>HEY SAAS</span><span>ESCROW LEDGER</span><span>USD</span>
        </div>
        {rows.map((r, i) => (
          <div key={i} className="hs-receipt-row">
            <span className="truncate">{r.t}</span>
            <span className="tabular-nums">{r.v}</span>
            <span className={`hs-receipt-tag ${r.s === "REFUND" ? "refund" : ""}`}>{r.s}</span>
          </div>
        ))}
        <div className="hs-receipt-foot">— end of tape —</div>
      </div>
    </section>
  );
}

/* ------------------------------ Audit ------------------------------ */
function AuditTape() {
  const rows = [
    { t: "auth.check", h: "3a91…c02f", d: "ok" },
    { t: "bulk.mute", h: "17ea…9d8b", d: "3 threads" },
    { t: "listing.publish", h: "0b1f…44a7", d: "live" },
    { t: "swap.accepted", h: "9e04…7112", d: "matched" },
  ];
  return (
    <section className="hs-body-block mt-6" aria-label="Audit tape">
      <BlockHeader eyebrow="Audit" title="A very calm paper trail." />
      <div className="hs-audit">
        {rows.map((r, i) => (
          <div key={i} className="hs-audit-row">
            <span className="hs-audit-time">{String(3 + i).padStart(2, "0")}:14:0{i}</span>
            <span className="hs-audit-t">{r.t}</span>
            <span className="hs-audit-h">{r.h}</span>
            <span className="hs-audit-d">{r.d}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------ Settings ------------------------------ */
function MovementStrip() {
  return (
    <section className="hs-body-block mt-6" aria-label="Movement">
      <BlockHeader eyebrow="Cal. HS-19" title="Tuned to your preferences." />
      <div className="hs-movement">
        <svg viewBox="0 0 240 80" aria-hidden className="hs-movement-svg">
          <defs>
            <radialGradient id="hsGear" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(255,255,255,0.14)" />
              <stop offset="100%" stopColor="rgba(255,255,255,0.02)" />
            </radialGradient>
          </defs>
          {[40, 110, 180].map((cx, i) => (
            <g key={i} transform={`translate(${cx} 40)`}>
              <circle r="24" fill="url(#hsGear)" stroke="currentColor" strokeOpacity=".35" />
              {Array.from({ length: 12 }).map((_, j) => (
                <rect
                  key={j}
                  x="-1.5" y="-28" width="3" height="6"
                  fill="currentColor" opacity=".55"
                  transform={`rotate(${j * 30})`}
                />
              ))}
              <circle r="3" fill="currentColor" />
            </g>
          ))}
          <path d="M64 40 L86 40 M134 40 L156 40" stroke="currentColor" strokeOpacity=".35" />
        </svg>
        <div className="hs-movement-caption">
          <span>Baseplate · locked</span>
          <span>Mainspring · 42 h</span>
          <span>Beat · 28,800 vph</span>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ shared ------------------------------ */
function BlockHeader({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="mb-4 flex items-baseline justify-between gap-3">
      <div>
        <div className="hs-block-eyebrow">{eyebrow}</div>
        <div className="hs-block-title">{title}</div>
      </div>
      <span className="hs-block-rule" aria-hidden />
    </div>
  );
}

function sparkPath(seed: number) {
  const pts: [number, number][] = [];
  let y = 18 + ((seed * 5) % 6);
  for (let x = 0; x <= 120; x += 10) {
    y += Math.sin((x + seed * 30) / 12) * 2 + ((seed % 2 ? -1 : 1) * (x / 240));
    y = Math.max(4, Math.min(30, y));
    pts.push([x, y]);
  }
  return pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0]} ${p[1].toFixed(1)}`).join(" ");
}
