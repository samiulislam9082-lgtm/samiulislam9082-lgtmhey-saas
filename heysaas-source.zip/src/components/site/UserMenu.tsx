import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LayoutDashboard, LogOut, Plus, User as UserIcon } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAvatarUrl } from "@/hooks/useAvatarUrl";

export function UserMenu({ user }: { user: User }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [displayName, setDisplayName] = useState<string>("");
  const [avatarRef, setAvatarRef] = useState<string | null>(null);
  const avatar = useAvatarUrl(avatarRef);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("profiles").select("display_name, avatar_url").eq("id", user.id).maybeSingle();
      setDisplayName((data?.display_name as string) || user.email?.split("@")[0] || "Founder");
      setAvatarRef((data?.avatar_url as string) ?? null);
    })();
  }, [user.id, user.email]);

  const initials = (displayName || "F").slice(0, 2).toUpperCase();

  const onSignOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="rounded-full outline-none focus-visible:ring-2 focus-visible:ring-violet">
        <Avatar className="h-9 w-9 border border-hairline">
          {avatar ? <AvatarImage src={avatar} alt={displayName} /> : null}
          <AvatarFallback className="bg-surface text-xs">{initials}</AvatarFallback>
        </Avatar>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 rounded-2xl border-hairline bg-surface">
        <DropdownMenuLabel className="font-normal">
          <div className="text-sm font-medium">{displayName}</div>
          <div className="text-xs text-muted-foreground truncate">{user.email}</div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-hairline" />
        <DropdownMenuItem asChild>
          <Link to="/dashboard" className="cursor-pointer">
            <LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/list" className="cursor-pointer">
            <Plus className="h-4 w-4 mr-2" /> List your SaaS
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/dashboard" className="cursor-pointer">
            <UserIcon className="h-4 w-4 mr-2" /> Profile
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-hairline" />
        <DropdownMenuItem onClick={onSignOut} className="cursor-pointer text-foreground">
          <LogOut className="h-4 w-4 mr-2" /> Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
