import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Loader2, Eye, EyeOff, Ban, ShieldOff, Bell, Volume2, Keyboard, Type as TypeIcon, Rows3, Users, MessageSquare, RotateCcw } from "lucide-react";
import type { MessagePrefs } from "@/lib/message-prefs";

type BlockedProfile = { id: string; username: string | null; display_name: string | null; avatar_url: string | null };

export function MessageSettingsDialog({
  open,
  onOpenChange,
  presenceVisible,
  onPresenceChange,
  prefs,
  setPref,
  resetPrefs,
  stats,
  blockedIds,
  onUnblock,
  onUnmuteAll,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  presenceVisible: boolean;
  onPresenceChange: (v: boolean) => void;
  prefs: MessagePrefs;
  setPref: <K extends keyof MessagePrefs>(k: K, v: MessagePrefs[K]) => void;
  resetPrefs: () => void;
  stats: { threads: number; unread: number; muted: number; online: number };
  blockedIds: string[];
  onUnblock: (id: string) => void;
  onUnmuteAll: () => void;
}) {
  const [profiles, setProfiles] = useState<BlockedProfile[]>([]);
  const [loadingBlocked, setLoadingBlocked] = useState(false);

  useEffect(() => {
    if (!open || blockedIds.length === 0) { setProfiles([]); return; }
    let cancelled = false;
    setLoadingBlocked(true);
    supabase
      .from("profiles")
      .select("id, username, display_name, avatar_url")
      .in("id", blockedIds)
      .then(({ data }) => {
        if (cancelled) return;
        setProfiles((data || []) as BlockedProfile[]);
        setLoadingBlocked(false);
      });
    return () => { cancelled = true; };
  }, [open, blockedIds.join(",")]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto border-white/10 bg-[radial-gradient(120%_80%_at_0%_0%,color-mix(in_oklab,var(--color-foreground)_10%,transparent),transparent_60%),radial-gradient(120%_80%_at_100%_0%,color-mix(in_oklab,var(--color-foreground)_6%,transparent),transparent_55%),var(--color-card)]">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl tracking-tight">
            <span className="bg-[linear-gradient(90deg,var(--color-foreground),color-mix(in_oklab,var(--color-foreground)_55%,transparent))] bg-clip-text text-transparent">Message settings</span>
          </DialogTitle>
          <DialogDescription>Privacy, presence and how your inbox behaves. Saved on this device instantly.</DialogDescription>
        </DialogHeader>

        {/* Snapshot */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <Stat tone="color-mix(in oklab, var(--color-foreground) 44%, transparent)" icon={<MessageSquare className="h-3.5 w-3.5" />} label="Chats" value={stats.threads} />
          <Stat tone="color-mix(in oklab, var(--color-foreground) 74%, transparent)" icon={<Bell className="h-3.5 w-3.5" />} label="Unread" value={stats.unread} />
          <Stat tone="color-mix(in oklab, var(--color-foreground) 58%, transparent)" icon={<Users className="h-3.5 w-3.5" />} label="Online" value={presenceVisible ? stats.online : "—"} />
          <Stat tone="color-mix(in oklab, var(--color-foreground) 92%, transparent)" icon={<Ban className="h-3.5 w-3.5" />} label="Blocked" value={blockedIds.length} />
        </div>

        <Section title="Presence & privacy" tone="color-mix(in oklab, var(--color-foreground) 100%, transparent)">
          <Row
            tone="color-mix(in oklab, var(--color-foreground) 100%, transparent)"
            icon={presenceVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            title="Active status"
            desc={presenceVisible
              ? "Others see when you're online — and you can see who's online."
              : "You appear offline. While it's off, you also can't see anyone else's online status."}
            checked={presenceVisible}
            onChange={onPresenceChange}
          />
        </Section>

        <Section title="Conversations" tone="color-mix(in oklab, var(--color-foreground) 44%, transparent)">
          <Row
            tone="color-mix(in oklab, var(--color-foreground) 44%, transparent)"
            icon={<TypeIcon className="h-4 w-4" />}
            title="Typing indicators"
            desc="Let people see the three dots while you're writing."
            checked={prefs.typingIndicator}
            onChange={(v) => setPref("typingIndicator", v)}
          />
          <Row
            tone="color-mix(in oklab, var(--color-foreground) 44%, transparent)"
            icon={<Keyboard className="h-4 w-4" />}
            title="Press Enter to send"
            desc={prefs.enterToSend ? "Enter sends, Shift+Enter adds a line." : "Enter adds a line, use the send button."}
            checked={prefs.enterToSend}
            onChange={(v) => setPref("enterToSend", v)}
          />
          <Row
            tone="color-mix(in oklab, var(--color-foreground) 44%, transparent)"
            icon={<Volume2 className="h-4 w-4" />}
            title="New message sound"
            desc="Soft chime when a message lands while you're here."
            checked={prefs.soundOnMessage}
            onChange={(v) => setPref("soundOnMessage", v)}
          />
        </Section>

        <Section title="Appearance" tone="color-mix(in oklab, var(--color-foreground) 58%, transparent)">
          <Row
            tone="color-mix(in oklab, var(--color-foreground) 58%, transparent)"
            icon={<MessageSquare className="h-4 w-4" />}
            title="Message previews"
            desc="Show the last message text in the conversation list."
            checked={prefs.showPreviews}
            onChange={(v) => setPref("showPreviews", v)}
          />
          <Row
            tone="color-mix(in oklab, var(--color-foreground) 58%, transparent)"
            icon={<Rows3 className="h-4 w-4" />}
            title="Compact mode"
            desc="Tighter rows and bubbles — more conversations on screen."
            checked={prefs.compact}
            onChange={(v) => setPref("compact", v)}
          />
        </Section>

        <Section
          title={`Blocked people (${blockedIds.length})`}
          tone="color-mix(in oklab, var(--color-foreground) 92%, transparent)"
          action={stats.muted > 0 ? <Button variant="ghost" size="sm" className="h-7 text-xs rounded-full" onClick={onUnmuteAll}>Unmute all ({stats.muted})</Button> : null}
        >
          {blockedIds.length === 0 ? (
            <p className="px-3 py-3 text-sm text-muted-foreground">You haven't blocked anyone. Blocked people can't message you and disappear from your threads.</p>
          ) : loadingBlocked ? (
            <div className="py-6 flex justify-center"><Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /></div>
          ) : (
            <ul className="divide-y divide-white/5">
              {profiles.map((p) => (
                <li key={p.id} className="flex items-center gap-3 px-3 py-2.5">
                  {p.avatar_url ? (
                    <img src={p.avatar_url} alt="" className="h-8 w-8 rounded-full object-cover ring-1 ring-white/10" />
                  ) : (
                    <div
                      className="h-8 w-8 rounded-full grid place-items-center text-xs font-semibold text-background"
                      style={{ background: "linear-gradient(135deg, color-mix(in oklab, var(--color-foreground) 78%, transparent), color-mix(in oklab, var(--color-foreground) 38%, transparent))" }}
                    >
                      {(p.display_name || p.username || "?").charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="text-sm truncate">{p.display_name || p.username || "Unknown"}</div>
                    {p.username && <div className="text-[11px] text-muted-foreground truncate">@{p.username}</div>}
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-full h-8 border-transparent text-background hover:opacity-90"
                    style={{ background: "linear-gradient(135deg, color-mix(in oklab, var(--color-foreground) 60%, transparent), color-mix(in oklab, var(--color-foreground) 25%, transparent))" }}
                    onClick={() => onUnblock(p.id)}
                  >
                    <ShieldOff className="h-3.5 w-3.5 mr-1.5" />Unblock
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <div className="flex justify-end pt-1">
          <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground" onClick={resetPrefs}>
            <RotateCcw className="h-3.5 w-3.5 mr-1.5" />Reset to defaults
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Stat({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  return (
    <div
      className="rounded-xl border px-3 py-2.5"
      style={{
        borderColor: `color-mix(in oklab, ${tone} 30%, transparent)`,
        background: `linear-gradient(160deg, color-mix(in oklab, ${tone} 14%, transparent), transparent)`,
      }}
    >
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em]" style={{ color: tone }}>{icon}{label}</div>
      <div className="mt-1 font-display text-xl leading-none">{value}</div>
    </div>
  );
}

function Section({ title, action, children, tone }: { title: string; action?: React.ReactNode; children: React.ReactNode; tone: string }) {
  return (
    <div className="mt-1">
      <div className="flex items-center justify-between px-1 pb-1.5">
        <h3 className="text-[10px] uppercase tracking-[0.18em] flex items-center gap-1.5" style={{ color: tone }}>
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: tone, boxShadow: `0 0 8px ${tone}` }} aria-hidden />
          {title}
        </h3>
        {action}
      </div>
      <div
        className="rounded-2xl border overflow-hidden"
        style={{
          borderColor: `color-mix(in oklab, ${tone} 24%, transparent)`,
          background: `linear-gradient(180deg, color-mix(in oklab, ${tone} 7%, transparent), color-mix(in oklab, var(--color-secondary) 40%, transparent))`,
        }}
      >
        {children}
      </div>
    </div>
  );
}

function Row({ icon, title, desc, checked, onChange, tone }: { icon: React.ReactNode; title: string; desc: string; checked: boolean; onChange: (v: boolean) => void; tone: string }) {
  return (
    <div className="flex items-center justify-between gap-4 px-3 py-3 border-b border-white/5 last:border-b-0">
      <div className="flex items-start gap-2.5 min-w-0">
        <span
          className="mt-0.5 grid place-items-center h-7 w-7 rounded-lg shrink-0"
          style={{ color: tone, background: `color-mix(in oklab, ${tone} 14%, transparent)` }}
        >
          {icon}
        </span>
        <span className="min-w-0">
          <span className="block text-sm">{title}</span>
          <span className="block text-[11px] text-muted-foreground">{desc}</span>
        </span>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} aria-label={title} style={checked ? { background: tone } : undefined} />
    </div>
  );
}

