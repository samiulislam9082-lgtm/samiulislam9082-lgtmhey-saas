/**
 * Editorial ribbon that sits directly below the DashHero on every
 * dashboard page. Per-variant it renders a small "signal band" — a
 * live-feeling strip of numbers, chips or micro-widgets so the body
 * of the page picks up the hero's craft instead of dropping to a
 * plain table. Pure presentational; safe with reduced motion.
 */
import type { ReactNode } from "react";
import type { DashSignatureVariant } from "./DashSignature";

const ribbonMap: Record<DashSignatureVariant, RibbonSpec> = {
  overview: {
    label: "Cockpit signals",
    items: [
      { k: "Uptime", v: "99.99%", tone: "up" },
      { k: "Latency", v: "142ms", tone: "up" },
      { k: "Escrow health", v: "green", tone: "up" },
      { k: "Open threads", v: "3", tone: "neutral" },
      { k: "This week", v: "+2 swaps", tone: "up" },
    ],
  },
  listings: {
    label: "Shelf pulse",
    items: [
      { k: "Impressions 7d", v: "1,284", tone: "up" },
      { k: "Save rate", v: "6.8%", tone: "up" },
      { k: "Reply rate", v: "42%", tone: "up" },
      { k: "Median MRR", v: "$3.4K", tone: "neutral" },
      { k: "Freshness", v: "2d ago", tone: "neutral" },
    ],
  },
  swaps: {
    label: "Term sheet ticker",
    items: [
      { k: "In escrow", v: "$76", tone: "neutral" },
      { k: "Median close", v: "6d 4h", tone: "up" },
      { k: "Counter rate", v: "31%", tone: "neutral" },
      { k: "Ghost rate", v: "3.2%", tone: "down" },
      { k: "Signed 30d", v: "148", tone: "up" },
    ],
  },
  messages: {
    label: "Deal-room signal",
    items: [
      { k: "Response SLA", v: "18m", tone: "up" },
      { k: "Threads open", v: "12", tone: "neutral" },
      { k: "Awaiting you", v: "3", tone: "down" },
      { k: "Auto-triaged", v: "9", tone: "up" },
      { k: "Cooldown", v: "none", tone: "up" },
    ],
  },
  notifications: {
    label: "Signal sweep",
    items: [
      { k: "Strong returns", v: "6", tone: "up" },
      { k: "Watchlist", v: "14", tone: "neutral" },
      { k: "Faded 24h", v: "22", tone: "down" },
      { k: "Digest", v: "Sun 08:00", tone: "neutral" },
      { k: "Quiet hours", v: "22–07", tone: "neutral" },
    ],
  },
  bookmarks: {
    label: "Vault index",
    items: [
      { k: "Total pinned", v: "24", tone: "neutral" },
      { k: "Median MRR", v: "$4.1K", tone: "up" },
      { k: "New this week", v: "3", tone: "up" },
      { k: "Stale > 30d", v: "6", tone: "down" },
      { k: "Ready to act", v: "9", tone: "up" },
    ],
  },
  analytics: {
    label: "Market index",
    items: [
      { k: "Views 7d", v: "2,841", tone: "up", delta: "+12.4%" },
      { k: "Save rate", v: "6.1%", tone: "up", delta: "+0.8" },
      { k: "Offer rate", v: "1.9%", tone: "up", delta: "+0.3" },
      { k: "Fit score", v: "82", tone: "up", delta: "+4" },
      { k: "Match tempo", v: "1.4/d", tone: "neutral" },
    ],
  },
  payments: {
    label: "Ledger tape",
    items: [
      { k: "Held escrow", v: "$0", tone: "neutral" },
      { k: "Refund SLA", v: "24h", tone: "up" },
      { k: "Failed 30d", v: "0", tone: "up" },
      { k: "Fee model", v: "Flat $19", tone: "neutral" },
      { k: "Card on file", v: "•• 4242", tone: "neutral" },
    ],
  },
  audit: {
    label: "Audit tape",
    items: [
      { k: "Events 30d", v: "1,204", tone: "neutral" },
      { k: "Auth checks", v: "612", tone: "up" },
      { k: "Signed", v: "418", tone: "up" },
      { k: "Flags", v: "0", tone: "up" },
      { k: "Retention", v: "24 mo", tone: "neutral" },
    ],
  },
  settings: {
    label: "Cal. HS-19",
    items: [
      { k: "Profile", v: "Complete", tone: "up" },
      { k: "2FA", v: "on", tone: "up" },
      { k: "Motion", v: "auto", tone: "neutral" },
      { k: "Theme", v: "dark", tone: "neutral" },
      { k: "Digest", v: "weekly", tone: "neutral" },
    ],
  },
};

type Tone = "up" | "down" | "neutral";
type RibbonSpec = { label: string; items: { k: string; v: ReactNode; delta?: string; tone: Tone }[] };

export function DashRibbon(_: { variant: DashSignatureVariant }) {
  return null;
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const spec = ribbonMap["overview"];
  return (
    <div className="hs-dash-ribbon mt-6" role="region" aria-label={spec.label}>
      <div className="hs-dash-ribbon-label">
        <span className="hs-dash-ribbon-dot" />
        <span>{spec.label}</span>
      </div>
      <div className="hs-dash-ribbon-track">
        {spec.items.map((it, i) => (
          <div key={i} className={`hs-dash-ribbon-cell hs-dash-ribbon-cell--${it.tone}`}>
            <div className="hs-dash-ribbon-k">{it.k}</div>
            <div className="hs-dash-ribbon-v">
              <span>{it.v}</span>
              {it.delta && (
                <span className={`hs-dash-ribbon-delta hs-dash-ribbon-delta--${it.tone}`}>
                  {it.tone === "up" ? "▲" : it.tone === "down" ? "▼" : "—"} {it.delta}
                </span>
              )}
            </div>
            <span className="hs-dash-ribbon-meter" aria-hidden />
          </div>
        ))}
      </div>
    </div>
  );
}
