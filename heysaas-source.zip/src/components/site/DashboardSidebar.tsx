import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Sparkles,
  Repeat,
  MessageSquare,
  Bell,
  Bookmark,
  BarChart3,
  CreditCard,
  Settings,
  History,
  TrendingUp,
  Search,
} from "lucide-react";
import { useUnreadCounts } from "@/hooks/useUnreadCounts";
import { supabase } from "@/integrations/supabase/client";

type Item = {
  to: string;
  label: string;
  icon: typeof Sparkles;
  exact?: boolean;
  badgeKey?: "messages" | "notifications";
};

type Group = { label: string; items: Item[] };

const groups: Group[] = [
  {
    label: "Command",
    items: [
      { to: "/dashboard", label: "Overview", icon: Sparkles, exact: true },
      { to: "/dashboard/listings", label: "My SaaS", icon: Sparkles },
      { to: "/dashboard/swaps", label: "Swaps", icon: Repeat },
      { to: "/dashboard/messages", label: "Messages", icon: MessageSquare, badgeKey: "messages" },
      { to: "/dashboard/notifications", label: "Notifications", icon: Bell, badgeKey: "notifications" },
    ],
  },
  {
    label: "Analysis",
    items: [
      { to: "/dashboard/bookmarks", label: "Bookmarks", icon: Bookmark },
      { to: "/dashboard/analytics", label: "Analytics", icon: BarChart3 },
      { to: "/dashboard/growth", label: "Growth", icon: TrendingUp },
      { to: "/dashboard/seo", label: "SEO Toolkit", icon: Search },
      { to: "/dashboard/payments", label: "Payments", icon: CreditCard },
      { to: "/dashboard/audit", label: "Activity log", icon: History },
      { to: "/dashboard/settings", label: "Settings", icon: Settings },
    ],
  },
];

export function DashboardSidebar() {
  const counts = useUnreadCounts();
  const [profile, setProfile] = useState<{ display_name?: string | null; username?: string | null; avatar_url?: string | null } | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.from("profiles").select("display_name, username, avatar_url").eq("id", user.id).maybeSingle();
      setProfile(data ?? { display_name: user.email });
    })();
  }, []);

  const name = profile?.display_name || profile?.username || "Founder";
  const initial = (name || "F").slice(0, 1).toUpperCase();

  const navGroups = (
    <>
      {groups.map((group) => (
        <div key={group.label}>
          <div className="hs-side-section">
            <span>{group.label}</span>
          </div>

          {group.items.map((item) => {
            const badge = item.badgeKey ? counts[item.badgeKey] : 0;
            return (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.exact }}
                className="hs-side-link"
                activeProps={{ className: "hs-side-link active" }}
              >
                <item.icon className="h-4 w-4 opacity-80" />
                <span className="flex-1">{item.label}</span>
                {badge > 0 && <span className="hs-side-badge">{badge > 99 ? "99+" : badge}</span>}
              </Link>
            );
          })}
        </div>
      ))}
    </>
  );

  return (
    <>
      <nav className="hs-dash-mobile-nav lg:hidden" aria-label="Dashboard sections">
        {groups.flatMap((group) => group.items).map((item) => {
          const badge = item.badgeKey ? counts[item.badgeKey] : 0;
          return (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.exact }}
              className="hs-dash-mobile-link"
              activeProps={{ className: "hs-dash-mobile-link active" }}
            >
              <item.icon className="h-4 w-4" aria-hidden="true" />
              <span>{item.label}</span>
              {badge > 0 && <span className="hs-side-badge">{badge > 99 ? "99+" : badge}</span>}
            </Link>
          );
        })}
      </nav>

      <aside className="hidden lg:block w-64 shrink-0">
        <div className="sticky top-24">
          <nav className="hs-side">
            <div className="hs-side-rail" aria-hidden="true" />
            <div className="hs-side-brand-plate" aria-hidden="true">
              <span>Hey SaaS</span>
              <span>Founder desk</span>
            </div>
            <div className="hs-side-user">
              <div className="hs-side-avatar overflow-hidden">
                {profile?.avatar_url ? (
                  <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  initial
                )}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{name}</div>
                <div className="text-[11px] text-muted-foreground truncate">Founder workspace</div>
              </div>
            </div>

            {navGroups}

          </nav>
        </div>
      </aside>
    </>
  );
}
