import type { ReactNode } from "react";
import { DashSignature, type DashSignatureVariant } from "./DashSignature";

type Props = {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
  meta?: ReactNode;
  signature?: DashSignatureVariant;
};

export function DashHero({ eyebrow, title, description, actions, meta, signature }: Props) {
  return (
    <section className="hs-dash-hero mt-4 px-6 py-8 sm:px-10 sm:py-10">
      <div className="hs-dash-hero-orb hs-dash-hero-orb--a" aria-hidden />
      <div className="hs-dash-hero-orb hs-dash-hero-orb--b" aria-hidden />
      <span className="hs-dash-hero-corner hs-dash-hero-corner--tl" aria-hidden />
      <span className="hs-dash-hero-corner hs-dash-hero-corner--br" aria-hidden />
      <div className="hs-dash-hero-mast" aria-hidden="true">
        <span>Private marketplace desk</span>
        <span>HS · 19</span>
      </div>
      <div className="relative z-10 flex flex-wrap items-start justify-between gap-8">
        <div className="min-w-0 max-w-2xl flex-1">
          {eyebrow && (
            <span className="hs-dash-eyebrow">
              <span className="hs-dash-eyebrow-dot" aria-hidden />
              {eyebrow}
            </span>
          )}
          <h1 className="mt-4 font-display text-4xl md:text-5xl leading-[1.05] tracking-tight">
            {title}
          </h1>
          {description && (
            <p className="mt-3 text-[15px] text-muted-foreground max-w-xl leading-relaxed">
              {description}
            </p>
          )}
          {meta && <div className="mt-5">{meta}</div>}
          {actions && <div className="mt-6 flex items-center gap-2 flex-wrap">{actions}</div>}
        </div>
        {signature && (
          <div className="hs-dash-hero-signature w-full max-w-[320px] md:w-[260px] shrink-0">
            <DashSignature variant={signature} />
          </div>
        )}
      </div>
    </section>
  );
}
