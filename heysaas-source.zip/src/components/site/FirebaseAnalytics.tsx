import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";
import { getFirebaseAnalytics, trackEvent } from "@/lib/firebase";

export function FirebaseAnalytics() {
  const router = useRouter();

  useEffect(() => {
    // warm up analytics on mount
    void getFirebaseAnalytics();
  }, []);

  useEffect(() => {
    const unsub = router.subscribe("onResolved", ({ toLocation }) => {
      void trackEvent("page_view", {
        page_path: toLocation.pathname,
        page_location: typeof window !== "undefined" ? window.location.href : undefined,
      });
    });
    return () => {
      unsub();
    };
  }, [router]);

  return null;
}
