import { useEffect, useMemo, useState } from "react";
import { X, Activity, AlertTriangle, CheckCircle2, Copy, Download, Search, Plus } from "lucide-react";
import {
  isMotionDebugEnabled,
  isMotionDebugStrict,
  setMotionDebugEnabled,
  setMotionDebugStrict,
  subscribeMotionSuppression,
  syncMotionDebugFromUrl,
  reportMotionSuppression,
  getBufferedEvents,
  clearBufferedEvents,
  type MotionSuppressionEvent,
} from "@/lib/motion-debug";
import { motionPreferenceIsReduced } from "@/lib/motion";
import { findScrollAllowlistMatch } from "@/config/motion-scroll-allowlist";
import { recordLeakForCandidate } from "@/lib/motion-candidates";

/**
 * Lightweight, dev-only motion QA indicator.
 * Only renders when the debug flag is enabled — zero cost otherwise.
 */
type FilterMode = "all" | "leak" | "suppressed";
type SortMode = "time-desc" | "time-asc" | "route";

export function MotionDebugIndicator() {
  const [enabled, setEnabled] = useState(false);
  const [strict, setStrict] = useState(false);
  const [events, setEvents] = useState<MotionSuppressionEvent[]>([]);
  const [open, setOpen] = useState(true);
  const [reduced, setReduced] = useState(false);
  const [route, setRoute] = useState<string>("");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterMode>("all");
  const [sort, setSort] = useState<SortMode>("time-desc");

  useEffect(() => {
    syncMotionDebugFromUrl();
    setEnabled(isMotionDebugEnabled());
    setStrict(isMotionDebugStrict());
    setReduced(motionPreferenceIsReduced());
    if (typeof location !== "undefined") setRoute(location.pathname + location.search);
    const onToggle = (e: Event) => setEnabled(Boolean((e as CustomEvent).detail));
    const onMotion = () => setReduced(motionPreferenceIsReduced());
    const onNav = () => setRoute(location.pathname + location.search);
    window.addEventListener("motiondebugtoggle", onToggle as EventListener);
    window.addEventListener("motionpreferencechange", onMotion);
    window.addEventListener("popstate", onNav);
    window.addEventListener("hashchange", onNav);
    const iv = window.setInterval(onNav, 500);
    return () => {
      window.removeEventListener("motiondebugtoggle", onToggle as EventListener);
      window.removeEventListener("motionpreferencechange", onMotion);
      window.removeEventListener("popstate", onNav);
      window.removeEventListener("hashchange", onNav);
      window.clearInterval(iv);
    };
  }, []);

  useEffect(() => {
    if (!enabled) return;
    setEvents(getBufferedEvents().slice(-200).reverse());
    const unsub = subscribeMotionSuppression((e) => {
      setEvents((prev) => [e, ...prev].slice(0, 200));
      // Auto-fold repeated CSS leaks into candidate proposals.
      try { recordLeakForCandidate(e); } catch { /* ignore */ }
    });
    const restore = installScrollProbe();
    const stopCss = installCssScrollAuditor();
    return () => { unsub(); restore(); stopCss(); };
  }, [enabled]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    let out = events.filter((e) => {
      if (filter !== "all" && e.kind !== filter) return false;
      if (!q) return true;
      return (
        e.source.toLowerCase().includes(q) ||
        (e.route ?? "").toLowerCase().includes(q) ||
        (e.detail ?? "").toLowerCase().includes(q) ||
        (e.callsite ?? "").toLowerCase().includes(q) ||
        (e.ruleId ?? "").toLowerCase().includes(q)
      );
    });
    if (sort === "time-asc") out = [...out].sort((a, b) => a.ts - b.ts);
    else if (sort === "route") out = [...out].sort((a, b) => (a.route ?? "").localeCompare(b.route ?? ""));
    else out = [...out].sort((a, b) => b.ts - a.ts);
    return out;
  }, [events, query, filter, sort]);

  if (!enabled) return null;
  const leaks = events.filter((e) => e.kind === "leak").length;
  const suppressed = events.length - leaks;

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(getBufferedEvents(), null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `motion-debug-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const copyJson = async () => {
    try { await navigator.clipboard.writeText(JSON.stringify(getBufferedEvents(), null, 2)); } catch { /* ignore */ }
  };

  const chip = (mode: FilterMode, label: string, tone: string, count: number) => (
    <button
      type="button"
      onClick={() => setFilter(mode)}
      className={
        "rounded-md border px-1.5 py-0.5 text-[10px] uppercase tracking-widest " +
        (filter === mode
          ? `${tone} border-current`
          : "border-hairline text-muted-foreground hover:text-foreground")
      }
    >
      {label} · {count}
    </button>
  );

  return (
    <div
      className="pointer-events-auto fixed bottom-3 left-3 z-[9999] max-w-[380px] rounded-xl border border-hairline bg-background/95 text-foreground shadow-2xl backdrop-blur"
      role="status"
      aria-live="polite"
      aria-label="Motion debug indicator"
      style={{ fontFamily: "ui-sans-serif, system-ui" }}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-2 rounded-t-xl px-3 py-2 text-xs"
      >
        <span className="inline-flex items-center gap-2">
          <span
            className={
              "inline-flex h-2 w-2 rounded-full " +
              (leaks > 0
                ? "bg-rose-500 animate-pulse"
                : reduced
                  ? "bg-emerald-500"
                  : "bg-amber-500")
            }
            aria-hidden
          />
          <Activity className="h-3.5 w-3.5" aria-hidden />
          <span className="font-semibold tracking-tight">Motion debug</span>
          <span className="rounded-md bg-muted px-1.5 py-0.5 text-[10px] uppercase tracking-widest text-muted-foreground">
            {reduced ? "reduced" : "full"}
          </span>
          <span className="text-muted-foreground">· {events.length}</span>
          {leaks > 0 && (
            <span className="text-rose-500 font-medium">{leaks} leak{leaks === 1 ? "" : "s"}</span>
          )}
        </span>
        <span className="text-muted-foreground">{open ? "–" : "+"}</span>
      </button>

      {open && (
        <div className="border-t border-hairline">
          <div className="px-3 py-1.5 text-[10px] text-muted-foreground truncate border-b border-hairline/60">
            route: <span className="text-foreground">{route || "—"}</span>
          </div>
          <div className="flex items-center gap-1.5 border-b border-hairline/60 px-3 py-1.5">
            <Search className="h-3 w-3 text-muted-foreground" aria-hidden />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="search source / route / rule…"
              className="flex-1 bg-transparent text-[11px] outline-none placeholder:text-muted-foreground"
              aria-label="Search motion debug events"
            />
          </div>
          <div className="flex flex-wrap items-center gap-1 border-b border-hairline/60 px-3 py-1.5">
            {chip("all", "all", "text-foreground", events.length)}
            {chip("leak", "leak", "text-rose-500", leaks)}
            {chip("suppressed", "allow", "text-emerald-500", suppressed)}
            <span className="ml-auto inline-flex items-center gap-1">
              <label className="text-[10px] text-muted-foreground">sort</label>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortMode)}
                className="rounded border border-hairline bg-background px-1 py-0.5 text-[10px]"
                aria-label="Sort events"
              >
                <option value="time-desc">time ↓</option>
                <option value="time-asc">time ↑</option>
                <option value="route">route</option>
              </select>
            </span>
          </div>
          {!reduced && (
            <p className="px-3 py-2 text-[11px] text-muted-foreground">
              Effective motion is <span className="font-medium text-foreground">full</span>.
              Enable "Reduced motion" in Settings or your OS to see suppressions.
            </p>
          )}
          <ul className="max-h-72 overflow-auto text-[11px]">
            {visible.length === 0 && (
              <li className="px-3 py-3 text-muted-foreground">No events match.</li>
            )}
            {visible.map((e) => {
              const candidate =
                e.kind === "leak" && (e.source.includes("scroll-snap") || e.source.includes("scroll-behavior"));
              return (
                <li key={e.id} className="flex items-start gap-2 border-t border-hairline/60 px-3 py-1.5">
                  {e.kind === "leak" ? (
                    <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-500" aria-hidden />
                  ) : (
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" aria-hidden />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium">{e.source}</div>
                    {e.route && <div className="truncate text-muted-foreground">at {e.route}</div>}
                    {e.callsite && (
                      <div className="truncate text-muted-foreground" title={e.stack}>
                        <a
                          href={e.callsite.startsWith("http") ? e.callsite : undefined}
                          className="underline decoration-dotted"
                        >{e.callsite}</a>
                      </div>
                    )}
                    {e.detail && <div className="truncate text-muted-foreground">{e.detail}</div>}
                    {e.ruleId && (
                      <div className="mt-0.5 flex items-start gap-1 text-emerald-500/90 text-[10px]">
                        <span className="rounded bg-emerald-500/10 px-1 py-px font-mono">allow:{e.ruleId}</span>
                        {e.ruleReason && <span className="text-muted-foreground">{e.ruleReason}</span>}
                      </div>
                    )}
                    {e.hint && (
                      <div className="text-rose-500/90 text-[10px] mt-0.5">↳ {e.hint}</div>
                    )}
                    {candidate && (
                      <button
                        type="button"
                        onClick={() => { recordLeakForCandidate(e); }}
                        className="mt-0.5 inline-flex items-center gap-1 rounded border border-hairline px-1 py-px text-[10px] text-muted-foreground hover:text-foreground"
                        title="Fold this leak into an allowlist candidate rule (review in admin)"
                      >
                        <Plus className="h-2.5 w-2.5" /> propose rule
                      </button>
                    )}
                  </div>
                  <time className="shrink-0 text-muted-foreground tabular-nums">
                    {new Date(e.ts).toLocaleTimeString([], { hour12: false })}
                  </time>
                </li>
              );
            })}
          </ul>
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-hairline px-3 py-2 text-[11px]">
            <div className="flex items-center gap-1">
              <button type="button" className="rounded-md border border-hairline px-2 py-1 hover:bg-muted"
                onClick={() => { clearBufferedEvents(); setEvents([]); }}>Clear</button>
              <button type="button" className="inline-flex items-center gap-1 rounded-md border border-hairline px-2 py-1 hover:bg-muted"
                onClick={copyJson} title="Copy last 200 events as JSON"><Copy className="h-3 w-3" /> Copy</button>
              <button type="button" className="inline-flex items-center gap-1 rounded-md border border-hairline px-2 py-1 hover:bg-muted"
                onClick={downloadJson} title="Download last 200 events as JSON"><Download className="h-3 w-3" /> JSON</button>
              <label className="inline-flex items-center gap-1 ml-1 select-none" title="Fail tests on leak">
                <input type="checkbox" checked={strict}
                  onChange={(e) => { setStrict(e.target.checked); setMotionDebugStrict(e.target.checked); }} />
                strict
              </label>
            </div>
            <button type="button" onClick={() => setMotionDebugEnabled(false)}
              className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground"
              aria-label="Disable motion debug">
              <X className="h-3 w-3" /> Disable
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// -------------------- probes (unchanged) --------------------

let sanctioned = 0;
export function markSanctionedScroll<T>(fn: () => T): T {
  sanctioned++;
  try { return fn(); } finally { sanctioned--; }
}

function installScrollProbe(): () => void {
  if (typeof window === "undefined") return () => {};
  const origElScrollTo = Element.prototype.scrollTo;
  const origElScrollIntoView = Element.prototype.scrollIntoView;
  const origWinScrollTo = window.scrollTo.bind(window);

  const observe = (label: string, arg: unknown) => {
    if (!motionPreferenceIsReduced()) return;
    const behavior =
      arg && typeof arg === "object" && "behavior" in (arg as ScrollToOptions)
        ? (arg as ScrollToOptions).behavior
        : undefined;
    if (behavior !== "smooth") return;
    const kind = sanctioned > 0 ? "suppressed" : "leak";
    const stack = new Error().stack;
    reportMotionSuppression(label, {
      kind,
      detail: kind === "leak" ? "raw smooth call" : undefined,
      stack,
    });
  };

  Element.prototype.scrollTo = function (this: Element, ...args: unknown[]) {
    observe("Element.scrollTo", args[0]);
    return (origElScrollTo as any).apply(this, args);
  } as typeof Element.prototype.scrollTo;

  Element.prototype.scrollIntoView = function (this: Element, ...args: unknown[]) {
    observe("Element.scrollIntoView", args[0]);
    return (origElScrollIntoView as any).apply(this, args);
  } as typeof Element.prototype.scrollIntoView;

  (window as any).scrollTo = function (...args: unknown[]) {
    observe("window.scrollTo", args[0]);
    return (origWinScrollTo as any).apply(window, args);
  };

  return () => {
    Element.prototype.scrollTo = origElScrollTo;
    Element.prototype.scrollIntoView = origElScrollIntoView;
    (window as any).scrollTo = origWinScrollTo;
  };
}

function installCssScrollAuditor(): () => void {
  if (typeof window === "undefined" || typeof MutationObserver === "undefined") return () => {};
  const seenKey = (el: Element, kind: string) => {
    const marker = `__md_${kind}` as const;
    if ((el as any)[marker]) return true;
    (el as any)[marker] = true;
    return false;
  };
  const audit = () => {
    if (!motionPreferenceIsReduced()) return;
    const all = document.querySelectorAll<HTMLElement>("*");
    for (const el of Array.from(all)) {
      const cs = getComputedStyle(el);
      if (cs.scrollBehavior === "smooth" && !seenKey(el, "smooth")) {
        const match = findScrollAllowlistMatch(el, "scroll-behavior-smooth");
        reportMotionSuppression("css.scroll-behavior:smooth", {
          kind: match ? "suppressed" : "leak",
          detail: `on <${el.tagName.toLowerCase()}${el.id ? "#" + el.id : ""}${el.className ? "." + String(el.className).split(/\s+/).slice(0, 2).join(".") : ""}>`,
          ruleId: match?.rule.id,
          ruleReason: match?.rule.reason,
        });
      }
      const snap = cs.getPropertyValue("scroll-snap-type").trim();
      if (snap && snap !== "none" && !seenKey(el, "snap")) {
        const match = findScrollAllowlistMatch(el, "scroll-snap");
        reportMotionSuppression("css.scroll-snap-type", {
          kind: match ? "suppressed" : "leak",
          detail: `${snap} on <${el.tagName.toLowerCase()}${el.id ? "#" + el.id : ""}>`,
          ruleId: match?.rule.id,
          ruleReason: match?.rule.reason,
        });
      }
    }
  };
  let scheduled = false;
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    window.setTimeout(() => { scheduled = false; audit(); }, 500);
  };
  audit();
  const mo = new MutationObserver(schedule);
  mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ["class", "style", "data-motion"] });
  const onMotion = () => audit();
  window.addEventListener("motionpreferencechange", onMotion);
  return () => { mo.disconnect(); window.removeEventListener("motionpreferencechange", onMotion); };
}
