import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { UserPlus, UserCheck } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

export function FollowButton({ targetId }: { targetId: string }) {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!mounted) return;
      setUserId(user?.id ?? null);
      if (!user || user.id === targetId) return;
      const { data } = await supabase
        .from("follows")
        .select("id")
        .eq("follower_id", user.id)
        .eq("following_id", targetId)
        .maybeSingle();
      if (mounted) setFollowing(!!data);
    })();
    return () => { mounted = false; };
  }, [targetId]);

  if (userId === targetId) return null;

  async function toggle() {
    if (!userId) return navigate({ to: "/auth" });
    setBusy(true);
    try {
      if (following) {
        const { error } = await supabase
          .from("follows")
          .delete()
          .eq("follower_id", userId)
          .eq("following_id", targetId);
        if (error) throw error;
        setFollowing(false);
      } else {
        const { error } = await supabase
          .from("follows")
          .insert({ follower_id: userId, following_id: targetId });
        if (error) throw error;
        setFollowing(true);
      }
    } catch (err) {
      console.error(err);
      toast.error("Could not update follow");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Button
      variant={following ? "outline" : "default"}
      onClick={toggle}
      disabled={busy}
      className={`rounded-full ${following ? "" : "bg-foreground text-background hover:opacity-90"}`}
    >
      {following ? (
        <><UserCheck className="h-4 w-4 mr-2" /> Following</>
      ) : (
        <><UserPlus className="h-4 w-4 mr-2" /> Follow</>
      )}
    </Button>
  );
}
