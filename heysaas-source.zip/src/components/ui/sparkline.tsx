/**
 * Sparkline — the single visual spec used by every KPI ribbon
 * across HeySaaS and WebSwap.
 *
 * Spec:
 *  - viewBox 100 × 40, preserveAspectRatio="none" for fluid width
 *  - stroke 1.5px, uses currentColor (inherits from KPI tone)
 *  - gradient area fill: currentColor → transparent (60% top opacity)
 *  - last-point marker: 3px filled dot + 6px halo
 *  - empty state: dashed baseline + "No data yet" label
 *  - 400ms path draw on mount; skipped under reduced motion
 */
import { useEffect, useId, useRef, useState } from "react";
import { motionPreferenceIsReduced } from "@/lib/motion";
import { cn } from "@/lib/utils";

export type SparklineProps = {
  points?: number[] | null;
  className?: string;
  height?: number;
  ariaLabel?: string;
};

export function Sparkline({
  points,
  className,
  height = 40,
  ariaLabel,
}: SparklineProps) {
  const gid = useId();
  const pathRef = useRef<SVGPathElement>(null);
  const [len, setLen] = useState(0);

  const data = points && points.length > 1 ? points : null;

  useEffect(() => {
    if (!data || !pathRef.current) return;
    const l = pathRef.current.getTotalLength();
    setLen(l);
  }, [data]);

  if (!data) {
    return (
      <div
        className={cn(
          "relative flex items-center overflow-hidden text-muted-foreground",
          className
        )}
        style={{ height }}
        aria-label={ariaLabel ?? "No data yet"}
      >
        <div
          aria-hidden
          className="w-full border-t border-dashed border-current opacity-40"
        />
        <span className="pointer-events-none absolute inset-0 flex items-center justify-center text-[10px] uppercase tracking-widest opacity-70">
          No data yet
        </span>
      </div>
    );
  }

  const W = 100;
  const H = 40;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const step = W / (data.length - 1);
  const coords = data.map((v, i) => {
    const x = i * step;
    const y = H - ((v - min) / span) * (H - 4) - 2;
    return [x, y] as const;
  });
  const line = coords
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`)
    .join(" ");
  const area = `${line} L${W},${H} L0,${H} Z`;
  const [lx, ly] = coords[coords.length - 1];

  const reduced = motionPreferenceIsReduced();

  return (
    <svg
      className={cn("block w-full", className)}
      height={height}
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      role="img"
      aria-label={ariaLabel ?? "Trend"}
    >
      <defs>
        <linearGradient id={`spk-${gid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="currentColor" stopOpacity="0.6" />
          <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#spk-${gid})`} opacity="0.9" />
      <path
        ref={pathRef}
        d={line}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
        style={
          reduced || !len
            ? undefined
            : {
                strokeDasharray: len,
                strokeDashoffset: len,
                animation: "spk-draw 400ms cubic-bezier(0.16,1,0.3,1) forwards",
              }
        }
      />
      {/* Last-point marker: halo + dot */}
      <circle cx={lx} cy={ly} r="6" fill="currentColor" opacity="0.15" />
      <circle cx={lx} cy={ly} r="3" fill="currentColor" />
      <style>{`@keyframes spk-draw { to { stroke-dashoffset: 0; } }`}</style>
    </svg>
  );
}
