/**
 * Kpi — shared KPI ribbon primitive used by every dashboard in the app.
 * Guarantees consistent typography (tabular-nums, display serif),
 * formatting (via formatFinancial), delta color semantics, and sparkline spec.
 */
import { useEffect, useRef, useState } from "react";
import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { formatFinancial, type FinancialFormat } from "@/lib/format";
import { motionPreferenceIsReduced } from "@/lib/motion";
import { reportMotionSuppression } from "@/lib/motion-debug";
import { Sparkline } from "./sparkline";

export type KpiTone = "default" | "ws";

export type KpiProps = {
  label: string;
  value: number | string;
  format?: FinancialFormat;
  currency?: string;
  /** Fractional change, e.g. 0.124 = +12.4%. */
  delta?: number | null;
  /** Optional trend series for the sparkline. */
  spark?: number[] | null;
  /** Short caption below the value (e.g. "in last 7 days"). */
  sub?: string;
  icon?: React.ComponentType<{ className?: string }>;
  /** Wraps the ribbon in a Link when set. */
  to?: string;
  tone?: KpiTone;
  className?: string;
};

export function Kpi({
  label,
  value,
  format = "number",
  currency,
  delta,
  spark,
  sub,
  icon: Icon,
  to,
  tone = "default",
  className,
}: KpiProps) {
  const numericValue = typeof value === "number" ? value : null;
  const displayValue =
    typeof value === "string"
      ? value
      : formatFinancial(numericValue, format, { currency });

  const shell = (
    <div
      className={cn(
        "group relative flex h-full flex-col rounded-2xl border p-5 transition-[transform,border-color,box-shadow] duration-200",
        tone === "ws"
          ? "border-[color:var(--ws-line,#1a4a6e)]/60 bg-[color:var(--ws-panel,#0c2340)]/60 hover:border-[color:var(--ws-teal,#2dd4bf)]/60"
          : "border-hairline bg-surface hover:border-foreground/25 hover:-translate-y-0.5",
        to && "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div
          className={cn(
            "text-[10px] font-semibold uppercase tracking-[0.22em]",
            tone === "ws" ? "text-[color:var(--ws-mute,#7d94ad)]" : "text-muted-foreground"
          )}
        >
          {label}
        </div>
        {Icon ? (
          <Icon
            className={cn(
              "h-4 w-4 shrink-0",
              tone === "ws" ? "text-[color:var(--ws-mute,#7d94ad)]" : "text-muted-foreground"
            )}
          />
        ) : null}
      </div>

      <AnimatedValue
        value={numericValue}
        format={format}
        currency={currency}
        fallback={displayValue}
        className={cn(
          "mt-3 font-display tabular-nums leading-none",
          tone === "ws" ? "text-4xl italic text-[color:var(--ws-ink,#f5f7fa)]" : "text-3xl md:text-4xl text-foreground"
        )}
      />

      <div className="mt-2 flex items-center gap-2 text-xs">
        <DeltaPill delta={delta ?? null} tone={tone} />
        {sub && (
          <span
            className={cn(
              "truncate",
              tone === "ws" ? "text-[color:var(--ws-mute,#7d94ad)]" : "text-muted-foreground"
            )}
          >
            {sub}
          </span>
        )}
      </div>

      <div
        className={cn(
          "mt-4 flex items-end justify-between",
          tone === "ws" ? "text-[color:var(--ws-teal,#2dd4bf)]" : "text-violet"
        )}
      >
        <div className="min-w-0 flex-1">
          <Sparkline points={spark ?? null} ariaLabel={`${label} trend`} />
        </div>
        <span
          className={cn(
            "ml-3 shrink-0 text-[10px] font-semibold uppercase tracking-widest",
            tone === "ws" ? "text-[color:var(--ws-mute,#7d94ad)]" : "text-muted-foreground"
          )}
        >
          7d
        </span>
      </div>
    </div>
  );

  if (to) {
    return (
      <Link to={to} className="block h-full">
        {shell}
      </Link>
    );
  }
  return shell;
}

function DeltaPill({ delta, tone }: { delta: number | null; tone: KpiTone }) {
  if (delta == null || Number.isNaN(delta)) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 text-muted-foreground",
          tone === "ws" && "text-[color:var(--ws-mute,#7d94ad)]"
        )}
      >
        <Minus className="h-3 w-3" /> —
      </span>
    );
  }
  const dir = delta > 0 ? "up" : delta < 0 ? "down" : "flat";
  const Icon = dir === "up" ? ArrowUpRight : dir === "down" ? ArrowDownRight : Minus;
  const color =
    dir === "up"
      ? "text-emerald-500 dark:text-emerald-400"
      : dir === "down"
        ? "text-rose-500 dark:text-rose-400"
        : "text-muted-foreground";
  const label = `${dir === "up" ? "+" : ""}${(delta * 100).toFixed(1)}%`;
  return (
    <span className={cn("inline-flex items-center gap-1 font-medium tabular-nums", color)}>
      <Icon className="h-3 w-3" /> {label}
    </span>
  );
}

function AnimatedValue({
  value,
  format,
  currency,
  fallback,
  className,
}: {
  value: number | null;
  format: FinancialFormat;
  currency?: string;
  fallback: string;
  className?: string;
}) {
  const [n, setN] = useState<number | null>(value);
  const started = useRef<number | null>(null);
  useEffect(() => {
    if (value == null) {
      setN(null);
      started.current = null;
      return;
    }
    if (motionPreferenceIsReduced()) {
      reportMotionSuppression("kpi.CountUp", { detail: String(value) });
      setN(value);
      return;
    }
    if (started.current === value) return;
    started.current = value;
    const duration = 700;
    const from = 0;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(from + (value - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else setN(value);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);

  const text =
    value == null
      ? fallback
      : n == null
        ? fallback
        : formatFinancial(n, format, { currency });
  return <div className={className} data-kpi-value>{text}</div>;
}
