import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import {
  LayoutGrid,
  Compass,
  PlusCircle,
  MessageSquare,
  Heart,
  LogIn,
  Menu,
  X,
  ChevronDown,
  Check,
  Globe,
  Sparkles,
  ArrowLeftRight,
} from "lucide-react";

/**
 * WebSwap shell — "Magazine Gallery" design language.
 * Scoped via `.ws-root` so it never bleeds into HeySaaS.
 */
export function WebSwapShell({
  children,
  variant = "marketing",
}: {
  children: ReactNode;
  /** marketing = expressive background; app = calmer for data pages */
  variant?: "marketing" | "app";
}) {
  const [user, setUser] = useState<User | null>(null);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <div className="ws-root relative min-h-dvh antialiased">
      {/* Background system */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {variant === "marketing" && <div className="ws-mesh ws-mesh-anim" />}
        <div className="ws-grid" style={variant === "app" ? { opacity: 0.5 } : undefined} />
        <div className="ws-noise" />
      </div>

      {/* Product switcher strip */}
      <ProductSwitcher />

      <header className="relative z-20 border-b border-[#1a4a6e]/50 backdrop-blur supports-[backdrop-filter]:bg-[#04101a]/70">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link to="/websites" className="flex items-baseline gap-0.5 shrink-0 group">
            <span className="ws-serif text-2xl italic text-white tracking-tight">Web</span>
            <span className="ws-serif text-2xl italic text-[#2dd4bf] tracking-tight">Swap</span>
            <span className="ml-2 hidden sm:inline text-[10px] uppercase tracking-[0.2em] font-semibold text-[#e2b464]/80">
              Est. 2026
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <ShellNavLink to="/websites" exact>Home</ShellNavLink>
            <ShellNavLink to="/websites/browse">Marketplace</ShellNavLink>
            {user && <ShellNavLink to="/websites/dashboard">Console</ShellNavLink>}
          </nav>

          <div className="flex items-center gap-2">
            {user ? (
              <button
                className="hidden sm:inline-flex ws-btn-primary items-center gap-1.5"
                onClick={() => navigate({ to: "/websites/dashboard/listings/new" })}
              >
                <PlusCircle className="h-3.5 w-3.5" /> List
              </button>
            ) : (
              <button
                className="ws-btn-primary inline-flex items-center gap-1.5"
                onClick={() => navigate({ to: "/auth" })}
              >
                <LogIn className="h-3.5 w-3.5" /> Sign in
              </button>
            )}
            <button
              className="md:hidden inline-flex items-center justify-center h-10 w-10 rounded-sm border border-[#1a4a6e] text-[#f5f7fa] hover:border-[#2dd4bf] hover:text-[#2dd4bf]"
              onClick={() => setOpen((o) => !o)}
              aria-label="Toggle navigation"
              aria-expanded={open}
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="md:hidden border-t border-[#1a4a6e]/50 bg-[#04101a]/95">
            <nav className="mx-auto max-w-7xl px-4 py-3 space-y-1">
              {[
                { to: "/websites", label: "Home", exact: true },
                { to: "/websites/browse", label: "Marketplace" },
                ...(user ? [{ to: "/websites/dashboard", label: "Console" }] : []),
              ].map((n) => (
                <Link
                  key={n.to}
                  to={n.to}
                  onClick={() => setOpen(false)}
                  className="block px-3 py-3 text-sm text-[#e6eef7] hover:bg-[#1a4a6e]/30"
                  activeProps={{ className: "block px-3 py-3 text-sm text-[#2dd4bf] bg-[#1a4a6e]/30" }}
                  activeOptions={{ exact: n.exact }}
                >
                  {n.label}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </header>

      <main id="main" className="relative z-10">{children}</main>

      <footer className="relative z-10 mt-24 border-t border-[#1a4a6e]/40">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 grid gap-6 md:grid-cols-3 items-start">
          <div>
            <div className="flex items-baseline gap-0.5">
              <span className="ws-serif text-2xl italic text-white">Web</span>
              <span className="ws-serif text-2xl italic text-[#2dd4bf]">Swap</span>
            </div>
            <p className="mt-2 text-xs text-[#7d94ad] max-w-xs">
              The verified marketplace for websites and online businesses. DNS-verified sellers, transparent numbers.
            </p>
          </div>
          <div className="text-xs text-[#7d94ad] uppercase tracking-[0.2em]">
            © {new Date().getFullYear()} WebSwap · A HeySaaS product
          </div>
          <div className="flex md:justify-end gap-6 text-xs uppercase tracking-widest text-[#7d94ad]">
            <Link to="/legal/terms" className="hover:text-[#2dd4bf]">Terms</Link>
            <Link to="/legal/privacy" className="hover:text-[#2dd4bf]">Privacy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ShellNavLink({
  to,
  exact,
  children,
}: {
  to: string;
  exact?: boolean;
  children: ReactNode;
}) {
  return (
    <Link
      to={to}
      className="relative text-sm text-[#c7d5e6] hover:text-white transition-colors py-1"
      activeProps={{
        className:
          "relative text-sm text-white font-medium py-1 after:absolute after:left-0 after:right-0 after:-bottom-1 after:h-[2px] after:bg-[#2dd4bf]",
      }}
      activeOptions={{ exact }}
    >
      {children}
    </Link>
  );
}

/** Workspace-style product switcher — HeySaaS ↔ WebSwap. */
function ProductSwitcher() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);
  return (
    <div className="relative z-30 border-b border-[#1a4a6e]/40 bg-[#03080f]/80 text-xs">
      <div className="mx-auto flex h-9 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 text-[#7d94ad]">
          <ArrowLeftRight className="h-3 w-3 text-[#2dd4bf]" />
          <span className="hidden sm:inline">Verified marketplace for websites & online businesses</span>
          <span className="sm:hidden">Verified marketplace</span>
        </div>
        <div ref={ref} className="relative">
          <button
            onClick={() => setOpen((o) => !o)}
            className="inline-flex items-center gap-2 rounded-sm px-2 py-1 text-[#c7d5e6] hover:bg-[#1a4a6e]/30 hover:text-white transition"
            aria-haspopup="menu"
            aria-expanded={open}
          >
            <span className="inline-flex h-4 w-4 items-center justify-center rounded-sm bg-[#2dd4bf] text-[#04101a]">
              <Globe className="h-2.5 w-2.5" strokeWidth={3} />
            </span>
            <span className="font-semibold text-white">WebSwap</span>
            <ChevronDown className="h-3 w-3" />
          </button>
          {open && (
            <div
              role="menu"
              className="absolute right-0 top-9 w-72 rounded-sm border border-[#1a4a6e] bg-[#04101a] shadow-2xl shadow-black/60 overflow-hidden"
            >
              <div className="px-3 py-2 text-[10px] uppercase tracking-[0.2em] text-[#7d94ad] border-b border-[#1a4a6e]/60">
                Switch workspace
              </div>
              <a
                href="/websites"
                className="flex items-start gap-3 px-3 py-3 bg-[#0c2340]/60"
                role="menuitem"
              >
                <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-sm bg-[#2dd4bf] text-[#04101a]">
                  <Globe className="h-4 w-4" strokeWidth={2.4} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-semibold text-white">WebSwap</span>
                    <Check className="h-3.5 w-3.5 text-[#2dd4bf]" />
                  </div>
                  <div className="text-[11px] text-[#7d94ad]">Websites & online businesses</div>
                </div>
              </a>
              <a
                href="/"
                className="flex items-start gap-3 px-3 py-3 hover:bg-[#0c2340]/60 transition"
                role="menuitem"
              >
                <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-sm bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white">
                  <Sparkles className="h-4 w-4" strokeWidth={2.4} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-white">HeySaaS</div>
                  <div className="text-[11px] text-[#7d94ad]">SaaS-for-SaaS founder swaps</div>
                </div>
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/** Sidebar (rail) for the WebSwap console. Grouped, distinctive active state. */
export function WsSidebar() {
  const currentPath = useRouterState({ select: (r) => r.location.pathname });
  const groups: { label: string; items: { to: string; label: string; icon: typeof LayoutGrid; exact?: boolean }[] }[] = [
    {
      label: "Console",
      items: [
        { to: "/websites/dashboard", label: "Overview", icon: LayoutGrid, exact: true },
        { to: "/websites/dashboard/listings", label: "Inventory", icon: Globe },
      ],
    },
    {
      label: "Deals",
      items: [
        { to: "/websites/dashboard/messages", label: "Inquiries", icon: MessageSquare },
        { to: "/websites/dashboard/watchlist", label: "Watchlist", icon: Heart },
      ],
    },
    {
      label: "Discover",
      items: [{ to: "/websites/browse", label: "Marketplace", icon: Compass }],
    },
  ];

  const isActive = (to: string, exact?: boolean) =>
    exact ? currentPath === to : currentPath === to || currentPath.startsWith(to + "/");

  return (
    <>
      {/* Desktop rail */}
      <aside className="hidden md:block w-60 shrink-0">
        <div className="sticky top-24 space-y-8">
          {groups.map((g) => (
            <div key={g.label}>
              <div className="mb-3 px-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-[#7d94ad]">
                {g.label}
              </div>
              <nav className="space-y-0.5">
                {g.items.map((it) => {
                  const active = isActive(it.to, it.exact);
                  return (
                    <Link
                      key={it.to}
                      to={it.to}
                      className={
                        active
                          ? "group relative flex items-center gap-3 rounded-sm px-3 py-2 text-sm font-medium text-white bg-gradient-to-r from-[#1a4a6e]/70 to-[#0c2340]/40 before:absolute before:inset-y-1.5 before:left-0 before:w-[3px] before:bg-[#2dd4bf]"
                          : "group flex items-center gap-3 rounded-sm px-3 py-2 text-sm text-[#c7d5e6] hover:text-white hover:bg-[#1a4a6e]/25 transition-colors"
                      }
                    >
                      <it.icon className={`h-4 w-4 ${active ? "text-[#2dd4bf]" : "text-[#7d94ad] group-hover:text-[#2dd4bf]"}`} />
                      {it.label}
                    </Link>
                  );
                })}
              </nav>
            </div>
          ))}

          {/* Tier / status card */}
          <div className="rounded-sm border border-[#1a4a6e] bg-[#0c2340]/60 p-4">
            <div className="text-[10px] uppercase tracking-[0.22em] text-[#2dd4bf] font-semibold">
              Account tier
            </div>
            <div className="mt-1.5 ws-serif italic text-lg text-[#e2b464]">Founding Member</div>
            <div className="mt-2 text-[11px] text-[#7d94ad] leading-relaxed">
              Free listings during early access.
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile tab bar */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 border-t border-[#1a4a6e] bg-[#04101a]/95 backdrop-blur">
        <div className="grid grid-cols-4">
          {groups.flatMap((g) => g.items).slice(0, 4).map((it) => {
            const active = isActive(it.to, it.exact);
            return (
              <Link
                key={it.to}
                to={it.to}
                className={
                  active
                    ? "flex flex-col items-center justify-center gap-1 py-2.5 text-[10px] text-[#2dd4bf]"
                    : "flex flex-col items-center justify-center gap-1 py-2.5 text-[10px] text-[#7d94ad]"
                }
              >
                <it.icon className="h-4 w-4" />
                {it.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}
