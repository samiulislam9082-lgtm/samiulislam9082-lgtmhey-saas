/**
 * Compact listing card + skeleton used on Browse.
 * Uses the same "Magazine Gallery" design language (scoped .ws-root tokens).
 */
import { Link } from "@tanstack/react-router";
import { Globe } from "lucide-react";
import { Sparkline, VerifiedSeal } from "@/components/websites/ws-ui";

export function WsListingSkeleton() {
  return (
    <div className="animate-pulse space-y-3">
      <div className="aspect-[16/10] bg-[#0c2340]" />
      <div className="h-5 w-3/4 bg-[#0c2340]" />
      <div className="h-3 w-1/2 bg-[#0c2340]" />
    </div>
  );
}

export function WsListingCard({
  l,
}: {
  l: {
    id: string;
    title: string;
    domain: string;
    description: string | null;
    niche: string | null;
    listing_type: "for_sale" | "open_to_swap" | "open_to_both";
    asking_price_usd: number | null;
    monthly_revenue_usd: number | null;
    monthly_traffic: number | null;
    tech_stack: string[];
    screenshots: string[];
    ownership_verified?: boolean;
  };
}) {
  const typeLabel = {
    for_sale: "For sale",
    open_to_swap: "Open to swap",
    open_to_both: "Sale or swap",
  }[l.listing_type];
  const price = l.asking_price_usd != null ? `$${Number(l.asking_price_usd).toLocaleString()}` : "—";

  return (
    <Link
      to="/websites/$id"
      params={{ id: l.id }}
      className="ws-hover-lift group block space-y-3"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-[#0c2340] border border-[#1a4a6e]/60">
        {l.screenshots?.[0] ? (
          <img
            src={l.screenshots[0]}
            alt={l.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-[#1a4a6e]">
            <Globe className="h-10 w-10" strokeWidth={1} />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#04101a]/80 via-transparent to-transparent" />
        {l.ownership_verified !== false && (
          <div className="absolute top-2 right-2"><VerifiedSeal label="Verified" /></div>
        )}
        <div className="absolute bottom-2 left-2 text-[10px] uppercase tracking-widest text-[#2dd4bf] bg-[#04101a]/70 px-2 py-0.5 font-semibold backdrop-blur-sm">
          {typeLabel}
        </div>
      </div>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="ws-serif text-xl italic text-white group-hover:text-[#2dd4bf] transition-colors line-clamp-1">
            {l.title}
          </h3>
          <p className="mt-0.5 text-[10px] uppercase tracking-widest text-[#7d94ad] truncate">{l.domain}</p>
        </div>
        <span className="ws-num text-sm font-semibold text-[#e2b464] shrink-0">{price}</span>
      </div>
      <div className="flex items-center justify-between border-t border-[#1a4a6e]/60 pt-2 text-[11px] text-[#c7d5e6]/80">
        <div className="flex gap-3">
          {l.monthly_revenue_usd != null && (
            <span><span className="ws-num text-[#2dd4bf]">${Number(l.monthly_revenue_usd).toLocaleString()}</span> MRR</span>
          )}
          {l.monthly_traffic != null && (
            <span><span className="ws-num">{Number(l.monthly_traffic).toLocaleString()}</span> visits</span>
          )}
        </div>
        {l.monthly_revenue_usd != null && <Sparkline height={16} className="text-[#2dd4bf] w-[54px]" />}
      </div>
    </Link>
  );
}
