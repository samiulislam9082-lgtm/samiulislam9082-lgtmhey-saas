import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsAttachmentSignedUrl } from "@/lib/websites.functions";
import { FileText, Download } from "lucide-react";
import { bytesLabel } from "@/lib/ws-messaging";

type A = { id: string; storage_path: string; mime: string; size: number; kind: string; width: number | null; height: number | null };

export function Attachment({ a }: { a: A }) {
  const signer = useServerFn(wsAttachmentSignedUrl);
  const { data } = useQuery({
    queryKey: ["ws", "attach-url", a.storage_path],
    queryFn: () => signer({ data: { path: a.storage_path } }),
    staleTime: 1000 * 60 * 20,
    retry: false,
  });
  const url = data?.url;
  const isImage = a.mime.startsWith("image/");
  if (isImage) {
    return (
      <a href={url} target="_blank" rel="noopener noreferrer" className="block mt-1 rounded-xl overflow-hidden border border-white/10 max-w-xs">
        {url ? <img src={url} alt="attachment" className="block max-h-64 w-auto" /> : <div className="h-32 w-48 bg-black/40 animate-pulse" />}
      </a>
    );
  }
  const fname = a.storage_path.split("/").pop() ?? "file";
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-1 flex items-center gap-3 rounded-xl border border-white/10 bg-black/30 p-3 hover:border-emerald-400/40 transition max-w-xs"
    >
      <div className="h-10 w-10 rounded-lg bg-emerald-500/10 border border-emerald-400/20 flex items-center justify-center">
        <FileText className="h-5 w-5 text-emerald-300" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm text-white truncate">{fname}</div>
        <div className="text-xs text-emerald-100/50">{bytesLabel(a.size)}</div>
      </div>
      <Download className="h-4 w-4 text-emerald-300/70 shrink-0" />
    </a>
  );
}
