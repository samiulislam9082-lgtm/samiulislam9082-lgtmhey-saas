import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsFetchLinkPreview } from "@/lib/websites.functions";
import { ExternalLink } from "lucide-react";

export function LinkPreview({ url }: { url: string }) {
  const fetchFn = useServerFn(wsFetchLinkPreview);
  const { data } = useQuery({
    queryKey: ["ws", "link-preview", url],
    queryFn: () => fetchFn({ data: { url } }),
    staleTime: 1000 * 60 * 60,
    retry: false,
  });
  if (!data || (!data.title && !data.image_url)) return null;
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-2 flex gap-3 rounded-xl border border-white/10 bg-black/30 p-3 hover:border-emerald-400/40 transition max-w-md"
    >
      {data.image_url && (
        <img
          src={data.image_url}
          alt=""
          className="h-16 w-16 rounded-lg object-cover shrink-0"
          onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
        />
      )}
      <div className="min-w-0 flex-1">
        <div className="text-xs text-emerald-300/70 truncate flex items-center gap-1">
          {data.site_name || new URL(url).hostname}
          <ExternalLink className="h-3 w-3" />
        </div>
        <div className="text-sm font-medium text-white truncate">{data.title}</div>
        {data.description && <div className="text-xs text-emerald-100/60 line-clamp-2 mt-0.5">{data.description}</div>}
      </div>
    </a>
  );
}
