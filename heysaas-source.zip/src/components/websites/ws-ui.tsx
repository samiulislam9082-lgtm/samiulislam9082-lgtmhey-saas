import { useEffect, useRef, useState } from "react";
import { ShieldCheck } from "lucide-react";
import { motionPreferenceIsReduced } from "@/lib/motion";
import { reportMotionSuppression } from "@/lib/motion-debug";
export { Sparkline } from "@/components/ui/sparkline";


/** Tabular count-up for financial figures. Respects prefers-reduced-motion. */
export function CountUp({
  value,
  prefix = "",
  suffix = "",
  duration = 900,
  compact = false,
  className = "",
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  compact?: boolean;
  className?: string;
}) {
  const [n, setN] = useState(0);
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const reduce = motionPreferenceIsReduced();
    if (reduce || duration <= 0) {
      if (reduce) reportMotionSuppression("ws.CountUp", { detail: String(value) });
      setN(value);
      return;
    }
    const from = 0;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(from + (value - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  const shown = compact
    ? formatCompact(n)
    : Math.round(n).toLocaleString("en-US");
  return (
    <span className={`ws-num ${className}`}>
      {prefix}
      {shown}
      {suffix}
    </span>
  );
}

function formatCompact(n: number) {
  if (Math.abs(n) >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (Math.abs(n) >= 1_000) return (n / 1_000).toFixed(1) + "k";
  return Math.round(n).toString();
}

// Sparkline is re-exported from "@/components/ui/sparkline" above so any
// existing WebSwap imports keep working with the shared visual spec.



/** Distinctive verification seal — used across WebSwap. */
export function VerifiedSeal({
  label = "DNS Verified",
  className = "",
}: {
  label?: string;
  className?: string;
}) {
  return (
    <span className={`ws-seal ${className}`}>
      <ShieldCheck className="h-3 w-3" strokeWidth={2.4} />
      {label}
    </span>
  );
}
