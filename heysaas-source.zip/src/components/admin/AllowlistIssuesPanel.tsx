/**
 * Shared issues panel used by the motion allowlist admin page for:
 *   1. Parse-time issues from an imported JSON file
 *   2. Server-side validation issues returned when saving to the overlay
 *
 * Provides search, group-by-field, severity summary, per-issue copy, full
 * payload copy, and j/k keyboard navigation.
 */
import * as React from "react";
import { toast } from "sonner";

export type AllowlistIssueLike = {
  index: number;
  id?: string;
  field?: string;
  message: string;
};

type Severity = "error" | "warning";

function inferSeverity(iss: AllowlistIssueLike): Severity {
  // The current pipelines only surface hard errors, but the panel supports
  // a "warning" bucket for future soft validations (e.g. deprecations).
  const msg = iss.message.toLowerCase();
  if (msg.startsWith("warning:") || msg.includes("deprecat")) return "warning";
  return "error";
}

function downloadBlob(name: string, mime: string, body: string) {
  const blob = new Blob([body], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

async function copyText(text: string, label: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(`${label} copied`);
  } catch {
    toast.error(`Could not copy ${label.toLowerCase()}`);
  }
}

export type AllowlistIssuesPanelProps = {
  title: string;
  fileName?: string | null;
  issues: AllowlistIssueLike[];
  exportKind: string;
  onJumpToRule: (id: string | undefined | null) => void;
  helperText?: React.ReactNode;
  tone?: "rose" | "amber";
  /** Optional extra action buttons rendered in the header (e.g. legacy Export JSON/CSV). */
  headerExtras?: React.ReactNode;
  /**
   * Optional one-click fix. Return `{ ok, description }` — `ok: true` removes
   * the issue and shows a success toast. When provided, per-issue Fix buttons
   * and a header "Fix all fixable" button appear. `fixable(iss)` gates which
   * issues get a live Fix button (defaults to always true).
   */
  onFix?: (iss: AllowlistIssueLike) => Promise<{ ok: boolean; description?: string }> | { ok: boolean; description?: string };
  fixable?: (iss: AllowlistIssueLike) => boolean;
  /**
   * Optional preview of what a Fix will change for this issue. When provided,
   * the per-issue Fix button opens an inline before/after panel instead of
   * applying immediately; the operator confirms to apply via `onFix`.
   * Return `null` when no preview can be computed (falls back to direct apply).
   */
  previewFix?: (
    iss: AllowlistIssueLike,
  ) =>
    | { before: unknown; after: unknown; description?: string }
    | null
    | Promise<{ before: unknown; after: unknown; description?: string } | null>;
};


function stringifyForDiff(v: unknown): string {
  try {
    return JSON.stringify(v, null, 2) ?? String(v);
  } catch {
    return String(v);
  }
}

/**
 * Line-level classifier for two JSON blobs. Not a semantic diff — good enough
 * to visually confirm what a Fix will change (add / remove / change) for the
 * scoped rule object supplied by `previewFix`.
 */
function classifyDiffLines(beforeStr: string, afterStr: string) {
  const beforeLines = beforeStr.split("\n");
  const afterLines = afterStr.split("\n");
  const beforeSet = new Set(beforeLines);
  const afterSet = new Set(afterLines);
  return {
    before: beforeLines.map((line) => ({
      line,
      status: (afterSet.has(line) ? "same" : "removed") as "same" | "removed" | "added",
    })),
    after: afterLines.map((line) => ({
      line,
      status: (beforeSet.has(line) ? "same" : "added") as "same" | "removed" | "added",
    })),
  } as const;
}


function DiffPane({
  label,
  lines,
  tone,
}: {
  label: string;
  lines: ReadonlyArray<{ line: string; status: "same" | "added" | "removed" }>;
  tone: "before" | "after";
}) {
  return (
    <div className="min-w-0 flex-1">
      <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider opacity-75">
        {label}
      </div>
      <pre className="max-h-64 overflow-auto rounded border border-current/20 bg-background/60 p-2 font-mono text-[10.5px] leading-snug">
        {lines.length === 0 ? (
          <span className="opacity-60">(empty)</span>
        ) : (
          lines.map((row, i) => {
            const cls =
              row.status === "same"
                ? "opacity-70"
                : tone === "before"
                  ? "bg-rose-500/20 text-rose-900 dark:text-rose-100"
                  : "bg-emerald-500/20 text-emerald-900 dark:text-emerald-100";
            const marker =
              row.status === "same" ? "  " : tone === "before" ? "- " : "+ ";
            return (
              <div key={i} className={`whitespace-pre-wrap ${cls}`}>
                {marker}
                {row.line || " "}
              </div>
            );
          })
        )}
      </pre>
    </div>
  );
}

export function AllowlistIssuesPanel({
  title,

  fileName,
  issues,
  exportKind,
  onJumpToRule,
  helperText,
  tone = "rose",
  headerExtras,
  onFix,
  fixable,
  previewFix,
}: AllowlistIssuesPanelProps) {
  const [query, setQuery] = React.useState("");
  const [groupByField, setGroupByField] = React.useState(false);
  const [severityFilter, setSeverityFilter] = React.useState<Severity | "all">(
    "all",
  );
  const [onlyFixable, setOnlyFixable] = React.useState(false);

  const [activeIdx, setActiveIdx] = React.useState(0);
  const [fixingKey, setFixingKey] = React.useState<string | null>(null);
  const [previewKey, setPreviewKey] = React.useState<string | null>(null);
  const [preview, setPreview] = React.useState<{
    before: unknown;
    after: unknown;
    description?: string;
    loading?: boolean;
  } | null>(null);
  const listRef = React.useRef<HTMLDivElement>(null);


  const decorated = React.useMemo(
    () => issues.map((iss) => ({ iss, severity: inferSeverity(iss) })),
    [issues],
  );

  const severityCounts = React.useMemo(() => {
    let error = 0;
    let warning = 0;
    for (const d of decorated) {
      if (d.severity === "error") error++;
      else warning++;
    }
    return { error, warning };
  }, [decorated]);

  const fieldCounts = React.useMemo(() => {
    const map = new Map<string, number>();
    for (const { iss } of decorated) {
      const key = iss.field ?? "(unspecified)";
      map.set(key, (map.get(key) ?? 0) + 1);
    }
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [decorated]);

  const fixableCount = React.useMemo(() => {
    if (!onFix) return 0;
    return decorated.reduce(
      (n, { iss }) => n + ((fixable ? fixable(iss) : true) ? 1 : 0),
      0,
    );
  }, [decorated, onFix, fixable]);

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    return decorated.filter(({ iss, severity }) => {
      if (severityFilter !== "all" && severity !== severityFilter) return false;
      if (onlyFixable && onFix && !(fixable ? fixable(iss) : true)) return false;
      if (!q) return true;
      return (
        iss.message.toLowerCase().includes(q) ||
        (iss.id ?? "").toLowerCase().includes(q) ||
        (iss.field ?? "").toLowerCase().includes(q) ||
        String(iss.index).includes(q)
      );
    });
  }, [decorated, query, severityFilter, onlyFixable, onFix, fixable]);


  // Keep active index in-bounds when the filtered list changes.
  React.useEffect(() => {
    if (activeIdx >= filtered.length) setActiveIdx(Math.max(0, filtered.length - 1));
  }, [filtered.length, activeIdx]);

  const grouped = React.useMemo(() => {
    if (!groupByField) return null;
    const map = new Map<string, typeof filtered>();
    for (const item of filtered) {
      const key = item.iss.field ?? "(unspecified)";
      const arr = map.get(key);
      if (arr) arr.push(item);
      else map.set(key, [item]);
    }
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [filtered, groupByField]);

  // j/k keyboard navigation over the flat filtered list (also works while
  // grouped — activeIdx maps to `filtered`).
  React.useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!listRef.current) return;
      const target = e.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName))
        return;
      // Only respond when the panel is roughly in view / focused within.
      const rect = listRef.current.getBoundingClientRect();
      const isVisible = rect.bottom > 0 && rect.top < window.innerHeight;
      if (!isVisible) return;

      if (e.key === "j") {
        e.preventDefault();
        setActiveIdx((i) => Math.min(filtered.length - 1, i + 1));
      } else if (e.key === "k") {
        e.preventDefault();
        setActiveIdx((i) => Math.max(0, i - 1));
      } else if (e.key === "Enter") {
        const cur = filtered[activeIdx];
        if (cur?.iss.id) {
          e.preventDefault();
          onJumpToRule(cur.iss.id);
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [filtered, activeIdx, onJumpToRule]);

  // Scroll the active row into view when j/k moves it.
  React.useEffect(() => {
    const el = listRef.current?.querySelector<HTMLElement>(
      `[data-issue-idx="${activeIdx}"]`,
    );
    el?.scrollIntoView({ block: "nearest" });
  }, [activeIdx]);

  const toneCls =
    tone === "amber"
      ? {
          box: "border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300",
          row: "border-amber-500/30 bg-amber-500/5",
          btn: "border-amber-500/40 hover:bg-amber-500/20",
          chip: "bg-amber-500/15",
          strong: "text-amber-800 dark:text-amber-200",
        }
      : {
          box: "border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-300",
          row: "border-rose-500/30 bg-rose-500/5",
          btn: "border-rose-500/40 hover:bg-rose-500/20",
          chip: "bg-rose-500/15",
          strong: "text-rose-800 dark:text-rose-200",
        };

  function exportPayload(format: "json" | "csv") {
    const list = filtered.map((f) => f.iss);
    const ts = new Date().toISOString();
    if (format === "json") {
      const payload = {
        schemaVersion: 1,
        exportKind,
        exportedAt: ts,
        source: fileName ?? null,
        count: list.length,
        totalBeforeFilter: issues.length,
        query: query || null,
        severityFilter,
        issues: list,
      };
      downloadBlob(
        `${exportKind}-${Date.now()}.json`,
        "application/json",
        JSON.stringify(payload, null, 2),
      );
    } else {
      const esc = (v: unknown) => {
        const s = v == null ? "" : String(v);
        return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
      };
      const header = "index,id,field,severity,message";
      const rows = filtered.map(({ iss, severity }) =>
        [iss.index, iss.id ?? "", iss.field ?? "", severity, iss.message]
          .map(esc)
          .join(","),
      );
      const meta = [
        `# exportKind: ${exportKind}`,
        `# exportedAt: ${ts}`,
        `# count: ${list.length}`,
      ].join("\n");
      downloadBlob(
        `${exportKind}-${Date.now()}.csv`,
        "text/csv",
        `${meta}\n${header}\n${rows.join("\n")}`,
      );
    }
    toast.success(`Exported ${list.length} issue(s) as ${format.toUpperCase()}`);
  }

  async function copyFullPayload() {
    const payload = {
      schemaVersion: 1,
      exportKind,
      exportedAt: new Date().toISOString(),
      source: fileName ?? null,
      count: issues.length,
      issues,
    };
    await copyText(JSON.stringify(payload, null, 2), "Full validation payload");
  }

  async function runFix(iss: AllowlistIssueLike, key: string) {
    if (!onFix) return;
    setFixingKey(key);
    try {
      const res = await onFix(iss);
      if (res.ok) toast.success(res.description ?? "Issue fixed");
      else toast.error(res.description ?? "Could not auto-fix this issue");
    } finally {
      setFixingKey(null);
      if (previewKey === key) {
        setPreviewKey(null);
        setPreview(null);
      }
    }
  }

  async function openPreview(iss: AllowlistIssueLike, key: string) {
    if (previewKey === key) {
      setPreviewKey(null);
      setPreview(null);
      return;
    }
    if (!previewFix) {
      void runFix(iss, key);
      return;
    }
    setPreviewKey(key);
    setPreview({ before: null, after: null, loading: true });
    try {
      const p = await previewFix(iss);
      if (!p) {
        // No preview available — apply directly, matching prior behaviour.
        setPreviewKey(null);
        setPreview(null);
        void runFix(iss, key);
        return;
      }
      setPreview({ ...p, loading: false });
    } catch (err) {
      setPreview({
        before: null,
        after: null,
        description: err instanceof Error ? err.message : "Preview failed",
        loading: false,
      });
    }
  }


  async function fixAll() {
    if (!onFix) return;
    const targets = issues.filter((i) => (fixable ? fixable(i) : true));
    let ok = 0;
    for (const iss of targets) {
      // sequential — parent state mutates issue list between runs
      // eslint-disable-next-line no-await-in-loop
      const r = await onFix(iss);
      if (r.ok) ok++;
    }
    toast[ok > 0 ? "success" : "error"](
      `Auto-fixed ${ok} of ${targets.length} issue${targets.length === 1 ? "" : "s"}`,
    );
  }

  function renderIssueRow(item: (typeof filtered)[number], flatIdx: number) {
    const { iss, severity } = item;
    const canJump = Boolean(iss.id);
    const canFix = !!onFix && (fixable ? fixable(iss) : true);
    const fixKey = `${iss.index}-${iss.id ?? "?"}-${iss.field ?? ""}`;
    const isActive = flatIdx === activeIdx;
    return (
      <li
        key={`${iss.index}-${iss.id ?? "?"}-${flatIdx}`}
        data-issue-idx={flatIdx}
        onClick={() => setActiveIdx(flatIdx)}
        className={`cursor-pointer rounded border p-2 transition-colors ${
          isActive
            ? "border-primary/70 ring-1 ring-primary/40"
            : `border ${toneCls.row}`
        }`}
      >
        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
          <span
            className={`rounded px-1 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${
              severity === "warning"
                ? "bg-amber-500/20 text-amber-800 dark:text-amber-200"
                : "bg-rose-500/20 text-rose-800 dark:text-rose-200"
            }`}
          >
            {severity}
          </span>
          <span className={`font-mono text-[11px] ${toneCls.strong}`}>
            {iss.id ? (
              <>
                rule <code>{iss.id}</code>
              </>
            ) : (
              <em>rule #{iss.index}</em>
            )}
          </span>
          {iss.field && (
            <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${toneCls.chip}`}>
              field: <code>{iss.field}</code>
            </span>
          )}
          {iss.index >= 0 && iss.id && (
            <span className="text-[10px] opacity-70">(index {iss.index})</span>
          )}
          <div className="ml-auto flex shrink-0 gap-1">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                copyText(
                  JSON.stringify({ ...iss, severity }, null, 2),
                  "Issue details",
                );
              }}
              className={`rounded border px-2 py-0.5 text-[11px] font-medium ${toneCls.btn}`}
              title="Copy this issue as JSON"
            >
              Copy
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onJumpToRule(iss.id);
              }}
              disabled={!canJump}
              className={`rounded border px-2 py-0.5 text-[11px] font-medium ${toneCls.btn} disabled:cursor-not-allowed disabled:opacity-40`}
              title={
                canJump
                  ? "Scroll to this rule in the preview"
                  : "Rule has no id — cannot jump"
              }
            >
              Jump
            </button>
            {canFix && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (previewFix) void openPreview(iss, fixKey);
                  else void runFix(iss, fixKey);
                }}
                disabled={fixingKey === fixKey}
                className={`rounded border border-emerald-500/40 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-medium text-emerald-800 hover:bg-emerald-500/20 dark:text-emerald-200 disabled:opacity-40`}
                title={
                  previewFix
                    ? `Preview auto-fix for field: ${iss.field ?? "(auto)"}`
                    : `One-click fix for field: ${iss.field ?? "(auto)"}`
                }
              >
                {fixingKey === fixKey
                  ? "Fixing…"
                  : previewKey === fixKey
                    ? "Hide preview"
                    : previewFix
                      ? "Fix…"
                      : "Fix"}
              </button>
            )}
          </div>
        </div>
        <div className="mt-1 text-[11px] leading-snug">{iss.message}</div>
        {previewKey === fixKey && preview && (
          <div className="mt-2 rounded border border-current/25 bg-background/40 p-2">
            <div className="mb-1 flex flex-wrap items-center justify-between gap-2 text-[10px] uppercase tracking-wider opacity-80">
              <span>
                Fix preview
                {preview.description ? ` — ${preview.description}` : ""}
                {preview.loading ? " (loading…)" : ""}
              </span>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setPreviewKey(null);
                    setPreview(null);
                  }}
                  className={`rounded border px-2 py-0.5 text-[11px] font-medium ${toneCls.btn}`}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    void runFix(iss, fixKey);
                  }}
                  disabled={preview.loading || fixingKey === fixKey}
                  className="rounded border border-emerald-500/40 bg-emerald-500/20 px-2 py-0.5 text-[11px] font-medium text-emerald-900 hover:bg-emerald-500/30 dark:text-emerald-100 disabled:opacity-40"
                >
                  {fixingKey === fixKey ? "Applying…" : "Apply fix"}
                </button>
              </div>
            </div>
            {preview.loading ? (
              <div className="p-2 text-[11px] italic opacity-70">
                Computing preview…
              </div>
            ) : (
              (() => {
                const beforeStr = stringifyForDiff(preview.before);
                const afterStr = stringifyForDiff(preview.after);
                const diff = classifyDiffLines(beforeStr, afterStr);
                return (
                  <div className="flex flex-col gap-2 md:flex-row">
                    <DiffPane label="Before" lines={diff.before} tone="before" />
                    <DiffPane label="After" lines={diff.after} tone="after" />
                  </div>
                );
              })()
            )}
          </div>
        )}
      </li>
    );
  }


  return (
    <div role="alert" className={`rounded-md border px-3 py-2 text-xs ${toneCls.box}`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <strong className={toneCls.strong}>
            {title} — {issues.length} issue{issues.length === 1 ? "" : "s"}
          </strong>
          {fileName && (
            <span className="ml-2 opacity-80">
              in <code>{fileName}</code>
            </span>
          )}
          <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[10px]">
            <span className={`rounded px-1.5 py-0.5 ${toneCls.chip}`}>
              {severityCounts.error} error{severityCounts.error === 1 ? "" : "s"}
            </span>
            {severityCounts.warning > 0 && (
              <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-amber-800 dark:text-amber-200">
                {severityCounts.warning} warning
                {severityCounts.warning === 1 ? "" : "s"}
              </span>
            )}
            {fieldCounts.slice(0, 5).map(([field, count]) => (
              <span
                key={field}
                className="rounded border border-current/30 px-1.5 py-0.5 opacity-90"
                title={`${count} issue(s) with field=${field}`}
              >
                {field}: {count}
              </span>
            ))}
          </div>
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-1">
          {headerExtras}
          {onFix && (
            <button
              type="button"
              onClick={() => void fixAll()}
              className="rounded border border-emerald-500/40 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-medium text-emerald-800 hover:bg-emerald-500/20 dark:text-emerald-200"
              title="Auto-fix every issue that has a safe automatic remedy"
            >
              Fix all fixable
            </button>
          )}
          <button
            type="button"
            onClick={copyFullPayload}
            className={`rounded border px-2 py-0.5 text-[11px] font-medium ${toneCls.btn}`}
            title="Copy the entire validation payload as JSON"
          >
            Copy payload
          </button>
          <button
            type="button"
            onClick={() => exportPayload("json")}
            className={`rounded border px-2 py-0.5 text-[11px] font-medium ${toneCls.btn}`}
          >
            Export JSON
          </button>
          <button
            type="button"
            onClick={() => exportPayload("csv")}
            className={`rounded border px-2 py-0.5 text-[11px] font-medium ${toneCls.btn}`}
          >
            Export CSV
          </button>
        </div>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-2">
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search id, field, message, index…"
          className="flex-1 min-w-[10rem] rounded border border-current/30 bg-background/50 px-2 py-1 text-[11px] outline-none focus:ring-1 focus:ring-current/40"
          aria-label="Filter issues"
        />
        <select
          value={severityFilter}
          onChange={(e) =>
            setSeverityFilter(e.target.value as Severity | "all")
          }
          className="rounded border border-current/30 bg-background/50 px-2 py-1 text-[11px]"
          aria-label="Filter by severity"
        >
          <option value="all">All severities</option>
          <option value="error">Errors only</option>
          <option value="warning">Warnings only</option>
        </select>
        <label className="flex items-center gap-1 text-[11px]">
          <input
            type="checkbox"
            checked={groupByField}
            onChange={(e) => setGroupByField(e.target.checked)}
          />
          Group by field
        </label>
        {onFix && (
          <label
            className="flex items-center gap-1 text-[11px]"
            title={
              fixableCount === 0
                ? "No issues in this batch have an automatic remedy"
                : `Show only the ${fixableCount} issue${fixableCount === 1 ? "" : "s"} with a one-click fix`
            }
          >
            <input
              type="checkbox"
              checked={onlyFixable}
              onChange={(e) => setOnlyFixable(e.target.checked)}
              disabled={fixableCount === 0}
            />
            Show only fixable ({fixableCount})
          </label>
        )}

        <span className="text-[10px] opacity-70">
          {filtered.length} shown · press <kbd className="rounded bg-black/10 px-1">j</kbd>/<kbd className="rounded bg-black/10 px-1">k</kbd> to navigate, <kbd className="rounded bg-black/10 px-1">Enter</kbd> to jump
        </span>
      </div>

      <div ref={listRef} className="mt-2 max-h-[60vh] overflow-y-auto">
        {filtered.length === 0 ? (
          <p className="p-2 text-[11px] italic opacity-80">
            No issues match the current filters.
          </p>
        ) : grouped ? (
          <div className="space-y-3">
            {grouped.map(([field, items]) => (
              <div key={field}>
                <div className="mb-1 flex items-baseline gap-2 text-[10px] font-semibold uppercase tracking-wider opacity-80">
                  <span>field: {field}</span>
                  <span className={`rounded px-1.5 py-0.5 ${toneCls.chip}`}>
                    {items.length}
                  </span>
                </div>
                <ul className="space-y-1">
                  {items.map((it) => renderIssueRow(it, filtered.indexOf(it)))}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <ul className="space-y-1">
            {filtered.map((it, i) => renderIssueRow(it, i))}
          </ul>
        )}
      </div>

      {helperText && <div className="mt-2 text-[11px] opacity-90">{helperText}</div>}
    </div>
  );
}
