/**
 * Advanced XLSX export dialog for the motion coverage diff.
 *
 * Provides:
 *   - Column picker (choose which fields land in the worksheet)
 *   - Scope selector (changed only / full / current preview subset)
 *   - Sheet layout selector (single sheet vs multi-sheet workbook with Summary)
 *   - Named preset save / load / delete
 *   - Filename prefix
 */
import * as React from "react";
import { toast } from "sonner";
import type { DiffSummary } from "@/lib/motion-probe-snapshots";
import type { ProbeSnapshot } from "@/lib/motion-probe-snapshots";
import {
  ALL_XLSX_COLUMNS,
  DEFAULT_XLSX_PRESET,
  deleteXlsxPreset,
  isValidColumn,
  listXlsxPresets,
  loadXlsxLastUsed,
  saveXlsxLastUsed,
  saveXlsxPreset,
  type XlsxColumn,
  type XlsxExportPreset,
  type XlsxScope,
  type XlsxSheetMode,
} from "@/lib/motion-export-presets";


type DiffRow = DiffSummary["entries"][number];

const COLUMN_LABELS: Record<XlsxColumn, string> = {
  status: "Status",
  signature: "Signature",
  kind: "Kind",
  tag: "Tag",
  id: "Element id",
  classes: "Classes",
  beforeRuleId: "Before rule id",
  afterRuleId: "After rule id",
  beforeSnapshotId: "Before snapshot id",
  currentSnapshotId: "Current snapshot id",
  currentPathname: "Current pathname",
};

const COLUMN_WIDTHS: Record<XlsxColumn, number> = {
  status: 10,
  signature: 32,
  kind: 10,
  tag: 8,
  id: 18,
  classes: 24,
  beforeRuleId: 18,
  afterRuleId: 18,
  beforeSnapshotId: 22,
  currentSnapshotId: 22,
  currentPathname: 28,
};

export type DiffXlsxExportDialogProps = {
  diff: DiffSummary | null;
  currentSnapshot: ProbeSnapshot | null;
  previousSnapshot: ProbeSnapshot | null;
  changedRows: DiffRow[];
  fullRows: DiffRow[];
  /** Rows currently visible in the ExportPreview subset (post-search). */
  previewRows: DiffRow[];
  diffFilterRuleId: string;
  diffFilterStatus: string;
};

export function DiffXlsxExportDialog({
  diff,
  currentSnapshot,
  previousSnapshot,
  changedRows,
  fullRows,
  previewRows,
  diffFilterRuleId,
  diffFilterStatus,
}: DiffXlsxExportDialogProps) {
  const [open, setOpen] = React.useState(false);
  const [presets, setPresets] = React.useState<XlsxExportPreset[]>([]);

  // Hydrate from last-used selections so the operator's previous choices
  // (columns, scope, sheet mode, filename prefix, active preset) survive a
  // page reload without needing to re-open a named preset.
  const initial = React.useMemo(() => loadXlsxLastUsed(), []);

  const [activePresetId, setActivePresetId] = React.useState<string | null>(
    initial?.activePresetId ?? null,
  );
  const [presetName, setPresetName] = React.useState(initial?.presetName ?? "");

  const [columns, setColumns] = React.useState<XlsxColumn[]>(
    initial?.columns?.length
      ? initial.columns.filter(isValidColumn)
      : [...DEFAULT_XLSX_PRESET.columns],
  );
  const [scope, setScope] = React.useState<XlsxScope>(
    initial?.scope ?? DEFAULT_XLSX_PRESET.scope,
  );
  const [sheetMode, setSheetMode] = React.useState<XlsxSheetMode>(
    initial?.sheetMode ?? DEFAULT_XLSX_PRESET.sheetMode,
  );
  const [filenamePrefix, setFilenamePrefix] = React.useState(
    initial?.filenamePrefix ??
      DEFAULT_XLSX_PRESET.filenamePrefix ??
      "motion-coverage-diff-v1",
  );

  React.useEffect(() => {
    if (open) setPresets(listXlsxPresets());
  }, [open]);

  // Persist selections whenever they change so the next visit restores them.
  React.useEffect(() => {
    saveXlsxLastUsed({
      columns,
      scope,
      sheetMode,
      filenamePrefix,
      activePresetId,
      presetName,
    });
  }, [columns, scope, sheetMode, filenamePrefix, activePresetId, presetName]);


  function applyPreset(p: XlsxExportPreset) {
    setColumns(p.columns.filter(isValidColumn));
    setScope(p.scope);
    setSheetMode(p.sheetMode);
    setFilenamePrefix(p.filenamePrefix ?? "motion-coverage-diff-v1");
    setActivePresetId(p.id);
    setPresetName(p.name);
  }

  function toggleColumn(col: XlsxColumn) {
    setColumns((prev) =>
      prev.includes(col) ? prev.filter((c) => c !== col) : [...prev, col],
    );
  }

  function rowsFor(target: XlsxScope): DiffRow[] {
    if (target === "changed") return changedRows;
    if (target === "full") return fullRows;
    return previewRows;
  }

  function saveCurrentAsPreset() {
    const name = presetName.trim();
    if (!name) {
      toast.error("Give the preset a name");
      return;
    }
    if (columns.length === 0) {
      toast.error("Pick at least one column");
      return;
    }
    const saved = saveXlsxPreset({
      id: activePresetId ?? undefined,
      name,
      columns,
      scope,
      sheetMode,
      filenamePrefix: filenamePrefix.trim() || undefined,
    });
    setActivePresetId(saved.id);
    setPresets(listXlsxPresets());
    toast.success(`Preset "${saved.name}" saved`);
  }

  function removePreset(id: string) {
    if (!window.confirm("Delete this preset?")) return;
    deleteXlsxPreset(id);
    setPresets(listXlsxPresets());
    if (activePresetId === id) setActivePresetId(null);
    toast.success("Preset deleted");
  }

  async function runExport() {
    if (!diff || !currentSnapshot) {
      toast.error("No diff to export");
      return;
    }
    if (columns.length === 0) {
      toast.error("Pick at least one column");
      return;
    }

    const XLSX = await import("xlsx");
    const exportedAt = new Date().toISOString();
    const rows = rowsFor(scope);

    if (rows.length === 0) {
      toast.error("Nothing to export in the selected scope");
      return;
    }

    const buildSheet = (subset: DiffRow[]) => {
      const header: string[] = columns.map((c) => c);
      const aoa: (string | number)[][] = [header];
      for (const e of subset) {
        const ref = e.after ?? e.before;
        const row: (string | number)[] = columns.map((col) => {
          switch (col) {
            case "status":
              return e.status;
            case "signature":
              return e.signature;
            case "kind":
              return ref?.kind ?? currentSnapshot.kind;
            case "tag":
              return ref?.tag ?? "";
            case "id":
              return ref?.id ?? "";
            case "classes":
              return ref?.classes ?? "";
            case "beforeRuleId":
              return e.before?.ruleId ?? "";
            case "afterRuleId":
              return e.after?.ruleId ?? "";
            case "beforeSnapshotId":
              return previousSnapshot?.id ?? "";
            case "currentSnapshotId":
              return currentSnapshot.id;
            case "currentPathname":
              return currentSnapshot.pathname;
          }
        });
        aoa.push(row);
      }
      const ws = XLSX.utils.aoa_to_sheet(aoa);
      ws["!cols"] = columns.map((c) => ({ wch: COLUMN_WIDTHS[c] }));
      ws["!autofilter"] = {
        ref: XLSX.utils.encode_range({
          s: { r: 0, c: 0 },
          e: {
            r: Math.max(0, aoa.length - 1),
            c: Math.max(0, columns.length - 1),
          },
        }),
      };
      return ws;
    };

    const wb = XLSX.utils.book_new();

    if (sheetMode === "multi") {
      const summaryAoa: (string | number)[][] = [
        ["Motion coverage diff"],
        [],
        ["schemaVersion", 1],
        ["exportKind", "motion-coverage-diff-xlsx"],
        ["exportedAt", exportedAt],
        ["baselineId", previousSnapshot?.id ?? ""],
        ["baselineRanAt", previousSnapshot?.ranAt ?? ""],
        ["currentId", currentSnapshot.id],
        ["currentRanAt", currentSnapshot.ranAt],
        ["pathname", currentSnapshot.pathname],
        ["selector", currentSnapshot.selector],
        ["kind", currentSnapshot.kind],
        [],
        ["Counts"],
        ["added", diff.added],
        ["removed", diff.removed],
        ["changed", diff.changed],
        ["unchanged", diff.unchanged],
        [],
        ["Filters"],
        ["ruleId", diffFilterRuleId || ""],
        ["status", diffFilterStatus],
        ["scope", scope],
        ["rowsExported", rows.length],
        [],
        ["Columns"],
        ...columns.map((c) => [c, COLUMN_LABELS[c]]),
      ];
      const summary = XLSX.utils.aoa_to_sheet(summaryAoa);
      summary["!cols"] = [{ wch: 22 }, { wch: 48 }];
      XLSX.utils.book_append_sheet(wb, summary, "Summary");
      XLSX.utils.book_append_sheet(
        wb,
        buildSheet(changedRows.filter((r) => rows.includes(r) || scope !== "changed" ? true : true)),
        "Diff (changed)",
      );
      // Second data sheet: whichever scope was picked
      const label =
        scope === "changed"
          ? "Diff (changed)"
          : scope === "full"
            ? "Full (incl. unchanged)"
            : "Preview subset";
      if (label !== "Diff (changed)") {
        XLSX.utils.book_append_sheet(wb, buildSheet(rows), label);
      }
    } else {
      XLSX.utils.book_append_sheet(
        wb,
        buildSheet(rows),
        scope === "changed"
          ? "Diff (changed)"
          : scope === "full"
            ? "Full (incl. unchanged)"
            : "Preview subset",
      );
    }

    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
    const blob = new Blob([out], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const prefix = (filenamePrefix.trim() || "motion-coverage-diff-v1").replace(
      /[^a-z0-9._-]+/gi,
      "-",
    );
    a.download = `${prefix}-${scope}-${sheetMode}-${exportedAt.replace(/[:.]/g, "-")}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast.success(
      `Exported ${rows.length} row(s) · ${columns.length} column(s) · ${sheetMode === "multi" ? "multi-sheet" : "single sheet"}`,
    );
  }

  const canExport = Boolean(diff) && columns.length > 0 && rowsFor(scope).length > 0;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted"
        title="Open advanced XLSX export options — column picker, sheet mode, presets"
      >
        Advanced XLSX…
      </button>

      {open && (
        <div className="mt-3 w-full rounded-md border border-hairline bg-background/70 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Advanced XLSX export
            </h3>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded border border-hairline px-2 py-0.5 text-[11px] hover:bg-muted"
            >
              Close
            </button>
          </div>

          <div className="mt-3 grid gap-4 md:grid-cols-2">
            <section>
              <h4 className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Columns ({columns.length}/{ALL_XLSX_COLUMNS.length})
              </h4>
              <div className="flex flex-wrap gap-1">
                {ALL_XLSX_COLUMNS.map((c) => {
                  const on = columns.includes(c);
                  return (
                    <button
                      key={c}
                      type="button"
                      onClick={() => toggleColumn(c)}
                      aria-pressed={on}
                      className={`rounded border px-1.5 py-0.5 text-[11px] ${on ? "border-primary/70 bg-primary/10" : "border-hairline hover:bg-muted"}`}
                      title={COLUMN_LABELS[c]}
                    >
                      {c}
                    </button>
                  );
                })}
              </div>
              <div className="mt-1 flex gap-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => setColumns([...ALL_XLSX_COLUMNS])}
                  className="underline opacity-80 hover:opacity-100"
                >
                  Select all
                </button>
                <button
                  type="button"
                  onClick={() => setColumns([])}
                  className="underline opacity-80 hover:opacity-100"
                >
                  Clear
                </button>
              </div>
            </section>

            <section>
              <h4 className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Scope & layout
              </h4>
              <div className="flex flex-col gap-1 text-[11px]">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="xlsx-scope"
                    checked={scope === "changed"}
                    onChange={() => setScope("changed")}
                  />
                  Changed only ({changedRows.length})
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="xlsx-scope"
                    checked={scope === "full"}
                    onChange={() => setScope("full")}
                  />
                  Full incl. unchanged ({fullRows.length})
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="xlsx-scope"
                    checked={scope === "preview"}
                    onChange={() => setScope("preview")}
                  />
                  Current preview subset ({previewRows.length})
                </label>
              </div>
              <div className="mt-2 flex flex-col gap-1 text-[11px]">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="xlsx-sheet"
                    checked={sheetMode === "multi"}
                    onChange={() => setSheetMode("multi")}
                  />
                  Multi-sheet (Summary + data)
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="xlsx-sheet"
                    checked={sheetMode === "single"}
                    onChange={() => setSheetMode("single")}
                  />
                  Single sheet
                </label>
              </div>
              <label className="mt-2 block text-[11px]">
                Filename prefix
                <input
                  value={filenamePrefix}
                  onChange={(e) => setFilenamePrefix(e.target.value)}
                  className="mt-0.5 block w-full rounded border border-hairline bg-transparent px-2 py-1 font-mono text-[11px] outline-none focus:border-foreground/40"
                />
              </label>
            </section>
          </div>

          <section className="mt-4 rounded border border-hairline p-2">
            <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              Presets
            </h4>
            <div className="flex flex-wrap items-center gap-2">
              <input
                value={presetName}
                onChange={(e) => setPresetName(e.target.value)}
                placeholder="Preset name…"
                className="h-7 min-w-[10rem] flex-1 rounded border border-hairline bg-transparent px-2 text-[11px] outline-none focus:border-foreground/40"
              />
              <button
                type="button"
                onClick={saveCurrentAsPreset}
                className="rounded border border-hairline bg-primary px-2 py-1 text-[11px] font-medium text-primary-foreground hover:opacity-90"
              >
                {activePresetId ? "Update preset" : "Save preset"}
              </button>
              {activePresetId && (
                <button
                  type="button"
                  onClick={() => {
                    setActivePresetId(null);
                    setPresetName("");
                  }}
                  className="rounded border border-hairline px-2 py-1 text-[11px] hover:bg-muted"
                >
                  New preset
                </button>
              )}
            </div>
            {presets.length === 0 ? (
              <p className="mt-2 text-[11px] italic text-muted-foreground">
                No saved presets yet.
              </p>
            ) : (
              <ul className="mt-2 flex flex-wrap gap-1">
                {presets.map((p) => (
                  <li
                    key={p.id}
                    className={`flex items-center gap-1 rounded border px-1.5 py-0.5 text-[11px] ${activePresetId === p.id ? "border-primary/70 bg-primary/10" : "border-hairline"}`}
                  >
                    <button
                      type="button"
                      onClick={() => applyPreset(p)}
                      title={`${p.columns.length} cols · ${p.scope} · ${p.sheetMode}`}
                      className="hover:underline"
                    >
                      {p.name}
                    </button>
                    <button
                      type="button"
                      onClick={() => removePreset(p.id)}
                      className="opacity-60 hover:opacity-100"
                      aria-label={`Delete preset ${p.name}`}
                      title="Delete preset"
                    >
                      ×
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <div className="mt-3 flex flex-wrap items-center justify-end gap-2">
            <span className="mr-auto text-[11px] text-muted-foreground">
              {rowsFor(scope).length} row(s) will be exported ·{" "}
              {columns.length} column(s) ·{" "}
              {sheetMode === "multi" ? "multi-sheet" : "single sheet"}
            </span>
            <button
              type="button"
              onClick={runExport}
              disabled={!canExport}
              className="rounded-md border border-hairline bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Export XLSX
            </button>
          </div>
        </div>
      )}
    </>
  );
}
