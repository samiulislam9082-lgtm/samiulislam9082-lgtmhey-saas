import { createFileRoute } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/legal/safety-fee-policy")({
  head: () =>
    buildHead({
      path: "/legal/safety-fee-policy",
      title: "Safety Fee Policy — Hey SaaS",
      description:
        "Why we charge $19 per side per swap, what it covers, and when it is refundable.",
    }),
  component: FeePolicy,
});

function FeePolicy() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="font-display text-5xl mb-2">Safety Fee Policy</h1>
        <p className="text-sm text-muted-foreground mb-10">$19 per side. Non-refundable. Here's why.</p>
        <article className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
          <section>
            <h2 className="text-foreground font-display text-2xl">The problem</h2>
            <p>A free swap marketplace = a graveyard of ghosted DMs. The fee filters for founders who are actually going to show up.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">What $19 unlocks</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>Access to the private Swap Room for your matched swap</li>
              <li>Direct messaging with your swap partner</li>
              <li>Dispute protection — admins mediate if something goes wrong</li>
              <li>Fraud prevention on both sides</li>
            </ul>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">When you pay</h2>
            <p>Only after the other founder accepts your proposal. You get 7 days to pay. Both sides must pay before the Swap Room opens.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">Refunds</h2>
            <p>The fee is non-refundable. Exceptions, at admin discretion:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Proven fraud by the other side (fake product, chargeback bait)</li>
              <li>Platform outage that blocks the swap for &gt; 72h</li>
              <li>Duplicate charge caused by a payment processor error</li>
            </ul>
            <p>Request via dispute in the Swap Room. Decisions are final.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">What Hey SaaS is NOT</h2>
            <p>We're not an escrow, not a merchant of record for your SaaS, and not a party to the exchange of access. The safety fee is a platform access fee — not a payment for your partner's product.</p>
          </section>
        </article>
      </main>
      <Footer />
    </div>
  );
}
