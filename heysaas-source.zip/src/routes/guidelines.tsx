import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/guidelines")({
  head: () => ({
    meta: [
      { title: "Community guidelines — Hey SaaS" },
      { name: "description", content: "The rules that keep Hey SaaS a trustworthy place to swap SaaS products." },
    ],
  }),
  component: () => (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto max-w-3xl w-full px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h1 className="font-display text-5xl md:text-6xl">Community guidelines</h1>
        <div className="mt-10 space-y-6 text-muted-foreground leading-relaxed">
          <p><strong className="text-foreground">Be honest.</strong> List real products. Self-reported MRR should be truthful — if a swap partner discovers fraud, we side with them.</p>
          <p><strong className="text-foreground">Be responsive.</strong> If you propose a swap or receive one, reply within a few days. Silence is a report-worthy offense at scale.</p>
          <p><strong className="text-foreground">Handovers are your responsibility.</strong> Hey SaaS provides a checklist, not the actual transfer. Complete your side in good faith.</p>
          <p><strong className="text-foreground">No side deals for cash.</strong> The platform exists specifically because we don't handle money between founders. Trying to route cash through DMs violates the spirit of the platform.</p>
          <p><strong className="text-foreground">Report anything shady.</strong> Every listing, message, and profile has a report button. We investigate.</p>
        </div>
      </main>
      <Footer />
    </div>
  ),
});
