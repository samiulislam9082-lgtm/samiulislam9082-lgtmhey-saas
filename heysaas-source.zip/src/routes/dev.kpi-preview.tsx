import { createFileRoute } from "@tanstack/react-router";
import { Kpi } from "@/components/ui/kpi";
import { Sparkline } from "@/components/ui/sparkline";
import { DollarSign, Users, Eye, Repeat } from "lucide-react";
import { useEffect, useState } from "react";
import { formatFinancial } from "@/lib/format";

export const Route = createFileRoute("/dev/kpi-preview")({
  head: () => ({ meta: [{ title: "KPI QA" }, { name: "robots", content: "noindex" }] }),
  component: KpiPreview,
});

const trend = [4, 6, 5, 8, 7, 9, 11, 10, 13, 15, 14, 18];
const flat = [5, 5, 5, 5, 5, 5, 5];
const down = [12, 10, 11, 9, 8, 7, 6];

function KpiPreview() {
  const [theme, setTheme] = useState<"light" | "dark">(
    typeof document !== "undefined" && document.documentElement.classList.contains("light") ? "light" : "dark"
  );
  useEffect(() => {
    const e = document.documentElement;
    e.classList.toggle("light", theme === "light");
    e.classList.toggle("dark", theme === "dark");
    e.style.colorScheme = theme;
  }, [theme]);

  const samples = [
    { label: "MRR", value: 12480, format: "currency" as const, delta: 0.124, spark: trend, icon: DollarSign },
    { label: "Users", value: 3421, format: "compact" as const, delta: 0.048, spark: trend, icon: Users, sub: "in last 7 days" },
    { label: "Views", value: 87200, format: "compact" as const, delta: -0.032, spark: down, icon: Eye },
    { label: "Swaps", value: 12, format: "number" as const, delta: 0, spark: flat, icon: Repeat, sub: "unchanged" },
    { label: "Revenue (large)", value: 2_450_000, format: "currency" as const, delta: 0.21, spark: trend, icon: DollarSign },
    { label: "Empty state", value: 0, format: "number" as const, delta: null, spark: null, icon: Eye },
  ];

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <div className="mx-auto max-w-6xl px-6 py-12 space-y-10">
        <header className="flex items-end justify-between gap-4">
          <div>
            <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Visual QA</div>
            <h1 className="font-display text-4xl">KPI & Sparkline</h1>
            <p className="text-sm text-muted-foreground">
              Formatter check: {formatFinancial(12480, "currency")} · {formatFinancial(2_450_000, "currency")} · {formatFinancial(3421, "compact")}
            </p>
          </div>
          <button
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="rounded-full border border-hairline px-4 py-2 text-sm hover:border-foreground/40"
          >
            {theme === "light" ? "→ Dark" : "→ Light"}
          </button>
        </header>

        <section>
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-widest text-muted-foreground">HeySaaS (default tone)</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {samples.map((s, i) => (
              <Kpi key={i} {...s} />
            ))}
          </div>
        </section>

        <section className="ws-root bg-[#04101a] p-8 rounded-2xl">
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-widest text-[#2dd4bf]">WebSwap tone</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {samples.map((s, i) => (
              <Kpi key={i} {...s} tone="ws" />
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-widest text-muted-foreground">Sparkline sizes</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl border border-hairline p-4 text-violet">
              <div className="text-xs text-muted-foreground mb-2">h=24</div>
              <Sparkline points={trend} height={24} />
            </div>
            <div className="rounded-2xl border border-hairline p-4 text-violet">
              <div className="text-xs text-muted-foreground mb-2">h=40 (default)</div>
              <Sparkline points={trend} />
            </div>
            <div className="rounded-2xl border border-hairline p-4 text-muted-foreground">
              <div className="text-xs mb-2">empty</div>
              <Sparkline points={null} />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
