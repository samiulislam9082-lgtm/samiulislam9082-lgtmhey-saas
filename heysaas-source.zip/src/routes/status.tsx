import { createFileRoute } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { useEffect, useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, Circle } from "lucide-react";

export const Route = createFileRoute("/status")({
  head: () =>
    buildHead({
      path: "/status",
      title: "Platform Status — Hey SaaS",
      description: "Live platform metrics and system status for Hey SaaS.",
    }),
  component: StatusPage,
});

function StatusPage() {
  const [metrics, setMetrics] = useState({ founders: 0, listings: 0, swaps: 0 });

  useEffect(() => {
    (async () => {
      const [f, l, s] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("saas_listings").select("id", { count: "exact", head: true }).eq("status", "live"),
        supabase.from("swap_requests").select("id", { count: "exact", head: true }).eq("status", "completed"),
      ]);
      setMetrics({ founders: f.count || 0, listings: l.count || 0, swaps: s.count || 0 });
    })();
  }, []);

  const systems = [
    { name: "Web app", status: "operational" },
    { name: "Auth", status: "operational" },
    { name: "Database", status: "operational" },
    { name: "Storage", status: "operational" },
    { name: "Payments", status: "operational" },
  ];

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1">
        <section className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-20">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-4 py-1.5 text-xs uppercase tracking-wider text-emerald-400">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            All systems operational
          </div>
          <h1 className="mt-6 font-display text-5xl md:text-6xl">Platform status</h1>
          <p className="mt-4 text-lg text-muted-foreground">Real-time metrics for Hey SaaS.</p>

          <div className="mt-12 grid gap-4 grid-cols-1 md:grid-cols-3">
            {[
              { label: "Founders", value: metrics.founders },
              { label: "Live listings", value: metrics.listings },
              { label: "Completed swaps", value: metrics.swaps },
            ].map((m) => (
              <div key={m.label} className="rounded-2xl border border-hairline bg-surface p-6">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{m.label}</div>
                <div className="mt-2 font-display text-4xl">{m.value.toLocaleString()}</div>
              </div>
            ))}
          </div>

          <div className="mt-12 rounded-2xl border border-hairline bg-surface p-6">
            <h2 className="font-display text-2xl">Systems</h2>
            <ul className="mt-4 divide-y divide-hairline">
              {systems.map((s) => (
                <li key={s.name} className="flex items-center justify-between py-3">
                  <span>{s.name}</span>
                  <span className="inline-flex items-center gap-2 text-sm text-emerald-400">
                    <CheckCircle2 className="h-4 w-4" /> Operational
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-12 rounded-2xl border border-hairline bg-surface p-6">
            <h2 className="font-display text-2xl">Launch roadmap</h2>
            <ul className="mt-4 space-y-3 text-sm">
              {[
                { label: "Design system & auth", done: true },
                { label: "Listings & discovery", done: true },
                { label: "Swap loop & safety fee", done: true },
                { label: "Admin & trust tooling", done: true },
                { label: "SEO, sitemap & JSON-LD", done: true },
                { label: "Rate limits, GDPR export & delete", done: true },
                { label: "Public launch", done: false },
              ].map((r) => (
                <li key={r.label} className="flex items-center gap-2">
                  {r.done ? <CheckCircle2 className="h-4 w-4 text-emerald-400" /> : <Circle className="h-4 w-4 text-muted-foreground" />}
                  <span className={r.done ? "" : "text-muted-foreground"}>{r.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
