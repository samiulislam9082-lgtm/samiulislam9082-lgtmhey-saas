import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/robots.txt")({
  server: {
    handlers: {
      GET: async () => {
        const base = (process.env.PUBLIC_URL || "https://heysaas.lovable.app").replace(/\/$/, "");
        const body = `User-agent: *
Allow: /
Disallow: /dashboard
Disallow: /admin
Disallow: /auth
Disallow: /onboarding
Disallow: /reset-password
Disallow: /list

Sitemap: ${base}/sitemap.xml
`;
        return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "public, max-age=86400" } });
      },
    },
  },
});
