import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const BASE = () => process.env.PUBLIC_URL || "https://heysaas.lovable.app";

function urlXml(loc: string, changefreq = "weekly", priority = 0.6, lastmod?: string) {
  return `  <url><loc>${loc}</loc>${lastmod ? `<lastmod>${lastmod}</lastmod>` : ""}<changefreq>${changefreq}</changefreq><priority>${priority}</priority></url>`;
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const base = BASE().replace(/\/$/, "");
        const staticPaths = [
          ["/", "daily", 1.0],
          ["/explore", "hourly", 0.9],
          ["/how-it-works", "monthly", 0.7],
          ["/pricing", "monthly", 0.7],
          ["/leaderboard", "daily", 0.6],
          ["/founders", "daily", 0.6],
          ["/about", "monthly", 0.5],
          ["/blog", "daily", 0.6],
          ["/guidelines", "monthly", 0.4],
          ["/legal/terms", "yearly", 0.3],
          ["/legal/privacy", "yearly", 0.3],
          ["/legal/safety-fee-policy", "yearly", 0.3],
          ["/compare", "weekly", 0.5],
          ["/status", "weekly", 0.3],
        ] as const;

        let listings: { slug: string; updated_at: string }[] = [];
        let posts: { slug: string; updated_at: string }[] = [];
        let founders: { username: string; updated_at: string }[] = [];
        try {
          const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
          const supabasePublic = createClient<Database>(process.env.SUPABASE_URL!, key, {
            auth: { persistSession: false, autoRefreshToken: false },
            global: {
              fetch: (input, init) => {
                const h = new Headers(init?.headers);
                if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
                h.set("apikey", key);
                return fetch(input, { ...init, headers: h });
              },
            },
          });
          const [l, p, f] = await Promise.all([
            supabasePublic.from("saas_listings").select("slug, updated_at").eq("status", "live").limit(1000),
            supabasePublic.from("posts").select("slug, updated_at").not("published_at", "is", null).limit(1000),
            supabasePublic.from("profiles").select("username, updated_at").not("username", "is", null).limit(1000),
          ]);
          listings = (l.data as any) ?? [];
          posts = (p.data as any) ?? [];
          founders = (f.data as any) ?? [];
        } catch (e) {
          console.error("sitemap fetch failed", e);
        }

        const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${staticPaths.map(([p, cf, pr]) => urlXml(base + p, cf as string, pr as number)).join("\n")}
${listings.map((l) => urlXml(`${base}/saas/${l.slug}`, "weekly", 0.7, l.updated_at)).join("\n")}
${posts.map((p) => urlXml(`${base}/blog/${p.slug}`, "monthly", 0.6, p.updated_at)).join("\n")}
${founders.map((f) => urlXml(`${base}/@${f.username}`, "weekly", 0.5, f.updated_at)).join("\n")}
</urlset>`;
        return new Response(xml, { headers: { "Content-Type": "application/xml; charset=utf-8", "Cache-Control": "public, max-age=3600" } });
      },
    },
  },
});
