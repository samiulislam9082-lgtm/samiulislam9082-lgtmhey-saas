import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Check, ArrowRight, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/pricing")({
  head: () =>
    buildHead({
      path: "/pricing",
      title: "Pricing — HeySaaS",
      description:
        "Free listings, free browsing. $19 flat safety fee per side, only when a swap is mutually agreed. No hidden costs.",
    }),
  component: Pricing,
});

const included = [
  "Unlimited SaaS listings",
  "Unlimited swap proposals",
  "Private messaging",
  "Founder profile with swap history",
  "Bookmarks & 'Interested' signals",
  "Verified handover checklist",
  "Fully refundable if the other side ghosts",
];

const faqs = [
  { q: "When am I charged?", a: "Only when both founders click Confirm on a swap. Not before. No card required to list, browse, or negotiate." },
  { q: "What if the other side never pays?", a: "You get a full automatic refund. The Swap Room only unlocks when both fees clear." },
  { q: "Does HeySaaS take a cut of the SaaS?", a: "No. HeySaaS never touches the product, the customers, or any money moving between founders. The $19 goes to the platform for safe-handover infrastructure." },
  { q: "Is there a Pro plan?", a: "Not today. Promotion slots (optional) are $49 per listing for 14 days. Everything else is free." },
];

function Pricing() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />
          <div className="absolute inset-0 hero-grid pointer-events-none" />
          <div className="relative mx-auto max-w-5xl px-6 sm:px-10 pt-20 pb-8 md:pt-28 text-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-violet/30 bg-violet/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.22em] text-violet-glow">
              Pricing
            </div>
            <h1 className="mt-6 font-display text-5xl md:text-7xl leading-[0.95] text-balance">
              One fee. <span className="italic text-violet-glow">Only if you swap.</span>
            </h1>
            <p className="mt-6 mx-auto max-w-2xl text-lg text-muted-foreground">
              Listing and browsing are free forever. The only money that ever moves is a flat $19 safety fee, charged to each side <em>only after</em> both parties confirm a swap.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-6 sm:px-10 pb-16">
          <div className="relative rounded-[2rem] overflow-hidden border border-hairline bg-surface p-10 md:p-14 shadow-[var(--shadow-lift)]">
            <div aria-hidden className="absolute -top-20 -right-20 h-64 w-64 rounded-full hs-aurora pointer-events-none" />
            <div className="relative grid gap-10 md:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)] md:items-start">
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="font-display text-6xl md:text-8xl leading-none">$19</span>
                  <span className="text-muted-foreground">/ founder / swap</span>
                </div>
                <p className="mt-4 text-muted-foreground max-w-md">
                  Charged only when both sides confirm. No swap = no fee. If the other founder never pays, you get a full refund automatically.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <Link to="/list" className="inline-flex items-center gap-2 rounded-xl bg-violet px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors" style={{ boxShadow: "var(--shadow-glow)" }}>
                    List your first SaaS <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link to="/legal/safety-fee-policy" className="text-sm text-muted-foreground hover:text-foreground">
                    Read the safety fee policy →
                  </Link>
                </div>

                <div className="mt-8 inline-flex items-center gap-2 rounded-full border border-hairline bg-background/40 px-3 py-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-violet-glow" /> Refundable if the other side ghosts
                </div>
              </div>

              <ul className="grid gap-3 sm:grid-cols-2">
                {included.map((i) => (
                  <li key={i} className="flex items-start gap-3 rounded-xl border border-hairline bg-background/40 p-3">
                    <Check className="h-4 w-4 text-violet-glow shrink-0 mt-0.5" />
                    <span className="text-sm">{i}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="mx-auto max-w-5xl px-6 sm:px-10 pb-24">
          <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Frequently asked</div>
          <h2 className="mt-3 font-display text-3xl md:text-5xl">Questions, answered.</h2>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {faqs.map((f) => (
              <div key={f.q} className="rounded-2xl border border-hairline bg-surface p-6">
                <h3 className="font-display text-xl">{f.q}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.a}</p>
              </div>
            ))}
          </div>
          <p className="mt-8 text-xs text-muted-foreground max-w-2xl">
            HeySaaS never handles money between founders. The $19 fee goes to the platform for safe-handover infrastructure — not to the other founder.
          </p>
        </section>
      </main>
      <Footer />
    </div>
  );
}
