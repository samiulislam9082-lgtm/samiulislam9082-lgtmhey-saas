import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Share2, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/s/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `Shared search — HeySaaS` },
      { name: "description", content: `A shared saved search on HeySaaS (${params.slug}).` },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SharedPresetPage,
});

type Preset = {
  id: string;
  name: string;
  q: string | null;
  category_id: string | null;
  mrr_ranges: string[];
  tech_stack: string[];
  countries: string[];
  pricing_models: string[];
  looking_for: string[];
  sort: string;
  share_slug: string;
};

function SharedPresetPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const [preset, setPreset] = useState<Preset | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from("saved_searches")
        .select("id, name, q, category_id, mrr_ranges, tech_stack, countries, pricing_models, looking_for, sort, share_slug")
        .eq("share_slug", slug)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) { setNotFound(true); setLoading(false); return; }
      setPreset(data as unknown as Preset);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [slug]);

  const chip = (label: string) => (
    <span key={label} className="inline-flex items-center rounded-full border border-hairline bg-surface px-2.5 py-0.5 text-[11px] text-muted-foreground">{label}</span>
  );

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-2xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-6 inline-flex items-center gap-2 text-xs text-muted-foreground">
          <Share2 className="h-3.5 w-3.5" /> Shared search
        </div>
        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : notFound || !preset ? (
          <Card className="p-8 text-center">
            <p className="font-display text-2xl">This search isn't available</p>
            <p className="mt-2 text-sm text-muted-foreground">The owner may have unshared it, or the link is wrong.</p>
            <Button asChild className="mt-6"><Link to="/explore">Go to Explore</Link></Button>
          </Card>
        ) : (
          <Card className="p-8">
            <p className="text-xs text-muted-foreground">Someone shared this saved search with you</p>
            <h1 className="mt-1 font-display text-3xl">{preset.name}</h1>

            <div className="mt-5 space-y-3">
              {preset.q && <div className="text-sm"><span className="text-muted-foreground">Query:</span> "{preset.q}"</div>}
              <div className="flex flex-wrap gap-1.5">
                {preset.mrr_ranges.map((v) => chip(`MRR ${v}`))}
                {preset.tech_stack.map((v) => chip(v))}
                {preset.countries.map((v) => chip(v))}
                {preset.pricing_models.map((v) => chip(v))}
                {preset.looking_for.map((v) => chip(v))}
              </div>
              <div className="text-xs text-muted-foreground">Sort: {preset.sort}</div>
            </div>

            <div className="mt-8 flex gap-3">
              <Button
                onClick={() => navigate({ to: "/explore", search: { share: slug } as any })}
                className="gap-2"
              >
                Open in Explore <ArrowRight className="h-4 w-4" />
              </Button>
              <Button asChild variant="outline"><Link to="/explore">Browse all</Link></Button>
            </div>
          </Card>
        )}
      </main>
      <Footer />
    </div>
  );
}
