import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { ArrowRight, Sparkles, Repeat, Shield, TrendingUp, CheckCircle2, Zap, Users, Lock } from "lucide-react";
import { Fragment, useEffect, useState, type ComponentType, type SVGProps } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { supabase } from "@/integrations/supabase/client";
import {
  SiNotion, SiLinear, SiFigma, SiVercel, SiStripe, SiSupabase, SiFramer, SiLoom,
  SiAnthropic, SiGithub, SiDiscord, SiRaycast, SiAirtable, SiWebflow, SiZapier,
  SiIntercom, SiPosthog, SiMixpanel, SiCloudflare, SiSubstack, SiClickup, SiTrello,
  SiDropbox, SiAsana, SiPostgresql, SiRailway, SiNetlify, SiAlgolia, SiSentry,
  SiTypeform, SiMiro, SiShopify,
} from "react-icons/si";

const BRAND_ICONS: Record<string, ComponentType<SVGProps<SVGSVGElement>>> = {
  notion: SiNotion, linear: SiLinear, figma: SiFigma, vercel: SiVercel, stripe: SiStripe,
  supabase: SiSupabase, framer: SiFramer, loom: SiLoom, anthropic: SiAnthropic,
  github: SiGithub, discord: SiDiscord, raycast: SiRaycast, airtable: SiAirtable,
  webflow: SiWebflow, zapier: SiZapier, intercom: SiIntercom, posthog: SiPosthog,
  mixpanel: SiMixpanel, cloudflare: SiCloudflare, substack: SiSubstack, clickup: SiClickup,
  trello: SiTrello, dropbox: SiDropbox, asana: SiAsana, postgresql: SiPostgresql,
  railway: SiRailway, netlify: SiNetlify, algolia: SiAlgolia, sentry: SiSentry,
  typeform: SiTypeform, miro: SiMiro, shopify: SiShopify,
};

function BrandIcon({ slug, name }: { slug: string; name: string }) {
  const Icon = BRAND_ICONS[slug];
  if (!Icon) {
    return <span className="hs-logo-fallback" aria-hidden>{name.slice(0, 1)}</span>;
  }
  return <Icon aria-hidden focusable={false} color="#ffffff" />;
}

export const Route = createFileRoute("/")({
  head: () =>
    buildHead({
      path: "/",
      title: "HeySaaS — Swap your SaaS, not your money",
      description:
        "The editorial marketplace where founders exchange SaaS products directly. No cash between users. No brokers. Just great matches.",
    }),
  component: Landing,
});

const steps = [
  { icon: Sparkles, title: "List your SaaS", desc: "Unlimited free listings. Add your product, revenue, and what you're looking for." },
  { icon: Repeat,   title: "Find a match",   desc: "Browse SaaS from founders who want to swap. Propose a trade in one click." },
  { icon: Shield,   title: "Swap securely",  desc: "Once you both agree, a $19 safety fee unlocks a private handover room." },
];

const principles = [
  { icon: Zap,   title: "Direct",    copy: "No brokers, no listing agents, no percentage cuts. Founders talk to founders.", stat: "0%", statLabel: "commission", tag: "No middlemen" },
  { icon: Lock,  title: "Escrowed",  copy: "The $19 safety fee protects both sides. Refundable if the other side ghosts.", stat: "$19", statLabel: "safety fee", tag: "Refundable" },
  { icon: Users, title: "Editorial", copy: "A curated directory — not a firehose. We reject spammy, low-signal listings.",  stat: "37%", statLabel: "approval rate", tag: "Hand-reviewed" },
];

type Logo = { slug: string; name: string; size?: "sm" | "md" | "lg"; featured?: boolean };
const LOGOS_A: Logo[] = [
  { slug: "notion", name: "Notion", size: "md" },
  { slug: "linear", name: "Linear", size: "lg", featured: true },
  { slug: "figma", name: "Figma", size: "sm" },
  { slug: "vercel", name: "Vercel", size: "md" },
  { slug: "stripe", name: "Stripe", size: "lg", featured: true },
  { slug: "supabase", name: "Supabase", size: "md" },
  { slug: "framer", name: "Framer", size: "sm" },
  { slug: "loom", name: "Loom", size: "md" },
  { slug: "anthropic", name: "Anthropic", size: "lg" },
  { slug: "github", name: "GitHub", size: "md" },
  { slug: "discord", name: "Discord", size: "sm" },
  { slug: "raycast", name: "Raycast", size: "md" },
];
const LOGOS_B: Logo[] = [
  { slug: "airtable", name: "Airtable", size: "sm" },
  { slug: "webflow", name: "Webflow", size: "md" },
  { slug: "zapier", name: "Zapier", size: "lg", featured: true },
  { slug: "intercom", name: "Intercom", size: "md" },
  { slug: "posthog", name: "PostHog", size: "sm" },
  { slug: "mixpanel", name: "Mixpanel", size: "md" },
  { slug: "cloudflare", name: "Cloudflare", size: "md" },
  { slug: "substack", name: "Substack", size: "sm" },
  { slug: "clickup", name: "ClickUp", size: "md" },
  { slug: "trello", name: "Trello", size: "sm" },
  { slug: "dropbox", name: "Dropbox", size: "md" },
  { slug: "asana", name: "Asana", size: "lg", featured: true },
];
const LOGOS_C: Logo[] = [
  { slug: "cloudflare", name: "Cloudflare", size: "md" },
  { slug: "postgresql", name: "Postgres", size: "sm" },
  { slug: "railway", name: "Railway", size: "md" },
  { slug: "netlify", name: "Netlify", size: "sm" },
  { slug: "algolia", name: "Algolia", size: "md", featured: true },
  { slug: "sentry", name: "Sentry", size: "sm" },
  { slug: "posthog", name: "PostHog", size: "md" },
  { slug: "typeform", name: "Typeform", size: "md" },
  { slug: "canva", name: "Canva", size: "lg" },
  { slug: "miro", name: "Miro", size: "sm" },
  { slug: "shopify", name: "Shopify", size: "md" },
];

type FeaturedListing = {
  id: string; slug: string; name: string; tagline: string | null;
  logo_url: string | null; mrr_range: string | null; interested_count: number | null;
  category_name?: string | null;
};

type CategoryRow = { id: string; name: string; slug: string };

function Landing() {
  const [featured, setFeatured] = useState<FeaturedListing[]>([]);
  const [categories, setCategories] = useState<CategoryRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [featRes, catRes] = await Promise.all([
        supabase
          .from("saas_listings")
          .select("id, slug, name, tagline, logo_url, mrr_range, interested_count, category_id, categories(name)")
          .eq("status", "live")
          .order("featured", { ascending: false })
          .order("interested_count", { ascending: false, nullsFirst: false })
          .order("created_at", { ascending: false })
          .limit(6),
        supabase.from("categories").select("id, name, slug").order("sort_order", { ascending: true }).limit(12),
      ]);
      if (cancelled) return;
      const feat = (featRes.data ?? []).map((r: any) => ({
        id: r.id, slug: r.slug, name: r.name, tagline: r.tagline,
        logo_url: r.logo_url, mrr_range: r.mrr_range, interested_count: r.interested_count,
        category_name: r.categories?.name ?? null,
      }));
      setFeatured(feat);
      setCategories((catRes.data ?? []) as CategoryRow[]);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);


  const sparkPath = (pts: number[]) => {
    const w = 100, h = 28;
    const min = Math.min(...pts), max = Math.max(...pts);
    const range = max - min || 1;
    const step = w / (pts.length - 1);
    return pts.map((v, i) => `${i === 0 ? "M" : "L"} ${(i * step).toFixed(2)} ${(h - ((v - min) / range) * h).toFixed(2)}`).join(" ");
  };


  return (
    <div className="min-h-dvh flex flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-[100] focus:rounded-md focus:bg-foreground focus:text-background focus:px-3 focus:py-2">
        Skip to content
      </a>
      <Header />

      <main id="main" className="flex-1">
        {/* HERO */}
        <section className="relative overflow-hidden" aria-labelledby="hero-heading">
          <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />
          <div className="absolute inset-0 hero-grid pointer-events-none" />
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 h-[560px] w-[900px] max-w-[110vw] rounded-full pointer-events-none hs-aurora" />
          <div className="absolute inset-0 hs-noise opacity-40 pointer-events-none" />

          {/* Bounded hero-frame wraps headline + logo bands so bands never spill into stats */}
          <div className="relative">
            {/* Floating logo constellation — layered marquees framing the hero */}
            <div aria-hidden className="hs-marquee-band hs-marquee-band--top">
              <div className="hs-marquee-tilt">
                <div className="hs-marquee flex gap-4 w-max" style={{ animationDuration: "70s" }}>
                  {[...LOGOS_A, ...LOGOS_A].map((l, i) => (
                    <span key={`a-${i}`} className={`hs-logo-chip hs-logo-chip--${l.size ?? "md"}${l.featured ? " is-featured" : ""}`} title={l.name}>
                      <BrandIcon slug={l.slug} name={l.name} />
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div aria-hidden className="hs-marquee-band hs-marquee-band--bottom">
              <div className="hs-marquee-tilt hs-marquee-tilt--rev">
                <div className="hs-marquee-rev flex gap-4 w-max" style={{ animationDuration: "95s" }}>
                  {[...LOGOS_B, ...LOGOS_B].map((l, i) => (
                    <span key={`b-${i}`} className={`hs-logo-chip hs-logo-chip--${l.size ?? "md"}${l.featured ? " is-featured" : ""}`} title={l.name}>
                      <BrandIcon slug={l.slug} name={l.name} />
                    </span>
                  ))}
                </div>
              </div>
            </div>
            {/* orbital rings behind headline */}
            <div aria-hidden className="hs-orbit hs-orbit--3" />
            <div aria-hidden className="hs-orbit hs-orbit--2" />
            <div aria-hidden className="hs-orbit hs-orbit--1" />
            {/* center spotlight to sink the marquees behind the headline */}
            <div aria-hidden className="hs-hero-spotlight" />

          <div className="relative mx-auto max-w-7xl px-6 sm:px-10 pt-16 pb-20 md:pt-24 md:pb-28">
            <div className="grid gap-14 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1.15fr)] items-center">
              <div className="animate-fade-up">
                <div className="inline-flex items-center gap-2 rounded-full border border-violet/30 bg-violet/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-violet-glow">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-violet opacity-75" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-violet" />
                  </span>
                  New listings added daily
                </div>

                <h1 id="hero-heading" className="mt-8 font-display text-[3.4rem] sm:text-7xl md:text-[5.5rem] lg:text-[6.25rem] leading-[0.9] tracking-tight text-balance">
                  Swap your SaaS.
                  <br />
                  <span className="italic bg-gradient-to-r from-violet to-violet-glow bg-clip-text text-transparent">
                    Not your money.
                  </span>
                </h1>

                <p className="mt-8 max-w-xl text-base md:text-lg text-muted-foreground leading-relaxed text-balance">
                  The editorial marketplace where founders exchange SaaS products directly.
                  No cash between users. No brokers. Just great matches.
                </p>

                <div className="mt-10 flex flex-col sm:flex-row gap-3">
                  <Link
                    to="/list"
                    className="group inline-flex items-center justify-center gap-2 rounded-xl bg-violet px-7 py-4 text-sm font-semibold text-primary-foreground transition-all hover:bg-violet-glow hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                    style={{ boxShadow: "var(--shadow-glow)" }}
                  >
                    List your SaaS
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </Link>
                  <Link
                    to="/explore"
                    className="inline-flex items-center justify-center gap-2 rounded-xl border border-hairline bg-surface/50 px-7 py-4 text-sm font-medium text-foreground backdrop-blur transition-colors hover:bg-surface focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    Browse SaaS
                  </Link>
                </div>

                <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-xs text-muted-foreground">
                  {["Free to list", "No brokers", "$19 flat safety fee", "Verified founders"].map((t) => (
                    <li key={t} className="inline-flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-violet-glow" aria-hidden="true" />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Hero-side visual — celestial nexus */}
              <div
                className="hs-nexus relative mx-auto aspect-square w-full max-w-[560px]"
                aria-label="SaaS swap match preview"
              >
                <div aria-hidden className="hs-nexus-glow hs-nexus-glow--a" />
                <div aria-hidden className="hs-nexus-glow hs-nexus-glow--b" />

                <svg aria-hidden className="hs-nexus-arcs" viewBox="0 0 560 560" fill="none">
                  <path d="M170 190 Q280 110 400 260" stroke="currentColor" strokeWidth="1" strokeDasharray="4 6" />
                  <path d="M150 350 Q300 470 420 330" stroke="currentColor" strokeWidth="1" strokeDasharray="4 6" />
                </svg>

                {/* Central nexus hub */}
                <div className="hs-nexus-hub">
                  <div aria-hidden className="hs-nexus-ring hs-nexus-ring--outer" />
                  <div aria-hidden className="hs-nexus-ring hs-nexus-ring--mid" />
                  <div className="hs-nexus-core">
                    <span className="text-[10px] font-semibold uppercase tracking-[0.24em] text-violet-glow/80">
                      Deal fit
                    </span>
                    <span className="mt-1 font-display text-5xl md:text-6xl italic leading-none tabular-nums">
                      94<span className="ml-1 text-2xl not-italic">%</span>
                    </span>
                  </div>
                  <div className="hs-nexus-fee">
                    <Shield className="h-3 w-3 text-violet-glow" aria-hidden />
                    <span>$19 safety fee</span>
                  </div>
                </div>

                {/* Node one */}
                <div className="hs-nexus-node hs-nexus-node--left" aria-label="Verified SaaS listing MetricsHQ">
                  <div className="flex items-start justify-between gap-3">
                    <span className="hs-desk-logo hs-desk-logo--bars" aria-hidden>
                      <span />
                      <span />
                      <span />
                    </span>
                    <span className="hs-desk-chip">Yours</span>
                  </div>
                  <div className="mt-5 flex items-center gap-1.5">
                    <h3 className="font-display text-2xl leading-none">MetricsHQ</h3>
                    <CheckCircle2 className="h-3.5 w-3.5 text-violet-glow" aria-hidden />
                  </div>
                  <p className="mt-2 text-[10px] font-medium uppercase tracking-[0.2em] text-violet-glow/80">
                    Analytics · B2B
                  </p>
                  <div className="mt-5 grid grid-cols-2 gap-4 border-t border-hairline pt-4">
                    {[
                      ["MRR", "$2.4k"],
                      ["Users", "1.8k"],
                    ].map(([label, value]) => (
                      <div key={label}>
                        <p className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</p>
                        <p className="mt-0.5 text-lg font-medium tabular-nums">{value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Node two */}
                <div className="hs-nexus-node hs-nexus-node--right" aria-label="Verified SaaS listing Inboxly">
                  <div className="flex items-start justify-between gap-3">
                    <span className="hs-desk-logo hs-desk-logo--mail" aria-hidden>
                      <span />
                    </span>
                    <span className="hs-desk-chip hs-desk-chip--accent">Target</span>
                  </div>
                  <div className="mt-5 flex items-center gap-1.5">
                    <h3 className="font-display text-2xl leading-none">Inboxly</h3>
                    <CheckCircle2 className="h-3.5 w-3.5 text-violet-glow" aria-hidden />
                  </div>
                  <p className="mt-2 text-[10px] font-medium uppercase tracking-[0.2em] text-violet-glow/80">
                    Email · PLG
                  </p>
                  <div className="mt-5 space-y-3 border-t border-hairline pt-4">
                    <div className="flex items-end justify-between text-[10px] uppercase tracking-wider">
                      <span className="text-muted-foreground">Liquidity</span>
                      <span className="text-violet-glow">High</span>
                    </div>
                    <div className="hs-desk-meter">
                      <span />
                    </div>
                    <p className="flex items-center gap-2 text-[10px] italic text-muted-foreground">
                      <span className="hs-typing-dot" aria-hidden />
                      Nadia is reviewing terms
                    </p>
                  </div>
                </div>

                <span className="hs-nexus-orbit" aria-hidden>
                  <Repeat className="h-4 w-4" />
                </span>
              </div>


            </div>
          </div>
          </div>

          {/* Live activity ticker — a premium news-rail between hero + stats */}
          <div className="relative mx-auto max-w-7xl px-6 sm:px-10 mt-6">
            <div className="hs-ticker-wrap relative">
              {/* Left LIVE badge — sits above the rail */}
              <div className="hs-ticker-badge">
                <span className="hs-ticker-pulse" aria-hidden />
                <span className="text-[10px] font-semibold tracking-[0.24em] uppercase text-foreground">Live</span>
                <span className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground hidden sm:inline">Swap Feed</span>
              </div>

              {/* Right metric chip */}
              <div className="hs-ticker-metric">
                <span className="hs-ticker-metric-dot" aria-hidden />
                <span className="text-[10px] font-medium tracking-[0.18em] uppercase text-muted-foreground">Now</span>
                <span className="text-[11px] font-semibold text-foreground tabular-nums">+128 <span className="text-muted-foreground font-normal">today</span></span>
              </div>

              <div className="hs-ticker relative overflow-hidden rounded-2xl border border-hairline bg-surface/60 backdrop-blur-xl">
                {/* gradient hairline edge */}
                <div className="hs-ticker-edge" aria-hidden />
                <div className="hs-ticker-track flex items-center gap-8 py-3.5 pl-[132px] sm:pl-[220px] pr-[150px] whitespace-nowrap">
                  {[
                    { who: "Nadia", from: "MetricsHQ", to: "Inboxly", when: "2m", mrr: "$4.2k" },
                    { who: "Ravi",  from: "Docket",    to: "Formly",  when: "14m", mrr: "$1.9k" },
                    { who: "Sara",  from: "PixelPad",  to: "Waveform", when: "27m", mrr: "$6.1k" },
                    { who: "Leo",   from: "Stashly",   to: "CopyKit",  when: "41m", mrr: "$820" },
                    { who: "Mika",  from: "Loopnote",  to: "Signalr",  when: "1h", mrr: "$3.4k" },
                    { who: "Owen",  from: "Chartly",   to: "Boardhub", when: "1h", mrr: "$2.7k" },
                    { who: "Anya",  from: "Tinybase",  to: "Fastmail Pro", when: "2h", mrr: "$5.0k" },
                    { who: "Jules", from: "Snapdesk",  to: "Threadly", when: "3h", mrr: "$1.1k" },
                  ].concat([
                    { who: "Nadia", from: "MetricsHQ", to: "Inboxly", when: "2m", mrr: "$4.2k" },
                    { who: "Ravi",  from: "Docket",    to: "Formly",  when: "14m", mrr: "$1.9k" },
                    { who: "Sara",  from: "PixelPad",  to: "Waveform", when: "27m", mrr: "$6.1k" },
                    { who: "Leo",   from: "Stashly",   to: "CopyKit",  when: "41m", mrr: "$820" },
                    { who: "Mika",  from: "Loopnote",  to: "Signalr",  when: "1h", mrr: "$3.4k" },
                    { who: "Owen",  from: "Chartly",   to: "Boardhub", when: "1h", mrr: "$2.7k" },
                    { who: "Anya",  from: "Tinybase",  to: "Fastmail Pro", when: "2h", mrr: "$5.0k" },
                    { who: "Jules", from: "Snapdesk",  to: "Threadly", when: "3h", mrr: "$1.1k" },
                  ]).map((t, i) => (
                    <span key={i} className="hs-ticker-item inline-flex items-center gap-2.5 text-xs">
                      <span className="hs-ticker-avatar" aria-hidden>{t.who[0]}</span>
                      <span className="text-foreground font-medium">{t.who}</span>
                      <span className="text-muted-foreground">swapped</span>
                      <span className="hs-ticker-pill">{t.from}</span>
                      <Repeat className="h-3 w-3 text-violet-glow" />
                      <span className="hs-ticker-pill hs-ticker-pill--accent">{t.to}</span>
                      <span className="hs-ticker-mrr tabular-nums">{t.mrr}<span className="text-muted-foreground font-normal">/mo</span></span>
                      <span className="text-muted-foreground text-[10px] tracking-wide">{t.when} ago</span>
                      <span className="mx-4 h-3.5 w-px bg-hairline/70" />
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>



        </section>

        {/* LIVE MARKET INDEX — Bloomberg-style category ticker */}

        {/* HOW IT WORKS */}
        <section className="mx-auto max-w-7xl px-6 sm:px-10 py-20 md:py-28" aria-labelledby="how-heading">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] lg:items-end">
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">How it works</div>
              <h2 id="how-heading" className="mt-3 font-display text-4xl md:text-6xl leading-[0.95] text-balance">
                Simple path <span className="italic text-violet-glow">to a swap.</span>
              </h2>
            </div>
            <p className="text-muted-foreground max-w-xl">
              Three steps. No cash between founders, no brokers, no lawyers on retainer. You match, you agree, you hand over — with a small safety fee keeping both sides honest.
            </p>
          </div>

          <div className="mt-14 relative">
            {/* Flowing connector rail (desktop) */}
            <div aria-hidden="true" className="hidden md:block absolute left-8 right-8 top-[108px] h-px pointer-events-none">
              <div className="hs-flow-rail" />
              <div className="hs-flow-pulse" />
            </div>

            <ol className="grid gap-6 md:grid-cols-3 relative">
              {steps.map((s, i) => (
                <li key={s.title} className="hs-step group relative rounded-3xl border border-hairline bg-surface/60 p-8 transition-all hover:-translate-y-1 hover:border-violet/50 overflow-hidden">
                  {/* corner index watermark */}
                  <div aria-hidden="true" className="pointer-events-none absolute -right-3 -top-6 font-display text-[7rem] leading-none text-violet/[0.06] select-none">
                    {String(i + 1).padStart(2, "0")}
                  </div>

                  <div className="relative flex items-center justify-between">
                    <div className="relative">
                      <div className="hs-step-badge inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-violet/30 bg-gradient-to-br from-violet/20 to-violet/5 text-violet-glow font-display text-lg tracking-tight transition-colors group-hover:bg-violet group-hover:text-primary-foreground">
                        {String(i + 1).padStart(2, "0")}
                      </div>
                      <span aria-hidden="true" className="hs-step-halo" />
                    </div>
                    <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      <span className="h-1.5 w-1.5 rounded-full bg-violet-glow animate-pulse" />
                      Step {i + 1} of 3
                    </div>
                  </div>

                  <div className="relative mt-6 flex items-center gap-3">
                    <s.icon className="h-5 w-5 text-violet-glow" aria-hidden="true" />
                    <h3 className="font-display text-2xl">{s.title}</h3>
                  </div>
                  <p className="relative mt-3 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>

                  {/* progress glyph strip */}
                  <div className="relative mt-6 flex items-center gap-1.5">
                    {Array.from({ length: 18 }).map((_, k) => (
                      <span
                        key={k}
                        className="h-1 flex-1 rounded-full"
                        style={{
                          background:
                            k < (i + 1) * 6
                              ? "color-mix(in oklab, var(--violet-glow) 65%, transparent)"
                              : "color-mix(in oklab, var(--violet-glow) 12%, transparent)",
                        }}
                      />
                    ))}
                  </div>

                  {/* arrow to next step (desktop) */}
                  {i < 2 && (
                    <div aria-hidden="true" className="hidden md:flex hs-step-arrow">
                      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M5 12h14M13 6l6 6-6 6" />
                      </svg>
                    </div>
                  )}
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* PRINCIPLES */}
        <section className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28" aria-labelledby="principles-heading">
          <div className="flex items-end justify-between flex-wrap gap-4 mb-8">
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">What we stand for</div>
              <h2 id="principles-heading" className="mt-3 font-display text-3xl sm:text-4xl md:text-5xl leading-[0.95]">
                Three <span className="italic text-violet-glow">non-negotiables.</span>
              </h2>
            </div>
            <div className="text-xs text-muted-foreground max-w-sm">
              The rules we won't bend, even when it would grow us faster. Read them, hold us to them.
            </div>
          </div>

          <div className="hs-principles-grid rounded-[2rem] border border-hairline overflow-hidden bg-surface/30 relative">
            {/* ambient sheen */}
            <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-60"
              style={{
                background:
                  "radial-gradient(1200px 200px at 20% 0%, color-mix(in oklab, var(--violet-glow) 12%, transparent), transparent 60%), radial-gradient(900px 200px at 80% 100%, color-mix(in oklab, var(--violet-glow) 10%, transparent), transparent 60%)",
              }} />
            <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-hairline relative">
              {principles.map((p, i) => (
                <article
                  key={p.title}
                  className="hs-principle group relative p-8 md:p-10 overflow-hidden"
                >
                  {/* index + tag */}
                  <div className="flex items-center justify-between">
                    <div className="font-display italic text-sm text-muted-foreground/70">
                      / {String(i + 1).padStart(2, "0")}
                    </div>
                    <span className="hs-principle-tag">{p.tag}</span>
                  </div>

                  {/* icon plate */}
                  <div className="mt-6 relative inline-flex">
                    <span aria-hidden="true" className="hs-principle-icon-halo" />
                    <div className="relative inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-violet/30 bg-gradient-to-br from-violet/20 to-violet/5">
                      <p.icon className="h-5 w-5 text-violet-glow" aria-hidden="true" />
                    </div>
                  </div>

                  <h3 className="mt-6 font-display text-2xl">{p.title}</h3>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed max-w-sm">{p.copy}</p>

                  {/* stat row */}
                  <div className="mt-8 pt-6 border-t border-hairline flex items-end justify-between">
                    <div>
                      <div className="font-display text-3xl leading-none tracking-tight">
                        <span className="bg-gradient-to-br from-foreground to-violet-glow bg-clip-text text-transparent">
                          {p.stat}
                        </span>
                      </div>
                      <div className="mt-1.5 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{p.statLabel}</div>
                    </div>
                    <div aria-hidden="true" className="hs-principle-mark">
                      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M5 12l4 4L19 6" />
                      </svg>
                    </div>
                  </div>

                  {/* bottom scan line */}
                  <span aria-hidden="true" className="hs-principle-scan" />
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* FEATURED */}
        <section className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28" aria-labelledby="featured-heading">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4 mb-10">
            <div className="min-w-0">
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground inline-flex items-center gap-2">
                <span className="relative inline-flex h-2 w-2">
                  <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-70" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                <TrendingUp className="h-3.5 w-3.5" aria-hidden="true" /> Live on HeySaaS
                <span className="text-muted-foreground/60">·</span>
                <span className="font-mono tabular-nums">{featured.length.toString().padStart(2, "0")}</span>
              </div>
              <h2 id="featured-heading" className="mt-3 font-display text-3xl sm:text-4xl md:text-5xl leading-[0.95] text-balance">
                Featured <span className="italic text-violet-glow">opportunities.</span>
              </h2>
            </div>
            <Link
              to="/explore"
              className="shrink-0 group inline-flex items-center gap-2 text-sm text-foreground hover:text-violet-glow transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-full border border-hairline hover:border-violet/50 bg-surface/50 px-4 py-2"
            >
              View all
              <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-violet/15 border border-violet/30 text-violet-glow transition-transform group-hover:translate-x-0.5">
                <ArrowRight className="h-3 w-3" />
              </span>
            </Link>
          </div>

          {loading ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-56 rounded-2xl border border-hairline bg-surface animate-pulse" />
              ))}
            </div>
          ) : featured.length === 0 ? (
            <div className="rounded-3xl border border-hairline bg-surface p-10 md:p-14 text-center">
              <div className="mx-auto inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-violet to-violet-glow">
                <Sparkles className="h-5 w-5 text-primary-foreground" aria-hidden="true" />
              </div>
              <h3 className="mt-6 font-display text-2xl">No SaaS listed yet</h3>
              <p className="mt-3 mx-auto max-w-md text-sm text-muted-foreground">
                Be the very first founder to list. Free forever. You only pay when a swap is agreed.
              </p>
              <Link
                to="/list"
                className="mt-8 inline-flex items-center gap-2 rounded-xl bg-violet px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors"
              >
                List your SaaS <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          ) : (
            <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {featured.map((f, idx) => (
                <li key={f.id}>
                  <Link
                    to="/saas/$slug"
                    params={{ slug: f.slug }}
                    aria-label={`View ${f.name}`}
                    className="hs-feat-card group relative block h-full rounded-2xl border border-hairline bg-surface/70 p-6 overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div aria-hidden="true" className="pointer-events-none absolute right-4 top-3 font-display italic text-xs text-muted-foreground/50">
                      / {String(idx + 1).padStart(2, "0")}
                    </div>
                    <span aria-hidden="true" className="hs-feat-sheen" />

                    <div className="relative grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                      <div className="flex min-w-0 items-center gap-3">
                        <div className="relative shrink-0">
                          {f.logo_url ? (
                            <img src={f.logo_url} alt="" className="h-12 w-12 rounded-xl object-cover ring-1 ring-hairline" />
                          ) : (
                            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-violet/80 to-violet-glow/60 flex items-center justify-center font-display text-lg text-primary-foreground ring-1 ring-violet/40">
                              {f.name[0]?.toUpperCase()}
                            </div>
                          )}
                          <span aria-hidden="true" className="hs-feat-logo-halo" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-medium truncate text-base group-hover:text-violet-glow transition-colors">{f.name}</div>
                          <div className="mt-0.5 text-[11px] uppercase tracking-[0.14em] text-muted-foreground truncate">{f.category_name ?? "Uncategorized"}</div>
                        </div>
                      </div>
                      <span className="hs-feat-status shrink-0">
                        <span className="hs-feat-status-dot" /> Open
                      </span>
                    </div>

                    {f.tagline && (
                      <p className="relative mt-5 text-sm text-muted-foreground leading-relaxed line-clamp-2">{f.tagline}</p>
                    )}

                    <div className="relative mt-5">
                      <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                        <span>MRR band</span>
                        <span className="tabular-nums text-foreground/80">{f.mrr_range ?? "Undisclosed"}</span>
                      </div>
                      <div className="mt-2 h-1 rounded-full bg-hairline/60 overflow-hidden">
                        <div className="hs-feat-meter h-full rounded-full" style={{ width: `${28 + ((idx * 17) % 60)}%` }} />
                      </div>
                    </div>

                    <div className="relative mt-5 pt-4 border-t border-hairline flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Users className="h-3.5 w-3.5 text-violet-glow" aria-hidden="true" />
                        <span className="tabular-nums text-foreground">{f.interested_count ?? 0}</span> interested
                      </div>
                      <span className="hs-feat-arrow inline-flex items-center gap-1 text-xs text-violet-glow">
                        View <ArrowRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* CATEGORIES */}
        {categories.length > 0 && (
          <section className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28" aria-labelledby="cats-heading">
            <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)] lg:items-end">
              <div>
                <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground inline-flex items-center gap-2">
                  <span className="h-1 w-6 bg-violet-glow rounded-full" /> Categories
                  <span className="text-muted-foreground/60">·</span>
                  <span className="font-mono tabular-nums">{categories.length.toString().padStart(2, "0")}</span>
                </div>
                <h2 id="cats-heading" className="mt-3 font-display text-3xl sm:text-4xl md:text-5xl leading-[0.95] text-balance">
                  What are you <span className="italic text-violet-glow">into?</span>
                </h2>
              </div>
              <p className="text-muted-foreground max-w-lg">
                Scan the constellation. Every chip is a live corner of the marketplace — the bigger it looks, the more founders are trading there right now.
              </p>
            </div>

            <div className="mt-10 flex flex-wrap gap-2.5">
              {categories.map((c, i) => {
                const size = i % 5 === 0 ? "lg" : i % 3 === 0 ? "md" : "sm";
                const count = 3 + ((i * 7) % 21);
                return (
                  <Link
                    key={c.id}
                    to="/explore"
                    className={`hs-cat-chip hs-cat-${size} group relative inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 text-foreground transition-all hover:-translate-y-0.5 hover:border-violet/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring`}
                  >
                    <span className="hs-cat-dot" aria-hidden="true" />
                    <span className="truncate">{c.name}</span>
                    <span className="text-[10px] font-mono tabular-nums text-muted-foreground group-hover:text-violet-glow transition-colors">{count}</span>
                  </Link>
                );
              })}
            </div>
          </section>
        )}


        {/* PRESS & PROOF */}
        <section className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28" aria-labelledby="press-heading">
          <div className="hs-press relative overflow-hidden rounded-[1.75rem] border border-hairline p-6 md:p-10">
            <div aria-hidden className="absolute inset-0 pointer-events-none opacity-[0.05]" style={{ background: "var(--gradient-hero)" }} />
            <div aria-hidden className="absolute -bottom-40 right-0 h-[420px] w-[600px] rounded-full hs-aurora opacity-40 pointer-events-none" />

            <div className="relative flex flex-col md:flex-row md:items-end md:justify-between gap-6">
              <div>
                <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground inline-flex items-center gap-2">
                  <span className="h-1 w-6 bg-violet-glow rounded-full" />
                  Louder rooms
                  <span className="text-muted-foreground/60">·</span>
                  <span className="font-mono tabular-nums">Press · 10</span>
                </div>
                <h2 id="press-heading" className="mt-4 text-3xl md:text-4xl font-serif tracking-tight max-w-2xl">
                  Featured where <em className="italic text-violet-glow">founders read</em> before they build.
                </h2>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>2,140,000 impressions · last 90 days</span>
              </div>
            </div>

            {/* Press logos */}
            <div className="relative mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {[
                { name: "TechCrunch", quote: "Bloomberg-terminal seriousness", tag: "Featured" },
                { name: "Product Hunt", quote: "#1 Product of the Day", tag: "Winner" },
                { name: "Hacker News", quote: "Front page · 812 pts", tag: "Top 3" },
                { name: "Indie Hackers", quote: "The swap that rewrote M&A", tag: "Cover" },
                { name: "Sifted", quote: "The anti-broker marketplace", tag: "Deep dive" },
                { name: "The Information", quote: "SaaS-for-SaaS, priced flat", tag: "Analysis" },
              ].map((p, i) => (
                <a key={p.name} href="#" className="hs-press-chip group relative rounded-2xl border border-hairline p-4 flex flex-col justify-between min-h-[120px] overflow-hidden" style={{ animationDelay: `${i * 70}ms` }}>
                  <span aria-hidden className="hs-press-sheen absolute inset-0 pointer-events-none" />
                  <div className="relative flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-mono">{p.tag}</span>
                    <span className="h-1.5 w-1.5 rounded-full bg-violet-glow/60 group-hover:bg-violet-glow transition-colors" />
                  </div>
                  <div className="relative">
                    <div className="font-display text-lg leading-tight text-foreground">{p.name}</div>
                    <div className="mt-1 text-[11px] text-muted-foreground italic leading-snug">"{p.quote}"</div>
                  </div>
                </a>
              ))}
            </div>

            {/* Metric ledger */}
            <div className="relative mt-8 grid grid-cols-2 md:grid-cols-4 divide-x divide-hairline border-t border-hairline pt-6">
              {[
                { k: "48", v: "publications", s: "covered a HeySaaS deal" },
                { k: "#1", v: "product hunt", s: "March 2026 launch" },
                { k: "812", v: "pts on HN", s: "peak front-page rank" },
                { k: "4.9★", v: "trustpilot", s: "across 812 verified swaps" },
              ].map((m, i) => (
                <div key={m.k} className={`px-4 ${i === 0 ? "pl-0" : ""}`}>
                  <div className="font-serif text-3xl md:text-4xl leading-none tabular-nums bg-gradient-to-br from-foreground to-violet-glow bg-clip-text text-transparent">{m.k}</div>
                  <div className="mt-1 text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-mono">{m.v}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{m.s}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28" aria-labelledby="faq-heading">

          <div className="grid gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.4fr)] lg:items-start">
            <div className="lg:sticky lg:top-24">
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground inline-flex items-center gap-2">
                <span className="h-1 w-6 bg-violet-glow rounded-full" />
                Fine print, plain-spoken
                <span className="text-muted-foreground/60">·</span>
                <span className="font-mono tabular-nums">FAQ · 06</span>
              </div>
              <h2 id="faq-heading" className="mt-3 font-display text-3xl sm:text-4xl md:text-5xl leading-[0.95] text-balance">
                Everything a careful founder <span className="italic text-violet-glow">would ask.</span>
              </h2>
              <p className="mt-5 text-muted-foreground max-w-md">
                No dark patterns, no asterisks. If a policy isn't listed here, it doesn't exist yet — and if it changes, you'll see a changelog before a T&C update.
              </p>
              <div className="mt-8 inline-flex items-center gap-3 rounded-2xl border border-hairline bg-surface/60 p-4">
                <span className="hs-quote-avatar hs-quote-avatar-violet" aria-hidden="true">HS</span>
                <div>
                  <div className="text-sm font-medium text-foreground">Still stuck? Ask a human.</div>
                  <div className="text-[11px] text-muted-foreground">Avg reply · <span className="text-foreground tabular-nums">under 2h</span></div>
                </div>
              </div>
            </div>

            <ol className="hs-faq-list divide-y divide-hairline border border-hairline rounded-2xl bg-surface/50 overflow-hidden">
              {[
                { q: "Do I ever pay a commission?", a: "Never. HeySaaS charges a flat $19 safety fee to each side when a swap is agreed. No percentage of MRR, no listing fees, no upsells.", tag: "Pricing" },
                { q: "What actually protects the swap?", a: "The $19 unlocks a private handover room with a shared checklist, a signed transfer receipt, and a 24-hour cooling window. If either side ghosts before handover, the fee is refunded automatically.", tag: "Escrow" },
                { q: "How do you keep the marketplace clean?", a: "Every listing is reviewed by an editor. Roughly 63% of submissions get sent back for edits or rejected — the ones you see are the ones that passed.", tag: "Trust" },
                { q: "Who owns the SaaS after a swap?", a: "You do. HeySaaS never takes custody of code, customers, or infrastructure. We facilitate the introduction, checklist, and receipt — the transfer itself happens directly between founders.", tag: "Ownership" },
                { q: "What if the numbers don't check out?", a: "Sellers can connect Stripe read-only to publish verified MRR. Unverified listings are visibly marked, and the buyer always has the option to walk before the $19 clears.", tag: "Verification" },
                { q: "Can I list a SaaS I don't want to swap yet?", a: "Yes — mark it as \"watching\" instead of \"open\". You'll still get inbound interest counters and can flip to open when the timing is right.", tag: "Listings" },
              ].map((f, i) => (
                <li key={i} className="hs-faq-item group">
                  <details className="hs-faq-details">
                    <summary className="hs-faq-summary relative flex items-start gap-4 px-5 sm:px-7 py-6 cursor-pointer list-none">
                      <span className="hs-faq-index font-mono text-[11px] tabular-nums text-muted-foreground pt-1">{String(i + 1).padStart(2, "0")}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 flex-wrap">
                          <h3 className="font-display text-lg sm:text-xl text-foreground leading-tight">{f.q}</h3>
                          <span className="text-[10px] font-mono uppercase tracking-[0.14em] text-violet-glow bg-violet/10 border border-violet/25 rounded-full px-2 py-0.5">
                            {f.tag}
                          </span>
                        </div>
                      </div>
                      <span className="hs-faq-toggle" aria-hidden="true">
                        <span className="hs-faq-toggle-bar" />
                        <span className="hs-faq-toggle-bar hs-faq-toggle-bar-v" />
                      </span>
                    </summary>
                    <div className="hs-faq-body px-5 sm:px-7 pb-7 pl-14 sm:pl-16">
                      <p className="text-muted-foreground max-w-2xl leading-relaxed">{f.a}</p>
                      <div className="mt-4 flex items-center gap-3">
                        <Link to="/how-it-works" className="story-link text-xs text-foreground">Read the full policy</Link>
                        <span className="text-muted-foreground/40 text-xs">·</span>
                        <span className="text-[10px] font-mono uppercase tracking-[0.14em] text-muted-foreground">Updated 3d ago</span>
                      </div>
                    </div>
                  </details>
                </li>
              ))}
            </ol>
          </div>
        </section>




        {/* SAVINGS CALCULATOR */}





        {/* MATCH ENGINE — animated two-column matcher */}
        <section aria-labelledby="engine-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] lg:items-center">
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Match engine</div>
              <h2 id="engine-heading" className="mt-3 font-display text-4xl md:text-6xl leading-[0.95] text-balance">
                We wire the <span className="italic text-violet-glow">right two people</span> together.
              </h2>
              <p className="mt-6 max-w-md text-muted-foreground leading-relaxed">
                Not a search box that returns 400 rows. A weighted engine that reads
                intent, stack, MRR, timezone and ambition — and only surfaces founders
                you could actually swap with this week.
              </p>
              <ul className="mt-8 space-y-3 text-sm">
                {[
                  { k: "Intent",   v: "growth vs. exit vs. cashflow" },
                  { k: "Stack",    v: "language, infra, and payment rails" },
                  { k: "Range",    v: "MRR within a defensible ratio" },
                  { k: "Timezone", v: "overlapping business hours" },
                ].map((r) => (
                  <li key={r.k} className="flex items-baseline gap-3">
                    <span className="hs-me-tag">{r.k}</span>
                    <span className="text-muted-foreground">{r.v}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="hs-me-board relative rounded-[1.75rem] border border-hairline overflow-hidden">
              <div aria-hidden className="hs-me-grid" />
              <div aria-hidden className="hs-me-glow" />

              <div className="relative flex items-center justify-between px-6 pt-6 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                <span className="inline-flex items-center gap-2">
                  <span className="hs-me-dot" /> Live weighting
                </span>
                <span>6 candidates · 3 matched</span>
              </div>

              <div className="relative grid grid-cols-[minmax(0,1fr)_100px_minmax(0,1fr)] gap-4 px-6 py-8 sm:py-10">
                {/* left column */}
                <div className="flex flex-col gap-3">
                  {[
                    { name: "Chartly",   cat: "Analytics",    mrr: "$4.2k", match: 96 },
                    { name: "Loopnote",  cat: "AI / ML",      mrr: "$7.9k", match: 88 },
                    { name: "Stashly",   cat: "Marketing",    mrr: "$1.1k", match: 74 },
                  ].map((r, i) => (
                    <div key={r.name} className={`hs-me-card hs-me-card--l ${i === 0 ? "is-hot" : ""}`} style={{ animationDelay: `${i * .25}s` }}>
                      <div className="flex items-center justify-between">
                        <span className="hs-me-avatar">{r.name[0]}</span>
                        <span className={`hs-me-match ${r.match >= 90 ? "is-hot" : ""}`}>{r.match}%</span>
                      </div>
                      <div className="mt-3 font-display text-lg leading-tight">{r.name}</div>
                      <div className="mt-0.5 text-[11px] uppercase tracking-[0.16em] text-muted-foreground">{r.cat}</div>
                      <div className="mt-2 text-xs tabular-nums text-foreground/80">{r.mrr}<span className="text-muted-foreground">/mo</span></div>
                    </div>
                  ))}
                </div>

                {/* animated connector column */}
                <div className="relative">
                  <svg viewBox="0 0 100 320" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
                    <defs>
                      <linearGradient id="me-wire" x1="0" x2="1">
                        <stop offset="0%"   stopColor="var(--violet)"      stopOpacity=".2" />
                        <stop offset="50%"  stopColor="var(--violet-glow)" stopOpacity="1"  />
                        <stop offset="100%" stopColor="var(--violet)"      stopOpacity=".2" />
                      </linearGradient>
                    </defs>
                    {[
                      { y1: 45,  y2: 45,  hot: true  },
                      { y1: 160, y2: 160, hot: false },
                      { y1: 275, y2: 275, hot: false },
                    ].map((w, i) => (
                      <g key={i}>
                        <path
                          d={`M 0 ${w.y1} C 40 ${w.y1}, 60 ${w.y2}, 100 ${w.y2}`}
                          fill="none"
                          stroke="url(#me-wire)"
                          strokeWidth={w.hot ? "1.6" : "1"}
                          strokeDasharray="4 6"
                          className="hs-me-wire"
                          style={{ animationDelay: `${i * .4}s` }}
                        />
                      </g>
                    ))}
                  </svg>
                </div>

                {/* right column */}
                <div className="flex flex-col gap-3">
                  {[
                    { name: "Boardhub",     cat: "Productivity", mrr: "$3.8k", match: 96 },
                    { name: "Signalr",      cat: "DevTools",     mrr: "$8.4k", match: 88 },
                    { name: "CopyKit",      cat: "Productivity", mrr: "$1.3k", match: 74 },
                  ].map((r, i) => (
                    <div key={r.name} className={`hs-me-card hs-me-card--r ${i === 0 ? "is-hot" : ""}`} style={{ animationDelay: `${i * .25 + .15}s` }}>
                      <div className="flex items-center justify-between">
                        <span className={`hs-me-match ${r.match >= 90 ? "is-hot" : ""}`}>{r.match}%</span>
                        <span className="hs-me-avatar">{r.name[0]}</span>
                      </div>
                      <div className="mt-3 font-display text-lg leading-tight text-right">{r.name}</div>
                      <div className="mt-0.5 text-[11px] uppercase tracking-[0.16em] text-muted-foreground text-right">{r.cat}</div>
                      <div className="mt-2 text-xs tabular-nums text-foreground/80 text-right">{r.mrr}<span className="text-muted-foreground">/mo</span></div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative flex items-center justify-between border-t border-hairline/70 px-6 py-3 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                <span>Weighted score</span>
                <span className="tabular-nums text-foreground">0.914 · confident</span>
              </div>
            </div>
          </div>
        </section>

        {/* DEAL ROOM PREVIEW — product shot of the live swap room */}
        <section aria-labelledby="dr-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="hs-dr relative overflow-hidden rounded-[1.75rem] border border-hairline p-6 sm:p-10">
            <div aria-hidden className="hs-dr-grid" />
            <div aria-hidden className="hs-dr-glow" />
            <div className="relative flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between mb-8">
              <div className="max-w-2xl">
                <div className="hs-eyebrow inline-flex items-center gap-2">
                  <span className="hs-dr-live" /> Deal Room · live preview
                </div>
                <h2 id="dr-heading" className="mt-3 font-serif italic text-3xl sm:text-4xl md:text-5xl leading-[1.05] tracking-tight">
                  Where the handshake actually happens.
                </h2>
                <p className="mt-4 text-[15px] text-muted-foreground max-w-xl">
                  Chat, milestones, escrow status and handover artifacts — all in one room, timestamped and signed.
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="hs-dr-dot" />
                <span>Room #A47-923 · both parties online</span>
              </div>
            </div>

            <div className="relative grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
              {/* Left: chat window */}
              <div className="hs-dr-panel rounded-2xl overflow-hidden">
                <div className="hs-dr-topbar flex items-center justify-between px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="hs-dr-tl hs-dr-tl-r" />
                    <span className="hs-dr-tl hs-dr-tl-y" />
                    <span className="hs-dr-tl hs-dr-tl-g" />
                    <span className="ml-3 text-[11px] tracking-[0.18em] uppercase text-muted-foreground">Metrics.io ⇄ PulseCRM</span>
                  </div>
                  <span className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground">encrypted · e2e</span>
                </div>

                <div className="p-5 space-y-4 min-h-[420px]">
                  {/* Offer pinned card */}
                  <div className="hs-dr-offer rounded-xl p-4">
                    <div className="flex items-center justify-between text-[10px] tracking-[0.2em] uppercase text-muted-foreground">
                      <span>Pinned · Offer</span><span>signed 14:02 UTC</span>
                    </div>
                    <div className="mt-2 grid grid-cols-3 gap-3 text-sm">
                      <div><div className="text-muted-foreground text-[11px]">You give</div><div className="font-serif italic text-lg">Metrics.io</div><div className="text-[11px] text-muted-foreground">$4.2K MRR</div></div>
                      <div className="text-center self-center text-primary text-xl">⇄</div>
                      <div className="text-right"><div className="text-muted-foreground text-[11px]">You get</div><div className="font-serif italic text-lg">PulseCRM</div><div className="text-[11px] text-muted-foreground">$4.6K MRR</div></div>
                    </div>
                    <div className="mt-3 flex items-center justify-between text-[11px]">
                      <span className="hs-dr-pill">Escrow armed · $19 × 2</span>
                      <span className="text-muted-foreground">Delta rebalanced +$400/mo</span>
                    </div>
                  </div>

                  {/* messages */}
                  <div className="hs-dr-msg hs-dr-msg-in">
                    <div className="hs-dr-avatar">EL</div>
                    <div><div className="hs-dr-bubble">Uploaded GA4 + Stripe read-only. Numbers match the listing to 0.4%.</div><div className="hs-dr-meta">Elena · 14:07</div></div>
                  </div>
                  <div className="hs-dr-msg hs-dr-msg-out">
                    <div><div className="hs-dr-bubble hs-dr-bubble-out">Confirmed. Pushing DNS TXT now — should flip verified in ~90s.</div><div className="hs-dr-meta text-right">You · 14:09</div></div>
                    <div className="hs-dr-avatar hs-dr-avatar-out">YO</div>
                  </div>
                  <div className="hs-dr-msg hs-dr-msg-in">
                    <div className="hs-dr-avatar">EL</div>
                    <div><div className="hs-dr-bubble">Handover doc drafted — customers, Slack, vendor list, on-call rota.</div><div className="hs-dr-meta">Elena · 14:11</div></div>
                  </div>
                  <div className="hs-dr-typing"><span /><span /><span /> Elena is typing…</div>
                </div>

                <div className="hs-dr-composer flex items-center gap-3 px-4 py-3">
                  <div className="hs-dr-input flex-1">Attach handover checklist…</div>
                  <span className="hs-dr-send">Send ↵</span>
                </div>
              </div>

              {/* Right: milestones + activity */}
              <div className="space-y-6">
                <div className="hs-dr-panel rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground">Escrow milestones</div>
                    <span className="text-[11px] text-primary">3 / 5 complete</span>
                  </div>
                  <ol className="space-y-3">
                    {[
                      {t:"Offer signed by both parties", s:"done", ts:"14:02"},
                      {t:"Safety fee captured · $19 × 2", s:"done", ts:"14:03"},
                      {t:"Financials verified · Stripe + GA4", s:"done", ts:"14:07"},
                      {t:"DNS + auth handover", s:"live", ts:"in progress"},
                      {t:"48h clawback window", s:"pending", ts:"queued"},
                    ].map((m,i)=>(
                      <li key={i} className={`hs-dr-mile hs-dr-mile-${m.s}`}>
                        <span className="hs-dr-mile-dot" />
                        <div className="flex-1">
                          <div className="text-sm">{m.t}</div>
                          <div className="text-[11px] text-muted-foreground">{m.ts}</div>
                        </div>
                        {m.s==="done" && <span className="hs-dr-check">✓</span>}
                      </li>
                    ))}
                  </ol>
                </div>

                <div className="hs-dr-panel rounded-2xl p-5">
                  <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mb-3">Room activity</div>
                  <div className="space-y-2 text-[12px]">
                    <div className="hs-dr-act"><span className="hs-dr-act-dot" /> Elena uploaded <em className="text-foreground/80">handover.pdf</em> · 14:11</div>
                    <div className="hs-dr-act"><span className="hs-dr-act-dot" /> You verified <em className="text-foreground/80">metrics.io</em> DNS · 14:10</div>
                    <div className="hs-dr-act"><span className="hs-dr-act-dot" /> Escrow armed · $38 held · 14:03</div>
                    <div className="hs-dr-act"><span className="hs-dr-act-dot" /> Deal Score updated · <em className="text-primary">92 / 100</em></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* REPUTATION RADAR — six-axis founder trust score */}
        <section aria-labelledby="rr-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="hs-rr relative overflow-hidden rounded-[1.75rem] border border-hairline">
            <div aria-hidden className="hs-rr-glow" />
            <div className="relative grid gap-8 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] items-center p-8 sm:p-10">
              {/* radar */}
              <div className="hs-rr-wrap relative mx-auto w-full max-w-[520px] aspect-square">
                {(() => {
                  const axes = [
                    { k: "Reliability", you: 92, cat: 74 },
                    { k: "Response",    you: 88, cat: 68 },
                    { k: "Transparency",you: 95, cat: 71 },
                    { k: "Handover",    you: 84, cat: 66 },
                    { k: "Docs",        you: 78, cat: 62 },
                    { k: "Post-swap",   you: 90, cat: 70 },
                  ];
                  const cx = 200, cy = 200, R = 150;
                  const pt = (i: number, r: number) => {
                    const a = (Math.PI * 2 * i) / axes.length - Math.PI / 2;
                    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r] as const;
                  };
                  const poly = (vals: number[]) =>
                    vals.map((v, i) => pt(i, (v / 100) * R).join(",")).join(" ");
                  const rings = [0.25, 0.5, 0.75, 1];
                  return (
                    <svg viewBox="0 0 400 400" className="w-full h-full">
                      <defs>
                        <radialGradient id="rr-you-fill" cx="50%" cy="50%" r="50%">
                          <stop offset="0%" stopColor="currentColor" stopOpacity="0.55" />
                          <stop offset="100%" stopColor="currentColor" stopOpacity="0.12" />
                        </radialGradient>
                      </defs>
                      {/* rings */}
                      {rings.map((r, i) => (
                        <polygon
                          key={i}
                          points={axes.map((_, j) => pt(j, R * r).join(",")).join(" ")}
                          fill="none"
                          stroke="var(--hairline)"
                          strokeWidth="1"
                          opacity={0.55 + i * 0.08}
                        />
                      ))}
                      {/* spokes */}
                      {axes.map((_, i) => {
                        const [x, y] = pt(i, R);
                        return <line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke="var(--hairline)" strokeWidth="1" />;
                      })}
                      {/* category avg */}
                      <polygon
                        points={poly(axes.map((a) => a.cat))}
                        className="hs-rr-cat"
                        fill="rgba(255,255,255,0.06)"
                        stroke="rgba(255,255,255,0.35)"
                        strokeWidth="1.25"
                        strokeDasharray="3 4"
                      />
                      {/* you */}
                      <polygon
                        points={poly(axes.map((a) => a.you))}
                        className="hs-rr-you text-violet-glow"
                        fill="url(#rr-you-fill)"
                        stroke="currentColor"
                        strokeWidth="1.75"
                      />
                      {/* value dots */}
                      {axes.map((a, i) => {
                        const [x, y] = pt(i, (a.you / 100) * R);
                        return (
                          <g key={i} className="hs-rr-dot" style={{ animationDelay: `${400 + i * 90}ms` }}>
                            <circle cx={x} cy={y} r="4.5" className="text-violet-glow" fill="currentColor" />
                            <circle cx={x} cy={y} r="9" fill="none" stroke="currentColor" strokeOpacity="0.35" className="text-violet-glow" />
                          </g>
                        );
                      })}
                      {/* labels */}
                      {axes.map((a, i) => {
                        const [x, y] = pt(i, R + 26);
                        return (
                          <g key={a.k}>
                            <text
                              x={x}
                              y={y}
                              textAnchor="middle"
                              dominantBaseline="middle"
                              className="fill-current text-foreground/85"
                              style={{ font: "600 11px ui-sans-serif, system-ui", letterSpacing: "0.06em" }}
                            >
                              {a.k.toUpperCase()}
                            </text>
                            <text
                              x={x}
                              y={y + 14}
                              textAnchor="middle"
                              dominantBaseline="middle"
                              className="fill-current text-violet-glow"
                              style={{ font: "500 11px ui-monospace, monospace" }}
                            >
                              {a.you}
                            </text>
                          </g>
                        );
                      })}
                    </svg>
                  );
                })()}
              </div>

              {/* copy */}
              <div>
                <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Reputation index · v3</div>
                <h2 id="rr-heading" className="mt-3 font-display text-4xl md:text-5xl leading-[0.95] text-balance">
                  Your track record, <span className="italic text-violet-glow">plotted six ways.</span>
                </h2>
                <p className="mt-4 text-muted-foreground max-w-md">
                  After every closed swap, both parties rate six things. Your radar builds over time — public, tamper-proof, and impossible to fake with a testimonial page.
                </p>

                <div className="mt-8 grid grid-cols-2 gap-3">
                  {[
                    { k: "Composite", v: "88", d: "top 6%" },
                    { k: "Swaps",     v: "14", d: "signed" },
                    { k: "On-time",   v: "100%", d: "handovers" },
                    { k: "Repeat",    v: "5", d: "counterparties" },
                  ].map((s) => (
                    <div key={s.k} className="rounded-xl border border-hairline bg-white/[0.02] p-3">
                      <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{s.k}</div>
                      <div className="mt-1 flex items-baseline gap-2">
                        <span className="font-display text-2xl leading-none text-violet-glow">{s.v}</span>
                        <span className="text-[10px] text-muted-foreground/80">{s.d}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex items-center gap-4 text-[11px] text-muted-foreground">
                  <span className="inline-flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-sm bg-[color-mix(in_oklab,var(--primary)_70%,transparent)]" />
                    You
                  </span>
                  <span className="inline-flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-sm border border-dashed border-white/50 bg-white/5" />
                    Category avg
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FOUNDER TRADING CARD — collectible holo-foil stat card */}
        <section aria-labelledby="fc-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="grid gap-10 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] items-center">
            <div className="hs-fc-stage">
              {/* Back card */}
              <div className="hs-fc hs-fc--back" aria-hidden>
                <div className="hs-fc-frame">
                  <div className="hs-fc-rarity">RARE</div>
                  <div className="hs-fc-holo" />
                </div>
              </div>

              {/* Front card */}
              <article className="hs-fc hs-fc--front" role="img" aria-label="Founder trading card for Maya Alvarez">
                <div className="hs-fc-frame">
                  <div className="hs-fc-holo" aria-hidden />
                  <div className="hs-fc-noise" aria-hidden />

                  <header className="hs-fc-head">
                    <span className="hs-fc-set">SET · S1 · 087 / 500</span>
                    <span className="hs-fc-rarity">MYTHIC</span>
                  </header>

                  <div className="hs-fc-name">
                    <div className="hs-fc-name-first">MAYA</div>
                    <div className="hs-fc-name-last">ALVAREZ</div>
                    <div className="hs-fc-name-title">Founder · Underwriter III</div>
                  </div>

                  <div className="hs-fc-portrait" aria-hidden>
                    <div className="hs-fc-portrait-glow" />
                    <div className="hs-fc-portrait-badge">MA</div>
                    <svg className="hs-fc-portrait-orbits" viewBox="0 0 200 200">
                      <circle cx="100" cy="100" r="76" />
                      <circle cx="100" cy="100" r="60" />
                      <circle cx="100" cy="100" r="44" />
                    </svg>
                    <div className="hs-fc-flag">USA · SF</div>
                  </div>

                  <div className="hs-fc-stats">
                    <div className="hs-fc-stat">
                      <span className="hs-fc-stat-label">MRR</span>
                      <span className="hs-fc-stat-value">$4.2K</span>
                      <span className="hs-fc-stat-bar"><i style={{ width: '72%' }} /></span>
                    </div>
                    <div className="hs-fc-stat">
                      <span className="hs-fc-stat-label">TRUST</span>
                      <span className="hs-fc-stat-value">94</span>
                      <span className="hs-fc-stat-bar"><i style={{ width: '94%' }} /></span>
                    </div>
                    <div className="hs-fc-stat">
                      <span className="hs-fc-stat-label">RUNWAY</span>
                      <span className="hs-fc-stat-value">18 mo</span>
                      <span className="hs-fc-stat-bar"><i style={{ width: '60%' }} /></span>
                    </div>
                    <div className="hs-fc-stat">
                      <span className="hs-fc-stat-label">SWAPS</span>
                      <span className="hs-fc-stat-value">7 · 0 L</span>
                      <span className="hs-fc-stat-bar"><i style={{ width: '100%' }} /></span>
                    </div>
                  </div>

                  <div className="hs-fc-abilities">
                    <div className="hs-fc-ability">
                      <span className="hs-fc-ability-icon">◇</span>
                      <div>
                        <b>Cold Open</b>
                        <span>Sends a 3-line pitch that gets a reply in &lt;24h · 82%.</span>
                      </div>
                    </div>
                    <div className="hs-fc-ability">
                      <span className="hs-fc-ability-icon">✦</span>
                      <div>
                        <b>Clean Handover</b>
                        <span>Closes escrow with zero disputes across 7 consecutive swaps.</span>
                      </div>
                    </div>
                  </div>

                  <footer className="hs-fc-foot">
                    <span>© HEYSAAS · 2026</span>
                    <span className="hs-fc-foot-sig">signed · <b>M.A</b></span>
                    <span className="hs-fc-foot-hash">#087·A2F9</span>
                  </footer>

                  <span className="hs-fc-corner hs-fc-corner--tl" aria-hidden />
                  <span className="hs-fc-corner hs-fc-corner--tr" aria-hidden />
                  <span className="hs-fc-corner hs-fc-corner--bl" aria-hidden />
                  <span className="hs-fc-corner hs-fc-corner--br" aria-hidden />
                  <span className="hs-fc-gem" aria-hidden />
                </div>
              </article>

              <div className="hs-fc-caption">
                <span className="hs-fc-caption-dot" /> Live card · rotate on hover · re-mints on every closed swap
              </div>
            </div>

            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Founder card · S1 · 087</div>
              <h2 id="fc-heading" className="mt-3 font-display text-4xl md:text-5xl leading-[0.95] text-balance">
                Reputation, <span className="italic text-violet-glow">printed on foil.</span>
              </h2>
              <p className="mt-4 text-muted-foreground max-w-md">
                Every founder gets one card — no vanity metrics, no follower counts. MRR verified
                through Stripe, trust earned in closed swaps, abilities minted from actual behaviour
                in the room. Trade the card, not the tweet.
              </p>
              <div className="mt-6 grid grid-cols-3 gap-3 max-w-md">
                <div className="hs-fc-legend"><b>MYTHIC</b><span>10+ swaps · 0 losses</span></div>
                <div className="hs-fc-legend hs-fc-legend--rare"><b>RARE</b><span>3–9 swaps</span></div>
                <div className="hs-fc-legend hs-fc-legend--base"><b>BASE</b><span>Verified · 0 swaps</span></div>
              </div>
            </div>
          </div>
        </section>

        {/* STAR CHART — founder constellation atlas */}

        {/* BROADSHEET — vintage newspaper front page */}

        {/* CORKBOARD — detective's deal wall */}

        {/* VINYL — the swap as a record */}

        {/* HOROLOGY — watchmaker's exploded movement */}

        {/* BLUEPRINT — engineering schematic of a swap */}





        <section aria-labelledby="bp-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] items-start">
            <div className="lg:sticky lg:top-24">
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Sheet 04 / 07 · Rev. C</div>
              <h2 id="bp-heading" className="mt-3 font-display text-4xl md:text-5xl leading-[0.95] text-balance">
                A swap, <span className="italic text-violet-glow">to scale.</span>
              </h2>
              <p className="mt-4 text-muted-foreground max-w-md">
                Drawn like a bridge, not a landing page. Every load-bearing member is labelled,
                every clearance dimensioned, every failure mode annotated in the margin. This is
                the drawing that gets stamped before the deal ships.
              </p>
              <div className="mt-6 hs-bp-legend">
                <div><span className="hs-bp-swatch hs-bp-sw--load" /> Load-bearing path</div>
                <div><span className="hs-bp-swatch hs-bp-sw--data" /> Data / telemetry</div>
                <div><span className="hs-bp-swatch hs-bp-sw--escrow" /> Escrow rail</div>
                <div><span className="hs-bp-swatch hs-bp-sw--note" /> Engineer's note</div>
              </div>
            </div>

            <figure className="hs-bp" role="img" aria-label="Blueprint schematic of a HeySaaS swap">
              <div className="hs-bp-paper">
                <div aria-hidden className="hs-bp-grid" />
                <div aria-hidden className="hs-bp-grid hs-bp-grid--fine" />
                <div aria-hidden className="hs-bp-fold" />

                {/* Title block */}
                <div className="hs-bp-title">
                  <div className="hs-bp-title-row">
                    <span>Project</span><b>HeySaaS · Swap Assembly</b>
                  </div>
                  <div className="hs-bp-title-row">
                    <span>Drawn</span><b>M. Alvarez</b><span>Scale</span><b>1 : 1</b>
                  </div>
                  <div className="hs-bp-title-row">
                    <span>Sheet</span><b>04 / 07</b><span>Rev.</span><b>C</b>
                  </div>
                </div>

                {/* Corner stamp */}
                <div className="hs-bp-stamp" aria-hidden>
                  <div>APPROVED</div>
                  <div>03 · 14 · 26</div>
                </div>

                {/* Main SVG schematic */}
                <svg viewBox="0 0 800 460" className="hs-bp-svg" aria-hidden>
                  <defs>
                    <marker id="bp-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse">
                      <path d="M0,0 L10,5 L0,10 z" fill="currentColor" />
                    </marker>
                    <marker id="bp-dim" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                      <path d="M0,0 L10,5 L0,10" fill="none" stroke="currentColor" strokeWidth="1" />
                    </marker>
                  </defs>

                  {/* Node A — Founder A */}
                  <g className="hs-bp-node">
                    <circle cx="120" cy="230" r="54" />
                    <circle cx="120" cy="230" r="44" className="hs-bp-node-inner" />
                    <text x="120" y="228" textAnchor="middle" className="hs-bp-node-title">FOUNDER · A</text>
                    <text x="120" y="244" textAnchor="middle" className="hs-bp-node-sub">$4.2K MRR</text>
                  </g>

                  {/* Node B — Founder B */}
                  <g className="hs-bp-node">
                    <circle cx="680" cy="230" r="54" />
                    <circle cx="680" cy="230" r="44" className="hs-bp-node-inner" />
                    <text x="680" y="228" textAnchor="middle" className="hs-bp-node-title">FOUNDER · B</text>
                    <text x="680" y="244" textAnchor="middle" className="hs-bp-node-sub">$3.8K MRR</text>
                  </g>

                  {/* Central escrow vault */}
                  <g className="hs-bp-vault">
                    <rect x="340" y="180" width="120" height="100" rx="4" />
                    <rect x="352" y="192" width="96" height="76" rx="2" className="hs-bp-vault-inner" />
                    <circle cx="400" cy="230" r="16" className="hs-bp-vault-dial" />
                    <line x1="400" y1="230" x2="400" y2="218" strokeLinecap="round" />
                    <text x="400" y="170" textAnchor="middle" className="hs-bp-label">ESCROW · $38.00</text>
                    <text x="400" y="298" textAnchor="middle" className="hs-bp-sub">2-KEY RELEASE</text>
                  </g>

                  {/* Load path A -> Vault */}
                  <path className="hs-bp-load hs-bp-flow" d="M 174 230 L 340 230" markerEnd="url(#bp-arrow)" />
                  {/* Load path B -> Vault */}
                  <path className="hs-bp-load hs-bp-flow" d="M 626 230 L 460 230" markerEnd="url(#bp-arrow)" />

                  {/* Data telemetry (Stripe + DNS) - top loops */}
                  <path className="hs-bp-data hs-bp-flow" d="M 120 176 C 120 90, 340 90, 400 164" markerEnd="url(#bp-arrow)" strokeDasharray="4 4" />
                  <path className="hs-bp-data hs-bp-flow" d="M 680 176 C 680 90, 460 90, 400 164" markerEnd="url(#bp-arrow)" strokeDasharray="4 4" />
                  <g>
                    <rect x="248" y="66" width="84" height="26" rx="3" className="hs-bp-chip" />
                    <text x="290" y="83" textAnchor="middle" className="hs-bp-chip-text">STRIPE · OAUTH</text>
                    <rect x="468" y="66" width="84" height="26" rx="3" className="hs-bp-chip" />
                    <text x="510" y="83" textAnchor="middle" className="hs-bp-chip-text">DNS · TXT · 200</text>
                  </g>

                  {/* Escrow rail — bottom */}
                  <path className="hs-bp-escrow hs-bp-flow" d="M 120 284 C 120 380, 680 380, 680 284" markerEnd="url(#bp-arrow)" />
                  <g>
                    <rect x="352" y="362" width="96" height="26" rx="3" className="hs-bp-chip hs-bp-chip--escrow" />
                    <text x="400" y="379" textAnchor="middle" className="hs-bp-chip-text">STRIPE · CONNECT</text>
                  </g>

                  {/* Dimension line — total distance */}
                  <g className="hs-bp-dim">
                    <line x1="120" y1="420" x2="680" y2="420" markerStart="url(#bp-dim)" markerEnd="url(#bp-dim)" />
                    <line x1="120" y1="410" x2="120" y2="430" />
                    <line x1="680" y1="410" x2="680" y2="430" />
                    <text x="400" y="414" textAnchor="middle">Ø 560 · avg. 6.4 days · σ 1.2</text>
                  </g>

                  {/* Callout — vault */}
                  <g className="hs-bp-callout">
                    <line x1="400" y1="180" x2="620" y2="120" />
                    <circle cx="620" cy="120" r="3" />
                    <text x="628" y="112">01 · Refund window 72h</text>
                    <text x="628" y="126" className="hs-bp-callout-sub">Auto-release on dual sign-off</text>
                  </g>

                  {/* Callout — founder A */}
                  <g className="hs-bp-callout">
                    <line x1="66" y1="230" x2="20" y2="300" />
                    <circle cx="20" cy="300" r="3" />
                    <text x="24" y="316">02 · KYC · Tier III</text>
                    <text x="24" y="330" className="hs-bp-callout-sub">Liveness + gov ID cleared</text>
                  </g>

                  {/* Failure mode note */}
                  <g className="hs-bp-note">
                    <rect x="590" y="300" width="196" height="56" rx="3" />
                    <text x="602" y="318">NOTE · fail-safe</text>
                    <text x="602" y="334" className="hs-bp-note-sub">If MRR delta &gt; 25 %, escrow</text>
                    <text x="602" y="346" className="hs-bp-note-sub">holds pending re-underwrite.</text>
                  </g>

                  {/* Traveling dot on load path */}
                  <circle r="3.5" className="hs-bp-traveler">
                    <animateMotion dur="4.6s" repeatCount="indefinite" rotate="auto">
                      <mpath href="#bp-orbit" />
                    </animateMotion>
                  </circle>
                  <path id="bp-orbit" d="M 174 230 L 340 230 M 460 230 L 626 230" fill="none" stroke="none" />
                </svg>

                {/* Corner rivets */}
                <span aria-hidden className="hs-bp-rivet hs-bp-rivet--tl" />
                <span aria-hidden className="hs-bp-rivet hs-bp-rivet--tr" />
                <span aria-hidden className="hs-bp-rivet hs-bp-rivet--bl" />
                <span aria-hidden className="hs-bp-rivet hs-bp-rivet--br" />
              </div>
              <figcaption className="hs-bp-caption">
                <span>DWG · HS-SWAP-04-C.dwg</span>
                <span>·</span>
                <span>Stamped by underwriting · Mar 14 · 2026</span>
              </figcaption>
            </figure>
          </div>
        </section>




        {/* HEATMAP — swap volume by category × week */}
        <section aria-labelledby="hm-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] items-start">
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Category flow · Q3 2026</div>
              <h2 id="hm-heading" className="mt-3 font-display text-4xl md:text-5xl leading-[0.95] text-balance">
                Where the swaps are <span className="italic text-violet-glow">actually happening.</span>
              </h2>
              <p className="mt-4 text-muted-foreground max-w-md">
                A 13-week heat sheet of signed swaps by category. No vanity totals — just weekly print counts, so you can see which rooms are hot before you list.
              </p>
              <div className="mt-6 flex items-center gap-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                <span>less</span>
                <div className="flex gap-1">
                  {[0.08, 0.22, 0.4, 0.62, 0.85, 1].map((o) => (
                    <span key={o} className="h-3 w-4 rounded-[3px]" style={{ background: `color-mix(in oklab, var(--primary) ${o * 100}%, transparent)` }} />
                  ))}
                </div>
                <span>more</span>
              </div>

              <div className="mt-8 grid grid-cols-3 gap-3">
                {[
                  { k: "Analytics", v: "+38%", t: "hottest wk 09" },
                  { k: "CRM",       v: "+21%", t: "steady climb" },
                  { k: "DevTools",  v: "+64%", t: "breakout" },
                ].map((s) => (
                  <div key={s.k} className="rounded-xl border border-hairline bg-white/[0.02] p-3">
                    <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{s.k}</div>
                    <div className="mt-1 font-display text-xl leading-none text-violet-glow">{s.v}</div>
                    <div className="mt-1 text-[10px] text-muted-foreground/80">{s.t}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* the heatmap */}
            <div className="hs-hm relative rounded-2xl border border-hairline bg-black/40 backdrop-blur-sm p-5 sm:p-6 overflow-hidden">
              <div aria-hidden className="hs-hm-glow" />
              <div className="relative">
                {/* week header */}
                <div className="grid" style={{ gridTemplateColumns: "110px repeat(13, minmax(0, 1fr))" }}>
                  <div />
                  {Array.from({ length: 13 }).map((_, i) => (
                    <div key={i} className="text-center font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground/80 pb-2">
                      w{String(i + 1).padStart(2, "0")}
                    </div>
                  ))}
                </div>

                {/* rows */}
                {[
                  { c: "Analytics", d: [0.20,0.28,0.32,0.44,0.55,0.62,0.71,0.80,0.95,0.88,0.72,0.68,0.74] },
                  { c: "CRM",       d: [0.42,0.48,0.51,0.55,0.58,0.60,0.64,0.68,0.72,0.75,0.78,0.82,0.86] },
                  { c: "DevTools",  d: [0.10,0.14,0.20,0.28,0.38,0.50,0.62,0.72,0.84,0.90,0.96,0.99,1.00] },
                  { c: "AI/ML",     d: [0.65,0.70,0.68,0.72,0.75,0.78,0.82,0.85,0.88,0.92,0.90,0.94,0.97] },
                  { c: "Marketing", d: [0.30,0.34,0.36,0.40,0.44,0.42,0.48,0.52,0.50,0.55,0.60,0.58,0.62] },
                  { c: "Fintech",   d: [0.18,0.22,0.28,0.30,0.34,0.40,0.44,0.46,0.50,0.54,0.58,0.62,0.66] },
                  { c: "eComm",     d: [0.55,0.52,0.48,0.50,0.46,0.44,0.42,0.44,0.40,0.42,0.38,0.36,0.40] },
                  { c: "HR/Ops",    d: [0.12,0.14,0.18,0.22,0.24,0.28,0.30,0.32,0.36,0.38,0.42,0.44,0.48] },
                ].map((row, r) => (
                  <div key={row.c} className="grid items-center py-[3px]" style={{ gridTemplateColumns: "110px repeat(13, minmax(0, 1fr))" }}>
                    <div className="pr-3 text-[11px] tracking-wide text-foreground/85 truncate">{row.c}</div>
                    {row.d.map((v, i) => (
                      <div key={i} className="px-[2px]">
                        <div
                          className="hs-hm-cell aspect-square rounded-[4px]"
                          title={`${row.c} · w${i + 1} · ${Math.round(v * 100)}%`}
                          style={{
                            background: `color-mix(in oklab, var(--primary) ${8 + v * 82}%, transparent)`,
                            boxShadow: v > 0.85 ? `0 0 12px color-mix(in oklab, var(--primary) 60%, transparent)` : undefined,
                            animationDelay: `${(r * 13 + i) * 12}ms`,
                          }}
                        />
                      </div>
                    ))}
                  </div>
                ))}

                {/* footer legend */}
                <div className="mt-4 flex items-center justify-between border-t border-hairline pt-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  <span>rows · category</span>
                  <span className="text-violet-glow">peak · DevTools w13</span>
                  <span>13 weeks · 1,842 prints</span>
                </div>
              </div>
            </div>
          </div>
        </section>





        {/* TERM SHEET — animated dual-signature contract preview */}
        <section aria-labelledby="ts-heading" className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="grid gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] items-center">
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">Term sheet · draft 03</div>
              <h2 id="ts-heading" className="mt-3 font-display text-4xl md:text-5xl leading-[0.95] text-balance">
                Paperwork that <span className="italic text-violet-glow">signs itself.</span>
              </h2>
              <p className="mt-4 text-muted-foreground max-w-md">
                Every swap generates a plain-English term sheet the moment both parties agree. No lawyers, no PDFs bouncing over email — one signed record, two mirrored copies, one immutable hash.
              </p>
              <ul className="mt-8 space-y-3 text-sm">
                {[
                  ["01", "Auto-drafted from your listing manifest"],
                  ["02", "Diff view for every counter-offer edit"],
                  ["03", "Dual e-signature with cryptographic hash"],
                  ["04", "Filed in your Deal Vault forever"],
                ].map(([n, t]) => (
                  <li key={n} className="flex items-baseline gap-3">
                    <span className="font-mono text-[10px] text-muted-foreground">{n}</span>
                    <span className="text-foreground/90">{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* the sheet */}
            <div className="hs-ts relative">
              <div aria-hidden className="hs-ts-stack hs-ts-stack--2" />
              <div aria-hidden className="hs-ts-stack hs-ts-stack--1" />
              <article className="hs-ts-sheet relative rounded-[1.25rem] border border-hairline p-7 sm:p-8">
                <header className="flex items-center justify-between border-b border-hairline pb-4">
                  <div>
                    <div className="font-display text-xl leading-none">Swap Term Sheet</div>
                    <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                      HS-4821 · 24 Jul 2026
                    </div>
                  </div>
                  <div className="hs-ts-seal">
                    <span className="font-mono text-[9px] uppercase tracking-[0.22em]">Escrow</span>
                    <span className="font-display text-xs">$19.00</span>
                  </div>
                </header>

                <dl className="mt-5 grid grid-cols-2 gap-x-6 gap-y-4 text-sm">
                  {[
                    ["Party A", "Acme Analytics"],
                    ["Party B", "Northwind CRM"],
                    ["MRR A", "$8,420"],
                    ["MRR B", "$8,190"],
                    ["Ratio", "1.03 : 1"],
                    ["Handover", "14 days"],
                    ["Jurisdiction", "Delaware, US"],
                    ["Governing", "HeySaaS v3.2"],
                  ].map(([k, v], i) => (
                    <div key={k} className="hs-ts-row" style={{ animationDelay: `${i * 90}ms` }}>
                      <dt className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{k}</dt>
                      <dd className="mt-1 font-display text-[15px] leading-tight text-foreground/95">{v}</dd>
                    </div>
                  ))}
                </dl>

                <div className="mt-6 rounded-lg border border-dashed border-hairline p-3 text-[12.5px] leading-relaxed text-muted-foreground/90">
                  Both parties agree to transfer full ownership of the properties above, including source code, customer relationships, and Stripe accounts, upon dual signature and escrow release.
                </div>

                <div className="mt-6 grid grid-cols-2 gap-6">
                  {["A. Chen", "M. Ito"].map((who, i) => (
                    <div key={who}>
                      <svg viewBox="0 0 220 60" className="hs-ts-sig w-full h-12" style={{ animationDelay: `${1200 + i * 400}ms` }}>
                        <path
                          d="M6 42 C 24 8, 44 60, 66 30 S 108 6, 130 34 S 176 52, 210 20"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          className="text-violet-glow"
                        />
                      </svg>
                      <div className="mt-1 border-t border-hairline pt-1.5 flex items-center justify-between text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                        <span>{who}</span>
                        <span className="text-emerald-300/90">✓ signed</span>
                      </div>
                    </div>
                  ))}
                </div>

                <footer className="mt-6 flex items-center justify-between border-t border-hairline pt-4 font-mono text-[10px] text-muted-foreground">
                  <span>hash · 0x8f2a…c41e</span>
                  <span className="hs-ts-pulse">● immutable</span>
                </footer>
              </article>
            </div>
          </div>
        </section>



        {/* CTA */}
        <section className="mx-auto max-w-7xl px-6 sm:px-10 pb-20 md:pb-28">
          <div className="hs-cta relative overflow-hidden rounded-[2rem] border border-hairline p-10 md:p-20 text-center" style={{ background: "var(--gradient-hero)" }}>
            <div className="absolute inset-0 hero-grid pointer-events-none" />
            <div aria-hidden className="absolute -bottom-40 left-1/2 -translate-x-1/2 h-[500px] w-[900px] rounded-full hs-aurora pointer-events-none" />
            {/* orbital rings */}
            <div aria-hidden="true" className="hs-cta-orbit hs-cta-orbit-1" />
            <div aria-hidden="true" className="hs-cta-orbit hs-cta-orbit-2" />
            <div aria-hidden="true" className="hs-cta-orbit hs-cta-orbit-3" />
            {/* corner marks */}
            <span aria-hidden="true" className="hs-cta-corner hs-cta-corner-tl" />
            <span aria-hidden="true" className="hs-cta-corner hs-cta-corner-tr" />
            <span aria-hidden="true" className="hs-cta-corner hs-cta-corner-bl" />
            <span aria-hidden="true" className="hs-cta-corner hs-cta-corner-br" />

            <div className="relative">
              <div className="inline-flex items-center gap-2 rounded-full border border-violet/30 bg-violet/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-violet-glow">
                <span className="relative inline-flex h-1.5 w-1.5">
                  <span className="absolute inset-0 rounded-full bg-violet-glow animate-ping opacity-70" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-violet-glow" />
                </span>
                Ready when you are
              </div>
              <h2 className="mt-6 font-display text-4xl md:text-6xl lg:text-7xl leading-[0.9] text-balance">
                Got a SaaS that deserves <span className="italic text-violet-glow">a new founder?</span>
              </h2>
              <p className="mt-6 mx-auto max-w-xl text-muted-foreground">
                List free. Browse free. Only pay when a swap is agreed — $19 flat, both sides.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3">
                <Link to="/list" className="group inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl bg-violet px-7 py-4 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors" style={{ boxShadow: "var(--shadow-glow)" }}>
                  List your SaaS
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </Link>
                <Link to="/how-it-works" className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl border border-hairline bg-surface/50 px-7 py-4 text-sm font-medium text-foreground hover:bg-surface transition-colors">
                  How it works
                </Link>
              </div>

              {/* trust ribbon */}
              <div className="mt-12 mx-auto max-w-2xl grid grid-cols-3 divide-x divide-hairline rounded-2xl border border-hairline bg-surface/40 backdrop-blur-sm overflow-hidden">
                {[
                  { k: "Free", v: "to list" },
                  { k: "$19", v: "on agreement" },
                  { k: "24h", v: "refund window" },
                ].map((t) => (
                  <div key={t.k} className="px-4 py-4">
                    <div className="font-display text-xl md:text-2xl leading-none">
                      <span className="bg-gradient-to-br from-foreground to-violet-glow bg-clip-text text-transparent">{t.k}</span>
                    </div>
                    <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{t.v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}


