import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsListPublicListings } from "@/lib/websites.functions";
import { useMemo, useState } from "react";
import { WsListingCard, WsListingSkeleton } from "@/components/websites/ws-listing-card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, X, SlidersHorizontal, Compass } from "lucide-react";

export const Route = createFileRoute("/websites/browse")({
  head: () => ({
    meta: [
      { title: "Browse websites for sale & swap — WebSwap" },
      { name: "description", content: "Filter verified websites by niche, price, revenue, traffic, and tech stack." },
      { property: "og:title", content: "Browse websites for sale & swap — WebSwap" },
      { property: "og:description", content: "Every listing is domain-verified. Filter by price, revenue, traffic, and stack." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BrowsePage,
});

const TECH = ["Next.js", "React", "WordPress", "Shopify", "Webflow", "Ghost", "Rails", "Laravel", "Django"];

function BrowsePage() {
  const list = useServerFn(wsListPublicListings);
  const [q, setQ] = useState("");
  const [listingType, setListingType] = useState<string>("");
  const [priceMax, setPriceMax] = useState("");
  const [revenueMin, setRevenueMin] = useState("");
  const [trafficMin, setTrafficMin] = useState("");
  const [tech, setTech] = useState<string[]>([]);
  const [niche, setNiche] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const filters = {
    q: q || undefined,
    listing_type: listingType ? (listingType as "for_sale" | "open_to_swap" | "open_to_both") : undefined,
    price_max: priceMax ? Number(priceMax) : undefined,
    revenue_min: revenueMin ? Number(revenueMin) : undefined,
    traffic_min: trafficMin ? Number(trafficMin) : undefined,
    tech: tech.length ? tech : undefined,
    niche: niche || undefined,
    limit: 48,
    offset: 0,
  };

  const { data, isFetching, isLoading } = useQuery({
    queryKey: ["ws", "browse", filters],
    queryFn: () => list({ data: filters }),
    placeholderData: (prev) => prev,
  });

  const activeChips = useMemo(() => {
    const chips: { key: string; label: string; clear: () => void }[] = [];
    if (q) chips.push({ key: "q", label: `“${q}”`, clear: () => setQ("") });
    if (listingType) chips.push({
      key: "type",
      label: { for_sale: "For sale", open_to_swap: "Open to swap", open_to_both: "Sale or swap" }[listingType] ?? listingType,
      clear: () => setListingType(""),
    });
    if (niche) chips.push({ key: "niche", label: `Niche: ${niche}`, clear: () => setNiche("") });
    if (priceMax) chips.push({ key: "priceMax", label: `≤ $${Number(priceMax).toLocaleString()}`, clear: () => setPriceMax("") });
    if (revenueMin) chips.push({ key: "revMin", label: `MRR ≥ $${Number(revenueMin).toLocaleString()}`, clear: () => setRevenueMin("") });
    if (trafficMin) chips.push({ key: "trfMin", label: `Traffic ≥ ${Number(trafficMin).toLocaleString()}`, clear: () => setTrafficMin("") });
    tech.forEach((t) => chips.push({ key: `t-${t}`, label: t, clear: () => setTech((prev) => prev.filter((x) => x !== t)) }));
    return chips;
  }, [q, listingType, niche, priceMax, revenueMin, trafficMin, tech]);

  const clearAll = () => {
    setQ(""); setListingType(""); setPriceMax(""); setRevenueMin(""); setTrafficMin(""); setTech([]); setNiche("");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-10 pb-24">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">Marketplace</h1>
          <p className="text-sm text-emerald-100/60 mt-1">
            {isLoading ? "Loading listings…" : `${data?.length ?? 0} verified ${data?.length === 1 ? "listing" : "listings"}`}
          </p>
        </div>
        <button
          onClick={() => setShowFilters((s) => !s)}
          className="md:hidden inline-flex items-center gap-1.5 text-sm px-3 py-2 rounded-md border border-emerald-900/60 text-emerald-100 hover:bg-emerald-500/10"
        >
          <SlidersHorizontal className="h-3.5 w-3.5" /> Filters
          {activeChips.length > 0 && (
            <span className="ml-1 inline-flex items-center justify-center rounded-full bg-emerald-500 text-black text-[10px] font-bold h-4 min-w-[16px] px-1">
              {activeChips.length}
            </span>
          )}
        </button>
      </div>

      <div className={`${showFilters ? "block" : "hidden"} md:block rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-4 mb-4`}>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="relative sm:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-emerald-500/60" />
            <Input
              placeholder="Search title, domain, niche…"
              className="pl-9 bg-black/40 border-emerald-900/60 text-emerald-50 placeholder:text-emerald-100/40 focus-visible:ring-emerald-500/40"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <Select value={listingType || "any"} onValueChange={(v) => setListingType(v === "any" ? "" : v)}>
            <SelectTrigger className="bg-black/40 border-emerald-900/60 text-emerald-50">
              <SelectValue placeholder="Listing type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Any type</SelectItem>
              <SelectItem value="for_sale">For sale</SelectItem>
              <SelectItem value="open_to_swap">Open to swap</SelectItem>
              <SelectItem value="open_to_both">Sale or swap</SelectItem>
            </SelectContent>
          </Select>
          <Input placeholder="Niche (e.g. saas, ecom)" className="bg-black/40 border-emerald-900/60 text-emerald-50 placeholder:text-emerald-100/40" value={niche} onChange={(e) => setNiche(e.target.value)} />
          <Input placeholder="Max price ($)" type="number" className="bg-black/40 border-emerald-900/60 text-emerald-50 placeholder:text-emerald-100/40" value={priceMax} onChange={(e) => setPriceMax(e.target.value)} />
          <Input placeholder="Min revenue ($/mo)" type="number" className="bg-black/40 border-emerald-900/60 text-emerald-50 placeholder:text-emerald-100/40" value={revenueMin} onChange={(e) => setRevenueMin(e.target.value)} />
          <Input placeholder="Min traffic (/mo)" type="number" className="bg-black/40 border-emerald-900/60 text-emerald-50 placeholder:text-emerald-100/40" value={trafficMin} onChange={(e) => setTrafficMin(e.target.value)} />
          <div className="lg:col-span-4">
            <div className="text-xs text-emerald-100/50 mb-1.5">Tech stack</div>
            <div className="flex flex-wrap gap-1.5">
              {TECH.map((t) => {
                const active = tech.includes(t);
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTech((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]))}
                    className={`text-xs px-2.5 py-1 rounded-full border transition ${
                      active
                        ? "bg-emerald-500/20 border-emerald-400 text-emerald-200"
                        : "border-emerald-900/60 text-emerald-100/70 hover:border-emerald-500/40"
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {activeChips.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-2">
          <span className="text-xs text-emerald-100/50">Active filters:</span>
          {activeChips.map((c) => (
            <button
              key={c.key}
              onClick={c.clear}
              className="inline-flex items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 pl-2.5 pr-1.5 py-1 text-xs text-emerald-200 hover:bg-emerald-500/20 transition"
            >
              {c.label} <X className="h-3 w-3" />
            </button>
          ))}
          <Button variant="ghost" size="sm" onClick={clearAll} className="h-7 px-2 text-emerald-100/70 hover:text-white">
            Clear all
          </Button>
        </div>
      )}

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <WsListingSkeleton key={i} />)}
        </div>
      ) : !data || data.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-emerald-900/60 p-12 text-center">
          <Compass className="h-8 w-8 text-emerald-500/50 mx-auto" />
          <p className="mt-3 text-emerald-100/80 font-medium">No listings match these filters</p>
          <p className="mt-1 text-sm text-emerald-100/50">Try widening your price or revenue range, or clear filters to see everything.</p>
          {activeChips.length > 0 && (
            <Button className="mt-5 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold" onClick={clearAll}>
              Clear filters
            </Button>
          )}
        </div>
      ) : (
        <div className={`grid gap-4 sm:grid-cols-2 lg:grid-cols-3 transition-opacity ${isFetching ? "opacity-70" : "opacity-100"}`}>
          {data.map((l) => (
            <WsListingCard key={l.id} l={l} />
          ))}
        </div>
      )}
    </div>
  );
}
