import { createFileRoute, useNavigate, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsGetPublicListing, wsCreateOrGetThread, wsToggleWatchlist } from "@/lib/websites.functions";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ShieldCheck,
  Globe,
  DollarSign,
  TrendingUp,
  Users,
  Calendar,
  Heart,
  MessageSquare,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Check,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/websites/$id")({
  loader: async ({ params }) => {
    const listing = await wsGetPublicListing({ data: { id: params.id } });
    if (!listing) throw notFound();
    return listing;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.title} — WebSwap` },
          { name: "description", content: loaderData.description?.slice(0, 160) ?? `Website listing on WebSwap: ${loaderData.domain}` },
          { property: "og:title", content: `${loaderData.title} — WebSwap` },
          { property: "og:description", content: loaderData.description?.slice(0, 160) ?? loaderData.domain },
          { property: "og:type", content: "article" },
          { name: "twitter:card", content: "summary_large_image" },
          ...(loaderData.screenshots?.[0]
            ? [
                { property: "og:image", content: loaderData.screenshots[0] },
                { name: "twitter:image", content: loaderData.screenshots[0] },
              ]
            : []),
        ]
      : [{ title: "Listing — WebSwap" }, { name: "robots", content: "noindex" }],
  }),
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-24 text-center">
      <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 border border-emerald-500/30 mb-4">
        <Globe className="h-7 w-7 text-emerald-400" />
      </div>
      <h1 className="text-3xl font-bold text-white">Listing not found</h1>
      <p className="mt-2 text-emerald-100/60">
        This website may have been unlisted, sold, or is not yet verified.
      </p>
      <Link
        to="/websites/browse"
        className="mt-6 inline-flex items-center gap-1 text-emerald-300 hover:text-emerald-200"
      >
        <ChevronLeft className="h-4 w-4" /> Back to marketplace
      </Link>
    </div>
  ),
  component: ListingDetail,
});

function ListingDetail() {
  const l = Route.useLoaderData();
  const [signedIn, setSignedIn] = useState(false);
  const [watching, setWatching] = useState(false);
  const [galleryIdx, setGalleryIdx] = useState(0);
  const navigate = useNavigate();
  const openThread = useServerFn(wsCreateOrGetThread);
  const toggleWatch = useServerFn(wsToggleWatchlist);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSignedIn(!!data.session));
  }, []);

  const { data: watchState } = useQuery({
    queryKey: ["ws", "watching", l.id],
    enabled: signedIn,
    queryFn: async () => {
      const { data } = await supabase
        .from("ws_watchlists")
        .select("listing_id")
        .eq("listing_id", l.id)
        .maybeSingle();
      return !!data;
    },
  });

  useEffect(() => {
    if (watchState != null) setWatching(watchState);
  }, [watchState]);

  const typeLabel =
    ({ for_sale: "For sale", open_to_swap: "Open to swap", open_to_both: "Sale or swap" } as Record<string, string>)[
      l.listing_type
    ] ?? "Listed";

  async function handleContact() {
    if (!signedIn) return navigate({ to: "/auth" });
    try {
      const t = await openThread({ data: { listing_id: l.id } });
      navigate({ to: "/websites/dashboard/messages/$threadId", params: { threadId: t.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not open conversation.");
    }
  }

  async function handleWatch() {
    if (!signedIn) return navigate({ to: "/auth" });
    try {
      const r = await toggleWatch({ data: { listing_id: l.id } });
      setWatching(r.watched);
      toast.success(r.watched ? "Added to watchlist." : "Removed from watchlist.");
    } catch {
      toast.error("Could not update watchlist.");
    }
  }

  const shots: string[] = l.screenshots ?? [];
  const currentShot = shots[galleryIdx];

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6 sm:py-10 pb-32 lg:pb-10">
      <Link
        to="/websites/browse"
        className="inline-flex items-center gap-1 text-sm text-emerald-300 hover:text-emerald-200"
      >
        <ChevronLeft className="h-4 w-4" /> Marketplace
      </Link>

      {/* Hero header */}
      <header className="mt-4 sm:mt-6">
        <div className="flex flex-wrap items-center gap-2">
          <Badge className="bg-emerald-500/15 border border-emerald-400/30 text-emerald-300">{typeLabel}</Badge>
          <Badge className="bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 gap-1">
            <ShieldCheck className="h-3 w-3" /> Ownership verified
          </Badge>
          {l.niche && (
            <span className="text-xs text-emerald-100/60 border border-emerald-900/60 rounded-full px-2 py-0.5">
              {l.niche}
            </span>
          )}
        </div>
        <h1 className="mt-3 text-3xl sm:text-4xl font-bold text-white tracking-tight">{l.title}</h1>
        <a
          href={l.website_url.startsWith("http") ? l.website_url : `https://${l.domain}`}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-1.5 inline-flex items-center gap-1 text-emerald-300 hover:text-emerald-200 text-sm"
        >
          {l.domain} <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </header>

      {/* Hero metrics — mobile */}
      <div className="mt-6 grid grid-cols-3 gap-2 lg:hidden">
        <HeroStat label="Price" value={l.asking_price_usd != null ? `$${Number(l.asking_price_usd).toLocaleString()}` : "Open"} highlight />
        <HeroStat label="MRR" value={l.monthly_revenue_usd != null ? `$${Number(l.monthly_revenue_usd).toLocaleString()}` : "—"} />
        <HeroStat label="Traffic" value={l.monthly_traffic != null ? Number(l.monthly_traffic).toLocaleString() : "—"} />
      </div>

      <div className="mt-6 grid gap-6 lg:gap-8 lg:grid-cols-3">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Gallery */}
          {shots.length > 0 && (
            <section>
              <div className="rounded-2xl border border-emerald-900/60 overflow-hidden bg-black/40 relative group">
                <img
                  src={currentShot}
                  alt={`${l.title} screenshot ${galleryIdx + 1}`}
                  className="w-full aspect-video object-cover"
                />
                {shots.length > 1 && (
                  <>
                    <button
                      onClick={() => setGalleryIdx((i) => (i - 1 + shots.length) % shots.length)}
                      className="absolute left-2 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition opacity-0 group-hover:opacity-100"
                      aria-label="Previous screenshot"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => setGalleryIdx((i) => (i + 1) % shots.length)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition opacity-0 group-hover:opacity-100"
                      aria-label="Next screenshot"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </button>
                    <div className="absolute bottom-2 right-2 rounded-full bg-black/70 px-2 py-0.5 text-[11px] text-white">
                      {galleryIdx + 1} / {shots.length}
                    </div>
                  </>
                )}
              </div>
              {shots.length > 1 && (
                <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
                  {shots.map((s, i) => (
                    <button
                      key={s}
                      onClick={() => setGalleryIdx(i)}
                      className={`shrink-0 h-14 w-20 rounded-md overflow-hidden border-2 transition ${
                        i === galleryIdx ? "border-emerald-400" : "border-transparent opacity-60 hover:opacity-100"
                      }`}
                    >
                      <img src={s} alt="" className="h-full w-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </section>
          )}

          {l.description && (
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">About this website</h2>
              <p className="text-emerald-100/80 whitespace-pre-wrap leading-relaxed">{l.description}</p>
            </section>
          )}

          {l.reason_for_selling && (
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">Reason for selling</h2>
              <p className="text-emerald-100/80 whitespace-pre-wrap leading-relaxed">{l.reason_for_selling}</p>
            </section>
          )}

          {l.tech_stack?.length > 0 && (
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">Tech stack</h2>
              <div className="flex flex-wrap gap-2">
                {l.tech_stack.map((t: string) => (
                  <span
                    key={t}
                    className="text-xs px-2.5 py-1 rounded-full border border-emerald-900/60 bg-emerald-950/40 text-emerald-100/80"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </section>
          )}

          {l.included_assets &&
            Object.keys(l.included_assets).some((k) => (l.included_assets as Record<string, boolean>)[k]) && (
              <section>
                <h2 className="text-lg font-semibold text-white mb-2">What's included</h2>
                <ul className="grid grid-cols-2 gap-2 text-emerald-100/80">
                  {["domain", "code", "socials", "email_list"].map((k) =>
                    (l.included_assets as Record<string, boolean>)[k] ? (
                      <li
                        key={k}
                        className="flex items-center gap-2 rounded-lg border border-emerald-900/60 bg-emerald-950/30 px-3 py-2 text-sm"
                      >
                        <Check className="h-4 w-4 text-emerald-400" />
                        <span className="capitalize">{k.replace("_", " ")}</span>
                      </li>
                    ) : null
                  )}
                </ul>
              </section>
            )}
        </div>

        {/* Right column — sticky on desktop */}
        <aside className="hidden lg:block space-y-4">
          <div className="sticky top-24 space-y-4">
            <div className="rounded-2xl border border-emerald-500/30 bg-gradient-to-b from-emerald-950/60 to-emerald-950/20 p-5 shadow-xl shadow-emerald-950/40">
              <div className="text-xs text-emerald-100/60 uppercase tracking-wider">Asking price</div>
              <div className="mt-1 text-3xl font-bold text-emerald-300">
                {l.asking_price_usd != null ? `$${Number(l.asking_price_usd).toLocaleString()}` : "Open to offers"}
              </div>
              {(l.estimated_value_low || l.estimated_value_high) && (
                <div className="mt-2 text-xs text-emerald-100/50 leading-relaxed">
                  Estimated range: ${Number(l.estimated_value_low || 0).toLocaleString()}–$
                  {Number(l.estimated_value_high || 0).toLocaleString()}
                  <div className="mt-0.5 italic">Estimate based on self-reported data.</div>
                </div>
              )}

              <div className="mt-5 space-y-2">
                <Button
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-semibold shadow-md shadow-emerald-900/40"
                  onClick={handleContact}
                >
                  <MessageSquare className="h-4 w-4 mr-2" /> Contact seller
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-emerald-400/30 text-emerald-200 hover:bg-emerald-500/10 bg-transparent"
                  onClick={handleWatch}
                >
                  <Heart className={`h-4 w-4 mr-2 ${watching ? "fill-emerald-400 text-emerald-400" : ""}`} />
                  {watching ? "Watching" : "Add to watchlist"}
                </Button>
              </div>
            </div>

            <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-5 space-y-3">
              <Metric icon={DollarSign} label="Monthly revenue (self-reported)" value={l.monthly_revenue_usd != null ? `$${Number(l.monthly_revenue_usd).toLocaleString()}` : "—"} />
              <Metric icon={TrendingUp} label="Monthly traffic (self-reported)" value={l.monthly_traffic != null ? Number(l.monthly_traffic).toLocaleString() : "—"} />
              <Metric icon={Calendar} label="Site age" value={l.site_age_months != null ? `${l.site_age_months} months` : "—"} />
              <Metric icon={Globe} label="Domain" value={l.domain} />
            </div>

            {l.seller && (
              <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-5">
                <div className="text-xs text-emerald-100/50 uppercase tracking-wider mb-3">Seller</div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-emerald-500/20 flex items-center justify-center overflow-hidden ring-1 ring-emerald-400/30">
                    {l.seller.avatar_url ? (
                      <img src={l.seller.avatar_url} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <Users className="h-5 w-5 text-emerald-400" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-white font-medium truncate">{l.seller.display_name || l.seller.username}</div>
                    <div className="text-xs text-emerald-100/50">@{l.seller.username}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </aside>
      </div>

      {/* Mobile sticky action bar */}
      <div className="lg:hidden fixed bottom-0 inset-x-0 z-30 border-t border-emerald-950/70 bg-[#04120e]/95 backdrop-blur px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-wider text-emerald-100/50">Asking</div>
            <div className="text-lg font-bold text-emerald-300 truncate">
              {l.asking_price_usd != null ? `$${Number(l.asking_price_usd).toLocaleString()}` : "Open"}
            </div>
          </div>
          <Button
            variant="outline"
            size="icon"
            className="border-emerald-400/30 text-emerald-200 hover:bg-emerald-500/10 bg-transparent shrink-0"
            onClick={handleWatch}
            aria-label="Watchlist"
          >
            <Heart className={`h-4 w-4 ${watching ? "fill-emerald-400 text-emerald-400" : ""}`} />
          </Button>
          <Button
            className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold"
            onClick={handleContact}
          >
            <MessageSquare className="h-4 w-4 mr-2" /> Contact seller
          </Button>
        </div>
      </div>
    </div>
  );
}

function HeroStat({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="rounded-xl border border-emerald-900/60 bg-emerald-950/30 px-3 py-2.5">
      <div className="text-[10px] uppercase tracking-wider text-emerald-100/50">{label}</div>
      <div className={`text-sm font-semibold truncate ${highlight ? "text-emerald-300" : "text-white"}`}>{value}</div>
    </div>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="text-xs text-emerald-100/50">{label}</div>
        <div className="text-sm text-white truncate">{value}</div>
      </div>
    </div>
  );
}
