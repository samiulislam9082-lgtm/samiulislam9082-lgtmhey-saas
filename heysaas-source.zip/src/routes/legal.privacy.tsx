import { createFileRoute } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/legal/privacy")({
  head: () =>
    buildHead({
      path: "/legal/privacy",
      title: "Privacy Policy — Hey SaaS",
      description:
        "How Hey SaaS collects, uses, and protects your data as a founder swapping SaaS products.",
    }),
  component: Privacy,
});

function Privacy() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="font-display text-5xl mb-2">Privacy Policy</h1>
        <p className="text-sm text-muted-foreground mb-10">Last updated: {new Date().toLocaleDateString()}</p>
        <article className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
          <section>
            <h2 className="text-foreground font-display text-2xl">What we collect</h2>
            <p>Account info (email, display name, avatar), listing content you submit, swap and message history, payment metadata from Stripe (never your full card number), and standard product analytics (page views, referrers).</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">How we use it</h2>
            <p>To run the marketplace, match swap partners, prevent fraud, send transactional emails (proposals, receipts, dispute updates), and improve the product. We do not sell your data.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">Who we share with</h2>
            <p>Stripe (payments), our email provider (transactional email), our hosting/database provider, and analytics tooling. All under standard data processing agreements.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">Your rights</h2>
            <p>Export or delete your data any time from Settings → Data. GDPR/CCPA requests: privacy@heysaas.co.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">Cookies</h2>
            <p>We use essential cookies for authentication and lightweight analytics cookies. No third-party advertising cookies.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">Retention</h2>
            <p>We keep account data while your account exists, and payment/audit records for the period required by law (typically 7 years).</p>
          </section>
        </article>
      </main>
      <Footer />
    </div>
  );
}
