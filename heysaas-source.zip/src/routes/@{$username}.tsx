import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useSignedImage } from "@/hooks/useSignedImage";
import { ListingCard, type ListingCardData } from "@/components/site/ListingCard";
import { FollowButton } from "@/components/site/FollowButton";
import { BookmarkButton } from "@/components/site/BookmarkButton";
import {
  Globe,
  Twitter,
  Github,
  Linkedin,
  MapPin,
  CheckCircle2,
  Loader2,
} from "lucide-react";

type Profile = {
  id: string;
  username: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  cover_url: string | null;
  location: string | null;
  country: string | null;
  website_url: string | null;
  twitter_handle: string | null;
  github_handle: string | null;
  linkedin_handle: string | null;
  verified: boolean;
  created_at: string;
};

export const Route = createFileRoute("/@{$username}")({
  loader: async ({ params }) => {
    const PUBLIC_COLS =
      "id, username, display_name, bio, avatar_url, cover_url, website_url, twitter_handle, github_handle, linkedin_handle, verified, created_at";
    const { data, error } = await supabase
      .from("profiles")
      .select(PUBLIC_COLS)
      .eq("username", params.username)
      .maybeSingle();
    if (error) throw error;
    if (!data) throw notFound();

    // Location fields are only readable by signed-in users.
    let location: string | null = null;
    let country: string | null = null;
    const { data: session } = await supabase.auth.getSession();
    if (session.session) {
      const { data: priv } = await supabase
        .from("profiles")
        .select("location, country")
        .eq("id", (data as { id: string }).id)
        .maybeSingle();
      location = priv?.location ?? null;
      country = priv?.country ?? null;
    }
    return { profile: { ...(data as object), location, country } as Profile };
  },

  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Founder not found — Hey SaaS" }, { name: "robots", content: "noindex" }] };
    }
    const p = loaderData.profile;
    const name = p.display_name || p.username;
    const title = `${name} (@${p.username}) — Hey SaaS`;
    const description = p.bio || `${name} — SaaS founder on Hey SaaS.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "profile" },
        { name: "twitter:card", content: "summary" },
      ],
    };
  },
  errorComponent: FounderError,
  notFoundComponent: FounderNotFound,
  component: FounderProfile,
});

function FounderProfile() {
  const { profile } = Route.useLoaderData() as { profile: Profile };
  const avatar = useSignedImage("avatars", profile.avatar_url);
  const cover = useSignedImage("covers", profile.cover_url);
  const [listings, setListings] = useState<ListingCardData[] | null>(null);
  const [swapCount, setSwapCount] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      const [{ data: rows }, { count: sc }] = await Promise.all([
        supabase
          .from("saas_listings")
          .select("id, slug, name, tagline, logo_url, cover_url, status, mrr_range, views, interested_count, tag_slugs")
          .eq("owner_id", profile.id)
          .neq("status", "draft")
          .order("interested_count", { ascending: false }),
        supabase
          .from("swap_requests")
          .select("id", { count: "exact", head: true })
          .or(`initiator_id.eq.${profile.id},recipient_id.eq.${profile.id}`)
          .eq("status", "completed"),
      ]);
      setListings((rows ?? []) as ListingCardData[]);
      setSwapCount(sc ?? 0);
    })();
  }, [profile.id]);
  const listingCount = listings?.length ?? null;

  const initials = (profile.display_name || profile.username).slice(0, 2).toUpperCase();
  const memberSince = new Date(profile.created_at).toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
  });

  return (
    <div className="min-h-dvh flex flex-col bg-background">
      <Header />
      <main id="main" className="flex-1">
        {/* Cover */}
        <div className="relative h-56 md:h-80 w-full overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,color-mix(in_oklab,var(--violet)_35%,transparent),transparent_70%)]" />
          <div className="absolute inset-0 hero-grid opacity-60" />
          {cover && (
            <img src={cover} alt="" className="h-full w-full object-cover opacity-40 mix-blend-luminosity" />
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/40 to-background" />
        </div>

        <div className="mx-auto w-full max-w-5xl px-4 sm:px-6 lg:px-8 -mt-24 md:-mt-28 relative">
          {/* Editorial masthead */}
          <div className="relative rounded-[2rem] border border-hairline bg-surface/70 backdrop-blur-xl p-6 md:p-10 shadow-lift overflow-hidden">
            <div className="absolute -top-24 -right-24 h-64 w-64 rounded-full bg-violet/20 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-violet-glow/10 blur-3xl pointer-events-none" />

            <div className="relative flex flex-col md:flex-row md:items-end md:justify-between gap-8">
              <div className="flex flex-col sm:flex-row sm:items-end gap-6 min-w-0">
                <div className="relative shrink-0">
                  <div className="absolute -inset-1 rounded-full bg-gradient-to-br from-violet to-violet-glow opacity-60 blur-md" />
                  <Avatar className="relative h-28 w-28 md:h-36 md:w-36 ring-4 ring-background">
                    {avatar && <AvatarImage src={avatar} alt={profile.username} />}
                    <AvatarFallback className="text-3xl font-display bg-surface-elevated">{initials}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] uppercase tracking-[0.2em] text-violet/80 font-medium">
                    Founder · Est. {memberSince}
                  </div>
                  <div className="mt-2 flex items-center gap-3 flex-wrap">
                    <h1 className="font-display text-4xl md:text-6xl leading-[0.95] text-balance">
                      {profile.display_name || profile.username}
                    </h1>
                    {profile.verified && (
                      <Badge className="bg-violet/15 text-violet border border-violet/30 hover:bg-violet/15 rounded-full px-2.5">
                        <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Verified
                      </Badge>
                    )}
                  </div>
                  <p className="mt-2 text-muted-foreground">
                    <span className="text-foreground/70">@{profile.username}</span>
                    {(profile.location || profile.country) && (
                      <>
                        <span className="mx-2 text-hairline">·</span>
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5" />
                          {[profile.location, profile.country].filter(Boolean).join(", ")}
                        </span>
                      </>
                    )}
                  </p>
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                <FollowButton targetId={profile.id} />
                <BookmarkButton founderId={profile.id} variant="full" />
              </div>
            </div>

            {profile.bio && (
              <blockquote className="relative mt-8 max-w-3xl">
                <span aria-hidden className="absolute -left-3 -top-4 font-display text-6xl leading-none text-violet/30 select-none">“</span>
                <p className="pl-6 font-display text-xl md:text-2xl leading-snug text-foreground/95 text-balance">
                  {profile.bio}
                </p>
              </blockquote>
            )}

            {(profile.website_url || profile.twitter_handle || profile.github_handle || profile.linkedin_handle) && (
              <div className="mt-8 flex flex-wrap items-center gap-2">
                {profile.website_url && (
                  <SocialChip href={profile.website_url} icon={Globe} label="Website" />
                )}
                {profile.twitter_handle && (
                  <SocialChip href={`https://twitter.com/${profile.twitter_handle}`} icon={Twitter} label={`@${profile.twitter_handle}`} />
                )}
                {profile.github_handle && (
                  <SocialChip href={`https://github.com/${profile.github_handle}`} icon={Github} label={profile.github_handle} />
                )}
                {profile.linkedin_handle && (
                  <SocialChip href={`https://linkedin.com/in/${profile.linkedin_handle}`} icon={Linkedin} label="LinkedIn" />
                )}
              </div>
            )}
          </div>

          <div className="mt-10 grid grid-cols-3 gap-3 md:gap-5">
            <Stat label="Listings" value={listingCount} />
            <Stat label="Swaps closed" value={swapCount} />
            <Stat label="Member since" value={memberSince} />
          </div>

          <section className="mt-20">
            <div className="flex items-end justify-between gap-4 border-b border-hairline pb-4">
              <div>
                <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Portfolio</div>
                <h2 className="font-display text-3xl md:text-4xl mt-1">Listings & ventures</h2>
              </div>
              {listingCount !== null && listingCount > 0 && (
                <span className="text-sm text-muted-foreground shrink-0">{listingCount} live</span>
              )}
            </div>
            {listings === null ? (
              <div className="mt-8 flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : listings.length === 0 ? (
              <div className="mt-8 rounded-3xl border border-dashed border-hairline bg-surface/50 p-16 text-center">
                <p className="font-display text-2xl text-foreground/90">A blank page — for now.</p>
                <p className="mt-2 text-muted-foreground">
                  {profile.display_name || profile.username} hasn't published any SaaS listings yet.
                </p>
                <Link to="/explore">
                  <Button variant="outline" className="mt-6 rounded-full">Explore other founders</Button>
                </Link>
              </div>
            ) : (
              <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {listings.map((l) => <ListingCard key={l.id} listing={l} />)}
              </div>
            )}
          </section>
        </div>
        <div className="h-24" />
      </main>
      <Footer />
    </div>
  );
}

function SocialChip({ href, icon: Icon, label }: { href: string; icon: React.ComponentType<{ className?: string }>; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="inline-flex items-center gap-1.5 rounded-full border border-hairline bg-background/40 px-3 py-1.5 text-xs text-foreground/80 hover:text-foreground hover:border-violet/40 hover:bg-violet/5 transition"
    >
      <Icon className="h-3.5 w-3.5" /> {label}
    </a>
  );
}

function Stat({ label, value }: { label: string; value: number | string | null }) {
  return (
    <div className="group relative rounded-2xl border border-hairline bg-surface/60 p-5 overflow-hidden hover:border-violet/30 transition">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet/40 to-transparent opacity-0 group-hover:opacity-100 transition" />
      <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className="font-display text-2xl md:text-3xl mt-2 text-foreground">
        {value === null ? <Loader2 className="h-4 w-4 animate-spin inline" /> : value}
      </div>
    </div>
  );
}

function FounderNotFound() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <h1 className="font-display text-5xl">Founder not found</h1>
          <p className="mt-3 text-muted-foreground">
            We couldn't find a founder with that handle.
          </p>
          <Link to="/explore">
            <Button className="mt-6 rounded-full bg-foreground text-background hover:opacity-90">
              Explore founders
            </Button>
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function FounderError({ reset }: { reset: () => void }) {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <h1 className="font-display text-4xl">Something went wrong</h1>
          <p className="mt-3 text-muted-foreground">We couldn't load this profile.</p>
          <Button onClick={reset} className="mt-6 rounded-full">Try again</Button>
        </div>
      </main>
      <Footer />
    </div>
  );
}
