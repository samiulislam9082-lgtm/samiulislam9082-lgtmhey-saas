import { createFileRoute, Outlet } from "@tanstack/react-router";
import { WebSwapShell } from "@/components/websites/WebSwapShell";

export const Route = createFileRoute("/websites")({
  head: () => ({
    meta: [
      { title: "WebSwap — Buy, sell, and swap websites" },
      { name: "description", content: "The marketplace for founders to buy, sell, or directly swap ownership of websites and online businesses. Domain-verified listings only." },
      { property: "og:title", content: "WebSwap — Buy, sell, and swap websites" },
      { property: "og:description", content: "Verified marketplace for websites and online businesses." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <WebSwapShell>
      <Outlet />
    </WebSwapShell>
  ),
});
