import { createFileRoute } from "@tanstack/react-router";
import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

type Msg = { role: "user" | "assistant"; content: string };

const SYSTEM_PROMPT = `You are the HeySaaS support assistant — a friendly, concise customer support agent for HeySaaS, a marketplace where founders swap SaaS products directly (no cash between users, $19 safety fee unlocks a private Swap Room after both parties agree).

Also help with WebSwap (/websites) — the sibling marketplace for buying, selling, and swapping websites with DNS-verified ownership.

Guidelines:
- Answer in 2–5 short sentences. Use markdown when helpful (bold, lists, short code).
- Common topics: listing a SaaS (/list), browsing (/explore), swaps, the $19 safety fee, messaging, verification, payments, refunds, deleting an account, WebSwap listings, DNS verification.
- If asked something you don't know or that requires account action, tell them to email support@heysaas.app.
- Never invent prices, refund windows, or policies. Free to list, free to browse, $19 flat safety fee per side once a swap is agreed.
- Be warm but professional. No emojis unless the user uses one first.`;

async function logServerEvent(fields: {
  session_id?: string;
  event_type: string;
  topic?: string | null;
  error_code?: string | null;
  status?: number | null;
  meta?: Record<string, unknown>;
}) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("support_chat_events").insert({
      session_id: fields.session_id ?? "server",
      event_type: fields.event_type,
      topic: fields.topic ?? null,
      error_code: fields.error_code ?? null,
      status: fields.status ?? null,
      meta: (fields.meta ?? {}) as never,
    });
  } catch {
    // never break the response
  }
}

export const Route = createFileRoute("/api/support-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let session_id: string | undefined;
        let topic: string | undefined;
        try {
          const body = (await request.json()) as { messages?: Msg[]; session_id?: string; topic?: string };
          session_id = body.session_id;
          topic = body.topic;
          const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
          if (messages.length === 0) {
            return new Response(JSON.stringify({ error: "No messages" }), { status: 400 });
          }
          const key = process.env.LOVABLE_API_KEY;
          if (!key) {
            void logServerEvent({ session_id, event_type: "chat_error", topic, error_code: "missing_api_key", status: 500 });
            return new Response(JSON.stringify({ error: "Support is temporarily unavailable." }), { status: 500 });
          }
          const gateway = createLovableAiGatewayProvider(key);
          const { text } = await generateText({
            model: gateway("google/gemini-3.6-flash"),
            system: SYSTEM_PROMPT,
            messages: messages.map((m) => ({ role: m.role, content: m.content })),
          });
          return Response.json({ reply: text });
        } catch (e: any) {
          const msg = String(e?.message ?? e);
          const status = msg.includes("429") ? 429 : msg.includes("402") ? 402 : 500;
          const error_code =
            status === 429 ? "rate_limited" : status === 402 ? "credits_exhausted" : "server_error";
          void logServerEvent({
            session_id,
            event_type: "chat_error",
            topic,
            error_code,
            status,
            meta: { source: "gateway", message: msg.slice(0, 300) },
          });
          const userMsg =
            status === 429
              ? "Too many messages right now — please try again in a moment."
              : status === 402
                ? "Support AI credits are exhausted. Please contact support@heysaas.app."
                : "Something went wrong. Try again or email support@heysaas.app.";
          return new Response(JSON.stringify({ error: userMsg }), { status });
        }
      },
    },
  },
});
