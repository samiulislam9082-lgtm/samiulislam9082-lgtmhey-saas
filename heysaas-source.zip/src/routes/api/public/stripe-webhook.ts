import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";

/**
 * Stripe webhook — verifies signature, records events, updates payment + swap state.
 * Only used when STRIPE_SECRET_KEY + STRIPE_WEBHOOK_SECRET are configured.
 */
export const Route = createFileRoute("/api/public/stripe-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.STRIPE_WEBHOOK_SECRET;
        const stripeKey = process.env.STRIPE_SECRET_KEY;
        if (!secret || !stripeKey) return new Response("Stripe not configured", { status: 501 });

        const sig = request.headers.get("stripe-signature") || "";
        const body = await request.text();

        const { default: Stripe } = await import("stripe");
        const stripe = new Stripe(stripeKey, { apiVersion: "2024-11-20.acacia" as never });
        let event: import("stripe").Stripe.Event;
        try {
          event = stripe.webhooks.constructEvent(body, sig, secret);
        } catch {
          return new Response("Invalid signature", { status: 400 });
        }
        void createHmac; void timingSafeEqual;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Idempotency
        const { data: seen } = await supabaseAdmin.from("stripe_events").select("id").eq("stripe_event_id", event.id).maybeSingle();
        if (seen) return new Response("ok");
        await supabaseAdmin.from("stripe_events").insert({ stripe_event_id: event.id, event_type: event.type });

        if (event.type === "checkout.session.completed") {
          const session = event.data.object as import("stripe").Stripe.Checkout.Session;
          const swapId = (session.metadata?.swap_id as string) || (session.client_reference_id as string);
          const userId = session.metadata?.user_id as string;
          if (swapId && userId) {
            await supabaseAdmin
              .from("payments")
              .update({
                status: "paid",
                paid_at: new Date().toISOString(),
                stripe_payment_intent_id: (session.payment_intent as string) || null,
              })
              .eq("swap_request_id", swapId)
              .eq("user_id", userId);

            const { data: swap } = await supabaseAdmin
              .from("swap_requests")
              .select("id, initiator_id, recipient_id")
              .eq("id", swapId)
              .maybeSingle();
            if (swap) {
              const { data: paid } = await supabaseAdmin
                .from("payments")
                .select("user_id")
                .eq("swap_request_id", swapId)
                .eq("status", "paid");
              const paidUsers = new Set((paid || []).map((r: any) => r.user_id));
              const bothPaid = paidUsers.has(swap.initiator_id) && paidUsers.has(swap.recipient_id);
              await supabaseAdmin
                .from("swap_requests")
                .update({ status: bothPaid ? "confirmed" : "fee_paid_one_side" })
                .eq("id", swapId);

              const otherId = userId === swap.initiator_id ? swap.recipient_id : swap.initiator_id;
              await supabaseAdmin.from("notifications").insert({
                user_id: otherId,
                type: bothPaid ? "swap_confirmed" : "fee_paid_by_partner",
                title: bothPaid ? "Swap confirmed — start exchanging!" : "Your swap partner paid the fee",
                link: `/dashboard/swaps/${swapId}`,
              });
            }
          }
        }

        return new Response("ok");
      },
    },
  },
});
