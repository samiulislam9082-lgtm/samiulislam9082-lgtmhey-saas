// Public cron endpoint. Called by pg_cron every day.
// For each saved_search with email_notify=true, finds listings created since
// last_notified_at that match the filters, inserts an in-app notification, and
// (if RESEND_API_KEY is configured) sends an email digest via the Lovable
// connector gateway.
import { createFileRoute } from "@tanstack/react-router";
import { requireCronSecret } from "@/lib/cron-auth.server";

export const Route = createFileRoute("/api/public/saved-search-digest")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        // Auth: shared CRON_SECRET. The publishable/anon key is public by
        // design and is NOT a credential — it must never gate this endpoint.
        const denied = requireCronSecret(request);
        if (denied) return denied;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: searches, error } = await supabaseAdmin
          .from("saved_searches")
          .select("*")
          .eq("email_notify", true);
        if (error) return new Response(error.message, { status: 500 });

        let totalMatches = 0;
        const now = new Date().toISOString();

        for (const s of searches ?? []) {
          const since = s.last_notified_at ?? s.created_at;
          let q = supabaseAdmin
            .from("saas_listings")
            .select("id, slug, name, tagline, mrr_range, tech_stack, country, owner_id")
            .eq("status", "live")
            .gt("created_at", since)
            .neq("owner_id", s.user_id)
            .limit(20);

          if (s.category_id) q = q.eq("category_id", s.category_id);
          if (s.q) q = q.ilike("name", `%${s.q}%`);
          if (s.mrr_ranges?.length) q = q.in("mrr_range", s.mrr_ranges);
          if (s.tech_stack?.length) q = q.overlaps("tech_stack", s.tech_stack);
          if (s.countries?.length) q = q.in("country", s.countries);

          const { data: matches } = await q;
          if (!matches || matches.length === 0) {
            await supabaseAdmin
              .from("saved_searches")
              .update({ last_notified_at: now })
              .eq("id", s.id);
            continue;
          }

          totalMatches += matches.length;

          // In-app notification
          await supabaseAdmin.from("notifications").insert({
            user_id: s.user_id,
            type: "saved_search_match",
            title: `${matches.length} new ${matches.length === 1 ? "listing matches" : "listings match"} “${s.name}”`,
            body: matches.slice(0, 5).map((m: any) => m.name).join(", "),
            link: "/explore",
            metadata: { search_id: s.id, listing_slugs: matches.map((m: any) => m.slug) },
          });

          // Optional email via Resend connector gateway
          const resendKey = process.env.RESEND_API_KEY;
          const lovableKey = process.env.LOVABLE_API_KEY;
          if (resendKey && lovableKey) {
            const { data: profile } = await supabaseAdmin
              .from("profiles")
              .select("id, display_name")
              .eq("id", s.user_id)
              .maybeSingle();
            const { data: userRes } = await supabaseAdmin.auth.admin.getUserById(s.user_id);
            const email = userRes?.user?.email;
            if (email) {
              const listItems = matches
                .slice(0, 10)
                .map(
                  (m: any) =>
                    `<li><a href="https://heysaas.lovable.app/saas/${m.slug}">${m.name}</a>${m.tagline ? ` — ${m.tagline}` : ""}</li>`,
                )
                .join("");
              await fetch("https://connector-gateway.lovable.dev/resend/emails", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${lovableKey}`,
                  "X-Connection-Api-Key": resendKey,
                },
                body: JSON.stringify({
                  from: "HeySaaS <onboarding@resend.dev>",
                  to: [email],
                  subject: `${matches.length} new SaaS match “${s.name}”`,
                  html: `<p>Hi ${profile?.display_name ?? "there"},</p><p>${matches.length} new listing${matches.length === 1 ? "" : "s"} matched your saved search <strong>${s.name}</strong>:</p><ul>${listItems}</ul><p><a href="https://heysaas.lovable.app/explore">Open marketplace →</a></p>`,
                }),
              }).catch(() => {});
            }
          }

          await supabaseAdmin
            .from("saved_searches")
            .update({ last_notified_at: now })
            .eq("id", s.id);
        }

        return new Response(
          JSON.stringify({ ok: true, searches: searches?.length ?? 0, matches: totalMatches }),
          { headers: { "Content-Type": "application/json" } },
        );
      },
    },
  },
});
