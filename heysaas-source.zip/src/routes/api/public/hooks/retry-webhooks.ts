import { createFileRoute } from "@tanstack/react-router";
import { runRetryCycle } from "@/lib/support-webhooks.functions";
import { requireCronSecret } from "@/lib/cron-auth.server";

// Called by pg_cron every minute to retry pending/failed webhook deliveries
// with exponential backoff. See support-webhooks.functions.ts.
// Requires the CRON_SECRET shared secret: this endpoint triggers outbound
// HTTP requests and DB writes, so it must never be anonymously callable.
export const Route = createFileRoute("/api/public/hooks/retry-webhooks")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const denied = requireCronSecret(request);
        if (denied) return denied;
        try {
          const result = await runRetryCycle(50);
          return Response.json({ ok: true, ...result });
        } catch (e) {
          console.error("[retry-webhooks] cycle failed", e);
          // Don't leak internal error details to the caller.
          return Response.json({ ok: false, error: "Retry cycle failed" }, { status: 500 });
        }
      },
      GET: async () => Response.json({ ok: true, hint: "POST to run retry cycle" }),
    },
  },
});
