import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useSignedImage } from "@/hooks/useSignedImage";
import { BookmarkButton } from "@/components/site/BookmarkButton";
import { ProposeSwapDialog } from "@/components/site/ProposeSwapDialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Eye, Sparkles, ExternalLink, Calendar, MapPin, Code2, Repeat, CheckCircle2, MessageSquare, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Listing = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  logo_url: string | null;
  cover_url: string | null;
  website_url: string | null;
  launch_year: number | null;
  country: string | null;
  status: string;
  pricing_model: string | null;
  mrr_range: string | null;
  arr_range: string | null;
  user_count_range: string | null;
  tech_stack: string[];
  tag_slugs: string[];
  screenshots: string[];
  demo_video_url: string | null;
  reason_for_swap: string | null;
  looking_for: string | null;
  views: number;
  interested_count: number;
  owner_id: string;
  category_id: string | null;
};

type Owner = {
  id: string;
  username: string;
  display_name: string | null;
  avatar_url: string | null;
  verified: boolean;
};

export const Route = createFileRoute("/saas/$slug")({
  loader: async ({ params }) => {
    const { data, error } = await supabase
      .from("saas_listings")
      .select("*")
      .eq("slug", params.slug)
      .neq("status", "draft")
      .maybeSingle();
    if (error) throw error;
    if (!data) throw notFound();
    const { data: owner } = await supabase
      .from("profiles")
      .select("id, username, display_name, avatar_url, verified")
      .eq("id", data.owner_id)
      .maybeSingle();
    const listing = {
      ...data,
      screenshots: Array.isArray(data.screenshots) ? (data.screenshots as string[]) : [],
    } as Listing;
    return { listing, owner: owner as Owner | null };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "SaaS not found — Hey SaaS" }, { name: "robots", content: "noindex" }] };
    const l = loaderData.listing;
    const title = `${l.name}${l.tagline ? ` — ${l.tagline}` : ""} | Hey SaaS`;
    const desc = l.tagline || l.description?.slice(0, 155) || `${l.name} on Hey SaaS`;
    const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Product",
      name: l.name,
      description: desc,
      brand: { "@type": "Brand", name: l.name },
      category: "SaaS",
      offers: {
        "@type": "Offer",
        price: "0",
        priceCurrency: "USD",
        availability: l.status === "live" ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
        description: "Open to swap — no cash sale",
      },
    };
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
      scripts: [{ type: "application/ld+json", children: JSON.stringify(jsonLd) }],
    };
  },
  errorComponent: () => <NotFound title="Something went wrong" />,
  notFoundComponent: () => <NotFound title="SaaS not found" />,
  component: SaaSDetail,
});

function SaaSDetail() {
  const { listing, owner } = Route.useLoaderData() as { listing: Listing; owner: Owner | null };
  const navigate = useNavigate();
  const logo = useSignedImage("logos", listing.logo_url);
  const cover = useSignedImage("covers", listing.cover_url);
  const ownerAvatar = useSignedImage("avatars", owner?.avatar_url ?? null);
  const [proposeOpen, setProposeOpen] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [interested, setInterested] = useState(false);
  const [messaging, setMessaging] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUserId(user?.id ?? null);
      if (!user) return;
      const { data } = await supabase
        .from("interests")
        .select("id")
        .eq("user_id", user.id)
        .eq("listing_id", listing.id)
        .maybeSingle();
      setInterested(!!data);
    })();
    // Fire-and-forget view increment
    supabase.rpc as any; // no rpc needed, use update
    supabase.from("saas_listings").update({ views: listing.views + 1 }).eq("id", listing.id).then(() => {});
  }, [listing.id]);

  async function toggleInterested() {
    if (!userId) { navigate({ to: "/auth" }); return; }
    if (interested) {
      await supabase.from("interests").delete().eq("user_id", userId).eq("listing_id", listing.id);
      setInterested(false);
    } else {
      await supabase.from("interests").insert({ user_id: userId, listing_id: listing.id });
      setInterested(true);
    }
  }

  async function startConversation() {
    if (!userId) { navigate({ to: "/auth" }); return; }
    if (userId === listing.owner_id) return;
    setMessaging(true);
    try {
      const [a, b] = [userId, listing.owner_id].sort();
      const { data: existing } = await supabase
        .from("threads")
        .select("id")
        .is("swap_request_id", null)
        .eq("user_a", a)
        .eq("user_b", b)
        .maybeSingle();
      let threadId = existing?.id;
      if (!threadId) {
        const { data: created, error } = await supabase
          .from("threads")
          .insert({ user_a: a, user_b: b })
          .select("id")
          .single();
        if (error) throw error;
        threadId = created.id;
      }
      navigate({ to: "/dashboard/messages", search: { t: threadId } });
    } catch (e) {
      console.error(e);
      toast.error(e instanceof Error ? e.message : "Could not start conversation");
    } finally {
      setMessaging(false);
    }
  }

  const canPropose = listing.status === "live" && userId && userId !== listing.owner_id;
  const isOwner = userId === listing.owner_id;

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1">
        {/* Cover */}
        <div className="relative h-56 md:h-80 w-full overflow-hidden bg-gradient-to-br from-violet/25 via-surface to-background">
          {cover && <img src={cover} alt="" className="h-full w-full object-cover opacity-80" />}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
        </div>

        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 -mt-16 md:-mt-24 relative">
          <div className="grid gap-10 lg:grid-cols-[1fr,320px]">
            <div className="min-w-0">
              <div className="flex items-start gap-5">
                <div className="h-24 w-24 shrink-0 overflow-hidden rounded-3xl border border-hairline bg-background shadow-2xl">
                  {logo ? <img src={logo} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center font-display text-3xl">{listing.name.slice(0, 1)}</div>}
                </div>
                <div className="min-w-0 pt-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="font-display text-3xl md:text-4xl">{listing.name}</h1>
                    <StatusBadge status={listing.status} />
                  </div>
                  {listing.tagline && <p className="mt-2 text-lg text-muted-foreground">{listing.tagline}</p>}
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                    <span className="inline-flex items-center gap-1"><Eye className="h-3.5 w-3.5" /> {listing.views + 1} views</span>
                    <span className="inline-flex items-center gap-1"><Sparkles className="h-3.5 w-3.5" /> {listing.interested_count} interested</span>
                    {listing.launch_year && <span className="inline-flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> Since {listing.launch_year}</span>}
                    {listing.country && <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {listing.country}</span>}
                  </div>
                </div>
              </div>

              {/* Description */}
              {listing.description && (
                <section className="mt-10">
                  <h2 className="font-display text-2xl">About</h2>
                  <div className="mt-4 whitespace-pre-wrap text-base leading-relaxed text-foreground/90">
                    {listing.description}
                  </div>
                </section>
              )}

              {/* Screenshots */}
              {listing.screenshots.length > 0 && (
                <section className="mt-12">
                  <h2 className="font-display text-2xl">Gallery</h2>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    {listing.screenshots.map((p, i) => (<Screenshot key={i} path={p} />))}
                  </div>
                </section>
              )}

              {/* Stats */}
              <section className="mt-12">
                <h2 className="font-display text-2xl">Numbers <span className="text-xs font-body font-normal text-muted-foreground align-middle">Self-reported</span></h2>
                <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    ["MRR", listing.mrr_range],
                    ["ARR", listing.arr_range],
                    ["Users", listing.user_count_range],
                    ["Pricing", listing.pricing_model],
                  ].map(([k, v]) => (
                    <div key={k as string} className="rounded-2xl border border-hairline bg-surface p-4">
                      <div className="text-xs text-muted-foreground">{k}</div>
                      <div className="mt-1 font-medium">{(v as string | null) || "—"}</div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Tech */}
              {listing.tech_stack.length > 0 && (
                <section className="mt-10">
                  <h2 className="font-display text-2xl inline-flex items-center gap-2"><Code2 className="h-5 w-5" />Tech stack</h2>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {listing.tech_stack.map((t) => <Badge key={t} variant="outline" className="rounded-full">{t}</Badge>)}
                  </div>
                </section>
              )}

              {/* Preferences */}
              {(listing.reason_for_swap || listing.looking_for) && (
                <section className="mt-10 grid gap-4 md:grid-cols-2">
                  {listing.reason_for_swap && (
                    <div className="rounded-2xl border border-hairline bg-surface p-5">
                      <h3 className="font-medium">Why open to swap</h3>
                      <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{listing.reason_for_swap}</p>
                    </div>
                  )}
                  {listing.looking_for && (
                    <div className="rounded-2xl border border-hairline bg-surface p-5">
                      <h3 className="font-medium">Looking for</h3>
                      <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap">{listing.looking_for}</p>
                    </div>
                  )}
                </section>
              )}

              {listing.tag_slugs?.length > 0 && (
                <div className="mt-8 flex flex-wrap gap-2">
                  {listing.tag_slugs.map((t) => <Badge key={t} variant="secondary" className="rounded-full">#{t}</Badge>)}
                </div>
              )}
            </div>

            {/* Sidebar */}
            <aside className="lg:sticky lg:top-24 lg:self-start">
              <div className="rounded-3xl border border-hairline bg-surface p-6 space-y-4">
                {owner && (
                  <Link to="/@{$username}" params={{ username: owner.username }} className="flex items-center gap-3 group">
                    <Avatar className="h-11 w-11">
                      {ownerAvatar && <AvatarImage src={ownerAvatar} />}
                      <AvatarFallback>{(owner.display_name || owner.username).slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1 font-medium group-hover:underline">
                        {owner.display_name || owner.username}
                        {owner.verified && <CheckCircle2 className="h-3.5 w-3.5 text-violet" />}
                      </div>
                      <div className="text-xs text-muted-foreground">@{owner.username}</div>
                    </div>
                  </Link>
                )}

                {listing.website_url && (
                  <a href={listing.website_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                    <ExternalLink className="h-4 w-4" /> Visit website
                  </a>
                )}

                <div className="pt-2 space-y-2">
                  {isOwner ? (
                    <Link to="/dashboard/listings">
                      <Button variant="outline" className="w-full rounded-full">Manage listing</Button>
                    </Link>
                  ) : (
                    <>
                      <Button
                        onClick={startConversation}
                        disabled={messaging}
                        className="w-full rounded-full bg-foreground text-background hover:opacity-90"
                      >
                        {messaging ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <MessageSquare className="h-4 w-4 mr-2" />}
                        Message {owner?.display_name || owner?.username || "seller"}
                      </Button>
                      <Button
                        onClick={() => setProposeOpen(true)}
                        disabled={!canPropose}
                        variant="outline"
                        className="w-full rounded-full"
                        title={!canPropose ? "Sign in with a live listing to propose a swap" : undefined}
                      >
                        <Repeat className="h-4 w-4 mr-2" /> Propose swap
                      </Button>
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" onClick={toggleInterested} className="rounded-full">
                          <Sparkles className="h-4 w-4 mr-1" /> {interested ? "Interested" : "Interest"}
                        </Button>
                        <BookmarkButton listingId={listing.id} variant="full" />
                      </div>
                    </>
                  )}
                </div>
              </div>
            </aside>
          </div>
        </div>
        <div className="h-24" />
      </main>
      <Footer />

      {owner && (
        <ProposeSwapDialog
          open={proposeOpen}
          onOpenChange={setProposeOpen}
          recipientListingId={listing.id}
          recipientName={listing.name}
        />
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: string }> = {
    live: { label: "Open to swap", tone: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
    not_open: { label: "Not open", tone: "bg-muted text-muted-foreground" },
    access_paused: { label: "Paused", tone: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
    access_extended: { label: "Extended access", tone: "bg-sky-500/15 text-sky-400 border-sky-500/30" },
    swapped: { label: "Swapped", tone: "bg-violet/20 text-violet border-violet/30" },
  };
  const c = map[status] ?? { label: status, tone: "" };
  return <Badge variant="outline" className={`rounded-full ${c.tone}`}>{c.label}</Badge>;
}

function Screenshot({ path }: { path: string }) {
  const url = useSignedImage("screenshots", path);
  return (
    <div className="aspect-[16/10] overflow-hidden rounded-2xl border border-hairline bg-surface">
      {url && <img src={url} alt="" className="h-full w-full object-cover" />}
    </div>
  );
}

function NotFound({ title }: { title: string }) {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <h1 className="font-display text-5xl">{title}</h1>
          <p className="mt-3 text-muted-foreground">This listing may have been removed or made private.</p>
          <Link to="/explore"><Button className="mt-6 rounded-full bg-foreground text-background hover:opacity-90">Explore SaaS</Button></Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
