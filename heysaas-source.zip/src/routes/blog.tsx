import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { useSignedImage } from "@/hooks/useSignedImage";

type Post = { id: string; slug: string; title: string; excerpt: string | null; cover_url: string | null; published_at: string | null };

export const Route = createFileRoute("/blog")({
  head: () =>
    buildHead({
      path: "/blog",
      title: "Blog — Hey SaaS",
      description:
        "Stories, playbooks, and interviews from founders swapping their way to a better portfolio.",
    }),
  component: Blog,
});

function Blog() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    supabase.from("posts").select("id, slug, title, excerpt, cover_url, published_at").not("published_at", "is", null).order("published_at", { ascending: false }).limit(50).then(({ data }) => {
      setPosts((data ?? []) as Post[]);
      setLoading(false);
    });
  }, []);
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto max-w-5xl w-full px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h1 className="font-display text-5xl md:text-7xl">Blog</h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-xl">Founder stories, swap playbooks, and lessons from the trenches.</p>
        {loading ? (
          <div className="mt-16 text-muted-foreground">Loading…</div>
        ) : posts.length === 0 ? (
          <div className="mt-16 rounded-3xl border border-dashed border-hairline p-12 text-center">
            <p className="font-display text-2xl">No posts yet.</p>
            <p className="mt-2 text-muted-foreground">First stories are on the way.</p>
          </div>
        ) : (
          <div className="mt-16 grid gap-6 md:grid-cols-2">
            {posts.map((p) => <PostCard key={p.id} post={p} />)}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

function PostCard({ post }: { post: Post }) {
  const cover = useSignedImage("covers", post.cover_url);
  return (
    <Link to="/blog/$slug" params={{ slug: post.slug }} className="group block rounded-2xl border border-hairline bg-surface overflow-hidden hover:border-foreground/30 transition-colors">
      {cover && <img src={cover} alt="" className="w-full aspect-[16/9] object-cover" />}
      <div className="p-6">
        {post.published_at && <div className="text-xs text-muted-foreground">{new Date(post.published_at).toLocaleDateString()}</div>}
        <h2 className="mt-2 font-display text-2xl group-hover:text-foreground">{post.title}</h2>
        {post.excerpt && <p className="mt-3 text-sm text-muted-foreground line-clamp-3">{post.excerpt}</p>}
      </div>
    </Link>
  );
}
