import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { supabase } from "@/integrations/supabase/client";
import { useSignedImage } from "@/hooks/useSignedImage";

type Post = {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  body_md: string;
  cover_url: string | null;
  published_at: string | null;
  author_id: string | null;
};

export const Route = createFileRoute("/blog/$slug")({
  loader: async ({ params }) => {
    const { data, error } = await supabase
      .from("posts")
      .select("id, slug, title, excerpt, body_md, cover_url, published_at, author_id")
      .eq("slug", params.slug)
      .not("published_at", "is", null)
      .maybeSingle();
    if (error) throw error;
    if (!data) throw notFound();
    return { post: data as Post };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Post not found — Hey SaaS" }, { name: "robots", content: "noindex" }] };
    const p = loaderData.post;
    const desc = p.excerpt || p.body_md.slice(0, 155);
    return {
      meta: [
        { title: `${p.title} — Hey SaaS Blog` },
        { name: "description", content: desc },
        { property: "og:title", content: p.title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  errorComponent: () => <NotFound />,
  notFoundComponent: () => <NotFound />,
  component: BlogPost,
});

function NotFound() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto max-w-3xl w-full px-4 py-24 text-center">
        <h1 className="font-display text-5xl">Post not found</h1>
        <Link to="/blog" className="mt-6 inline-block text-muted-foreground hover:text-foreground">← Back to blog</Link>
      </main>
      <Footer />
    </div>
  );
}

function BlogPost() {
  const { post } = Route.useLoaderData();
  const cover = useSignedImage("covers", post.cover_url);
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto max-w-3xl w-full px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <Link to="/blog" className="text-sm text-muted-foreground hover:text-foreground">← All posts</Link>
        <h1 className="mt-4 font-display text-4xl md:text-6xl text-balance">{post.title}</h1>
        {post.published_at && (
          <p className="mt-4 text-sm text-muted-foreground">
            {new Date(post.published_at).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}
          </p>
        )}
        {cover && (
          <img src={cover} alt="" className="mt-8 rounded-2xl w-full aspect-[16/9] object-cover border border-hairline" />
        )}
        <article className="mt-10 prose prose-invert prose-lg max-w-none whitespace-pre-wrap text-foreground/90 leading-relaxed">
          {post.body_md}
        </article>
      </main>
      <Footer />
    </div>
  );
}
