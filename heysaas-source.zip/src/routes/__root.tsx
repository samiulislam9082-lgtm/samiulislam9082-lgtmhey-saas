import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Toaster as SonnerToaster } from "sonner";
import { CommandPalette } from "@/components/site/CommandPalette";


import { MotionSync } from "@/components/site/MotionSync";
import { MotionDebugIndicator } from "@/components/site/MotionDebugIndicator";
import { FirebaseAnalytics } from "@/components/site/FirebaseAnalytics";

function NotFoundComponent() {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mb-6 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet to-violet-glow text-2xl font-display">
          404
        </div>
        <h2 className="mt-4 text-2xl font-display text-foreground">
          This page took the swap and left.
        </h2>
        <p className="mt-3 text-sm text-muted-foreground">
          The page you're looking for doesn't exist. But there are plenty of SaaS to explore.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-dvh items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-2xl font-display tracking-tight text-foreground">
          Something didn't load.
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Try again or head back home — your listings are safe.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-full border border-border bg-transparent px-5 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Hey SaaS — Swap Your SaaS. Not Your Money." },
      {
        name: "description",
        content:
          "The marketplace where founders exchange SaaS products directly — no cash, no brokers, just great matches. List free, swap safely.",
      },
      { name: "author", content: "Hey SaaS" },
      { name: "theme-color", content: "#0B0B0F" },
      { property: "og:title", content: "Hey SaaS — Swap Your SaaS. Not Your Money." },
      {
        property: "og:description",
        content:
          "A trusted marketplace where founders exchange startups. Free listings, no cash between users, $19 safety fee only when a swap is agreed.",
      },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Hey SaaS" },
      { name: "twitter:card", content: "summary_large_image" },
      // twitter:title / twitter:description intentionally omitted —
      // Twitter falls back to og:title / og:description per route.
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "manifest", href: "/site.webmanifest" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&family=Pacifico&family=Work+Sans:wght@300;400;500;600;700&display=swap",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Organization",
              name: "Hey SaaS",
              url: "https://heysaas.lovable.app",
              logo: "https://heysaas.lovable.app/favicon.ico",
            },
            {
              "@type": "WebSite",
              name: "Hey SaaS",
              url: "https://heysaas.lovable.app",
              potentialAction: {
                "@type": "SearchAction",
                target: "https://heysaas.lovable.app/explore?q={search_term_string}",
                "query-input": "required name=search_term_string",
              },
            },
          ],
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark" style={{ colorScheme: "dark" }} data-motion="full">
      <head>
        <HeadContent />
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var e=document.documentElement;e.classList.remove('light');e.classList.add('dark');e.style.colorScheme='dark';try{localStorage.removeItem('heysaas.theme');}catch(_){}var m=localStorage.getItem('heysaas.motion')||'system';var mr=m==='reduced'||(m==='system'&&matchMedia('(prefers-reduced-motion: reduce)').matches);e.dataset.motion=mr?'reduced':'full';}catch(e){}})();`,
          }}
        />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("light");
    root.classList.add("dark");
    root.style.colorScheme = "dark";
    let unsub: (() => void) | undefined;
    import("@/integrations/supabase/client").then(({ supabase }) => {
      const { data } = supabase.auth.onAuthStateChange(() => {
        router.invalidate();
      });
      unsub = () => data.subscription.unsubscribe();
    });
    return () => unsub?.();
  }, [router]);

  return (
    <QueryClientProvider client={queryClient}>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[200] focus:rounded-md focus:bg-foreground focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-background focus:shadow-lg"
      >
        Skip to main content
      </a>
      <MotionSync />
      <FirebaseAnalytics />
      <Outlet />
      <CommandPalette />
      {import.meta.env.DEV ? <MotionDebugIndicator /> : null}
      <SonnerToaster theme="dark" position="top-center" />
    </QueryClientProvider>

  );
}
