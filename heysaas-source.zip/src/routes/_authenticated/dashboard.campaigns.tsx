import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Copy, Link2, Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/campaigns")({
  head: () => ({ meta: [{ title: "Campaigns — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: CampaignsPage,
});

const PRESETS = [
  { label: "Twitter / X", source: "twitter", medium: "social" },
  { label: "LinkedIn", source: "linkedin", medium: "social" },
  { label: "Product Hunt", source: "producthunt", medium: "referral" },
  { label: "Newsletter", source: "newsletter", medium: "email" },
  { label: "Reddit", source: "reddit", medium: "social" },
  { label: "IndieHackers", source: "indiehackers", medium: "community" },
];

type Listing = { id: string; name: string; slug: string; status: string };

function CampaignsPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [listingSlug, setListingSlug] = useState<string>("");
  const [source, setSource] = useState("twitter");
  const [medium, setMedium] = useState("social");
  const [campaign, setCampaign] = useState("launch");
  const [content, setContent] = useState("");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data } = await supabase.from("saas_listings").select("id, name, slug, status").eq("owner_id", user.id);
      setListings(data ?? []);
      if (data?.[0]) setListingSlug(data[0].slug);
      setLoading(false);
    })();
  }, []);

  const base = typeof window !== "undefined" ? window.location.origin : "";
  const url = useMemo(() => {
    if (!listingSlug) return "";
    const u = new URL(`${base}/l/${listingSlug}`);
    if (source) u.searchParams.set("utm_source", source);
    if (medium) u.searchParams.set("utm_medium", medium);
    if (campaign) u.searchParams.set("utm_campaign", campaign);
    if (content) u.searchParams.set("utm_content", content);
    return u.toString();
  }, [base, listingSlug, source, medium, campaign, content]);

  function copy(text: string) {
    navigator.clipboard.writeText(text);
    toast.success("Copied");
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="analytics"
              eyebrow="Marketing desk"
              title="Campaign links"
              description="Tag every share with UTM parameters so Analytics attributes traffic to the right channel."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : listings.length === 0 ? (
              <Card className="p-6 text-sm text-muted-foreground mt-6">
                Create a listing first to build campaign links. <a className="underline" href="/list">List your SaaS</a>.
              </Card>
            ) : (
              <div className="grid lg:grid-cols-2 gap-6 mt-6">
                <Card className="p-6 space-y-4">
                  <div>
                    <Label>Listing</Label>
                    <select
                      className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                      value={listingSlug}
                      onChange={(e) => setListingSlug(e.target.value)}
                    >
                      {listings.map((l) => (
                        <option key={l.id} value={l.slug}>{l.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <Label>Quick presets</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {PRESETS.map((p) => (
                        <button
                          key={p.source}
                          onClick={() => { setSource(p.source); setMedium(p.medium); }}
                          className={`text-xs px-2.5 py-1 rounded-full border ${source === p.source ? "border-primary text-primary bg-primary/10" : "border-border text-muted-foreground hover:text-foreground"}`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>utm_source</Label>
                      <Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="twitter" />
                    </div>
                    <div>
                      <Label>utm_medium</Label>
                      <Input value={medium} onChange={(e) => setMedium(e.target.value)} placeholder="social" />
                    </div>
                    <div>
                      <Label>utm_campaign</Label>
                      <Input value={campaign} onChange={(e) => setCampaign(e.target.value)} placeholder="launch" />
                    </div>
                    <div>
                      <Label>utm_content</Label>
                      <Input value={content} onChange={(e) => setContent(e.target.value)} placeholder="hero-cta" />
                    </div>
                  </div>
                </Card>

                <Card className="p-6 space-y-4">
                  <div>
                    <Label className="flex items-center gap-2"><Link2 className="h-4 w-4" /> Tagged URL</Label>
                    <div className="mt-2 rounded-md border border-border bg-muted/30 p-3 text-xs font-mono break-all">
                      {url || "—"}
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button onClick={() => copy(url)} disabled={!url}><Copy className="h-4 w-4 mr-1" /> Copy link</Button>
                      <Button
                        variant="outline"
                        onClick={() => copy(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}`)}
                        disabled={!url}
                      >
                        Copy tweet-intent
                      </Button>
                    </div>
                  </div>

                  <div className="border-t border-border pt-4">
                    <div className="text-sm font-medium mb-2">Why UTMs matter</div>
                    <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                      <li>Traffic without UTMs shows up as "direct" and can't be optimized.</li>
                      <li>Keep sources lowercase and consistent (twitter, not Twitter/X).</li>
                      <li>Use one <Badge variant="secondary" className="mx-1">utm_campaign</Badge> per push (e.g. "ph-launch-jul26").</li>
                    </ul>
                  </div>
                </Card>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
