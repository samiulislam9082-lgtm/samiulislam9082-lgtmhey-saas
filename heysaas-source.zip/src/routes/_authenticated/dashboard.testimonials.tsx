import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Copy, Quote, Star, Link as LinkIcon } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/testimonials")({
  head: () => ({ meta: [{ title: "Testimonials — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: TestimonialsPage,
});

type Testimonial = {
  id: string; name: string; role: string; company: string;
  quote: string; source_url: string; rating: number; avatar_url: string; approved: boolean; date: string;
};

function TestimonialsPage() {
  const [uid, setUid] = useState<string | null>(null);
  const [items, setItems] = useState<Testimonial[]>([]);
  const [draft, setDraft] = useState<Partial<Testimonial>>({ rating: 5 });

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUid(user.id);
      try {
        const raw = localStorage.getItem(`hs.testimonials.${user.id}`);
        if (raw) setItems(JSON.parse(raw));
      } catch {}
    })();
  }, []);

  const persist = (next: Testimonial[]) => {
    setItems(next);
    if (uid) localStorage.setItem(`hs.testimonials.${uid}`, JSON.stringify(next));
  };

  const add = () => {
    if (!draft.quote || !draft.name) { toast.error("Name and quote required"); return; }
    const t: Testimonial = {
      id: crypto.randomUUID(),
      name: draft.name!, role: draft.role ?? "", company: draft.company ?? "",
      quote: draft.quote!, source_url: draft.source_url ?? "",
      rating: draft.rating ?? 5, avatar_url: draft.avatar_url ?? "",
      approved: true, date: new Date().toISOString(),
    };
    persist([t, ...items]);
    setDraft({ rating: 5 });
    toast.success("Testimonial saved");
  };

  const remove = (id: string) => persist(items.filter((t) => t.id !== id));

  const collectLink = uid ? `${window.location.origin}/t/collect?u=${uid}` : "";

  const embedSnippet = () => `<!-- Hey SaaS testimonials -->\n${items.slice(0, 3).map((t) => `<blockquote>\n  "${t.quote}"\n  — ${t.name}${t.role ? `, ${t.role}` : ""}${t.company ? ` at ${t.company}` : ""}\n</blockquote>`).join("\n")}`;

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <div className="hs-noir hs-dash-shell flex-1">
        <div className="hs-dash-canvas" aria-hidden="true">
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--one" />
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--two" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col lg:flex-row gap-8 relative">
          <DashboardSidebar />
          <main id="main" className="flex-1 min-w-0 space-y-6">
            <BackButton />
            <DashHero
              eyebrow="Marketing · Social proof"
              title="Let your users do the selling."
              description="Curate the quotes that make founders and acquirers lean in. Collect once, reuse everywhere — listing pages, pitch decks, embeds."
              signature="overview"
              actions={
                <>
                  <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(collectLink); toast.success("Collection link copied"); }}>
                    <LinkIcon className="w-4 h-4 mr-2" />Copy collect link
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(embedSnippet()); toast.success("Embed HTML copied"); }}>
                    <Copy className="w-4 h-4 mr-2" />Copy embed
                  </Button>
                  <Badge variant="secondary">{items.length} testimonials</Badge>
                </>
              }
            />

            <Card className="p-5">
              <h3 className="text-sm font-medium mb-3 flex items-center gap-2"><Plus className="w-4 h-4" /> Add testimonial</h3>
              <div className="grid gap-3 md:grid-cols-3">
                <Input placeholder="Name" value={draft.name ?? ""} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
                <Input placeholder="Role" value={draft.role ?? ""} onChange={(e) => setDraft({ ...draft, role: e.target.value })} />
                <Input placeholder="Company" value={draft.company ?? ""} onChange={(e) => setDraft({ ...draft, company: e.target.value })} />
                <Input placeholder="Source URL (tweet, review…)" value={draft.source_url ?? ""} onChange={(e) => setDraft({ ...draft, source_url: e.target.value })} />
                <Input placeholder="Avatar URL" value={draft.avatar_url ?? ""} onChange={(e) => setDraft({ ...draft, avatar_url: e.target.value })} />
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map((n) => (
                    <button key={n} type="button" onClick={() => setDraft({ ...draft, rating: n })}>
                      <Star className={`w-5 h-5 ${(draft.rating ?? 5) >= n ? "fill-amber-300 text-amber-300" : "text-white/30"}`} />
                    </button>
                  ))}
                </div>
              </div>
              <Textarea className="mt-3" rows={3} placeholder="Their exact words…" value={draft.quote ?? ""} onChange={(e) => setDraft({ ...draft, quote: e.target.value })} />
              <div className="mt-3 flex justify-end"><Button onClick={add}><Plus className="w-4 h-4 mr-2" />Save</Button></div>
            </Card>

            {items.length === 0 ? (
              <Card className="p-10 text-center text-sm text-muted-foreground">
                <Quote className="w-8 h-8 mx-auto opacity-40 mb-2" />
                No testimonials yet. Share the collect link with a happy user.
              </Card>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {items.map((t) => (
                  <Card key={t.id} className="p-5 relative">
                    <Quote className="absolute top-4 right-4 w-6 h-6 opacity-20" />
                    <div className="flex items-center gap-1 mb-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} className={`w-4 h-4 ${i < t.rating ? "fill-amber-300 text-amber-300" : "text-white/20"}`} />
                      ))}
                    </div>
                    <p className="font-display text-lg leading-relaxed">"{t.quote}"</p>
                    <div className="mt-4 flex items-center gap-3">
                      {t.avatar_url ? (
                        <img src={t.avatar_url} alt="" className="w-9 h-9 rounded-full object-cover" />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-xs">{t.name.slice(0,1)}</div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium truncate">{t.name}</div>
                        <div className="text-xs text-muted-foreground truncate">{[t.role, t.company].filter(Boolean).join(" · ")}</div>
                      </div>
                      {t.source_url && <a href={t.source_url} target="_blank" rel="noreferrer" className="text-xs text-cyan-300 hover:underline">Source</a>}
                      <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => remove(t.id)}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
