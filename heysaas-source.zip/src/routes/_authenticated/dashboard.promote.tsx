import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Rocket, TrendingUp, Star, CheckCircle2 } from "lucide-react";
import { promoteListing } from "@/lib/promotions.functions";

export const Route = createFileRoute("/_authenticated/dashboard/promote")({
  head: () => ({ meta: [{ title: "Promote — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: PromotePage,
});

type Row = {
  id: string;
  name: string;
  slug: string;
  status: string;
  views: number | null;
  interested_count: number | null;
  promoted?: { starts_at: string; ends_at: string } | null;
};

function PromotePage() {
  const promote = useServerFn(promoteListing);
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => { void load(); }, []);

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const { data: listings } = await supabase
      .from("saas_listings")
      .select("id, name, slug, status, views, interested_count")
      .eq("owner_id", user.id);
    const ids = (listings ?? []).map((l: any) => l.id);
    let promos: any[] = [];
    if (ids.length) {
      const { data } = await supabase
        .from("promotions")
        .select("listing_id, starts_at, ends_at")
        .in("listing_id", ids)
        .gt("ends_at", new Date().toISOString());
      promos = data ?? [];
    }
    setRows((listings ?? []).map((l: any) => ({
      ...l,
      promoted: promos.find((p) => p.listing_id === l.id) ?? null,
    })));
    setLoading(false);
  }

  async function onPromote(id: string) {
    setBusy(id);
    try {
      const res = await promote({ data: { listing_id: id } });
      if (res.mode === "stripe" && res.url) { window.location.href = res.url; return; }
      toast.success("Promoted for 7 days");
      await load();
    } catch (e: any) {
      toast.error(e?.message ?? "Could not promote");
    } finally { setBusy(null); }
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="listings"
              eyebrow="Marketing desk"
              title="Promote your listings"
              description="Boost a live SaaS into the featured rotation for 7 days — top of Explore, homepage rail, category flow."
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <Perk icon={Star} title="Featured badge" body="A gold star and top-of-list rank across Explore and category pages." />
              <Perk icon={TrendingUp} title="~4× more proposals" body="Median lift observed across founder-verified boosts in the last 90 days." />
              <Perk icon={Rocket} title="Instant activation" body="Live within seconds of payment — no queue, no waiting on review." />
            </div>

            <div className="mt-8">
              <h2 className="text-xl font-display italic mb-3">Your live SaaS</h2>
              {loading ? (
                <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
              ) : rows.length === 0 ? (
                <Card className="p-6 text-sm text-muted-foreground">
                  You have no listings yet. <a className="underline" href="/list">List your first SaaS</a> to unlock promotion.
                </Card>
              ) : (
                <div className="space-y-3">
                  {rows.map((r) => {
                    const active = !!r.promoted;
                    const disabled = r.status !== "live" || busy === r.id;
                    return (
                      <Card key={r.id} className="p-5 flex flex-col md:flex-row md:items-center gap-4 justify-between">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <div className="font-medium truncate">{r.name}</div>
                            <Badge variant={r.status === "live" ? "default" : "secondary"}>{r.status}</Badge>
                            {active && (
                              <Badge className="bg-primary/15 text-primary border border-primary/30">
                                <Star className="h-3 w-3 mr-1" /> Featured until {new Date(r.promoted!.ends_at).toLocaleDateString()}
                              </Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {r.views ?? 0} views · {r.interested_count ?? 0} interested
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            onClick={() => onPromote(r.id)}
                            disabled={disabled}
                            className="min-w-[160px]"
                          >
                            {busy === r.id ? <Loader2 className="h-4 w-4 animate-spin" /> : active ? "Extend 7 days · $49" : "Promote 7 days · $49"}
                          </Button>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>

            <Card className="mt-8 p-5">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-primary mt-0.5" />
                <div className="text-sm text-muted-foreground">
                  <div className="text-foreground font-medium mb-1">Marketing tips that actually move the needle</div>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Refresh your tagline before promoting — first 8 words drive most clicks.</li>
                    <li>Reply to every proposal within 24h; featured listings that don't reply lose ranking.</li>
                    <li>Add 3+ tech stack tags and 1 category to appear in more saved-search matches.</li>
                    <li>Ask a bookmarker to leave a review — social proof lifts proposal rate ~30%.</li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Perk({ icon: Icon, title, body }: { icon: any; title: string; body: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-2"><Icon className="h-4 w-4 text-primary" /><div className="font-medium">{title}</div></div>
      <p className="text-sm text-muted-foreground">{body}</p>
    </Card>
  );
}
