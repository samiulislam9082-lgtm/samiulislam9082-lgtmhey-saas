import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { verifyFounder } from "@/lib/admin.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/founders")({
  component: FoundersAdmin,
});

function FoundersAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const verify = useServerFn(verifyFounder);
  async function load() {
    let query = supabase.from("profiles").select("id, username, display_name, verified, created_at").order("created_at", { ascending: false }).limit(50);
    if (q) query = query.or(`username.ilike.%${q}%,display_name.ilike.%${q}%`);
    const { data } = await query;
    setItems(data || []);
  }
  useEffect(() => { load(); }, [q]);
  async function toggle(id: string, verified: boolean) {
    try { await verify({ data: { user_id: id, verified } }); toast.success("Updated"); load(); } catch (e: any) { toast.error(e.message); }
  }
  return (
    <div>
      <h1 className="font-display text-4xl mb-6">Founders</h1>
      <Input placeholder="Search by username or name…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-4 max-w-md" />
      <div className="space-y-2">
        {items.map((p) => (
          <Card key={p.id} className="p-4 flex items-center justify-between">
            <div>
              <div className="font-medium flex items-center gap-2">{p.display_name || p.username || "Unnamed"} {p.verified && <Badge className="bg-primary/20 text-primary border-0"><CheckCircle2 className="h-3 w-3 mr-1" />Verified</Badge>}</div>
              <div className="text-xs text-muted-foreground">@{p.username}</div>
            </div>
            <Button size="sm" variant={p.verified ? "outline" : "default"} onClick={() => toggle(p.id, !p.verified)}>
              {p.verified ? "Unverify" : "Verify"}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
}
