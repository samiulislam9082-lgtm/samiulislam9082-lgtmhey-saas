import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { sendBroadcast } from "@/lib/broadcasts.functions";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Send, Users, Bookmark, Heart, Megaphone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/broadcasts")({
  head: () => ({ meta: [{ title: "Broadcasts — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: BroadcastsPage,
});

type Listing = { id: string; name: string; slug: string };
type Audience = "followers" | "bookmarkers" | "interested";

function BroadcastsPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [listingId, setListingId] = useState<string>("");
  const [audience, setAudience] = useState<Audience>("bookmarkers");
  const [counts, setCounts] = useState<Record<Audience, number>>({ followers: 0, bookmarkers: 0, interested: 0 });
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [link, setLink] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [me, setMe] = useState<string | null>(null);

  useEffect(() => { void init(); }, []);

  async function init() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    setMe(user.id);
    const { data } = await supabase.from("saas_listings").select("id, name, slug").eq("owner_id", user.id);
    setListings(data ?? []);
    if (data?.[0]) { setListingId(data[0].id); setLink(`/l/${data[0].slug}`); }
    // Followers of me
    const { count: followers } = await supabase.from("follows").select("*", { count: "exact", head: true }).eq("following_id", user.id);
    setCounts((c) => ({ ...c, followers: followers ?? 0 }));
    setLoading(false);
  }

  useEffect(() => {
    (async () => {
      if (!listingId) return;
      const [{ count: bm }, { count: it }] = await Promise.all([
        supabase.from("bookmarks").select("*", { count: "exact", head: true }).eq("listing_id", listingId),
        supabase.from("interests").select("*", { count: "exact", head: true }).eq("listing_id", listingId),
      ]);
      setCounts((c) => ({ ...c, bookmarkers: bm ?? 0, interested: it ?? 0 }));
      const l = listings.find((x) => x.id === listingId);
      if (l && !link) setLink(`/l/${l.slug}`);
    })();
  }, [listingId, listings]);

  const recipientCount = counts[audience];

  async function send() {
    if (!me || !listingId) return;
    if (!title.trim()) { toast.error("Add a title"); return; }
    setSending(true);
    try {
      const res = await sendBroadcast({
        data: {
          listing_id: listingId,
          audience,
          title: title.trim(),
          body: body.trim() || null,
          link: link.trim() || null,
        },
      });
      if (!res.sent) { toast.info("No recipients in that audience yet"); return; }
      toast.success(`Broadcast sent to ${res.sent} founder${res.sent === 1 ? "" : "s"}`);
      setTitle(""); setBody("");
    } catch (e: any) {
      toast.error(e?.message ?? "Could not send broadcast");
    } finally { setSending(false); }
  }


  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="notifications"
              eyebrow="Marketing desk"
              title="Broadcasts"
              description="Send a single update to the founders paying attention. Use sparingly — signal, not noise."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : listings.length === 0 ? (
              <Card className="p-6 text-sm text-muted-foreground mt-6">Create a listing to unlock broadcasts.</Card>
            ) : (
              <div className="grid lg:grid-cols-3 gap-4 mt-6">
                <Card className="p-5 lg:col-span-2 space-y-4">
                  <div>
                    <Label>Listing</Label>
                    <select
                      value={listingId}
                      onChange={(e) => { setListingId(e.target.value); const l = listings.find((x) => x.id === e.target.value); if (l) setLink(`/l/${l.slug}`); }}
                      className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                    >
                      {listings.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                    </select>
                  </div>

                  <div>
                    <Label>Audience</Label>
                    <div className="grid grid-cols-3 gap-2 mt-1">
                      {([
                        { key: "bookmarkers" as const, icon: Bookmark, label: "Bookmarkers", n: counts.bookmarkers },
                        { key: "interested" as const, icon: Heart, label: "Interested", n: counts.interested },
                        { key: "followers" as const, icon: Users, label: "Followers", n: counts.followers },
                      ]).map((a) => (
                        <button
                          key={a.key}
                          onClick={() => setAudience(a.key)}
                          className={`text-left rounded-md border p-3 transition ${audience === a.key ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"}`}
                        >
                          <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wider"><a.icon className="h-3.5 w-3.5" /> {a.label}</div>
                          <div className="text-2xl font-display italic mt-1">{a.n}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Title</Label>
                    <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="New pricing tier launched" maxLength={120} />
                    <div className="text-[11px] text-muted-foreground mt-1">{title.length}/120</div>
                  </div>

                  <div>
                    <Label>Body (optional)</Label>
                    <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={4} placeholder="A short note — what changed and why they should care." maxLength={400} />
                    <div className="text-[11px] text-muted-foreground mt-1">{body.length}/400</div>
                  </div>

                  <div>
                    <Label>Link</Label>
                    <Input value={link} onChange={(e) => setLink(e.target.value)} placeholder="/l/your-listing" />
                  </div>

                  <Button onClick={send} disabled={sending || recipientCount === 0}>
                    {sending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                    Send to {recipientCount} founder{recipientCount === 1 ? "" : "s"}
                  </Button>
                </Card>

                <Card className="p-5">
                  <div className="text-sm font-medium mb-2 flex items-center gap-2"><Megaphone className="h-4 w-4 text-primary" /> Broadcast etiquette</div>
                  <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                    <li>One broadcast per listing per 2 weeks — more and unsubscribes climb.</li>
                    <li>Lead with the concrete change (numbers, dates), not adjectives.</li>
                    <li>Bookmarkers are your warmest audience — save the biggest news for them.</li>
                    <li>Recipients can mute your updates from their notification preferences.</li>
                  </ul>
                </Card>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
