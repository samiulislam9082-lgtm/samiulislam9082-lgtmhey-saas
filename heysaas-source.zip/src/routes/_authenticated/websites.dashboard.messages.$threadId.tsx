import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  wsGetThread,
  wsSendMessage,
  wsCreateOffer,
  wsRespondOffer,
  wsEditMessage,
  wsDeleteMessage,
  wsToggleReaction,
  wsMarkThreadRead,
  wsSetMute,
  wsReportThread,
  wsSuggestReply,
  wsSearchMessages,
  wsListThreads,
} from "@/lib/websites.functions";
import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { motionPreferenceIsReduced } from "@/lib/motion";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Send, DollarSign, ArrowLeft, Paperclip, Smile, Sparkles, MoreVertical,
  Reply, Pencil, Trash2, Bell, BellOff, Flag, ShieldAlert, X, Check, CheckCheck,
  ArrowDown, Search as SearchIcon, Image as ImageIcon, Globe, MessageSquare, Info,
} from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { REACTION_EMOJIS, QUICK_REPLIES, extractUrls, shortTime, groupByDay } from "@/lib/ws-messaging";
import { LinkPreview } from "@/components/websites/messaging/LinkPreview";
import { Attachment } from "@/components/websites/messaging/Attachment";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { usePresence } from "@/lib/presence";
import { formatDistanceToNowStrict } from "date-fns";

export const Route = createFileRoute("/_authenticated/websites/dashboard/messages/$threadId")({
  component: ThreadPage,
});

type Msg = {
  id: string; thread_id: string; sender_id: string; body: string;
  reply_to_id: string | null; edited_at: string | null; deleted_at: string | null;
  client_flags: unknown; created_at: string; kind: string;
};

/* ────────────────────────────────────────────────────────────────────
   Small helpers (visual only)
   ──────────────────────────────────────────────────────────────────── */

function Avatar({ url, name, size = 32, ring = true }: { url?: string | null; name?: string | null; size?: number; ring?: boolean }) {
  const initial = (name?.trim()?.[0] || "?").toUpperCase();
  return (
    <div
      className={`shrink-0 rounded-full overflow-hidden grid place-items-center bg-gradient-to-br from-emerald-500/30 to-emerald-800/30 text-emerald-50 font-medium ${ring ? "ring-1 ring-white/10" : ""}`}
      style={{ height: size, width: size, fontSize: size * 0.42 }}
    >
      {url ? <img src={url} alt="" className="h-full w-full object-cover" /> : <span>{initial}</span>}
    </div>
  );
}

function MessageSkeletons() {
  const rows = [
    { mine: false, w: "w-40" }, { mine: false, w: "w-64" }, { mine: true, w: "w-52" },
    { mine: false, w: "w-72" }, { mine: true, w: "w-32" }, { mine: true, w: "w-48" },
  ];
  return (
    <div className="space-y-3 p-4">
      {rows.map((r, i) => (
        <div key={i} className={`flex ${r.mine ? "justify-end" : "justify-start"}`}>
          <div className={`h-9 ${r.w} rounded-2xl animate-pulse ${r.mine ? "bg-emerald-500/20 rounded-br-md" : "bg-white/[0.05] rounded-bl-md"}`} />
        </div>
      ))}
    </div>
  );
}

function TypingBubble({ name }: { name?: string | null }) {
  return (
    <div className="flex items-end gap-2 px-1 motion-safe:animate-[fade-in_0.2s_ease-out]">
      <div className="rounded-2xl rounded-bl-md bg-white/[0.05] border border-white/5 px-3 py-2.5 flex items-center gap-1">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-300/70 motion-safe:animate-bounce [animation-delay:-0.3s]" />
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-300/70 motion-safe:animate-bounce [animation-delay:-0.15s]" />
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-300/70 motion-safe:animate-bounce" />
      </div>
      {name && <span className="text-[10px] text-emerald-100/40">{name} is typing</span>}
    </div>
  );
}

/* ────────────────────────────────────────────────────────────────────
   Main component
   ──────────────────────────────────────────────────────────────────── */

function ThreadPage() {
  const { threadId } = Route.useParams();
  const qc = useQueryClient();
  const get = useServerFn(wsGetThread);
  const send = useServerFn(wsSendMessage);
  const editFn = useServerFn(wsEditMessage);
  const delFn = useServerFn(wsDeleteMessage);
  const reactFn = useServerFn(wsToggleReaction);
  const markRead = useServerFn(wsMarkThreadRead);
  const muteFn = useServerFn(wsSetMute);
  const reportFn = useServerFn(wsReportThread);
  const suggestFn = useServerFn(wsSuggestReply);
  const searchFn = useServerFn(wsSearchMessages);
  const makeOffer = useServerFn(wsCreateOffer);
  const respondOffer = useServerFn(wsRespondOffer);
  const listThreadsFn = useServerFn(wsListThreads);

  const { data, isLoading } = useQuery({ queryKey: ["ws", "thread", threadId], queryFn: () => get({ data: { thread_id: threadId } }) });
  const threadsQ = useQuery({ queryKey: ["ws", "threads"], queryFn: () => listThreadsFn() });

  const [userId, setUserId] = useState<string | null>(null);
  useEffect(() => { supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null)); }, []);

  const { online } = usePresence(userId);

  const [body, setBody] = useState("");
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  const [editing, setEditing] = useState<Msg | null>(null);
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQ, setSearchQ] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reportDetails, setReportDetails] = useState("");
  const [blockedOther, setBlockedOther] = useState<boolean>(false);
  const [otherTyping, setOtherTyping] = useState(false);
  const [scrolledUp, setScrolledUp] = useState(false);
  const [amount, setAmount] = useState("");
  const [offerNote, setOfferNote] = useState("");
  const [showOfferPanel, setShowOfferPanel] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const invalidate = useCallback(() => qc.invalidateQueries({ queryKey: ["ws", "thread", threadId] }), [qc, threadId]);

  // Realtime: messages + reactions + thread updates
  useEffect(() => {
    if (!userId) return;
    const ch = supabase
      .channel(`ws:thread:${threadId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "ws_messages", filter: `thread_id=eq.${threadId}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "ws_threads", filter: `id=eq.${threadId}` }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "ws_message_reactions" }, invalidate)
      .on("broadcast", { event: "typing" }, (payload) => {
        const from = (payload.payload as { user_id: string }).user_id;
        if (from && from !== userId) {
          setOtherTyping(true);
          if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
          typingTimeoutRef.current = setTimeout(() => setOtherTyping(false), 3000);
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [threadId, userId, invalidate]);

  useEffect(() => {
    if (data) markRead({ data: { thread_id: threadId } }).catch(() => {});
  }, [data?.messages.length, markRead, threadId]);

  useEffect(() => {
    if (!userId || !data) return;
    const other = data.thread.buyer_id === userId ? data.thread.seller_id : data.thread.buyer_id;
    supabase.from("user_blocks").select("id").eq("blocker_id", userId).eq("blocked_id", other).maybeSingle()
      .then(({ data: row }) => setBlockedOther(!!row));
  }, [userId, data]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el || scrolledUp) return;
    const reduced = motionPreferenceIsReduced();
    el.scrollTo({ top: el.scrollHeight, behavior: reduced ? "auto" : "smooth" });
  }, [data?.messages?.length, scrolledUp]);

  // Auto-grow textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, [body]);

  function onScroll() {
    const el = scrollRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    setScrolledUp(!nearBottom);
  }

  function jumpToLatest() {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    setScrolledUp(false);
  }

  function broadcastTyping() {
    supabase.channel(`ws:thread:${threadId}`).send({ type: "broadcast", event: "typing", payload: { user_id: userId } });
  }
  const typingRef = useRef<number>(0);
  function onBodyChange(v: string) {
    setBody(v);
    const now = Date.now();
    if (now - typingRef.current > 1500) { typingRef.current = now; broadcastTyping(); }
  }

  async function uploadFiles(files: File[]): Promise<Array<{ storage_path: string; mime: string; size: number; kind: "image" | "file"; width?: number; height?: number }>> {
    const out = [];
    for (const f of files) {
      if (f.size > 10 * 1024 * 1024) { toast.error(`${f.name} exceeds 10 MB`); continue; }
      const ext = f.name.split(".").pop() ?? "bin";
      const path = `${threadId}/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("ws-message-attachments").upload(path, f, { contentType: f.type, upsert: false });
      if (error) { toast.error(`Upload failed: ${error.message}`); continue; }
      out.push({ storage_path: path, mime: f.type || "application/octet-stream", size: f.size, kind: f.type.startsWith("image/") ? "image" as const : "file" as const });
    }
    return out;
  }

  async function handleSend() {
    if (editing) return handleSaveEdit();
    const text = body.trim();
    if (!text && pendingFiles.length === 0) return;
    try {
      const attachments = pendingFiles.length ? await uploadFiles(pendingFiles) : undefined;
      await send({ data: { thread_id: threadId, body: text || "📎", reply_to_id: replyTo?.id ?? null, attachments } });
      setBody(""); setReplyTo(null); setPendingFiles([]);
      invalidate();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Send failed.");
    }
  }

  async function handleSaveEdit() {
    if (!editing) return;
    try {
      await editFn({ data: { id: editing.id, body: body.trim() } });
      setEditing(null); setBody("");
      invalidate();
    } catch (e) { toast.error(e instanceof Error ? e.message : "Edit failed."); }
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this message?")) return;
    try { await delFn({ data: { id } }); invalidate(); } catch (e) { toast.error(e instanceof Error ? e.message : "Delete failed."); }
  }

  async function handleReact(mid: string, emoji: string) {
    try { await reactFn({ data: { message_id: mid, emoji } }); invalidate(); } catch (e) { toast.error(e instanceof Error ? e.message : "Failed."); }
  }

  async function handleSuggest(seed?: string) {
    try {
      toast.loading("Drafting reply…", { id: "ai" });
      const { draft } = await suggestFn({ data: { thread_id: threadId, seed } });
      toast.success("Draft ready — edit before sending", { id: "ai" });
      setBody(draft);
    } catch (e) { toast.error(e instanceof Error ? e.message : "AI failed.", { id: "ai" }); }
  }

  const isBuyer = userId && data?.thread.buyer_id === userId;
  const other = isBuyer ? data?.seller : data?.buyer;
  const listing = (data?.thread as unknown as { ws_listings: { id: string; title: string; domain: string; asking_price_usd: number | null; screenshots?: string[] } } | undefined)?.ws_listings;
  const otherId = data ? (isBuyer ? data.thread.seller_id : data.thread.buyer_id) : null;
  const otherOnline = otherId ? online.has(otherId) : false;
  const otherLastReadAt = isBuyer ? data?.thread.seller_last_read_at : data?.thread.buyer_last_read_at;
  const myMuted = isBuyer ? data?.thread.buyer_muted : data?.thread.seller_muted;

  const activeOffer = useMemo(() => {
    const pend = (data?.offers ?? []).filter((o) => o.status === "pending");
    return pend.length ? pend[pend.length - 1] : null;
  }, [data?.offers]);

  const reactionsByMsg = useMemo(() => {
    const map = new Map<string, Array<{ emoji: string; count: number; mine: boolean }>>();
    for (const r of data?.reactions ?? []) {
      const arr = map.get(r.message_id) ?? [];
      const found = arr.find((x) => x.emoji === r.emoji);
      if (found) { found.count += 1; if (r.user_id === userId) found.mine = true; }
      else arr.push({ emoji: r.emoji, count: 1, mine: r.user_id === userId });
      map.set(r.message_id, arr);
    }
    return map;
  }, [data?.reactions, userId]);

  const attachByMsg = useMemo(() => {
    const map = new Map<string, Array<{ id: string; message_id: string; storage_path: string; mime: string; size: number; width: number | null; height: number | null; kind: string }>>();
    for (const a of data?.attachments ?? []) {
      const arr = map.get(a.message_id) ?? [];
      arr.push(a as never);
      map.set(a.message_id, arr);
    }
    return map;
  }, [data?.attachments]);

  const visibleMessages = data?.messages ?? [];
  const dayGroups = useMemo(() => groupByDay(visibleMessages as Msg[]), [visibleMessages]);

  const searchResults = useQuery({
    queryKey: ["ws", "thread-search", threadId, searchQ],
    queryFn: () => searchFn({ data: { thread_id: threadId, q: searchQ } }),
    enabled: showSearch && searchQ.trim().length > 0,
  });

  async function handleToggleBlock() {
    if (!otherId || !userId) return;
    if (blockedOther) {
      await supabase.from("user_blocks").delete().eq("blocker_id", userId).eq("blocked_id", otherId);
      setBlockedOther(false); toast.success("Unblocked");
    } else {
      if (!confirm("Block this user? They won't be able to message you again.")) return;
      await supabase.from("user_blocks").insert({ blocker_id: userId, blocked_id: otherId });
      setBlockedOther(true); toast.success("Blocked");
    }
  }

  async function submitReport() {
    if (!otherId || reportReason.trim().length < 2) { toast.error("Add a reason"); return; }
    try {
      await reportFn({ data: { thread_id: threadId, reported_user_id: otherId, reason: reportReason.trim(), details: reportDetails.trim() || undefined } });
      toast.success("Report sent to moderators.");
      setReportOpen(false); setReportReason(""); setReportDetails("");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Report failed."); }
  }

  const canSend = body.trim().length > 0 || pendingFiles.length > 0;

  return (
    <div className="h-[100dvh] sm:h-[calc(100dvh-64px)] w-full flex bg-[#04110f]">
      {/* ── LEFT: thread list (desktop only) ─────────────────────── */}
      <aside className="hidden md:flex w-[320px] shrink-0 flex-col border-r border-white/5 bg-black/20">
        <div className="p-4 border-b border-white/5">
          <Link to="/websites/dashboard/messages" className="text-[11px] uppercase tracking-widest text-emerald-100/50 hover:text-emerald-200 inline-flex items-center gap-1.5">
            <ArrowLeft className="h-3 w-3" /> All conversations
          </Link>
          <div className="mt-3 text-white font-semibold text-lg tracking-tight">Inbox</div>
        </div>
        <div className="flex-1 overflow-y-auto py-2">
          {threadsQ.isLoading && (
            <div className="space-y-2 px-3">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-14 rounded-xl bg-white/[0.03] animate-pulse" />
              ))}
            </div>
          )}
          {threadsQ.data?.map((t) => {
            const l = (t as unknown as { ws_listings: { id: string; title: string; domain: string; screenshots: string[] } }).ws_listings;
            const active = t.id === threadId;
            return (
              <Link
                key={t.id}
                to="/websites/dashboard/messages/$threadId"
                params={{ threadId: t.id }}
                className={`mx-2 my-0.5 flex items-center gap-3 rounded-xl px-3 py-2.5 transition group ${
                  active
                    ? "bg-emerald-500/10 ring-1 ring-emerald-400/30"
                    : "hover:bg-white/[0.03]"
                }`}
              >
                <div className="h-10 w-10 rounded-lg overflow-hidden shrink-0 bg-black/40 grid place-items-center ring-1 ring-white/5">
                  {l?.screenshots?.[0] ? <img src={l.screenshots[0]} alt="" className="h-full w-full object-cover" /> : <Globe className="h-4 w-4 text-emerald-500/50" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className={`truncate text-sm ${active ? "text-white font-semibold" : "text-emerald-50/90 font-medium"}`}>
                    {l?.title ?? "Untitled"}
                  </div>
                  <div className="truncate text-[11px] text-emerald-100/45">{l?.domain}</div>
                </div>
                {t.last_message_at && (
                  <div className="text-[10px] text-emerald-100/35 tabular-nums shrink-0">
                    {formatDistanceToNowStrict(new Date(t.last_message_at))}
                  </div>
                )}
              </Link>
            );
          })}
          {threadsQ.data?.length === 0 && (
            <div className="px-6 py-8 text-center text-xs text-emerald-100/40">No other conversations.</div>
          )}
        </div>
      </aside>

      {/* ── RIGHT: conversation ────────────────────────────────── */}
      <section className="flex-1 min-w-0 flex flex-col relative">
        {/* Header */}
        <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 sm:px-6 py-3 border-b border-white/5 bg-black/30 backdrop-blur">
          <div className="flex min-w-0 items-center gap-3">
            <Link to="/websites/dashboard/messages" className="md:hidden shrink-0 p-2 -ml-2 rounded-lg hover:bg-white/[0.05] text-emerald-100" aria-label="Back to inbox">
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div className="relative shrink-0">
              <Avatar url={other?.avatar_url} name={other?.display_name || other?.username} size={40} />
              <span
                aria-label={otherOnline ? "Online" : "Offline"}
                className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-[#04110f] ${otherOnline ? "bg-emerald-400" : "bg-emerald-100/25"}`}
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 min-w-0">
                <h2 className="truncate text-white font-semibold text-[15px] tracking-tight">
                  {other?.display_name || other?.username || "Conversation"}
                </h2>
                {myMuted && <BellOff className="h-3.5 w-3.5 text-emerald-100/40 shrink-0" aria-label="Muted" />}
                {blockedOther && <Badge className="bg-red-500/15 border border-red-400/30 text-red-300 text-[10px] shrink-0">Blocked</Badge>}
              </div>
              <div className="flex items-center gap-2 text-[11px] text-emerald-100/50 truncate">
                <span className="truncate">{listing?.title}</span>
                {listing?.domain && <span className="opacity-40">·</span>}
                {listing?.domain && <span className="truncate">{listing.domain}</span>}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={() => setShowSearch((s) => !s)} className="text-emerald-100/70 hover:bg-white/[0.05] hover:text-white" aria-label="Search in conversation">
              <SearchIcon className="h-4 w-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-emerald-100/70 hover:bg-white/[0.05] hover:text-white" aria-label="Conversation menu">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-[#0a1a17] border-white/10 text-emerald-50">
                <DropdownMenuItem onClick={async () => { await muteFn({ data: { thread_id: threadId, muted: !myMuted } }); invalidate(); }}>
                  {myMuted ? <><Bell className="h-4 w-4 mr-2" /> Unmute thread</> : <><BellOff className="h-4 w-4 mr-2" /> Mute thread</>}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleToggleBlock}>
                  <ShieldAlert className="h-4 w-4 mr-2" /> {blockedOther ? "Unblock user" : "Block user"}
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-white/10" />
                <DropdownMenuItem onClick={() => setReportOpen(true)} className="text-red-300 focus:text-red-200">
                  <Flag className="h-4 w-4 mr-2" /> Report conversation
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Active offer strip */}
        {activeOffer && (
          <button
            onClick={() => setShowOfferPanel(true)}
            className="mx-4 sm:mx-6 mt-3 rounded-xl border border-amber-400/25 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent px-4 py-2.5 flex items-center gap-3 text-left hover:border-amber-400/40 transition"
          >
            <div className="h-8 w-8 rounded-lg bg-amber-500/15 border border-amber-400/25 grid place-items-center shrink-0">
              <DollarSign className="h-4 w-4 text-amber-300" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-white font-semibold text-sm font-mono tabular-nums">
                ${Number(activeOffer.amount_usd ?? 0).toLocaleString()}
                <span className="ml-2 text-[11px] font-sans text-amber-100/70 font-normal">
                  {activeOffer.buyer_id === userId ? "waiting on seller" : "needs your response"}
                </span>
              </div>
            </div>
            <Badge className="bg-amber-400/15 border border-amber-400/30 text-amber-200 text-[10px] capitalize shrink-0">{activeOffer.status}</Badge>
          </button>
        )}

        {/* Search bar */}
        {showSearch && (
          <div className="border-b border-white/5 px-4 sm:px-6 py-3 space-y-2">
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <SearchIcon className="h-3.5 w-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-emerald-100/40" />
                <Input value={searchQ} onChange={(e) => setSearchQ(e.target.value)} placeholder="Search this conversation…"
                  className="pl-9 bg-white/[0.03] border-white/10 text-emerald-50 h-9" autoFocus />
              </div>
              <Button size="icon" variant="ghost" className="text-emerald-100/70 hover:bg-white/[0.05]" onClick={() => { setShowSearch(false); setSearchQ(""); }} aria-label="Close search">
                <X className="h-4 w-4" />
              </Button>
            </div>
            {searchResults.data && searchResults.data.length > 0 && (
              <div className="max-h-40 overflow-y-auto space-y-1">
                {searchResults.data.map((r) => (
                  <button key={r.id} className="w-full text-left rounded-lg px-3 py-2 bg-white/[0.02] hover:bg-white/[0.05] text-xs text-emerald-100/80 transition"
                    onClick={() => {
                      const el = document.getElementById(`msg-${r.id}`);
                      el?.scrollIntoView({ behavior: "smooth", block: "center" });
                      el?.classList.add("ring-2", "ring-emerald-400");
                      setTimeout(() => el?.classList.remove("ring-2", "ring-emerald-400"), 1600);
                    }}>
                    <div className="text-[10px] text-emerald-100/40 mb-0.5">{new Date(r.created_at).toLocaleString()}</div>
                    <div className="truncate">{r.body}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Messages scroller */}
        <div
          ref={scrollRef}
          onScroll={onScroll}
          className="flex-1 overflow-y-auto"
        >
          {isLoading && <MessageSkeletons />}

          {!isLoading && visibleMessages.length === 0 && (
            <div className="h-full grid place-items-center p-8">
              <div className="text-center max-w-sm">
                <div className="mx-auto h-16 w-16 rounded-2xl bg-emerald-500/10 border border-emerald-400/20 grid place-items-center mb-4">
                  <MessageSquare className="h-7 w-7 text-emerald-300" />
                </div>
                <div className="text-white font-medium mb-1">Start the conversation</div>
                <p className="text-sm text-emerald-100/50">Ask about traffic sources, revenue proof, or send an offer to open negotiation.</p>
              </div>
            </div>
          )}

          {!isLoading && dayGroups.map((g) => (
            <div key={g.label} className="px-4 sm:px-6 py-2">
              <div className="flex items-center gap-3 my-3" role="separator" aria-label={g.label}>
                <div className="flex-1 h-px bg-white/5" />
                <span className="text-[10px] uppercase tracking-widest text-emerald-100/40 font-medium">{g.label}</span>
                <div className="flex-1 h-px bg-white/5" />
              </div>

              <div className="space-y-0.5">
                {g.items.map((m, i) => {
                  const mine = m.sender_id === userId;
                  const prev = i > 0 ? g.items[i - 1] : null;
                  const next = i < g.items.length - 1 ? g.items[i + 1] : null;
                  const groupStart = !prev || prev.sender_id !== m.sender_id || (new Date(m.created_at).getTime() - new Date(prev.created_at).getTime()) > 5 * 60 * 1000;
                  const groupEnd = !next || next.sender_id !== m.sender_id || (new Date(next.created_at).getTime() - new Date(m.created_at).getTime()) > 5 * 60 * 1000;

                  const parent = m.reply_to_id ? visibleMessages.find((x) => x.id === m.reply_to_id) as Msg | undefined : undefined;
                  const flags = m.client_flags as { spam_score?: number; reasons?: string[] } | null;
                  const isSpam = !mine && (flags?.spam_score ?? 0) > 0;
                  const reacts = reactionsByMsg.get(m.id) ?? [];
                  const atts = attachByMsg.get(m.id) ?? [];
                  const urls = m.deleted_at ? [] : extractUrls(m.body);
                  const seen = mine && otherLastReadAt && new Date(otherLastReadAt) >= new Date(m.created_at);

                  // Speech-bubble tail: less rounded on sender side, at the last message of the group
                  const shapeMine = groupEnd ? "rounded-2xl rounded-br-md" : "rounded-2xl";
                  const shapeTheirs = groupEnd ? "rounded-2xl rounded-bl-md" : "rounded-2xl";

                  return (
                    <div
                      key={m.id}
                      id={`msg-${m.id}`}
                      className={`group flex gap-2 items-end motion-safe:animate-[fade-in_0.18s_ease-out] ${mine ? "justify-end" : "justify-start"} ${groupStart ? "mt-3" : "mt-0.5"}`}
                    >
                      {!mine && (
                        <div className={`w-8 shrink-0 ${groupEnd ? "opacity-100" : "opacity-0"}`}>
                          <Avatar url={other?.avatar_url} name={other?.display_name} size={28} />
                        </div>
                      )}

                      <div className={`flex flex-col max-w-[78%] sm:max-w-[62%] ${mine ? "items-end" : "items-start"}`}>
                        {groupStart && !mine && (
                          <div className="text-[11px] text-emerald-100/50 mb-1 ml-1">
                            {other?.display_name || other?.username}
                          </div>
                        )}

                        {parent && (
                          <button
                            onClick={() => {
                              const el = document.getElementById(`msg-${parent.id}`);
                              el?.scrollIntoView({ behavior: "smooth", block: "center" });
                            }}
                            className={`text-[11px] rounded-t-xl px-3 py-1.5 border-l-2 max-w-full truncate text-left mb-0.5 ${
                              mine ? "border-emerald-300 bg-emerald-500/10 text-emerald-100/80" : "border-emerald-500/50 bg-white/[0.03] text-emerald-100/60"
                            }`}
                          >
                            <Reply className="inline h-3 w-3 mr-1 -mt-0.5" />
                            {parent.deleted_at ? "message deleted" : parent.body.slice(0, 90)}
                          </button>
                        )}

                        <div
                          className={`relative px-3.5 py-2 text-[14px] leading-snug break-words whitespace-pre-wrap shadow-[0_1px_0_rgba(255,255,255,0.03)_inset] ${shape(mine, shapeMine, shapeTheirs)} ${
                            mine
                              ? "bg-gradient-to-br from-emerald-400 to-emerald-500 text-[#04110f]"
                              : "bg-white/[0.05] border border-white/5 text-emerald-50"
                          }`}
                        >
                          {m.deleted_at ? (
                            <span className="italic opacity-60">message deleted</span>
                          ) : (
                            <div className={`prose prose-sm max-w-none prose-p:my-0 prose-ul:my-1 prose-ol:my-1 prose-a:underline prose-a:underline-offset-2 ${mine ? "prose-invert prose-a:text-[#04110f]/80" : "prose-invert"}`}>
                              <ReactMarkdown allowedElements={["p","strong","em","ul","ol","li","code","a","br"]} unwrapDisallowed>{m.body}</ReactMarkdown>
                            </div>
                          )}
                          {atts.length > 0 && (
                            <div className={`mt-2 space-y-1.5 ${mine ? "" : ""}`}>
                              {atts.map((a) => <Attachment key={a.id} a={a as never} />)}
                            </div>
                          )}
                        </div>

                        {urls.length > 0 && !m.deleted_at && (
                          <div className={`w-full space-y-1 mt-1 ${mine ? "self-end" : "self-start"}`}>
                            {urls.slice(0, 2).map((u) => <LinkPreview key={u} url={u} />)}
                          </div>
                        )}

                        {isSpam && (
                          <div className="mt-1 text-[11px] text-amber-200 bg-amber-500/10 border border-amber-400/25 rounded-md px-2 py-1 max-w-full flex items-start gap-1.5">
                            <Info className="h-3 w-3 mt-0.5 shrink-0" />
                            <span>Looks suspicious ({flags?.reasons?.join(", ")}). Never move payments off-platform.</span>
                          </div>
                        )}

                        {reacts.length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {reacts.map((r) => (
                              <button key={r.emoji} onClick={() => handleReact(m.id, r.emoji)}
                                className={`text-xs rounded-full px-2 py-0.5 border transition ${
                                  r.mine
                                    ? "bg-emerald-400/20 border-emerald-300/50 text-emerald-100"
                                    : "bg-white/[0.05] border-white/10 text-emerald-100/80 hover:bg-white/[0.08]"
                                }`}>
                                {r.emoji} <span className="tabular-nums">{r.count}</span>
                              </button>
                            ))}
                          </div>
                        )}

                        {groupEnd && (
                          <div className={`mt-1 flex items-center gap-1.5 text-[10px] text-emerald-100/40 ${mine ? "self-end" : "self-start"}`}>
                            <span title={new Date(m.created_at).toLocaleString()}>{shortTime(m.created_at)}</span>
                            {m.edited_at && <span title={`Edited ${new Date(m.edited_at).toLocaleString()}`}>· edited</span>}
                            {mine && (seen ? <CheckCheck className="h-3 w-3 text-emerald-400" aria-label="Seen" /> : <Check className="h-3 w-3" aria-label="Sent" />)}
                          </div>
                        )}
                      </div>

                      {mine && <div className="w-0 shrink-0" />}

                      {/* Hover action strip */}
                      {!m.deleted_at && (
                        <div
                          className={`self-center opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition flex items-center gap-0.5 rounded-lg bg-[#0a1a17]/90 border border-white/10 shadow-lg px-1 py-0.5 ${
                            mine ? "order-first mr-1" : "ml-1"
                          }`}
                        >
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost" className="h-6 w-6 text-emerald-100/70 hover:bg-white/[0.06]" aria-label="React">
                                <Smile className="h-3.5 w-3.5" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="bg-[#0a1a17] border-white/10 flex gap-0.5 p-1">
                              {REACTION_EMOJIS.map((e) => (
                                <button key={e} onClick={() => handleReact(m.id, e)} className="text-lg p-1 hover:bg-white/[0.06] rounded">{e}</button>
                              ))}
                            </DropdownMenuContent>
                          </DropdownMenu>
                          <Button size="icon" variant="ghost" className="h-6 w-6 text-emerald-100/70 hover:bg-white/[0.06]" onClick={() => setReplyTo(m)} aria-label="Reply">
                            <Reply className="h-3.5 w-3.5" />
                          </Button>
                          {mine && (
                            <>
                              <Button size="icon" variant="ghost" className="h-6 w-6 text-emerald-100/70 hover:bg-white/[0.06]" onClick={() => { setEditing(m); setBody(m.body); textareaRef.current?.focus(); }} aria-label="Edit">
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                              <Button size="icon" variant="ghost" className="h-6 w-6 text-red-300 hover:bg-red-500/10" onClick={() => handleDelete(m.id)} aria-label="Delete">
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {otherTyping && (
            <div className="px-4 sm:px-6 pb-2 pl-14">
              <TypingBubble name={other?.display_name || other?.username} />
            </div>
          )}
        </div>

        {/* Jump-to-latest */}
        {scrolledUp && (
          <button
            onClick={jumpToLatest}
            className="absolute bottom-40 right-6 h-10 w-10 rounded-full bg-emerald-500 hover:bg-emerald-400 text-[#04110f] shadow-xl grid place-items-center motion-safe:animate-[scale-in_0.15s_ease-out]"
            aria-label="Jump to latest"
          >
            <ArrowDown className="h-4 w-4" />
          </button>
        )}

        {/* Composer */}
        {blockedOther ? (
          <div className="border-t border-white/5 bg-black/30 p-6 text-center">
            <ShieldAlert className="h-5 w-5 text-red-300 mx-auto mb-2" />
            <div className="text-sm text-red-200 mb-2">You've blocked this user.</div>
            <button className="text-xs text-emerald-300 hover:underline" onClick={handleToggleBlock}>Unblock to resume messaging</button>
          </div>
        ) : (
          <div className="border-t border-white/5 bg-black/30 backdrop-blur px-3 sm:px-6 py-3 space-y-2">
            {/* Quick replies row */}
            <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
              <Button size="sm" variant="outline"
                className="h-7 text-[11px] border-emerald-400/30 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/15 shrink-0"
                onClick={() => handleSuggest()}>
                <Sparkles className="h-3 w-3 mr-1" /> Suggest reply
              </Button>
              {QUICK_REPLIES.map((q) => (
                <Button key={q.label} size="sm" variant="ghost"
                  className="h-7 text-[11px] text-emerald-100/60 hover:bg-white/[0.05] hover:text-emerald-100 shrink-0"
                  onClick={() => handleSuggest(q.seed)}>
                  {q.label}
                </Button>
              ))}
              {isBuyer && (
                <Button size="sm" variant="ghost"
                  className="h-7 text-[11px] text-amber-200 hover:bg-amber-500/10 shrink-0 ml-auto"
                  onClick={() => setShowOfferPanel(true)}>
                  <DollarSign className="h-3 w-3 mr-1" /> Make an offer
                </Button>
              )}
            </div>

            {/* Reply / edit / attachment chips */}
            {replyTo && (
              <div className="flex items-center gap-2 rounded-lg bg-white/[0.03] border border-white/5 pl-3 pr-2 py-1.5 text-xs">
                <Reply className="h-3 w-3 text-emerald-300 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] uppercase tracking-wide text-emerald-100/40">Replying to</div>
                  <div className="truncate text-emerald-100/80">{replyTo.body.slice(0, 100)}</div>
                </div>
                <button onClick={() => setReplyTo(null)} className="p-1 hover:bg-white/[0.05] rounded" aria-label="Cancel reply"><X className="h-3 w-3" /></button>
              </div>
            )}
            {editing && (
              <div className="flex items-center gap-2 rounded-lg bg-emerald-500/10 border border-emerald-400/25 pl-3 pr-2 py-1.5 text-xs">
                <Pencil className="h-3 w-3 text-emerald-300 shrink-0" />
                <div className="min-w-0 flex-1 text-emerald-100">Editing your message</div>
                <button onClick={() => { setEditing(null); setBody(""); }} className="p-1 hover:bg-white/[0.05] rounded" aria-label="Cancel edit"><X className="h-3 w-3" /></button>
              </div>
            )}
            {pendingFiles.length > 0 && (
              <div className="flex gap-1.5 flex-wrap">
                {pendingFiles.map((f, i) => (
                  <div key={i} className="flex items-center gap-1.5 rounded-lg bg-white/[0.04] border border-white/5 pl-2 pr-1 py-1 text-[11px]">
                    <ImageIcon className="h-3 w-3 text-emerald-300" />
                    <span className="truncate max-w-[140px] text-emerald-100/85">{f.name}</span>
                    <button onClick={() => setPendingFiles((prev) => prev.filter((_, j) => j !== i))} className="p-0.5 hover:bg-white/[0.06] rounded" aria-label="Remove attachment">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            {showEmoji && (
              <div className="flex gap-0.5 rounded-lg bg-white/[0.03] border border-white/5 p-1.5 flex-wrap">
                {["😀","😂","😍","🤔","👍","🙏","🎉","🔥","💯","🚀","💸","✅","❌","👀","🤝","💎","⚡","🙌"].map((e) => (
                  <button key={e} className="text-lg hover:bg-white/[0.06] rounded p-1" onClick={() => { setBody((b) => b + e); setShowEmoji(false); textareaRef.current?.focus(); }}>{e}</button>
                ))}
              </div>
            )}

            {/* Input pill */}
            <div className="rounded-2xl bg-white/[0.03] border border-white/10 focus-within:border-emerald-400/50 focus-within:bg-white/[0.05] focus-within:shadow-[0_0_0_3px_rgba(52,211,153,0.08)] transition p-1.5 flex items-end gap-1">
              <input ref={fileInputRef} type="file" multiple accept="image/*,.pdf,.txt,.csv,.md,.doc,.docx" className="hidden"
                onChange={(e) => { const fs = Array.from(e.target.files ?? []); setPendingFiles((prev) => [...prev, ...fs].slice(0, 10)); e.target.value = ""; }} />

              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-emerald-100/60 hover:text-emerald-100 hover:bg-white/[0.05] shrink-0" onClick={() => fileInputRef.current?.click()} aria-label="Attach file">
                <Paperclip className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-emerald-100/60 hover:text-emerald-100 hover:bg-white/[0.05] shrink-0" onClick={() => setShowEmoji((s) => !s)} aria-label="Emoji picker">
                <Smile className="h-4 w-4" />
              </Button>
              <Textarea
                ref={textareaRef}
                rows={1}
                placeholder={editing ? "Edit your message…" : "Write a message… (supports **bold**, *italic*)"}
                value={body}
                onChange={(e) => onBodyChange(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                className="flex-1 bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-emerald-50 placeholder:text-emerald-100/30 min-h-[36px] max-h-[200px] py-2 resize-none shadow-none"
              />
              <Button
                onClick={handleSend}
                disabled={!canSend}
                aria-label="Send message"
                className={`h-9 w-9 rounded-xl shrink-0 grid place-items-center transition ${
                  canSend
                    ? "bg-emerald-400 hover:bg-emerald-300 text-[#04110f] shadow-[0_4px_12px_-2px_rgba(52,211,153,0.4)]"
                    : "bg-white/[0.05] text-emerald-100/30 cursor-not-allowed hover:bg-white/[0.05]"
                }`}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <div className="text-[10px] text-emerald-100/30 text-center">
              Press <kbd className="px-1 py-0.5 rounded bg-white/[0.05] text-emerald-100/50">Enter</kbd> to send · <kbd className="px-1 py-0.5 rounded bg-white/[0.05] text-emerald-100/50">Shift + Enter</kbd> for new line
            </div>
          </div>
        )}
      </section>

      {/* Offers side panel */}
      <Dialog open={showOfferPanel} onOpenChange={setShowOfferPanel}>
        <DialogContent className="bg-[#04110f] border-white/10 text-emerald-50 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white">Offers on {listing?.title}</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-emerald-100/50 -mt-2">
            Asking: <span className="text-emerald-200 font-mono tabular-nums">
              {listing?.asking_price_usd != null ? `$${Number(listing.asking_price_usd).toLocaleString()}` : "open"}
            </span>
          </p>

          {isBuyer && (
            <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3 space-y-2">
              <Input type="number" placeholder="Your offer (USD)" value={amount} onChange={(e) => setAmount(e.target.value)}
                className="bg-black/40 border-white/10 text-emerald-50 font-mono tabular-nums" />
              <Textarea rows={2} placeholder="Note (optional)" value={offerNote} onChange={(e) => setOfferNote(e.target.value)}
                className="bg-black/40 border-white/10 text-emerald-50 resize-none" />
              <Button className="w-full bg-emerald-400 hover:bg-emerald-300 text-[#04110f]" onClick={async () => {
                const n = Number(amount); if (!n || n <= 0) return toast.error("Enter a valid amount.");
                try { await makeOffer({ data: { thread_id: threadId, amount_usd: n, message: offerNote || undefined } }); setAmount(""); setOfferNote(""); toast.success("Offer sent."); invalidate(); }
                catch (e) { toast.error(e instanceof Error ? e.message : "Failed."); }
              }}>
                <DollarSign className="h-4 w-4 mr-1" /> Send offer
              </Button>
            </div>
          )}

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {data?.offers.length === 0 ? (
              <p className="text-xs text-emerald-100/50 text-center py-4">No offers yet.</p>
            ) : data?.offers.map((o) => (
              <div key={o.id} className="rounded-xl border border-amber-400/20 bg-gradient-to-br from-amber-500/[0.06] to-transparent p-3">
                <div className="flex items-baseline justify-between mb-1.5">
                  <div className="text-white text-lg font-semibold font-mono tabular-nums tracking-tight">
                    ${Number(o.amount_usd ?? 0).toLocaleString()}
                  </div>
                  <Badge className="bg-amber-400/15 border border-amber-400/30 text-amber-200 text-[10px] capitalize">{o.status}</Badge>
                </div>
                {o.message && <p className="text-xs text-emerald-100/70 mb-2">{o.message}</p>}
                {o.status === "pending" && !isBuyer && (
                  <div className="flex gap-1.5">
                    <Button size="sm" className="bg-emerald-400 hover:bg-emerald-300 text-[#04110f] h-8 text-xs flex-1"
                      onClick={async () => { await respondOffer({ data: { offer_id: o.id, action: "accept" } }); invalidate(); toast.success("Offer accepted"); }}>Accept</Button>
                    <Button size="sm" variant="outline" className="border-white/10 bg-transparent text-emerald-100 h-8 text-xs"
                      onClick={async () => { const c = prompt("Counter amount (USD)?"); if (c) { await respondOffer({ data: { offer_id: o.id, action: "counter", counter_amount: Number(c) } }); invalidate(); } }}>Counter</Button>
                    <Button size="sm" variant="ghost" className="text-red-300 hover:bg-red-500/10 h-8 text-xs"
                      onClick={async () => { await respondOffer({ data: { offer_id: o.id, action: "reject" } }); invalidate(); }}>Reject</Button>
                  </div>
                )}
                {o.status === "pending" && isBuyer && (
                  <Button size="sm" variant="ghost" className="text-red-300 hover:bg-red-500/10 h-8 text-xs w-full"
                    onClick={async () => { await respondOffer({ data: { offer_id: o.id, action: "withdraw" } }); invalidate(); }}>Withdraw</Button>
                )}
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Report dialog */}
      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="bg-[#04110f] border-white/10 text-emerald-50">
          <DialogHeader><DialogTitle className="text-white">Report this conversation</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Reason (e.g. scam, spam, off-platform payment)" value={reportReason} onChange={(e) => setReportReason(e.target.value)} className="bg-black/40 border-white/10" />
            <Textarea placeholder="Details (optional)" rows={4} value={reportDetails} onChange={(e) => setReportDetails(e.target.value)} className="bg-black/40 border-white/10 resize-none" />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setReportOpen(false)}>Cancel</Button>
            <Button className="bg-red-500 hover:bg-red-400 text-white" onClick={submitReport}>Send report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function shape(mine: boolean, m: string, t: string) {
  return mine ? m : t;
}
