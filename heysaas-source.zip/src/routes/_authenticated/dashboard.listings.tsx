import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, ExternalLink, Pencil, Eye, Sparkles, Loader2, MoreHorizontal, Play, Pause, Archive, Rocket } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { promoteListing } from "@/lib/promotions.functions";
import { BackButton } from "@/components/site/BackButton";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";

export const Route = createFileRoute("/_authenticated/dashboard/listings")({
  head: () => ({ meta: [{ title: "My listings — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: MyListings,
});

type Row = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  status: string;
  views: number;
  interested_count: number;
  updated_at: string;
};

const TABS = [
  { id: "all", label: "All" },
  { id: "live", label: "Live" },
  { id: "draft", label: "Drafts" },
  { id: "swapped", label: "Swapped" },
];

function MyListings() {
  const [rows, setRows] = useState<Row[]>([]);
  const [tab, setTab] = useState("all");
  const [loading, setLoading] = useState(true);
  const promote = useServerFn(promoteListing);

  async function onPromote(id: string) {
    try {
      const res = await promote({ data: { listing_id: id } });
      if (res.mode === "stripe" && res.url) { window.location.href = res.url; return; }
      toast.success("Listing promoted for 7 days");
    } catch (e: any) { toast.error(e.message || "Failed"); }
  }

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase
      .from("saas_listings")
      .select("id, slug, name, tagline, status, views, interested_count, updated_at")
      .eq("owner_id", user.id)
      .order("updated_at", { ascending: false });
    setRows((data ?? []) as Row[]);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const filtered = tab === "all" ? rows : rows.filter((r) => (tab === "swapped" ? r.status === "swapped" : tab === "draft" ? r.status === "draft" : r.status === "live"));

  async function setStatus(id: string, status: string) {
    const patch: any = { status };
    
    const { error } = await supabase.from("saas_listings").update(patch).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Updated");
    load();
  }

  async function remove(id: string) {
    if (!confirm("Delete this listing? This cannot be undone.")) return;
    const { error } = await supabase.from("saas_listings").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Deleted");
    load();
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
      <BackButton />
      <DashHero
              signature="listings"
        eyebrow="Your catalog"
        title="My listings."
        description="Every SaaS you've put on the table — live, in drafts, or already swapped. Manage them all from one editorial cockpit."
        actions={
          <Link to="/list">
            <Button className="rounded-full bg-foreground text-background hover:opacity-90 px-5 h-11 shadow-lg shadow-violet/20">
              <Plus className="h-4 w-4 mr-2" />New listing
            </Button>
          </Link>
        }

        meta={
          <div className="hs-seg">
            {TABS.map((t) => {
              const n = t.id === "all" ? rows.length : rows.filter((r) => (t.id === "swapped" ? r.status === "swapped" : t.id === "draft" ? r.status === "draft" : r.status === "live")).length;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`hs-seg-item inline-flex items-center gap-1.5 ${tab === t.id ? "active" : ""}`}
                >
                  {t.label}
                  <span className={`text-[10px] px-1.5 py-[1px] rounded-full ${tab === t.id ? "bg-white/25 text-white" : "bg-foreground/10 text-muted-foreground"}`}>{n}</span>
                </button>
              );
            })}
          </div>
        }
      />
      <DashRibbon variant="listings" />
            <DashBodyBlock variant="listings" />


      <div className="mt-8 px-1">
        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : filtered.length === 0 ? (
          <div className="hs-empty">
            <div className="hs-empty-icon"><Sparkles className="h-7 w-7" /></div>
            <p className="mt-5 font-display text-3xl">Nothing here yet.</p>
            <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">List your first SaaS to open the door to swaps. It takes about 4 minutes and autosaves as you go.</p>
            <Link to="/list"><Button className="mt-6 rounded-full bg-foreground text-background hover:opacity-90 px-6"><Plus className="h-4 w-4 mr-2" />Create listing</Button></Link>
          </div>
        ) : (
          <div className="hs-table-wrap">
            <table className="hs-table w-full text-sm">
              <thead className="bg-surface text-muted-foreground text-xs uppercase tracking-wider">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">Status</th>
                  <th className="text-left px-4 py-3 font-medium">Views</th>
                  <th className="text-left px-4 py-3 font-medium">Interest</th>
                  <th className="text-left px-4 py-3 font-medium">Updated</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.id} className="border-t border-hairline hover:bg-surface/50">
                    <td className="px-4 py-3">
                      <div className="font-medium">{r.name}</div>
                      {r.tagline && <div className="text-xs text-muted-foreground line-clamp-1">{r.tagline}</div>}
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3"><span className="inline-flex items-center gap-1 text-muted-foreground"><Eye className="h-3.5 w-3.5" />{r.views}</span></td>
                    <td className="px-4 py-3"><span className="inline-flex items-center gap-1 text-muted-foreground"><Sparkles className="h-3.5 w-3.5" />{r.interested_count}</span></td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">{new Date(r.updated_at).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-right">
                      <div className="inline-flex items-center gap-1">
                        <Link to="/saas/$slug" params={{ slug: r.slug }}>
                          <Button variant="ghost" size="icon" aria-label="View"><ExternalLink className="h-4 w-4" /></Button>
                        </Link>
                        <Link to="/list" search={{ id: r.id } as any}>
                          <Button variant="ghost" size="icon" aria-label="Edit"><Pencil className="h-4 w-4" /></Button>
                        </Link>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" aria-label="More"><MoreHorizontal className="h-4 w-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {r.status === "draft" && (
                              <DropdownMenuItem onClick={() => setStatus(r.id, "live")}><Play className="h-4 w-4 mr-2" />Publish</DropdownMenuItem>
                            )}
                            {r.status === "live" && (
                              <>
                                <DropdownMenuItem onClick={() => onPromote(r.id)}><Rocket className="h-4 w-4 mr-2" />Promote ($49 / 7 days)</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => setStatus(r.id, "not_open")}><Pause className="h-4 w-4 mr-2" />Set to not open</DropdownMenuItem>
                              </>
                            )}
                            {r.status === "not_open" && (
                              <DropdownMenuItem onClick={() => setStatus(r.id, "live")}><Play className="h-4 w-4 mr-2" />Reopen</DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => remove(r.id)} className="text-destructive"><Archive className="h-4 w-4 mr-2" />Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: string }> = {
    live: { label: "Live", tone: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
    draft: { label: "Draft", tone: "bg-muted text-muted-foreground border-hairline" },
    not_open: { label: "Not open", tone: "bg-muted text-muted-foreground border-hairline" },
    access_paused: { label: "Paused", tone: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
    access_extended: { label: "Extended", tone: "bg-sky-500/15 text-sky-400 border-sky-500/30" },
    swapped: { label: "Swapped", tone: "bg-violet/20 text-violet border-violet/30" },
  };
  const c = map[status] ?? { label: status, tone: "" };
  return <Badge variant="outline" className={`rounded-full ${c.tone}`}>{c.label}</Badge>;
}
