import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Copy, Sparkles, Bug, Zap, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/changelog")({
  head: () => ({ meta: [{ title: "Changelog — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: ChangelogPage,
});

type Kind = "shipped" | "improved" | "fixed" | "security";
type Entry = { id: string; listing_id: string; version: string; kind: Kind; title: string; body: string; date: string };

const kindMeta: Record<Kind, { label: string; icon: any; tone: string }> = {
  shipped: { label: "Shipped", icon: Sparkles, tone: "bg-emerald-500/15 text-emerald-200" },
  improved: { label: "Improved", icon: Zap, tone: "bg-cyan-500/15 text-cyan-200" },
  fixed: { label: "Fixed", icon: Bug, tone: "bg-amber-500/15 text-amber-200" },
  security: { label: "Security", icon: ShieldCheck, tone: "bg-rose-500/15 text-rose-200" },
};

function ChangelogPage() {
  const [uid, setUid] = useState<string | null>(null);
  const [listings, setListings] = useState<{ id: string; name: string }[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [entries, setEntries] = useState<Entry[]>([]);
  const [draft, setDraft] = useState<Partial<Entry>>({ kind: "shipped" });

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUid(user.id);
      const { data } = await supabase.from("saas_listings").select("id, name").eq("owner_id", user.id);
      setListings((data as any) ?? []);
      if (data?.[0]) setSelected(data[0].id);
      try {
        const raw = localStorage.getItem(`hs.changelog.${user.id}`);
        if (raw) setEntries(JSON.parse(raw));
      } catch {}
    })();
  }, []);

  const persist = (next: Entry[]) => {
    setEntries(next);
    if (uid) localStorage.setItem(`hs.changelog.${uid}`, JSON.stringify(next));
  };

  const add = () => {
    if (!selected) { toast.error("Select a listing"); return; }
    if (!draft.title) { toast.error("Title required"); return; }
    const e: Entry = {
      id: crypto.randomUUID(), listing_id: selected,
      version: draft.version ?? "", kind: (draft.kind as Kind) ?? "shipped",
      title: draft.title!, body: draft.body ?? "", date: new Date().toISOString(),
    };
    persist([e, ...entries]);
    setDraft({ kind: "shipped" });
    toast.success("Changelog entry added");
  };

  const remove = (id: string) => persist(entries.filter((e) => e.id !== id));

  const copyMarkdown = () => {
    const list = entries.filter((e) => e.listing_id === selected);
    const md = list.map((e) => `## ${e.version ? `v${e.version} — ` : ""}${e.title}\n_${kindMeta[e.kind].label} · ${new Date(e.date).toLocaleDateString()}_\n\n${e.body}\n`).join("\n");
    navigator.clipboard.writeText(md);
    toast.success("Markdown copied");
  };

  const shown = entries.filter((e) => !selected || e.listing_id === selected);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <div className="hs-noir hs-dash-shell flex-1">
        <div className="hs-dash-canvas" aria-hidden="true">
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--one" />
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--two" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col lg:flex-row gap-8 relative">
          <DashboardSidebar />
          <main id="main" className="flex-1 min-w-0 space-y-6">
            <BackButton />
            <DashHero
              eyebrow="Marketing · Changelog"
              title="Show the world you're shipping."
              description="A living record of what's new. Buyers on Hey SaaS trust products that keep evolving — publish weekly, even small wins."
              signature="overview"
              actions={
                <>
                  <Select value={selected} onValueChange={setSelected}>
                    <SelectTrigger className="h-9 w-56"><SelectValue placeholder="Choose listing" /></SelectTrigger>
                    <SelectContent>{listings.map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" onClick={copyMarkdown}><Copy className="w-4 h-4 mr-2" />Copy as Markdown</Button>
                </>
              }
            />

            <Card className="p-5">
              <h3 className="text-sm font-medium mb-3 flex items-center gap-2"><Plus className="w-4 h-4" /> New entry</h3>
              <div className="grid gap-3 md:grid-cols-3">
                <Input placeholder="Version (e.g. 1.4.0)" value={draft.version ?? ""} onChange={(e) => setDraft({ ...draft, version: e.target.value })} />
                <Select value={draft.kind as string} onValueChange={(v) => setDraft({ ...draft, kind: v as Kind })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.keys(kindMeta).map((k) => <SelectItem key={k} value={k}>{kindMeta[k as Kind].label}</SelectItem>)}</SelectContent>
                </Select>
                <Input placeholder="Title" value={draft.title ?? ""} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
              </div>
              <Textarea className="mt-3" rows={4} placeholder="What changed? Keep it plain and specific." value={draft.body ?? ""} onChange={(e) => setDraft({ ...draft, body: e.target.value })} />
              <div className="mt-3 flex justify-end"><Button onClick={add}><Plus className="w-4 h-4 mr-2" />Publish</Button></div>
            </Card>

            <div className="space-y-4">
              {shown.length === 0 ? (
                <Card className="p-10 text-center text-sm text-muted-foreground">No entries yet. Ship something small and log it.</Card>
              ) : shown.map((e) => {
                const M = kindMeta[e.kind];
                return (
                  <Card key={e.id} className="p-5 relative">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] ${M.tone}`}>
                        <M.icon className="w-3 h-3" /> {M.label}
                      </span>
                      {e.version && <Badge variant="outline" className="text-[10px]">v{e.version}</Badge>}
                      <span className="text-xs text-muted-foreground">{new Date(e.date).toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}</span>
                      <Button variant="ghost" size="icon" aria-label="Delete" className="ml-auto" onClick={() => remove(e.id)}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                    <h3 className="mt-2 font-display text-xl">{e.title}</h3>
                    {e.body && <p className="mt-2 text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">{e.body}</p>}
                  </Card>
                );
              })}
            </div>
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
