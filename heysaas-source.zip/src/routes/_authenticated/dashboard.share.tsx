import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Loader2, Twitter, Linkedin, Mail } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/share")({
  head: () => ({ meta: [{ title: "Share kit — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: ShareKitPage,
});

type Listing = { id: string; name: string; slug: string; tagline: string | null; status: string };

function ShareKitPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Listing | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data } = await supabase.from("saas_listings").select("id, name, slug, tagline, status").eq("owner_id", user.id);
      setListings(data ?? []);
      if (data?.[0]) setSelected(data[0]);
      setLoading(false);
    })();
  }, []);

  const base = typeof window !== "undefined" ? window.location.origin : "";
  const url = selected ? `${base}/l/${selected.slug}` : "";

  const templates = useMemo(() => selected ? {
    twitter: `Just listed ${selected.name} on @heysaas — open to a swap with the right founder.\n\n${selected.tagline ?? "Built with love."}\n\n${url}?utm_source=twitter&utm_medium=social`,
    linkedin: `I'm exploring strategic swap opportunities for ${selected.name}.\n\n${selected.tagline ?? ""}\n\nIf you run a complementary SaaS and want to trade instead of shut down or sell for pennies, take a look:\n${url}?utm_source=linkedin&utm_medium=social`,
    email: `Subject: A quick idea — swap ${selected.name}?\n\nHey there,\n\nI just listed ${selected.name} on Hey SaaS, a marketplace where founders swap products instead of shutting them down.\n\nHere's the listing: ${url}?utm_source=email&utm_medium=direct\n\nWould love your thoughts.\n\n— `,
    changelog: `## Listed on Hey SaaS 🎉\n\nWe've listed ${selected.name} on Hey SaaS — a curated marketplace for founder-to-founder SaaS swaps.\n\nIf you know a founder who might be a good fit, [send them our way](${url}).`,
  } : null, [selected, url]);

  function copy(text: string) { navigator.clipboard.writeText(text); toast.success("Copied"); }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="messages"
              eyebrow="Marketing desk"
              title="Share kit"
              description="Copy-paste posts tuned per channel. Every link is pre-tagged so Analytics attributes the traffic."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : !selected || !templates ? (
              <Card className="p-6 text-sm text-muted-foreground mt-6">Create a listing first to unlock the share kit.</Card>
            ) : (
              <>
                <Card className="p-5 mt-6">
                  <label className="text-sm font-medium">Listing</label>
                  <select
                    value={selected.id}
                    onChange={(e) => setSelected(listings.find((l) => l.id === e.target.value) ?? null)}
                    className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {listings.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                  </select>
                </Card>

                <Template
                  icon={<Twitter className="h-4 w-4" />}
                  title="Twitter / X"
                  text={templates.twitter}
                  onCopy={() => copy(templates.twitter)}
                  actionUrl={`https://twitter.com/intent/tweet?text=${encodeURIComponent(templates.twitter)}`}
                  actionLabel="Open in X"
                />
                <Template
                  icon={<Linkedin className="h-4 w-4" />}
                  title="LinkedIn"
                  text={templates.linkedin}
                  onCopy={() => copy(templates.linkedin)}
                  actionUrl={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`}
                  actionLabel="Open LinkedIn share"
                />
                <Template
                  icon={<Mail className="h-4 w-4" />}
                  title="Warm email"
                  text={templates.email}
                  onCopy={() => copy(templates.email)}
                />
                <Template
                  icon={<span className="text-xs font-mono">MD</span>}
                  title="Changelog / blog snippet"
                  text={templates.changelog}
                  onCopy={() => copy(templates.changelog)}
                />
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Template({ icon, title, text, onCopy, actionUrl, actionLabel }: { icon: React.ReactNode; title: string; text: string; onCopy: () => void; actionUrl?: string; actionLabel?: string }) {
  return (
    <Card className="p-5 mt-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 font-medium">{icon} {title}</div>
        <div className="flex gap-2">
          {actionUrl && <a href={actionUrl} target="_blank" rel="noopener"><Button size="sm" variant="outline">{actionLabel}</Button></a>}
          <Button size="sm" onClick={onCopy}><Copy className="h-3 w-3 mr-1" /> Copy</Button>
        </div>
      </div>
      <Textarea value={text} readOnly rows={6} className="font-mono text-xs" />
    </Card>
  );
}
