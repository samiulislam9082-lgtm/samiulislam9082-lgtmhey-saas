import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { wsAiGenerateDraft, wsCreateListing } from "@/lib/websites.functions";
import { WsSidebar } from "@/components/websites/WebSwapShell";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Loader2, Globe } from "lucide-react";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/websites/dashboard/listings/new")({
  component: NewListingPage,
});

const TECH = ["Next.js", "React", "Vue", "WordPress", "Shopify", "Webflow", "Ghost", "Rails", "Laravel", "Django", "Astro", "Node.js"];

function NewListingPage() {
  const navigate = useNavigate();
  const genDraft = useServerFn(wsAiGenerateDraft);
  const create = useServerFn(wsCreateListing);

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [aiLoading, setAiLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [websiteUrl, setWebsiteUrl] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [niche, setNiche] = useState("");
  const [listingType, setListingType] = useState<"for_sale" | "open_to_swap" | "open_to_both">("for_sale");
  const [askingPrice, setAskingPrice] = useState("");
  const [monthlyRevenue, setMonthlyRevenue] = useState("");
  const [monthlyTraffic, setMonthlyTraffic] = useState("");
  const [siteAgeMonths, setSiteAgeMonths] = useState("");
  const [reason, setReason] = useState("");
  const [tech, setTech] = useState<string[]>([]);
  const [assets, setAssets] = useState({ domain: true, code: true, socials: false, email_list: false });
  const [screenshots, setScreenshots] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [aiDraftUsed, setAiDraftUsed] = useState(false);

  async function runAi() {
    if (!websiteUrl.trim()) return toast.error("Enter your website URL first.");
    setAiLoading(true);
    try {
      const draft = await genDraft({ data: { url: websiteUrl.trim() } });
      setTitle(draft.title);
      setDescription(`${draft.description}\n\n---\nBusiness overview:\n${draft.business_overview}\n\nHighlights:\n${draft.feature_summary.map((f) => `• ${f}`).join("\n")}`);
      if (!niche) setNiche(draft.suggested_niche);
      if (tech.length === 0) setTech(draft.suggested_tech_stack.filter((t) => TECH.includes(t) || t.length < 30));
      setAiDraftUsed(true);
      toast.success("AI draft ready — review and edit before publishing.");
      setStep(2);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "AI draft failed.");
    } finally {
      setAiLoading(false);
    }
  }

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      const { data: session } = await supabase.auth.getUser();
      const uid = session.user?.id;
      if (!uid) throw new Error("Sign in to upload.");
      const uploaded: string[] = [];
      for (const file of Array.from(files).slice(0, 6 - screenshots.length)) {
        const path = `${uid}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
        const { error } = await supabase.storage.from("ws-listing-screenshots").upload(path, file, { upsert: false });
        if (error) throw error;
        const { data } = supabase.storage.from("ws-listing-screenshots").getPublicUrl(path);
        uploaded.push(data.publicUrl);
      }
      setScreenshots((prev) => [...prev, ...uploaded]);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  async function submit() {
    if (!title.trim() || !websiteUrl.trim()) {
      toast.error("Title and website URL are required.");
      return;
    }
    setSaving(true);
    try {
      const r = await create({
        data: {
          website_url: websiteUrl.trim(),
          title: title.trim(),
          description: description.trim() || null,
          niche: niche.trim() || null,
          listing_type: listingType,
          asking_price_usd: askingPrice ? Number(askingPrice) : null,
          monthly_revenue_usd: monthlyRevenue ? Number(monthlyRevenue) : null,
          monthly_traffic: monthlyTraffic ? Number(monthlyTraffic) : null,
          site_age_months: siteAgeMonths ? Number(siteAgeMonths) : null,
          tech_stack: tech,
          reason_for_selling: reason.trim() || null,
          included_assets: assets,
          screenshots,
        },
      });
      toast.success("Draft created — now verify domain ownership to publish.");
      navigate({ to: "/websites/dashboard/listings/$id", params: { id: r.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create listing.");
    } finally {
      setSaving(false);
    }
  }

  const stepLabels = ["Website URL", "Details", "Screenshots"] as const;
  const titleError = step === 2 && !title.trim() ? "Give your listing a clear title (e.g. \"Growing Newsletter SaaS in the productivity niche\")." : "";

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 pb-24 flex gap-8">
      <WsSidebar />
      <div className="flex-1 min-w-0 max-w-3xl">
        <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">List a website</h1>
        <p className="text-emerald-100/60 text-sm mb-6">
          Step {step} of 3 · <span className="text-emerald-200">{stepLabels[step - 1]}</span>
        </p>

        {/* Step indicator */}
        <ol className="mb-6 grid grid-cols-3 gap-2">
          {stepLabels.map((label, i) => {
            const n = (i + 1) as 1 | 2 | 3;
            const done = step > n;
            const active = step === n;
            return (
              <li key={label} className="flex items-center gap-2">
                <span
                  className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold shrink-0 border ${
                    done
                      ? "bg-emerald-500 text-black border-emerald-400"
                      : active
                      ? "bg-emerald-500/20 text-emerald-200 border-emerald-400"
                      : "bg-emerald-950/50 text-emerald-100/50 border-emerald-900/60"
                  }`}
                >
                  {done ? "✓" : n}
                </span>
                <div className="min-w-0 flex-1">
                  <div className={`text-xs uppercase tracking-wider ${active ? "text-emerald-300" : "text-emerald-100/50"}`}>Step {n}</div>
                  <div className={`text-sm font-medium truncate ${active || done ? "text-white" : "text-emerald-100/60"}`}>{label}</div>
                  <div className={`mt-1 h-0.5 rounded-full ${done ? "bg-emerald-500" : active ? "bg-emerald-500/50" : "bg-emerald-900/60"}`} />
                </div>
              </li>
            );
          })}
        </ol>


        {step === 1 && (
          <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-6 space-y-5">
            <div>
              <Label className="text-emerald-100">Website URL *</Label>
              <div className="mt-1.5 flex gap-2">
                <Input
                  placeholder="https://yoursite.com"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  className="bg-black/40 border-emerald-900/60 text-emerald-50"
                />
              </div>
              <p className="text-xs text-emerald-100/50 mt-1.5">You'll need to verify ownership via a DNS TXT record before publishing.</p>
            </div>

            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
              <div className="flex items-start gap-3">
                <Sparkles className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="text-white font-medium">Let AI draft it for you</div>
                  <p className="text-xs text-emerald-100/60 mt-1">Paste your URL — we'll fetch the site and draft a title, description, and stack suggestions. You review and edit everything before publishing.</p>
                </div>
              </div>
              <Button onClick={runAi} disabled={aiLoading || !websiteUrl.trim()} className="mt-4 bg-emerald-500 hover:bg-emerald-400 text-black w-full">
                {aiLoading ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Generating…</> : <><Sparkles className="h-4 w-4 mr-2" /> Generate AI draft</>}
              </Button>
            </div>

            <div className="flex justify-between pt-2">
              <div />
              <Button variant="outline" className="border-emerald-900/60 bg-transparent text-emerald-100" onClick={() => { if (!websiteUrl.trim()) return toast.error("Enter a URL."); setStep(2); }}>
                Skip AI, fill manually →
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-6 space-y-5">
            {aiDraftUsed && (
              <div className="rounded-xl border-2 border-dashed border-emerald-400/50 bg-emerald-500/5 p-4">
                <div className="flex items-start gap-2 text-emerald-200">
                  <Sparkles className="h-4 w-4 shrink-0 mt-0.5 text-emerald-300" />
                  <div className="text-xs leading-relaxed">
                    <span className="font-semibold text-emerald-100">AI-generated draft.</span>{" "}
                    Review and edit every field below — nothing publishes until you approve and verify ownership.
                  </div>
                </div>
              </div>
            )}
            <Field label="Title *" error={titleError}>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} className={`bg-black/40 text-emerald-50 ${titleError ? "border-red-500/60 focus-visible:ring-red-500/40" : "border-emerald-900/60"}`} />
            </Field>
            <Field label="Description">
              <Textarea rows={8} value={description} onChange={(e) => setDescription(e.target.value)} className="bg-black/40 border-emerald-900/60 text-emerald-50" />
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Niche / category"><Input value={niche} onChange={(e) => setNiche(e.target.value)} placeholder="e.g. SaaS, e-commerce" className="bg-black/40 border-emerald-900/60 text-emerald-50" /></Field>
              <Field label="Listing type">
                <Select value={listingType} onValueChange={(v) => setListingType(v as typeof listingType)}>
                  <SelectTrigger className="bg-black/40 border-emerald-900/60 text-emerald-50"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="for_sale">For sale</SelectItem>
                    <SelectItem value="open_to_swap">Open to swap</SelectItem>
                    <SelectItem value="open_to_both">Sale or swap</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Asking price (USD)"><Input type="number" value={askingPrice} onChange={(e) => setAskingPrice(e.target.value)} className="bg-black/40 border-emerald-900/60 text-emerald-50" /></Field>
              <Field label="Site age (months)"><Input type="number" value={siteAgeMonths} onChange={(e) => setSiteAgeMonths(e.target.value)} className="bg-black/40 border-emerald-900/60 text-emerald-50" /></Field>
              <Field label="Monthly revenue (USD, self-reported)"><Input type="number" value={monthlyRevenue} onChange={(e) => setMonthlyRevenue(e.target.value)} className="bg-black/40 border-emerald-900/60 text-emerald-50" /></Field>
              <Field label="Monthly traffic (self-reported)"><Input type="number" value={monthlyTraffic} onChange={(e) => setMonthlyTraffic(e.target.value)} className="bg-black/40 border-emerald-900/60 text-emerald-50" /></Field>
            </div>

            <div>
              <Label className="text-emerald-100">Tech stack</Label>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {TECH.map((t) => {
                  const active = tech.includes(t);
                  return (
                    <button key={t} type="button" onClick={() => setTech((p) => (p.includes(t) ? p.filter((x) => x !== t) : [...p, t]))}
                      className={`text-xs px-2.5 py-1 rounded-full border transition ${active ? "bg-emerald-500/20 border-emerald-400 text-emerald-200" : "border-emerald-900/60 text-emerald-100/70 hover:border-emerald-500/40"}`}>
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>

            <Field label="Reason for selling"><Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} className="bg-black/40 border-emerald-900/60 text-emerald-50" /></Field>

            <div>
              <Label className="text-emerald-100">Included assets</Label>
              <div className="mt-2 grid grid-cols-2 gap-2 text-sm text-emerald-100">
                {(Object.keys(assets) as Array<keyof typeof assets>).map((k) => (
                  <label key={k} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox checked={assets[k]} onCheckedChange={(v) => setAssets((a) => ({ ...a, [k]: !!v }))} />
                    <span className="capitalize">{k.replace("_", " ")}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex justify-between pt-3">
              <Button variant="outline" className="border-emerald-900/60 bg-transparent text-emerald-100" onClick={() => setStep(1)}>← Back</Button>
              <Button className="bg-emerald-500 hover:bg-emerald-400 text-black" onClick={() => setStep(3)}>Next: screenshots →</Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-6 space-y-5">
            <Label className="text-emerald-100">Screenshots (up to 6)</Label>
            <div className="grid grid-cols-3 gap-3">
              {screenshots.map((s, i) => (
                <div key={s} className="relative rounded-lg overflow-hidden aspect-video border border-emerald-900/60">
                  <img src={s} alt="" className="h-full w-full object-cover" />
                  <button className="absolute top-1 right-1 bg-black/70 rounded-full h-6 w-6 text-white text-xs" onClick={() => setScreenshots((p) => p.filter((_, ix) => ix !== i))}>×</button>
                </div>
              ))}
              {screenshots.length < 6 && (
                <label className="aspect-video rounded-lg border border-dashed border-emerald-900/60 flex flex-col items-center justify-center text-emerald-100/60 text-xs cursor-pointer hover:border-emerald-500/50">
                  {uploading ? <Loader2 className="h-5 w-5 animate-spin text-emerald-400" /> : <><Globe className="h-5 w-5 text-emerald-500/60 mb-1" />Add image</>}
                  <input type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} disabled={uploading} />
                </label>
              )}
            </div>
            <div className="flex justify-between pt-3">
              <Button variant="outline" className="border-emerald-900/60 bg-transparent text-emerald-100" onClick={() => setStep(2)}>← Back</Button>
              <Button className="bg-emerald-500 hover:bg-emerald-400 text-black" onClick={submit} disabled={saving}>
                {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving…</> : "Create draft"}
              </Button>
            </div>
            <p className="text-xs text-emerald-100/50 pt-2">
              Creates a draft. You'll be taken to the domain-verification step next — your listing goes public only after ownership is verified.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <Label className="text-emerald-100">{label}</Label>
      <div className="mt-1.5">{children}</div>
      {error && <p className="mt-1.5 text-xs text-red-400">{error}</p>}
    </div>
  );
}

