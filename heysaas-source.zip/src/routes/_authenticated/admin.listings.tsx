import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { moderateListing } from "@/lib/admin.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/listings")({
  component: ListingsAdmin,
});

function ListingsAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const moderate = useServerFn(moderateListing);
  async function load() {
    let query = supabase.from("saas_listings").select("id, name, slug, status, owner_id, created_at").order("created_at", { ascending: false }).limit(100);
    if (q) query = query.ilike("name", `%${q}%`);
    const { data } = await query;
    setItems(data || []);
  }
  useEffect(() => { load(); }, [q]);
  async function act(id: string, action: "archive" | "restore") {
    try { await moderate({ data: { listing_id: id, action } }); toast.success("Updated"); load(); } catch (e: any) { toast.error(e.message); }
  }
  return (
    <div>
      <h1 className="font-display text-4xl mb-6">Listings</h1>
      <Input placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-4 max-w-md" />
      <div className="space-y-2">
        {items.map((l) => (
          <Card key={l.id} className="p-4 flex items-center justify-between">
            <div>
              <div className="font-medium">{l.name}</div>
              <div className="text-xs text-muted-foreground">/{l.slug}</div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline">{l.status}</Badge>
              {l.status === "archived" ? (
                <Button size="sm" onClick={() => act(l.id, "restore")}>Restore</Button>
              ) : (
                <Button size="sm" variant="outline" onClick={() => act(l.id, "archive")}>Archive</Button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
