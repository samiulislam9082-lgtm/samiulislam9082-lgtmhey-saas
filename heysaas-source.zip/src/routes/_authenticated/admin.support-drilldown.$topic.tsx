import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Search, X, Link2, Check, ChevronDown, GitCompare, Bookmark, Star, Trash2, Plus } from "lucide-react";
import { toast } from "sonner";


type SearchState = {
  range: RangeKey;
  from?: string;
  to?: string;
  q?: string;
  ev?: string;
  err?: 1;
  ec?: string; // comma-separated error codes
};


export const Route = createFileRoute("/_authenticated/admin/support-drilldown/$topic")({
  head: ({ params }) => ({ meta: [{ title: `Topic drilldown: ${params.topic} — Admin` }, { name: "robots", content: "noindex" }] }),
  validateSearch: (raw: Record<string, unknown>): SearchState => {
    const range = (["1h","24h","7d","30d","custom"] as const).includes(raw.range as RangeKey)
      ? (raw.range as RangeKey) : "7d";
    const s: SearchState = { range };
    if (typeof raw.from === "string") s.from = raw.from;
    if (typeof raw.to === "string") s.to = raw.to;
    if (typeof raw.q === "string" && raw.q) s.q = raw.q;
    if (typeof raw.ev === "string" && raw.ev && raw.ev !== "all") s.ev = raw.ev;
    if (raw.err === 1 || raw.err === "1" || raw.err === true) s.err = 1;
    if (typeof raw.ec === "string" && raw.ec) s.ec = raw.ec;
    return s;
  },

  component: TopicDrilldown,
});


type Ev = {
  id: string;
  event_type: string;
  error_code: string | null;
  status: number | null;
  created_at: string;
  session_id: string;
  message: string | null;
};

type RangeKey = "1h" | "24h" | "7d" | "30d" | "custom";

const RANGE_HOURS: Record<Exclude<RangeKey, "custom">, number> = {
  "1h": 1,
  "24h": 24,
  "7d": 24 * 7,
  "30d": 24 * 30,
};

function toLocalInput(d: Date) {
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60_000).toISOString().slice(0, 16);
}

function TopicDrilldown() {
  const { topic } = Route.useParams();
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const setSearch = (patch: Partial<SearchState>) =>
    navigate({ search: ((prev: SearchState) => {
      const next: SearchState = { ...prev, ...patch };
      if (!next.q) delete next.q;
      if (!next.ev || next.ev === "all") delete next.ev;
      if (!next.err) delete next.err;
      if (!next.ec) delete next.ec;
      if (next.range !== "custom") { delete next.from; delete next.to; }
      return next;
    }) as never, replace: true });


  const range = search.range;
  const customFrom = search.from ?? toLocalInput(new Date(Date.now() - 7 * 86400_000));
  const customTo = search.to ?? toLocalInput(new Date());
  const query = search.q ?? "";
  const eventFilter = search.ev ?? "all";
  const errorsOnly = !!search.err;
  const selectedCodes = useMemo<Set<string>>(
    () => new Set((search.ec ?? "").split(",").map((s: string) => s.trim()).filter((s: string) => s.length > 0)),
    [search.ec]
  );


  const toggleCode = (code: string) => {
    const next = new Set(selectedCodes);
    if (next.has(code)) next.delete(code); else next.add(code);
    setSearch({ ec: next.size ? Array.from(next).join(",") : undefined });
  };
  const [events, setEvents] = useState<Ev[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [codeOpen, setCodeOpen] = useState(false);
  const codeRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!codeOpen) return;
    const onDoc = (e: MouseEvent) => {
      if (!codeRef.current?.contains(e.target as Node)) setCodeOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [codeOpen]);

  // ---- Saved filter presets (per topic, localStorage) ----
  type Preset = { id: string; name: string; state: SearchState; createdAt: number };
  const presetsKey = `heysaas.drilldown.presets.${topic}`;
  const defaultKey = `heysaas.drilldown.defaultPreset.${topic}`;
  const [presets, setPresets] = useState<Preset[]>([]);
  const [defaultId, setDefaultId] = useState<string | null>(null);
  const [presetsOpen, setPresetsOpen] = useState(false);
  const presetsRef = useRef<HTMLDivElement | null>(null);
  const bootRef = useRef(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(presetsKey);
      const list: Preset[] = raw ? JSON.parse(raw) : [];
      setPresets(Array.isArray(list) ? list : []);
      setDefaultId(localStorage.getItem(defaultKey));
    } catch { /* ignore */ }
  }, [presetsKey, defaultKey]);

  // Auto-apply default preset on first mount if URL has no explicit filters
  useEffect(() => {
    if (bootRef.current) return;
    bootRef.current = true;
    const isPristine = search.range === "7d" && !search.q && !search.ev && !search.err && !search.ec && !search.from && !search.to;
    if (!isPristine) return;
    const id = localStorage.getItem(defaultKey);
    if (!id) return;
    try {
      const raw = localStorage.getItem(presetsKey);
      const list: Preset[] = raw ? JSON.parse(raw) : [];
      const p = list.find(x => x.id === id);
      if (p) navigate({ search: p.state as never, replace: true });
    } catch { /* ignore */ }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!presetsOpen) return;
    const onDoc = (e: MouseEvent) => {
      if (!presetsRef.current?.contains(e.target as Node)) setPresetsOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [presetsOpen]);

  const persistPresets = (list: Preset[]) => {
    setPresets(list);
    try { localStorage.setItem(presetsKey, JSON.stringify(list)); } catch { /* ignore */ }
  };
  const saveCurrentAsPreset = () => {
    const name = window.prompt("Preset name")?.trim();
    if (!name) return;
    const snapshot: SearchState = { range };
    if (search.from) snapshot.from = search.from;
    if (search.to) snapshot.to = search.to;
    if (search.q) snapshot.q = search.q;
    if (search.ev) snapshot.ev = search.ev;
    if (search.err) snapshot.err = 1;
    if (search.ec) snapshot.ec = search.ec;
    const p: Preset = { id: crypto.randomUUID(), name, state: snapshot, createdAt: Date.now() };
    persistPresets([p, ...presets]);
    toast.success(`Saved preset "${name}"`);
  };
  const applyPreset = (p: Preset) => {
    navigate({ search: p.state as never, replace: true });
    setPresetsOpen(false);
    toast.success(`Applied "${p.name}"`);
  };
  const deletePreset = (id: string) => {
    persistPresets(presets.filter(p => p.id !== id));
    if (defaultId === id) {
      setDefaultId(null);
      try { localStorage.removeItem(defaultKey); } catch { /* ignore */ }
    }
  };
  const toggleDefault = (id: string) => {
    const next = defaultId === id ? null : id;
    setDefaultId(next);
    try {
      if (next) localStorage.setItem(defaultKey, next);
      else localStorage.removeItem(defaultKey);
    } catch { /* ignore */ }
    toast.success(next ? "Default preset set" : "Default cleared");
  };



  type Rule = { id: string; pattern: string; priority: number; active: boolean };
  const [rules, setRules] = useState<Rule[]>([]);
  useEffect(() => {
    supabase.from("support_topic_rules")
      .select("id, pattern, priority, active")
      .eq("topic_slug", topic)
      .eq("active", true)
      .order("priority", { ascending: false })
      .then(({ data }) => setRules((data as Rule[]) ?? []));
  }, [topic]);

  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);
  const toggleCompare = (id: string) => {
    setCompareIds(prev => {
      if (prev.includes(id)) return prev.filter(x => x !== id);
      if (prev.length >= 2) {
        toast.message("Two events already selected", { description: "Deselect one to pick another." });
        return prev;
      }
      return [...prev, id];
    });
  };

  const { fromISO, toISO, bucketMs, buckets } = useMemo(() => {
    let from: Date;
    let to: Date;

    if (range === "custom") {
      from = new Date(customFrom);
      to = new Date(customTo);
      if (!(from instanceof Date) || isNaN(from.getTime())) from = new Date(Date.now() - 7 * 86400_000);
      if (!(to instanceof Date) || isNaN(to.getTime())) to = new Date();
      if (to <= from) to = new Date(from.getTime() + 3600_000);
    } else {
      to = new Date();
      from = new Date(to.getTime() - RANGE_HOURS[range as Exclude<RangeKey, "custom">] * 3600_000);
    }

    const spanH = (to.getTime() - from.getTime()) / 3600_000;
    // Choose bucket size for ~24-40 bars
    const bucketMs = spanH <= 2 ? 5 * 60_000 : spanH <= 24 ? 3600_000 : spanH <= 24 * 3 ? 3 * 3600_000 : 86400_000;
    const start = Math.floor(from.getTime() / bucketMs) * bucketMs;
    const end = Math.ceil(to.getTime() / bucketMs) * bucketMs;
    const buckets: string[] = [];
    for (let t = start; t < end; t += bucketMs) buckets.push(new Date(t).toISOString());
    return { fromISO: from.toISOString(), toISO: to.toISOString(), bucketMs, buckets };
  }, [range, customFrom, customTo]);

  useEffect(() => {
    setLoading(true);
    supabase.from("support_chat_events")
      .select("id, event_type, error_code, status, created_at, session_id, message")
      .eq("topic", topic)
      .gte("created_at", fromISO)
      .lte("created_at", toISO)
      .order("created_at", { ascending: false })
      .limit(5000)
      .then(({ data }) => { setEvents((data as Ev[]) ?? []); setLoading(false); });
  }, [topic, fromISO, toISO]);

  const eventTypes = useMemo(() => {
    const s = new Set<string>();
    for (const e of events) s.add(e.event_type);
    return Array.from(s).sort();
  }, [events]);

  const availableCodes = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const e of events) {
      if (e.event_type !== "chat_error") continue;
      const k = e.error_code ?? "unknown";
      counts[k] = (counts[k] ?? 0) + 1;
    }
    return Object.entries(counts).sort((a,b) => b[1]-a[1]);
  }, [events]);

  const filteredEvents = useMemo(() => {
    const q = query.trim().toLowerCase();
    const hasCodes = selectedCodes.size > 0;
    return events.filter(e => {
      if (errorsOnly && e.event_type !== "chat_error") return false;
      if (eventFilter !== "all" && e.event_type !== eventFilter) return false;
      if (hasCodes) {
        // Only keep chat_error rows whose code is selected; drop non-error rows.
        if (e.event_type !== "chat_error") return false;
        if (!selectedCodes.has(e.error_code ?? "unknown")) return false;
      }
      if (!q) return true;
      return (
        (e.message ?? "").toLowerCase().includes(q) ||
        (e.error_code ?? "").toLowerCase().includes(q) ||
        e.event_type.toLowerCase().includes(q) ||
        e.session_id.toLowerCase().includes(q)
      );
    });
  }, [events, query, eventFilter, errorsOnly, selectedCodes]);

  const sessionIndex = useMemo(() => {
    // For each event id, its position in its session's chronological order within loaded window.
    const bySession: Record<string, Ev[]> = {};
    for (const e of [...events].sort((a,b)=>a.created_at.localeCompare(b.created_at))) {
      (bySession[e.session_id] ??= []).push(e);
    }
    const map: Record<string, { idx: number; total: number; prevAt: string | null }> = {};
    for (const sid of Object.keys(bySession)) {
      const arr = bySession[sid];
      arr.forEach((e, i) => {
        map[e.id] = { idx: i + 1, total: arr.length, prevAt: i > 0 ? arr[i-1].created_at : null };
      });
    }
    return map;
  }, [events]);

  const matchRules = (e: Ev): Rule[] => {
    const hay = `${e.event_type} ${e.error_code ?? ""} ${e.message ?? ""}`.toLowerCase();
    return rules.filter(r => {
      const p = r.pattern.trim();
      if (!p) return false;
      try {
        const rx = new RegExp(p, "i");
        return rx.test(hay);
      } catch {
        return hay.includes(p.toLowerCase());
      }
    });
  };

  const metricsFor = (e: Ev) => {
    const si = sessionIndex[e.id];
    const prevMs = si?.prevAt ? new Date(e.created_at).getTime() - new Date(si.prevAt).getTime() : null;
    return {
      is_error: e.event_type === "chat_error",
      is_message: ["message_sent","quick_reply_clicked","faq_ask_ai"].includes(e.event_type),
      is_escalation: ["escalation_started","follow_up_requested"].includes(e.event_type),
      is_ticket: e.event_type === "ticket_submitted",
      session_event_index: si ? `${si.idx} / ${si.total}` : "—",
      time_since_prev_in_session_ms: prevMs,
      message_length: e.message?.length ?? 0,
      bucket: new Date(Math.floor(new Date(e.created_at).getTime() / bucketMs) * bucketMs).toISOString(),
      status_class: e.status == null ? "—" : `${Math.floor(e.status / 100)}xx`,
    };
  };

  const stats = useMemo(() => {
    const sessions = new Set(filteredEvents.map(e => e.session_id));

    const messages = filteredEvents.filter(e => ["message_sent","quick_reply_clicked","faq_ask_ai"].includes(e.event_type)).length;
    const errors = filteredEvents.filter(e => e.event_type === "chat_error");
    const escalated = filteredEvents.filter(e => e.event_type === "escalation_started").length;
    const tickets = filteredEvents.filter(e => e.event_type === "ticket_submitted").length;
    const followUps = filteredEvents.filter(e => e.event_type === "follow_up_requested").length;

    const errBreakdown: Record<string, number> = {};
    for (const e of errors) errBreakdown[e.error_code ?? "unknown"] = (errBreakdown[e.error_code ?? "unknown"] ?? 0) + 1;

    const bmap: Record<string, { messages: number; errors: number; tickets: number; escalations: number }> = {};
    for (const iso of buckets) bmap[iso] = { messages: 0, errors: 0, tickets: 0, escalations: 0 };
    for (const e of filteredEvents) {
      const t = new Date(e.created_at).getTime();
      const key = new Date(Math.floor(t / bucketMs) * bucketMs).toISOString();
      if (!bmap[key]) continue;
      if (["message_sent","quick_reply_clicked","faq_ask_ai"].includes(e.event_type)) bmap[key].messages++;
      if (e.event_type === "chat_error") bmap[key].errors++;
      if (e.event_type === "ticket_submitted") bmap[key].tickets++;
      if (["escalation_started","follow_up_requested"].includes(e.event_type)) bmap[key].escalations++;
    }
    const timeline = Object.entries(bmap).sort((a,b) => a[0].localeCompare(b[0]));
    const totalEsc = escalated + followUps;

    return { sessions: sessions.size, messages, errors: errors.length, escalated, tickets, followUps, errBreakdown, timeline,
      totalEsc,
      escalationRate: messages ? totalEsc / messages : 0,
      ticketRate: totalEsc ? tickets / totalEsc : 0,
      ticketPerMessage: messages ? tickets / messages : 0,
    };
  }, [filteredEvents, buckets, bucketMs]);

  const maxMsgs = Math.max(1, ...stats.timeline.map(([,v]) => v.messages));
  const dayBucket = bucketMs >= 86400_000;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <Link to="/admin/support" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"><ArrowLeft className="h-3 w-3"/> Back to analytics</Link>
          <h1 className="text-2xl font-serif tracking-tight capitalize mt-1">{topic.replace(/_/g," ")}</h1>
          <p className="text-sm text-muted-foreground">Deep dive into events, errors, and escalations for this topic.</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="inline-flex rounded-full border border-hairline p-1 flex-wrap">
            {(["1h","24h","7d","30d","custom"] as RangeKey[]).map(d => (
              <button key={d} onClick={()=>setSearch({ range: d })} className={`px-3 py-1 text-xs rounded-full ${range===d?"bg-secondary":"text-muted-foreground"}`}>{d==="custom"?"Custom":d}</button>
            ))}
          </div>
          <div className="relative" ref={presetsRef}>
            <button
              type="button"
              onClick={()=>setPresetsOpen(o=>!o)}
              className="inline-flex items-center gap-1.5 rounded-full border border-hairline px-3 py-1 text-xs hover:bg-secondary"
              title="Saved filter presets"
            >
              <Bookmark className="h-3 w-3"/> Presets
              {presets.length > 0 && (
                <span className="rounded-full bg-secondary px-1.5 text-[10px]">{presets.length}</span>
              )}
              <ChevronDown className="h-3 w-3 opacity-60"/>
            </button>
            {presetsOpen && (
              <div className="absolute right-0 z-30 mt-1 w-72 rounded-md border border-hairline bg-surface shadow-lg p-2">
                <button
                  onClick={saveCurrentAsPreset}
                  className="w-full inline-flex items-center gap-1.5 rounded-md border border-hairline px-2 py-1.5 text-xs hover:bg-secondary mb-1"
                >
                  <Plus className="h-3 w-3"/> Save current filters
                </button>
                {presets.length === 0 ? (
                  <div className="px-2 py-3 text-[11px] text-muted-foreground text-center">
                    No presets yet. Save your current filters to reuse later.
                  </div>
                ) : (
                  <div className="max-h-72 overflow-auto divide-y divide-hairline">
                    {presets.map(p => {
                      const s = p.state;
                      const bits: string[] = [s.range];
                      if (s.q) bits.push(`"${s.q}"`);
                      if (s.ev) bits.push(s.ev);
                      if (s.err) bits.push("errors");
                      if (s.ec) bits.push(`${s.ec.split(",").length} codes`);
                      return (
                        <div key={p.id} className="flex items-center gap-1 py-1">
                          <button
                            onClick={()=>applyPreset(p)}
                            className="flex-1 text-left rounded px-2 py-1 hover:bg-background"
                            title="Apply preset"
                          >
                            <div className="text-xs truncate">{p.name}</div>
                            <div className="text-[10px] text-muted-foreground truncate">{bits.join(" · ")}</div>
                          </button>
                          <button
                            onClick={()=>toggleDefault(p.id)}
                            className={`p-1 rounded hover:bg-background ${defaultId===p.id ? "text-amber-500" : "text-muted-foreground"}`}
                            title={defaultId===p.id ? "Default preset (click to unset)" : "Set as default"}
                          >
                            <Star className={`h-3.5 w-3.5 ${defaultId===p.id ? "fill-current" : ""}`}/>
                          </button>
                          <button
                            onClick={()=>deletePreset(p.id)}
                            className="p-1 rounded text-muted-foreground hover:text-rose-500 hover:bg-background"
                            title="Delete preset"
                          >
                            <Trash2 className="h-3.5 w-3.5"/>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
          <button
            onClick={async () => {
              await navigator.clipboard.writeText(window.location.href);
              setCopied(true);
              toast.success("Link copied — filters preserved");
              setTimeout(() => setCopied(false), 1500);
            }}
            className="inline-flex items-center gap-1.5 rounded-full border border-hairline px-3 py-1 text-xs hover:bg-secondary"
            title="Copy shareable URL with current filters"
          >
            {copied ? <Check className="h-3 w-3"/> : <Link2 className="h-3 w-3"/>}
            {copied ? "Copied" : "Copy link"}
          </button>

        </div>
      </div>

      <div className="rounded-2xl border border-hairline bg-surface p-4 space-y-3">
        {range === "custom" && (
          <div className="flex flex-wrap items-end gap-3">
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-muted-foreground">From</span>
              <input type="datetime-local" value={customFrom} onChange={e=>setSearch({ from: e.target.value })} className="rounded-md border border-hairline bg-background px-2 py-1"/>
            </label>
            <label className="flex flex-col gap-1 text-xs">
              <span className="text-muted-foreground">To</span>
              <input type="datetime-local" value={customTo} onChange={e=>setSearch({ to: e.target.value })} className="rounded-md border border-hairline bg-background px-2 py-1"/>
            </label>
          </div>
        )}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground"/>
            <input
              value={query}
              onChange={e=>setSearch({ q: e.target.value })}
              placeholder="Search message, error code, session, event…"
              className="w-full rounded-md border border-hairline bg-background pl-8 pr-8 py-1.5 text-xs"
            />
            {query && <button onClick={()=>setSearch({ q: "" })} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5"/></button>}
          </div>
          <select value={eventFilter} onChange={e=>setSearch({ ev: e.target.value })} className="rounded-md border border-hairline bg-background px-2 py-1.5 text-xs">
            <option value="all">All events</option>
            {eventTypes.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <label className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <input type="checkbox" checked={errorsOnly} onChange={e=>setSearch({ err: e.target.checked ? 1 : undefined })}/> Errors only
          </label>

          <div className="relative" ref={codeRef}>
            <button
              type="button"
              onClick={()=>setCodeOpen(o=>!o)}
              disabled={availableCodes.length === 0}
              className="inline-flex items-center gap-1.5 rounded-md border border-hairline bg-background px-2 py-1.5 text-xs disabled:opacity-50"
              title="Filter by error code"
            >
              Error codes
              {selectedCodes.size > 0 && (
                <span className="rounded-full bg-rose-500/15 text-rose-500 px-1.5 text-[10px]">{selectedCodes.size}</span>
              )}
              <ChevronDown className="h-3 w-3 opacity-60"/>
            </button>
            {codeOpen && (
              <div className="absolute right-0 z-20 mt-1 w-64 rounded-md border border-hairline bg-surface shadow-lg p-2">
                <div className="flex items-center justify-between px-1 pb-1.5 text-[10px] uppercase text-muted-foreground">
                  <span>{availableCodes.length} codes</span>
                  {selectedCodes.size > 0 && (
                    <button className="text-muted-foreground hover:text-foreground" onClick={()=>setSearch({ ec: undefined })}>Clear</button>
                  )}
                </div>
                <div className="max-h-60 overflow-auto">
                  {availableCodes.map(([code, count]) => (
                    <label key={code} className="flex items-center gap-2 px-1.5 py-1 text-xs hover:bg-background rounded cursor-pointer">
                      <input type="checkbox" checked={selectedCodes.has(code)} onChange={()=>toggleCode(code)}/>
                      <span className="flex-1 truncate">{code}</span>
                      <span className="text-[10px] text-muted-foreground">{count}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          {selectedCodes.size > 0 && (
            <div className="flex flex-wrap items-center gap-1">
              {Array.from(selectedCodes).map(code => (
                <button key={code} onClick={()=>toggleCode(code)} className="inline-flex items-center gap-1 rounded-full border border-hairline bg-background px-2 py-0.5 text-[11px] hover:bg-secondary">
                  {code} <X className="h-3 w-3"/>
                </button>
              ))}
            </div>
          )}

          <span className="text-[11px] text-muted-foreground ml-auto">
            {filteredEvents.length} of {events.length} events
          </span>
        </div>

      </div>

      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        {[
          ["Sessions", stats.sessions],
          ["Messages", stats.messages],
          ["Errors", stats.errors],
          ["Escalated", stats.escalated + stats.followUps],
          ["Tickets", stats.tickets],
          ["Ticket rate", `${(stats.ticketRate*100).toFixed(0)}%`],
        ].map(([l,v]) => (
          <div key={l as string} className="rounded-xl border border-hairline bg-surface p-4">
            <div className="text-[11px] uppercase text-muted-foreground">{l}</div>
            <div className="mt-1 text-2xl font-serif">{v}</div>
          </div>
        ))}
      </div>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <h2 className="text-sm font-medium">Conversion funnel</h2>
          <div className="text-[11px] text-muted-foreground">
            Escalation rate <span className={stats.escalationRate>0.25?"text-amber-500":"text-foreground"}>{(stats.escalationRate*100).toFixed(1)}%</span>
            {" · "}Escalation → ticket <span className="text-foreground">{(stats.ticketRate*100).toFixed(0)}%</span>
            {" · "}End-to-end <span className="text-foreground">{(stats.ticketPerMessage*100).toFixed(1)}%</span>
          </div>
        </div>
        {(() => {
          const m = Math.max(1, stats.messages);
          const stages = [
            { label: "Messages", value: stats.messages, sub: "100%", cls: "bg-violet" },
            { label: "Escalated", value: stats.totalEsc, sub: `${(stats.escalationRate*100).toFixed(1)}% of messages`, cls: "bg-amber-500" },
            { label: "Tickets", value: stats.tickets, sub: `${(stats.ticketRate*100).toFixed(0)}% of escalations`, cls: "bg-emerald-500" },
          ];
          return (
            <ul className="space-y-2">
              {stages.map(s => (
                <li key={s.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span>{s.label} <span className="text-muted-foreground">· {s.value}</span></span>
                    <span className="text-muted-foreground">{s.sub}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted/40 overflow-hidden">
                    <div className={`h-full ${s.cls}`} style={{ width: `${(s.value/m)*100}%` }}/>
                  </div>
                </li>
              ))}
            </ul>
          );
        })()}
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-4">Escalation rate over time</h2>
          <div className="flex items-end gap-1 h-24">
            {stats.timeline.map(([d, v]) => {
              const rate = v.messages ? (v.escalations / v.messages) : 0;
              const label = dayBucket ? d.slice(0,10) : new Date(d).toLocaleString();
              return (
                <div key={d} className="flex-1" title={`${label}: ${(rate*100).toFixed(1)}% (${v.escalations}/${v.messages})`}>
                  <div className="w-full bg-amber-500 rounded" style={{ height: `${rate*100}%`, minHeight: v.escalations ? 2 : 0 }}/>
                </div>
              );
            })}
          </div>
          <div className="mt-2 text-[10px] text-muted-foreground">0–100% of messages escalated per bucket.</div>
        </section>

        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-4">Ticket conversion over time</h2>
          <div className="flex items-end gap-1 h-24">
            {stats.timeline.map(([d, v]) => {
              const rate = v.escalations ? (v.tickets / v.escalations) : 0;
              const label = dayBucket ? d.slice(0,10) : new Date(d).toLocaleString();
              return (
                <div key={d} className="flex-1" title={`${label}: ${(rate*100).toFixed(0)}% (${v.tickets}/${v.escalations})`}>
                  <div className="w-full bg-emerald-500 rounded" style={{ height: `${rate*100}%`, minHeight: v.tickets ? 2 : 0 }}/>
                </div>
              );
            })}
          </div>
          <div className="mt-2 text-[10px] text-muted-foreground">Share of escalations that became a ticket, per bucket.</div>
        </section>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-4">Timeline ({dayBucket ? "per day" : bucketMs >= 3600_000 ? `per ${bucketMs/3600_000}h` : `per ${bucketMs/60_000}m`})</h2>
          <div className="flex items-end gap-1 h-32">
            {stats.timeline.map(([d, v]) => {
              const label = dayBucket ? d.slice(0,10) : new Date(d).toLocaleString();
              return (
                <div key={d} className="flex-1 flex flex-col items-center gap-1" title={`${label}: ${v.messages} msgs, ${v.errors} err, ${v.tickets} tickets`}>
                  <div className="w-full bg-violet rounded-t" style={{ height: `${(v.messages/maxMsgs)*100}%`, minHeight: v.messages ? 2 : 0 }}/>
                  {v.errors > 0 && <div className="w-full bg-rose-500 rounded-b" style={{ height: `${(v.errors/maxMsgs)*100}%` }}/>}
                </div>
              );
            })}
          </div>
          <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
            <span>{stats.timeline[0] ? (dayBucket ? stats.timeline[0][0].slice(0,10) : new Date(stats.timeline[0][0]).toLocaleString()) : ""}</span>
            <span>{stats.timeline.at(-1) ? (dayBucket ? stats.timeline.at(-1)![0].slice(0,10) : new Date(stats.timeline.at(-1)![0]).toLocaleString()) : ""}</span>
          </div>
        </section>

        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-medium">Error breakdown</h2>
            <span className="text-[10px] text-muted-foreground">Click a code to filter</span>
          </div>
          {Object.keys(stats.errBreakdown).length === 0 ? (
            <p className="text-xs text-muted-foreground">No errors in window.</p>
          ) : (
            <ul className="space-y-1">
              {Object.entries(stats.errBreakdown).sort((a,b)=>b[1]-a[1]).map(([k,v]) => {
                const active = selectedCodes.has(k);
                return (
                  <li key={k}>
                    <button
                      onClick={()=>toggleCode(k)}
                      className={`w-full flex justify-between items-center text-xs px-2 py-1 rounded transition ${active ? "bg-rose-500/15 text-rose-500" : "hover:bg-background"}`}
                    >
                      <span className="capitalize flex items-center gap-2">
                        {active && <Check className="h-3 w-3"/>}
                        {k.replace(/_/g," ")}
                      </span>
                      <span className={active ? "text-rose-500" : "text-muted-foreground"}>{v}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>


      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <div className="flex items-center justify-between mb-4 gap-3 flex-wrap">
          <h2 className="text-sm font-medium">Recent events</h2>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-muted-foreground">Select two events to compare</span>
            <span className="rounded-full border border-hairline px-2 py-0.5 text-[11px]">{compareIds.length}/2</span>
            {compareIds.length > 0 && (
              <button onClick={()=>setCompareIds([])} className="text-muted-foreground hover:text-foreground text-[11px]">Clear</button>
            )}
            <button
              onClick={()=>setCompareOpen(true)}
              disabled={compareIds.length !== 2}
              className="inline-flex items-center gap-1.5 rounded-full bg-violet text-white px-3 py-1 text-[11px] disabled:opacity-40"
            >
              <GitCompare className="h-3 w-3"/> Compare
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="text-left text-muted-foreground">
              <tr>
                <th className="py-2 pr-2 w-6"></th>
                <th className="py-2 pr-4">When</th><th>Event</th><th>Message</th><th>Error</th><th>Session</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-hairline">
              {filteredEvents.slice(0,80).map(e => {
                const checked = compareIds.includes(e.id);
                const disabled = !checked && compareIds.length >= 2;
                return (
                  <tr key={e.id} className={checked ? "bg-violet/5" : undefined}>
                    <td className="py-2 pr-2">
                      <input
                        type="checkbox"
                        checked={checked}
                        disabled={disabled}
                        onChange={()=>toggleCompare(e.id)}
                        aria-label="Select for compare"
                      />
                    </td>
                    <td className="py-2 pr-4 whitespace-nowrap text-muted-foreground">{new Date(e.created_at).toLocaleString()}</td>
                    <td className="py-2 pr-4">{e.event_type}</td>
                    <td className="py-2 pr-4 max-w-md truncate">{e.message ?? "—"}</td>
                    <td className="py-2 pr-4">{e.error_code ? <span className="text-rose-500">{e.error_code}</span> : "—"}</td>
                    <td className="py-2 pr-4 font-mono text-[10px] text-muted-foreground">{e.session_id.slice(0,10)}…</td>
                  </tr>
                );
              })}
              {!loading && filteredEvents.length===0 && <tr><td colSpan={6} className="py-6 text-center text-muted-foreground">No events.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      {compareOpen && compareIds.length === 2 && (() => {
        const [a, b] = compareIds.map(id => events.find(e => e.id === id)).filter(Boolean) as Ev[];
        if (!a || !b) return null;
        const signalRows: Array<[string, string, string]> = [
          ["When", new Date(a.created_at).toLocaleString(), new Date(b.created_at).toLocaleString()],
          ["Event type", a.event_type, b.event_type],
          ["Error code", a.error_code ?? "—", b.error_code ?? "—"],
          ["Status", a.status?.toString() ?? "—", b.status?.toString() ?? "—"],
          ["Session", a.session_id, b.session_id],
          ["Message", a.message ?? "—", b.message ?? "—"],
        ];
        const rulesA = matchRules(a);
        const rulesB = matchRules(b);
        const rulesAIds = new Set(rulesA.map(r=>r.id));
        const rulesBIds = new Set(rulesB.map(r=>r.id));
        const mA = metricsFor(a);
        const mB = metricsFor(b);
        const metricRows: Array<[string, unknown, unknown]> = [
          ["is_error", mA.is_error, mB.is_error],
          ["is_message", mA.is_message, mB.is_message],
          ["is_escalation", mA.is_escalation, mB.is_escalation],
          ["is_ticket", mA.is_ticket, mB.is_ticket],
          ["Session position", mA.session_event_index, mB.session_event_index],
          ["Δ since prev in session", mA.time_since_prev_in_session_ms == null ? "—" : `${mA.time_since_prev_in_session_ms} ms`, mB.time_since_prev_in_session_ms == null ? "—" : `${mB.time_since_prev_in_session_ms} ms`],
          ["Message length", mA.message_length, mB.message_length],
          ["Bucket", new Date(mA.bucket).toLocaleString(), new Date(mB.bucket).toLocaleString()],
          ["Status class", mA.status_class, mB.status_class],
        ];
        const cell = (v: unknown, diff: boolean) => (
          <td className={`align-top py-2 px-3 text-xs ${diff ? "bg-amber-500/10 text-foreground" : "text-muted-foreground"}`}>
            <div className="whitespace-pre-wrap break-words">{typeof v === "boolean" ? (v ? "true" : "false") : String(v)}</div>
          </td>
        );
        return (
          <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={()=>setCompareOpen(false)}>
            <div className="relative w-full max-w-4xl max-h-[85vh] overflow-auto rounded-2xl border border-hairline bg-surface p-6" onClick={e=>e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <GitCompare className="h-4 w-4 text-violet"/>
                  <h3 className="text-lg font-serif">Compare events</h3>
                  <span className="text-[11px] text-muted-foreground">Differences highlighted</span>
                </div>
                <button onClick={()=>setCompareOpen(false)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4"/></button>
              </div>

              <h4 className="text-xs uppercase tracking-wide text-muted-foreground mb-2">Signals</h4>
              <table className="w-full mb-6 border border-hairline rounded overflow-hidden">
                <thead className="bg-background text-[10px] uppercase text-muted-foreground">
                  <tr><th className="text-left px-3 py-2 w-40">Field</th><th className="text-left px-3 py-2">Event A</th><th className="text-left px-3 py-2">Event B</th></tr>
                </thead>
                <tbody className="divide-y divide-hairline">
                  {signalRows.map(([k, va, vb]) => {
                    const diff = va !== vb;
                    return (
                      <tr key={k}>
                        <td className="px-3 py-2 text-xs font-medium">{k}</td>
                        {cell(va, diff)}
                        {cell(vb, diff)}
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              <h4 className="text-xs uppercase tracking-wide text-muted-foreground mb-2">Matched rules ({rules.length} active)</h4>
              <div className="grid grid-cols-2 gap-3 mb-6">
                {[["Event A", rulesA, rulesBIds], ["Event B", rulesB, rulesAIds]].map(([label, list, otherSet]) => (
                  <div key={label as string} className="rounded border border-hairline p-3">
                    <div className="text-[11px] font-medium mb-2">{label as string}</div>
                    {(list as Rule[]).length === 0 ? (
                      <p className="text-[11px] text-muted-foreground">No rules matched.</p>
                    ) : (
                      <ul className="space-y-1">
                        {(list as Rule[]).map(r => {
                          const shared = (otherSet as Set<string>).has(r.id);
                          return (
                            <li key={r.id} className={`text-[11px] px-2 py-1 rounded font-mono ${shared ? "bg-background text-muted-foreground" : "bg-amber-500/15 text-foreground"}`}>
                              <span className="opacity-60">p{r.priority} · </span>{r.pattern}
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>
                ))}
              </div>

              <h4 className="text-xs uppercase tracking-wide text-muted-foreground mb-2">Generated metrics</h4>
              <table className="w-full border border-hairline rounded overflow-hidden">
                <thead className="bg-background text-[10px] uppercase text-muted-foreground">
                  <tr><th className="text-left px-3 py-2 w-56">Metric</th><th className="text-left px-3 py-2">Event A</th><th className="text-left px-3 py-2">Event B</th></tr>
                </thead>
                <tbody className="divide-y divide-hairline">
                  {metricRows.map(([k, va, vb]) => {
                    const diff = va !== vb;
                    return (
                      <tr key={k as string}>
                        <td className="px-3 py-2 text-xs font-medium">{k as string}</td>
                        {cell(va, diff)}
                        {cell(vb, diff)}
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              <div className="mt-4 text-[10px] text-muted-foreground">
                Amber highlight = values differ (or rule matched on only one side).
              </div>
            </div>
          </div>
        );
      })()}
    </div>

  );
}
