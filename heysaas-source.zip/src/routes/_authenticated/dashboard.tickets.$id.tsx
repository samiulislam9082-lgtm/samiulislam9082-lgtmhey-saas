import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { getTicketAttachmentUrl } from "@/lib/support-tickets.functions";
import { BackButton } from "@/components/site/BackButton";
import { Paperclip, Download } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/tickets/$id")({
  head: () => ({ meta: [{ title: "Ticket — HeySaaS" }, { name: "robots", content: "noindex" }] }),
  component: TicketDetail,
});

type T = {
  id: string; subject: string; message: string; status: string; priority: string; created_at: string;
  attachment_path: string | null; attachment_name: string | null; attachment_size: number | null; attachment_mime: string | null;
};
type Ev = { id: string; event_type: string; from_status: string | null; to_status: string | null; note: string | null; created_at: string };

const statusTone: Record<string,string> = {
  new: "border-violet/60 bg-violet/10 text-violet",
  open: "border-amber-500/60 bg-amber-500/10 text-amber-400",
  pending: "border-blue-500/60 bg-blue-500/10 text-blue-400",
  resolved: "border-emerald-500/60 bg-emerald-500/10 text-emerald-400",
};

function TicketDetail() {
  const { id } = Route.useParams();
  const [t, setT] = useState<T | null>(null);
  const [events, setEvents] = useState<Ev[]>([]);
  const [attUrl, setAttUrl] = useState<{ url: string | null; mime: string | null; name: string | null } | null>(null);
  const getUrl = useServerFn(getTicketAttachmentUrl);
  useEffect(() => {
    (async () => {
      const [tk, ev] = await Promise.all([
        supabase.from("support_tickets").select("*").eq("id", id).maybeSingle(),
        supabase.from("support_ticket_events").select("*").eq("ticket_id", id).order("created_at"),
      ]);
      setT(tk.data as T);
      setEvents((ev.data as Ev[]) ?? []);
    })();
  }, [id]);
  useEffect(() => {
    if (!t?.attachment_path) return;
    getUrl({ data: { ticket_id: id } }).then((r)=>setAttUrl(r as never)).catch(()=>{});
  }, [t?.attachment_path, id, getUrl]);

  if (!t) return <p className="text-xs text-muted-foreground">Loading…</p>;
  return (
    <div className="space-y-6 max-w-3xl">
      <BackButton/>
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${statusTone[t.status]}`}>{t.status}</span>
          <span className="text-[11px] text-muted-foreground capitalize">{t.priority} priority</span>
        </div>
        <h1 className="text-2xl font-serif tracking-tight">{t.subject}</h1>
        <p className="text-xs text-muted-foreground">Submitted {new Date(t.created_at).toLocaleString()}</p>
      </div>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <div className="whitespace-pre-wrap text-sm">{t.message}</div>
      </section>

      {t.attachment_path && (
        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-3 flex items-center gap-1"><Paperclip className="h-3.5 w-3.5"/> Attachment</h2>
          <div className="text-xs text-muted-foreground mb-2">{t.attachment_name} · {((t.attachment_size??0)/1024).toFixed(0)} KB</div>
          {attUrl?.url ? (
            <>
              {t.attachment_mime?.startsWith("image/") ? (
                <img src={attUrl.url} alt={t.attachment_name ?? ""} className="max-h-96 rounded-md border border-hairline"/>
              ) : t.attachment_mime === "application/pdf" ? (
                <iframe src={attUrl.url} className="w-full h-96 rounded-md border border-hairline" title="pdf"/>
              ) : null}
              <a href={attUrl.url} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-violet hover:underline"><Download className="h-3 w-3"/> Secure download</a>
            </>
          ) : <p className="text-xs text-muted-foreground">Loading…</p>}
        </section>
      )}

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <h2 className="text-sm font-medium mb-3">Timeline</h2>
        <ul className="space-y-2 text-xs">
          {events.map(e => (
            <li key={e.id} className="border-l-2 border-hairline pl-3">
              <div className="text-muted-foreground text-[10px]">{new Date(e.created_at).toLocaleString()}</div>
              <div>{e.event_type === "status_changed" ? `Status: ${e.from_status ?? "—"} → ${e.to_status}` : e.event_type === "created" ? "Ticket submitted" : e.event_type}</div>
              {e.note && <div className="text-muted-foreground italic">"{e.note}"</div>}
            </li>
          ))}
          {events.length===0 && <li className="text-muted-foreground">No updates yet.</li>}
        </ul>
      </section>
    </div>
  );
}
