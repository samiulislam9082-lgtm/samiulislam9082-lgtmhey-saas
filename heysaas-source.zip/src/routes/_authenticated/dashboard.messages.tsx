import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { sendMessage, markThreadSeen } from "@/lib/messages.functions";
import { setThreadMuted, markThreadUnread, listThreadStates } from "@/lib/thread-states.functions";
import { logMessageAction } from "@/lib/message-audit.functions";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { BackButton } from "@/components/site/BackButton";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageComposer, AttachmentView, type ComposerAttachment } from "@/components/site/MessageComposer";
import { Loader2, MessageSquare, Search, Bell, BellOff, MailOpen, MoreHorizontal, CheckSquare, X, Ban, ShieldOff, Eye, EyeOff, MoreVertical, Settings2, ChevronUp, ChevronDown, Image as ImageIcon, Mic, Type as TypeIcon } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from "@/components/ui/dropdown-menu";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { usePresence } from "@/lib/presence";
import { useMessagePrefs, playMessageChime, getMessagePrefs } from "@/lib/message-prefs";
import { MessageSettingsDialog } from "@/components/site/MessageSettingsDialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { z } from "zod";

const searchSchema = z.object({ t: z.string().optional() });

export const Route = createFileRoute("/_authenticated/dashboard/messages")({
  head: () => ({ meta: [{ title: "Messages — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  validateSearch: (s) => searchSchema.parse(s),
  component: MessagesPage,
});

type Thread = {
  id: string;
  user_a: string;
  user_b: string;
  last_message_at: string | null;
  swap_request_id: string | null;
  other?: { id: string; username: string | null; display_name: string | null; avatar_url: string | null };
  last?: string;
  unread?: number;
};

function MessagesPage() {
  const { t: activeThread } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [threads, setThreads] = useState<Thread[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  // composer state lives inside <MessageComposer />
  const [q, setQ] = useState("");
  const [states, setStates] = useState<Record<string, { muted?: boolean; archived?: boolean }>>({});
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [selectMode, setSelectMode] = useState(false);
  const [busyIds, setBusyIds] = useState<Set<string>>(new Set());
  const [confirm, setConfirm] = useState<null | { kind: "mute" | "unmute" | "unread"; ids: string[] }>(null);
  const [blocked, setBlocked] = useState<Set<string>>(new Set());
  const [blockConfirm, setBlockConfirm] = useState<null | { userId: string; name: string }>(null);
  const [threadSearchOpen, setThreadSearchOpen] = useState(false);
  const [threadQ, setThreadQ] = useState("");
  const [threadFilter, setThreadFilter] = useState<"all" | "text" | "images" | "voice">("all");
  const [matchIdx, setMatchIdx] = useState(0);
  const msgRefs = useRef<Map<string, HTMLDivElement | null>>(new Map());
  const { online, visible: presenceVisible, setVisible: setPresenceVisible } = usePresence(userId);
  const { prefs, setPref, resetPrefs } = useMessagePrefs();
  const [settingsOpen, setSettingsOpen] = useState(false);
  // Reciprocity: if you hide your active status, you can't see anyone else's.
  const visibleOnline = useMemo(() => (presenceVisible ? online : new Set<string>()), [presenceVisible, online]);
  const send = useServerFn(sendMessage);
  const seen = useServerFn(markThreadSeen);
  const mute = useServerFn(setThreadMuted);
  const markUnread = useServerFn(markThreadUnread);
  const listStates = useServerFn(listThreadStates);
  const logAudit = useServerFn(logMessageAction);

  async function loadBlocks() {
    const { data } = await supabase.from("user_blocks").select("blocked_id");
    setBlocked(new Set((data || []).map((r: any) => r.blocked_id)));
  }

  async function blockUser(otherId: string, name: string) {
    if (!userId) return;
    const { error } = await supabase.from("user_blocks").insert({ blocker_id: userId, blocked_id: otherId });
    if (error) { toast.error(error.message); return; }
    setBlocked((s) => new Set(s).add(otherId));
    toast.success(`Blocked ${name}`, {
      action: {
        label: "Undo",
        onClick: async () => {
          await supabase.from("user_blocks").delete().eq("blocker_id", userId!).eq("blocked_id", otherId);
          setBlocked((s) => { const n = new Set(s); n.delete(otherId); return n; });
        },
      },
    });
  }

  async function unblockUser(otherId: string) {
    const { error } = await supabase.from("user_blocks").delete().eq("blocker_id", userId!).eq("blocked_id", otherId);
    if (error) { toast.error(error.message); return; }
    setBlocked((s) => { const n = new Set(s); n.delete(otherId); return n; });
    toast.success("Unblocked");
  }

  async function loadStates() {
    try {
      const rows = (await listStates({})) as any[];
      const map: Record<string, any> = {};
      for (const r of rows) map[r.thread_id] = { muted: r.muted, archived: r.archived };
      setStates(map);
    } catch { /* noop */ }
  }

  async function loadThreads() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setUserId(user.id);
    const { data: ts } = await supabase
      .from("threads")
      .select("id, user_a, user_b, last_message_at, swap_request_id")
      .or(`user_a.eq.${user.id},user_b.eq.${user.id}`)
      .order("last_message_at", { ascending: false, nullsFirst: false });
    const list = (ts || []) as Thread[];
    const otherIds = Array.from(new Set(list.map((t) => (t.user_a === user.id ? t.user_b : t.user_a))));
    if (otherIds.length) {
      const [{ data: profs }, { data: lastMsgs }, { data: unreadRows }] = await Promise.all([
        supabase.from("profiles").select("id, username, display_name, avatar_url").in("id", otherIds),
        supabase.from("messages").select("thread_id, body, created_at").in("thread_id", list.map((t) => t.id)).order("created_at", { ascending: false }),
        supabase.from("messages").select("thread_id").in("thread_id", list.map((t) => t.id)).is("seen_at", null).neq("sender_id", user.id),
      ]);
      const pmap = new Map((profs || []).map((p: any) => [p.id, p]));
      const lastMap = new Map<string, string>();
      (lastMsgs || []).forEach((m: any) => { if (!lastMap.has(m.thread_id)) lastMap.set(m.thread_id, m.body); });
      const unreadMap = new Map<string, number>();
      (unreadRows || []).forEach((r: any) => unreadMap.set(r.thread_id, (unreadMap.get(r.thread_id) || 0) + 1));
      list.forEach((t) => {
        t.other = pmap.get(t.user_a === user.id ? t.user_b : t.user_a) as any;
        t.last = lastMap.get(t.id);
        t.unread = unreadMap.get(t.id) || 0;
      });
    }
    setThreads(list);
    setLoading(false);
  }

  useEffect(() => { loadThreads(); loadStates(); }, []);
  useEffect(() => { if (userId) loadBlocks(); }, [userId]);

  function markBusy(ids: string[], on: boolean) {
    setBusyIds((s) => {
      const next = new Set(s);
      for (const id of ids) { if (on) next.add(id); else next.delete(id); }
      return next;
    });
  }

  async function toggleMute(id: string) {
    const cur = !!states[id]?.muted;
    setStates((s) => ({ ...s, [id]: { ...s[id], muted: !cur } }));
    markBusy([id], true);
    try {
      await mute({ data: { thread_id: id, muted: !cur } });
      logAudit({ data: { action: !cur ? "mute" : "unmute", thread_ids: [id], details: { bulk: false } } }).catch(() => {});
      toast.success(!cur ? "Muted" : "Unmuted", {
        action: {
          label: "Undo",
          onClick: async () => {
            setStates((s) => ({ ...s, [id]: { ...s[id], muted: cur } }));
            markBusy([id], true);
            try { await mute({ data: { thread_id: id, muted: cur } }); }
            catch (e: any) { toast.error(e.message ?? "Undo failed"); }
            finally { markBusy([id], false); }
          },
        },
      });
    } catch (e: any) {
      toast.error(e.message ?? "Failed");
      setStates((s) => ({ ...s, [id]: { ...s[id], muted: cur } }));
    } finally { markBusy([id], false); }
  }

  async function handleMarkUnread(id: string) {
    markBusy([id], true);
    try {
      await markUnread({ data: { thread_id: id } });
      if (activeThread === id) navigate({ search: {} });
      await loadThreads();
      logAudit({ data: { action: "mark_unread", thread_ids: [id], details: { bulk: false } } }).catch(() => {});
      toast.success("Marked unread", {
        action: {
          label: "Undo",
          onClick: async () => {
            markBusy([id], true);
            try { await seen({ data: { thread_id: id } }); await loadThreads(); }
            catch (e: any) { toast.error(e.message ?? "Undo failed"); }
            finally { markBusy([id], false); }
          },
        },
      });
    } catch (e: any) { toast.error(e.message ?? "Failed"); }
    finally { markBusy([id], false); }
  }

  async function unmuteAll() {
    const ids = Object.entries(states).filter(([, v]) => v?.muted).map(([k]) => k);
    if (!ids.length) return;
    try {
      await Promise.all(ids.map((id) => mute({ data: { thread_id: id, muted: false } })));
      setStates((s) => { const n = { ...s }; for (const id of ids) n[id] = { ...n[id], muted: false }; return n; });
      toast.success(`Unmuted ${ids.length} conversation${ids.length > 1 ? "s" : ""}`);
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
  }

  function toggleSelect(id: string) {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function clearSelection() { setSelected(new Set()); setSelectMode(false); }
  function selectAllVisible(ids: string[]) { setSelected(new Set(ids)); }

  function requestBulk(kind: "mute" | "unmute" | "unread") {
    const ids = Array.from(selected);
    if (!ids.length) return;
    setConfirm({ kind, ids });
  }

  async function runBulkMute(ids: string[], muted: boolean) {
    // Snapshot prior state for undo
    const prior: Record<string, boolean> = {};
    for (const id of ids) prior[id] = !!states[id]?.muted;
    setStates((s) => {
      const next = { ...s };
      for (const id of ids) next[id] = { ...next[id], muted };
      return next;
    });
    markBusy(ids, true);
    try {
      await Promise.all(ids.map((id) => mute({ data: { thread_id: id, muted } })));
      logAudit({ data: { action: muted ? "mute" : "unmute", thread_ids: ids, details: { bulk: true, count: ids.length } } }).catch(() => {});
      toast.success(`${muted ? "Muted" : "Unmuted"} ${ids.length} conversation${ids.length === 1 ? "" : "s"}`, {
        action: {
          label: "Undo",
          onClick: async () => {
            setStates((s) => {
              const next = { ...s };
              for (const id of ids) next[id] = { ...next[id], muted: prior[id] };
              return next;
            });
            markBusy(ids, true);
            try { await Promise.all(ids.map((id) => mute({ data: { thread_id: id, muted: prior[id] } }))); }
            catch (e: any) { toast.error(e.message ?? "Undo failed"); await loadStates(); }
            finally { markBusy(ids, false); }
          },
        },
      });
      clearSelection();
    } catch (e: any) { toast.error(e.message ?? "Failed"); await loadStates(); }
    finally { markBusy(ids, false); }
  }

  async function runBulkMarkUnread(ids: string[]) {
    markBusy(ids, true);
    try {
      await Promise.all(ids.map((id) => markUnread({ data: { thread_id: id } })));
      if (activeThread && ids.includes(activeThread)) navigate({ search: {} });
      await loadThreads();
      logAudit({ data: { action: "mark_unread", thread_ids: ids, details: { bulk: true, count: ids.length } } }).catch(() => {});
      toast.success(`Marked ${ids.length} unread`, {
        action: {
          label: "Undo",
          onClick: async () => {
            markBusy(ids, true);
            try { await Promise.all(ids.map((id) => seen({ data: { thread_id: id } }))); await loadThreads(); }
            catch (e: any) { toast.error(e.message ?? "Undo failed"); }
            finally { markBusy(ids, false); }
          },
        },
      });
      clearSelection();
    } catch (e: any) { toast.error(e.message ?? "Failed"); }
    finally { markBusy(ids, false); }
  }



  const [otherTyping, setOtherTyping] = useState(false);
  const typingHideRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const lastTypingSentRef = useRef(0);

  useEffect(() => {
    setOtherTyping(false);
    if (typingHideRef.current) { clearTimeout(typingHideRef.current); typingHideRef.current = null; }
    if (!activeThread) { setMessages([]); typingChannelRef.current = null; return; }
    supabase.from("messages").select("*").eq("thread_id", activeThread).order("created_at").then(({ data }) => setMessages(data || []));
    seen({ data: { thread_id: activeThread } }).then(() => loadThreads()).catch(() => {});
    const ch = supabase
      .channel(`t:${activeThread}`, { config: { broadcast: { self: false } } })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `thread_id=eq.${activeThread}` }, (p) => {
        setMessages((m) => [...m, p.new]);
        if ((p.new as any)?.sender_id !== userId && getMessagePrefs().soundOnMessage) playMessageChime();
        setOtherTyping(false);
        if (typingHideRef.current) { clearTimeout(typingHideRef.current); typingHideRef.current = null; }
      })
      .on("broadcast", { event: "typing" }, (payload) => {
        const from = (payload?.payload as { user_id?: string } | undefined)?.user_id;
        if (!from || from === userId) return;
        setOtherTyping(true);
        if (typingHideRef.current) clearTimeout(typingHideRef.current);
        typingHideRef.current = setTimeout(() => setOtherTyping(false), 3500);
      })
      .subscribe();
    typingChannelRef.current = ch;
    return () => {
      if (typingHideRef.current) { clearTimeout(typingHideRef.current); typingHideRef.current = null; }
      typingChannelRef.current = null;
      supabase.removeChannel(ch);
    };
  }, [activeThread, userId]);

  // Reset in-thread search when switching threads
  useEffect(() => {
    setThreadSearchOpen(false);
    setThreadQ("");
    setThreadFilter("all");
    setMatchIdx(0);
    msgRefs.current.clear();
  }, [activeThread]);

  const matchQuery = threadQ.trim().toLowerCase();
  const matchingIds = useMemo(() => {
    if (!threadSearchOpen && !matchQuery && threadFilter === "all") return null;
    const ids: string[] = [];
    for (const m of messages) {
      const atts: any[] = Array.isArray(m.attachments) ? m.attachments : [];
      const hasImg = atts.some((a) => a?.kind === "image" || a?.kind === "sticker");
      const hasVoice = atts.some((a) => a?.kind === "audio");
      const kindOk =
        threadFilter === "all" ? true :
        threadFilter === "text" ? !!(m.body && m.body.trim()) :
        threadFilter === "images" ? hasImg :
        threadFilter === "voice" ? hasVoice : true;
      if (!kindOk) continue;
      const textOk = !matchQuery || (m.body || "").toLowerCase().includes(matchQuery);
      if (!textOk) continue;
      ids.push(m.id);
    }
    return ids;
  }, [messages, matchQuery, threadFilter, threadSearchOpen]);

  const matchSet = useMemo(() => matchingIds ? new Set(matchingIds) : null, [matchingIds]);

  useEffect(() => { setMatchIdx(0); }, [matchQuery, threadFilter]);

  useEffect(() => {
    if (!matchingIds || matchingIds.length === 0) return;
    const id = matchingIds[Math.min(matchIdx, matchingIds.length - 1)];
    const el = msgRefs.current.get(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [matchIdx, matchingIds]);


  function broadcastTyping() {
    if (!activeThread || !userId || !prefs.typingIndicator) return;
    const now = Date.now();
    if (now - lastTypingSentRef.current < 1500) return;
    lastTypingSentRef.current = now;
    typingChannelRef.current?.send({ type: "broadcast", event: "typing", payload: { user_id: userId } });
  }

  async function handleSend(payload: { body: string; attachments: ComposerAttachment[] }) {
    if (!activeThread) return;
    try {
      await send({ data: { thread_id: activeThread, body: payload.body, attachments: payload.attachments } });
    } catch (e: any) { toast.error(e.message ?? "Send failed"); throw e; }
  }


  const filteredThreads = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return threads;
    return threads.filter((t) => {
      const name = (t.other?.display_name || t.other?.username || "").toLowerCase();
      return name.includes(query) || (t.last?.toLowerCase().includes(query) ?? false);
    });
  }, [threads, q]);

  const totalUnread = threads.reduce((s, t) => s + (t.unread || 0), 0);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="messages"
              eyebrow="Inbox"
              title="Messages"
              description="Direct lines with founders you're swapping with. Threads unlock the moment both sides clear the $19 safety fee."
              meta={totalUnread > 0 ? (
                <span className="inline-flex items-center gap-2 rounded-full border border-violet/30 bg-violet/10 px-3 py-1 text-xs text-violet-glow">
                  <span className="h-1.5 w-1.5 rounded-full bg-violet-glow shadow-[0_0_8px_var(--violet-glow)]" aria-hidden />
                  {totalUnread} unread
                </span>
              ) : null}
            />
            <DashRibbon variant="messages" />
            <DashBodyBlock variant="messages" />
            <div className="mt-8">
            {loading ? (
              <div className="flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : threads.length === 0 ? (
              <div className="hs-empty">
                <div className="hs-empty-icon"><MessageSquare className="h-6 w-6" /></div>
                <p className="hs-empty-title">No conversations yet</p>
                <p className="hs-empty-desc">Messages unlock after both sides pay the $19 safety fee. Send a proposal to open your first thread.</p>
              </div>

            ) : (
              <div className="grid gap-4 lg:grid-cols-[320px_1fr] min-h-[560px]">
                <Card className="relative p-2 overflow-hidden border-primary/10 bg-gradient-to-b from-card via-card to-card/60 backdrop-blur-sm">
                  <div className="pointer-events-none absolute inset-x-0 -top-24 h-40 bg-[radial-gradient(circle_at_top,hsl(var(--primary)/0.15),transparent_70%)]" aria-hidden />
                  <div className="relative overflow-y-auto max-h-[640px] pr-1">
                  <div className="p-2 sticky top-0 bg-card/95 backdrop-blur z-10 space-y-2 rounded-lg">
                    <div className="flex items-center gap-1.5">
                      <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search conversations…" className="pl-8 h-9 text-sm rounded-full bg-secondary/50 border-white/5 focus-visible:ring-primary/40" />
                      </div>
                      <button
                        onClick={() => setSettingsOpen(true)}
                        className="relative h-9 w-9 shrink-0 grid place-items-center rounded-full bg-secondary/50 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                        aria-label="Message settings"
                        title="Message settings"
                      >
                        <Settings2 className="h-4 w-4" />
                        {!presenceVisible && <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-amber-400 ring-2 ring-card" aria-hidden />}
                      </button>
                    </div>
                    {selectMode ? (
                      <div className="flex flex-wrap items-center gap-1 rounded-lg bg-secondary/60 p-1.5 text-xs">
                        <span className="px-1 font-medium">{selected.size} selected</span>
                        <div className="ml-auto flex items-center gap-1">
                          <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => selectAllVisible(filteredThreads.map((t) => t.id))}>All</Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2" disabled={!selected.size} onClick={() => requestBulk("mute")}><BellOff className="h-3 w-3 mr-1" />Mute</Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2" disabled={!selected.size} onClick={() => requestBulk("unmute")}><Bell className="h-3 w-3 mr-1" />Unmute</Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2" disabled={!selected.size} onClick={() => requestBulk("unread")}><MailOpen className="h-3 w-3 mr-1" />Unread</Button>
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={clearSelection} aria-label="Exit selection"><X className="h-3.5 w-3.5" /></Button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setSelectMode(true)}
                        className="w-full text-left text-[11px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1 px-1"
                      >
                        <CheckSquare className="h-3 w-3" /> Select conversations
                      </button>
                    )}
                  </div>
                  {filteredThreads.length === 0 ? (
                    <div className="p-4 text-xs text-muted-foreground text-center">No matches.</div>
                  ) : filteredThreads.map((t) => {
                    const st = states[t.id] || {};
                    const isSelected = selected.has(t.id);
                    const isBusy = busyIds.has(t.id);
                    const isActive = activeThread === t.id;
                    return (
                    <div
                      key={t.id}
                      className={`group relative w-full text-left rounded-xl ${prefs.compact ? "p-2 my-0.5" : "p-3 my-1"} transition-all duration-200 ${isActive ? "bg-gradient-to-r from-primary/20 via-primary/10 to-transparent ring-1 ring-primary/30 shadow-[0_0_20px_-8px_hsl(var(--primary)/0.5)]" : "hover:bg-secondary/70"} ${isSelected ? "ring-1 ring-primary/60" : ""} ${isBusy ? "opacity-60" : ""}`}
                    >
                      <div className="flex items-center gap-3">
                        {selectMode && (
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => toggleSelect(t.id)}
                            aria-label="Select conversation"
                          />
                        )}
                        <button
                          onClick={() => selectMode ? toggleSelect(t.id) : navigate({ search: { t: t.id } })}
                          className="flex-1 min-w-0 text-left"
                        >
                          <div className="flex items-center gap-3">
                            <div className="relative shrink-0">
                              {t.other?.avatar_url ? (
                                <img src={t.other.avatar_url} className="h-10 w-10 rounded-full ring-2 ring-primary/20 object-cover" alt="" />
                              ) : (
                                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 ring-2 ring-primary/20 flex items-center justify-center text-sm font-semibold text-primary">
                                  {(t.other?.display_name || t.other?.username || "?").charAt(0).toUpperCase()}
                                </div>
                              )}
                              {t.other?.id && visibleOnline.has(t.other.id) && (
                                <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-card shadow-[0_0_8px_rgb(52,211,153)]" aria-label="Online" />
                              )}
                              {t.other?.id && blocked.has(t.other.id) && (
                                <span className="absolute -bottom-0.5 -left-0.5 h-3.5 w-3.5 rounded-full bg-destructive/90 ring-2 ring-card flex items-center justify-center" aria-label="Blocked"><Ban className="h-2 w-2 text-white" /></span>
                              )}
                              {!!t.unread && !st.muted && (
                                <span className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-card shadow-[0_0_8px_hsl(var(--primary))]" aria-hidden />
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <div className={`text-sm truncate flex-1 ${t.unread ? "font-semibold text-foreground" : "font-medium text-foreground/90"}`}>{t.other?.display_name || t.other?.username || "Unknown"}</div>
                                {isBusy && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground shrink-0" />}
                                {st.muted && <BellOff className="h-3 w-3 text-muted-foreground shrink-0" />}
                                {!!t.unread && !st.muted && <span className="shrink-0 min-w-[18px] h-[18px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold inline-flex items-center justify-center shadow-[0_0_10px_-2px_hsl(var(--primary))]">{t.unread}</span>}
                              </div>
                              <div className="text-xs text-muted-foreground truncate pr-6 mt-0.5">{prefs.showPreviews ? (t.last || (t.last_message_at ? new Date(t.last_message_at).toLocaleDateString() : "New")) : (t.last_message_at ? new Date(t.last_message_at).toLocaleDateString() : "New message")}</div>
                            </div>
                          </div>
                        </button>
                      </div>
                      {!selectMode && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              onClick={(e) => e.stopPropagation()}
                              className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity p-1 rounded hover:bg-muted"
                              aria-label="Thread actions"
                            >
                              <MoreHorizontal className="h-3.5 w-3.5 text-muted-foreground" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuItem onClick={() => toggleMute(t.id)}>
                              {st.muted ? <><Bell className="h-3.5 w-3.5 mr-2" />Unmute</> : <><BellOff className="h-3.5 w-3.5 mr-2" />Mute</>}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleMarkUnread(t.id)}>
                              <MailOpen className="h-3.5 w-3.5 mr-2" />Mark as unread
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                    );
                  })}
                  </div>
                </Card>
                <Card className="relative p-0 flex flex-col overflow-hidden border-primary/10 bg-gradient-to-br from-card via-card/95 to-background/60 backdrop-blur-sm">
                  <div className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:radial-gradient(hsl(var(--primary))_1px,transparent_1px)] [background-size:22px_22px]" aria-hidden />
                  <div className="pointer-events-none absolute -top-32 -right-24 h-64 w-64 rounded-full bg-primary/15 blur-3xl" aria-hidden />
                  {!activeThread ? (
                    <div className="relative flex-1 flex flex-col items-center justify-center text-center p-10 gap-3">
                      <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary/30 to-primary/5 ring-1 ring-primary/30 flex items-center justify-center shadow-[0_0_40px_-8px_hsl(var(--primary)/0.6)]">
                        <MessageSquare className="h-6 w-6 text-primary" />
                      </div>
                      <div className="text-base font-semibold">Pick a conversation</div>
                      <p className="text-sm text-muted-foreground max-w-xs">Choose a thread on the left to start chatting. Your messages sync in real-time.</p>
                    </div>
                  ) : (
                    <>
                      {(() => {
                        const active = threads.find((t) => t.id === activeThread);
                        const other = active?.other;
                        const name = other?.display_name || other?.username || "Conversation";
                        const otherOnline = other?.id ? visibleOnline.has(other.id) : false;
                        const isBlocked = other?.id ? blocked.has(other.id) : false;
                        return (
                          <div className="relative flex items-center gap-3 px-4 sm:px-5 py-3 border-b border-white/5 bg-card/80 backdrop-blur-xl">
                            <div className="relative shrink-0">
                              {other?.avatar_url ? (
                                <img src={other.avatar_url} className="h-11 w-11 rounded-full ring-2 ring-primary/25 object-cover" alt="" />
                              ) : (
                                <div className="h-11 w-11 rounded-full bg-gradient-to-br from-primary/40 to-primary/10 ring-2 ring-primary/25 flex items-center justify-center text-base font-semibold text-primary">
                                  {name.charAt(0).toUpperCase()}
                                </div>
                              )}
                              <span
                                className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full ring-[3px] ring-card ${otherOnline ? "bg-emerald-400 shadow-[0_0_10px_rgb(52,211,153)]" : "bg-muted-foreground/40"}`}
                                aria-label={otherOnline ? "Online" : "Offline"}
                              />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="font-display text-lg sm:text-xl leading-tight tracking-tight truncate flex items-center gap-2">
                                {name}
                                {isBlocked && <span className="text-[10px] uppercase tracking-wider text-destructive/90 border border-destructive/40 rounded-full px-1.5 py-0.5">Blocked</span>}
                              </div>
                              <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                                <span className={`h-1.5 w-1.5 rounded-full ${otherOnline ? "bg-emerald-400 shadow-[0_0_6px_rgb(52,211,153)]" : "bg-muted-foreground/50"}`} aria-hidden />
                                {otherOnline ? "Active now" : "Offline"}
                                {states[activeThread]?.muted && <><span aria-hidden>·</span><BellOff className="h-3 w-3" /> Muted</>}
                              </div>
                            </div>
                            <div className="flex items-center gap-1">


                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <button className="h-9 w-9 grid place-items-center rounded-full hover:bg-secondary/70 transition-colors" aria-label="Chat settings">
                                    <Settings2 className="h-4 w-4 text-muted-foreground" />
                                  </button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-72 p-2">
                                  <DropdownMenuLabel className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground px-2">Chat settings</DropdownMenuLabel>

                                  <div className="rounded-xl bg-secondary/40 p-1 mt-1">
                                    <div className="flex items-center justify-between gap-3 px-2 py-2">
                                      <span className="flex items-center gap-2 text-sm">
                                        {presenceVisible ? <Eye className="h-4 w-4 text-muted-foreground" /> : <EyeOff className="h-4 w-4 text-muted-foreground" />}
                                        <span>
                                          Active status
                                          <span className="block text-[11px] text-muted-foreground">{presenceVisible ? "Others see you online" : "You appear offline"}</span>
                                        </span>
                                      </span>
                                      <Switch
                                        checked={presenceVisible}
                                        onCheckedChange={(v) => { setPresenceVisible(v); toast.success(v ? "You appear online" : "You appear offline"); }}
                                        aria-label="Show active status"
                                      />
                                    </div>
                                    <div className="flex items-center justify-between gap-3 px-2 py-2 border-t border-white/5">
                                      <span className="flex items-center gap-2 text-sm">
                                        {states[activeThread]?.muted ? <BellOff className="h-4 w-4 text-muted-foreground" /> : <Bell className="h-4 w-4 text-muted-foreground" />}
                                        <span>
                                          Notifications
                                          <span className="block text-[11px] text-muted-foreground">{states[activeThread]?.muted ? "Muted for this chat" : "On for this chat"}</span>
                                        </span>
                                      </span>
                                      <Switch
                                        checked={!states[activeThread]?.muted}
                                        onCheckedChange={() => toggleMute(activeThread)}
                                        aria-label="Notifications for this conversation"
                                      />
                                    </div>
                                  </div>

                                  <DropdownMenuSeparator className="my-2" />
                                  <DropdownMenuLabel className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground px-2">Conversation</DropdownMenuLabel>
                                  <DropdownMenuItem onClick={() => setThreadSearchOpen(true)}>
                                    <Search className="h-3.5 w-3.5 mr-2" />Search in conversation
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleMarkUnread(activeThread)}>
                                    <MailOpen className="h-3.5 w-3.5 mr-2" />Mark as unread
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => setSettingsOpen(true)}>
                                    <Settings2 className="h-3.5 w-3.5 mr-2" />All message settings
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator className="my-2" />
                                  <DropdownMenuLabel className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground px-2">Privacy</DropdownMenuLabel>
                                  {isBlocked ? (
                                    <DropdownMenuItem onClick={() => other?.id && unblockUser(other.id)}>
                                      <ShieldOff className="h-3.5 w-3.5 mr-2" />Unblock {name}
                                    </DropdownMenuItem>
                                  ) : (
                                    <DropdownMenuItem
                                      className="text-destructive focus:text-destructive"
                                      onClick={() => other?.id && setBlockConfirm({ userId: other.id, name })}
                                    >
                                      <Ban className="h-3.5 w-3.5 mr-2" />Block {name}
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </div>
                        );

                      })()}
                      {threadSearchOpen && (
                        <div className="relative border-b border-white/5 bg-card/80 backdrop-blur px-4 py-2.5 space-y-2">
                          <div className="flex items-center gap-2">
                            <div className="relative flex-1">
                              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                              <Input
                                autoFocus
                                value={threadQ}
                                onChange={(e) => setThreadQ(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === "Escape") { setThreadSearchOpen(false); setThreadQ(""); }
                                  if (e.key === "Enter") {
                                    if (!matchingIds || matchingIds.length === 0) return;
                                    setMatchIdx((i) => e.shiftKey ? (i - 1 + matchingIds.length) % matchingIds.length : (i + 1) % matchingIds.length);
                                  }
                                }}
                                placeholder="Search in this conversation…"
                                className="pl-8 pr-8 h-9 text-sm rounded-full bg-secondary/50 border-white/5 focus-visible:ring-primary/40"
                              />
                              {threadQ && (
                                <button
                                  onClick={() => setThreadQ("")}
                                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-muted"
                                  aria-label="Clear search"
                                >
                                  <X className="h-3 w-3 text-muted-foreground" />
                                </button>
                              )}
                            </div>
                            {matchingIds && (
                              <div className="flex items-center gap-1 text-[11px] text-muted-foreground tabular-nums">
                                <span className="min-w-[54px] text-center">
                                  {matchingIds.length === 0 ? "0 results" : `${Math.min(matchIdx, matchingIds.length - 1) + 1} / ${matchingIds.length}`}
                                </span>
                                <button
                                  disabled={!matchingIds.length}
                                  onClick={() => setMatchIdx((i) => (i - 1 + matchingIds.length) % matchingIds.length)}
                                  className="p-1 rounded hover:bg-secondary disabled:opacity-40"
                                  aria-label="Previous match"
                                >
                                  <ChevronUp className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  disabled={!matchingIds.length}
                                  onClick={() => setMatchIdx((i) => (i + 1) % matchingIds.length)}
                                  className="p-1 rounded hover:bg-secondary disabled:opacity-40"
                                  aria-label="Next match"
                                >
                                  <ChevronDown className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            )}
                            <button
                              onClick={() => { setThreadSearchOpen(false); setThreadQ(""); setThreadFilter("all"); }}
                              className="p-1.5 rounded-md hover:bg-secondary/70 text-muted-foreground"
                              aria-label="Close search"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {([
                              { k: "all", label: "All", Icon: MessageSquare },
                              { k: "text", label: "Text", Icon: TypeIcon },
                              { k: "images", label: "Images", Icon: ImageIcon },
                              { k: "voice", label: "Voice", Icon: Mic },
                            ] as const).map(({ k, label, Icon }) => {
                              const active = threadFilter === k;
                              return (
                                <button
                                  key={k}
                                  onClick={() => setThreadFilter(k)}
                                  className={`inline-flex items-center gap-1 h-7 px-2.5 rounded-full text-[11px] transition-colors ring-1 ${
                                    active
                                      ? "bg-primary/15 text-primary ring-primary/30"
                                      : "bg-secondary/40 text-muted-foreground ring-white/5 hover:text-foreground hover:ring-white/10"
                                  }`}
                                  aria-pressed={active}
                                >
                                  <Icon className="h-3 w-3" /> {label}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                      <div className="relative flex-1 overflow-y-auto px-5 py-5 space-y-2 max-h-[520px]">
                        {messages.length === 0 && (
                          <div className="h-full flex items-center justify-center text-xs text-muted-foreground">Say hi — this thread is fresh.</div>
                        )}
                        {matchSet && matchSet.size === 0 && messages.length > 0 && (
                          <div className="text-center text-xs text-muted-foreground py-6">No matches in this conversation.</div>
                        )}
                        {messages.map((m: any, idx: number) => {
                          const mine = m.sender_id === userId;
                          const prev = messages[idx - 1];
                          const next = messages[idx + 1];
                          const groupStart = !prev || prev.sender_id !== m.sender_id || (new Date(m.created_at).getTime() - new Date(prev.created_at).getTime()) > 5 * 60_000;
                          const groupEnd = !next || next.sender_id !== m.sender_id || (new Date(next.created_at).getTime() - new Date(m.created_at).getTime()) > 5 * 60_000;
                          const atts: ComposerAttachment[] = Array.isArray(m.attachments) ? m.attachments : [];
                          const time = new Date(m.created_at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
                          const showDayDivider = !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString();
                          const dayLabel = new Date(m.created_at).toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
                          const activeOther = threads.find((t) => t.id === activeThread)?.other;
                          const isMatch = matchSet ? matchSet.has(m.id) : true;
                          const activeMatchId = matchingIds && matchingIds.length ? matchingIds[Math.min(matchIdx, matchingIds.length - 1)] : null;
                          const isActiveMatch = activeMatchId === m.id;
                          const dimmed = matchSet ? !isMatch : false;
                          const renderHighlighted = (text: string) => {
                            if (!matchQuery) return text;
                            const parts: ReactNode[] = [];
                            const lower = text.toLowerCase();
                            let i = 0;
                            while (i < text.length) {
                              const at = lower.indexOf(matchQuery, i);
                              if (at === -1) { parts.push(text.slice(i)); break; }
                              if (at > i) parts.push(text.slice(i, at));
                              parts.push(
                                <mark key={at} className="bg-amber-300/70 text-black rounded px-0.5">
                                  {text.slice(at, at + matchQuery.length)}
                                </mark>
                              );
                              i = at + matchQuery.length;
                            }
                            return <>{parts}</>;
                          };
                          return (
                            <div
                              key={m.id}
                              ref={(el) => { msgRefs.current.set(m.id, el); }}
                              className={`transition-opacity ${dimmed ? "opacity-30" : "opacity-100"}`}
                            >
                              {showDayDivider && (
                                <div className="flex items-center gap-3 my-4">
                                  <div className="h-px flex-1 bg-white/5" />
                                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{dayLabel}</span>
                                  <div className="h-px flex-1 bg-white/5" />
                                </div>
                              )}
                              <div className={`flex items-end gap-2 ${mine ? "justify-end" : "justify-start"} ${groupStart ? "mt-3" : "mt-0.5"}`}>
                                {!mine && (
                                  <div className="w-7 shrink-0">
                                    {groupEnd && (activeOther?.avatar_url ? (
                                      <img src={activeOther.avatar_url} className="h-7 w-7 rounded-full object-cover ring-1 ring-white/10" alt="" />
                                    ) : (
                                      <div className="h-7 w-7 rounded-full bg-gradient-to-br from-primary/30 to-primary/5 ring-1 ring-white/10 flex items-center justify-center text-[10px] font-semibold text-primary">
                                        {(activeOther?.display_name || activeOther?.username || "?").charAt(0).toUpperCase()}
                                      </div>
                                    ))}
                                  </div>
                                )}
                                <div className={`max-w-[72%] space-y-1.5 ${mine ? "items-end" : "items-start"} flex flex-col`}>
                                  {atts.map((a, i) => (
                                    <div key={i} className={`flex ${mine ? "justify-end" : "justify-start"} ${isActiveMatch ? "ring-2 ring-amber-300/70 rounded-2xl" : ""}`}>
                                      <AttachmentView att={a} />
                                    </div>
                                  ))}
                                  {m.body && (() => {
                                    const trimmed = m.body.trim();
                                    const emojiOnly = /^(\p{Extended_Pictographic}|\p{Emoji_Presentation}|\s)+$/u.test(trimmed) && trimmed.length <= 8;
                                    if (emojiOnly) {
                                      return <div className={`text-5xl leading-none py-1 select-none ${isActiveMatch ? "ring-2 ring-amber-300/70 rounded-2xl px-2" : ""}`}>{trimmed}</div>;
                                    }
                                    return (
                                      <div
                                        className={`relative px-4 py-2.5 text-[14.5px] leading-relaxed whitespace-pre-wrap break-words min-w-[52px] ${
                                          mine
                                            ? `[background-image:var(--gradient-violet)] text-primary-foreground shadow-[0_8px_24px_-10px_var(--violet),inset_0_1px_0_rgb(255_255_255/0.18)] rounded-[22px] ${groupStart ? "" : "rounded-tr-[8px]"} ${groupEnd ? "rounded-br-[8px]" : ""}`
                                            : `bg-secondary/80 text-foreground ring-1 ring-white/10 shadow-[0_6px_18px_-12px_rgb(0_0_0/0.8)] rounded-[22px] ${groupStart ? "" : "rounded-tl-[8px]"} ${groupEnd ? "rounded-bl-[8px]" : ""}`
                                        } ${isActiveMatch ? "ring-2 ring-amber-300/80 shadow-[0_0_0_4px_rgb(252_211_77/0.25)]" : ""}`}
                                      >
                                        {renderHighlighted(m.body)}
                                      </div>
                                    );
                                  })()}
                                  {groupEnd && (
                                    <span className="text-[10px] text-muted-foreground px-1">{time}</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                        {otherTyping && (() => {
                          const activeOther = threads.find((t) => t.id === activeThread)?.other;
                          const label = activeOther?.display_name || activeOther?.username || "Someone";
                          return (
                            <div className="flex items-end gap-2 justify-start mt-3" aria-live="polite" aria-label={`${label} is typing`}>
                              <div className="w-7 shrink-0">
                                {activeOther?.avatar_url ? (
                                  <img src={activeOther.avatar_url} className="h-7 w-7 rounded-full object-cover ring-1 ring-white/10" alt="" />
                                ) : (
                                  <div className="h-7 w-7 rounded-full bg-gradient-to-br from-primary/30 to-primary/5 ring-1 ring-white/10 flex items-center justify-center text-[10px] font-semibold text-primary">
                                    {label.charAt(0).toUpperCase()}
                                  </div>
                                )}
                              </div>
                              <div className="rounded-[22px] rounded-bl-[8px] bg-secondary/80 ring-1 ring-white/10 shadow-[0_4px_14px_-8px_rgb(0_0_0/0.6)] px-3.5 py-2.5 flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-foreground/60 motion-safe:animate-[typing-bounce_1.2s_infinite_ease-in-out]" style={{ animationDelay: "0ms" }} />
                                <span className="h-1.5 w-1.5 rounded-full bg-foreground/60 motion-safe:animate-[typing-bounce_1.2s_infinite_ease-in-out]" style={{ animationDelay: "150ms" }} />
                                <span className="h-1.5 w-1.5 rounded-full bg-foreground/60 motion-safe:animate-[typing-bounce_1.2s_infinite_ease-in-out]" style={{ animationDelay: "300ms" }} />
                              </div>
                            </div>
                          );
                        })()}
                      </div>

                      {(() => {
                        const other = threads.find((t) => t.id === activeThread)?.other;
                        const isBlocked = other?.id ? blocked.has(other.id) : false;
                        if (isBlocked) {
                          return (
                            <div className="relative border-t border-white/5 bg-card/70 backdrop-blur px-5 py-4 flex items-center justify-between gap-3">
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Ban className="h-3.5 w-3.5 text-destructive" />
                                You've blocked this person. Messaging is disabled.
                              </div>
                              <Button size="sm" variant="outline" onClick={() => other?.id && unblockUser(other.id)}>
                                <ShieldOff className="h-3.5 w-3.5 mr-1.5" /> Unblock
                              </Button>
                            </div>
                          );
                        }
                        return (
                          <div className="relative border-t border-white/5 bg-card/70 backdrop-blur p-3">
                            <MessageComposer threadId={activeThread} onSend={handleSend} onTyping={broadcastTyping} enterToSend={prefs.enterToSend} />
                          </div>
                        );
                      })()}
                    </>
                  )}
                </Card>
              </div>
            )}
            </div>

          </div>
        </div>
      </main>
      <AlertDialog open={!!confirm} onOpenChange={(o) => { if (!o) setConfirm(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirm?.kind === "mute" && `Mute ${confirm.ids.length} conversation${confirm.ids.length === 1 ? "" : "s"}?`}
              {confirm?.kind === "unmute" && `Unmute ${confirm.ids.length} conversation${confirm.ids.length === 1 ? "" : "s"}?`}
              {confirm?.kind === "unread" && `Mark ${confirm?.ids.length} conversation${confirm?.ids.length === 1 ? "" : "s"} as unread?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirm?.kind === "mute" && "You'll stop getting notifications for these conversations. You can undo right after."}
              {confirm?.kind === "unmute" && "Notifications will resume for these conversations."}
              {confirm?.kind === "unread" && "Their latest message will show as unread again in your inbox."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (!confirm) return;
                const { kind, ids } = confirm;
                setConfirm(null);
                if (kind === "mute") runBulkMute(ids, true);
                else if (kind === "unmute") runBulkMute(ids, false);
                else runBulkMarkUnread(ids);
              }}
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <MessageSettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        presenceVisible={presenceVisible}
        onPresenceChange={(v) => { setPresenceVisible(v); toast.success(v ? "You appear online" : "You appear offline — you also can't see who's online"); }}
        prefs={prefs}
        setPref={setPref}
        resetPrefs={resetPrefs}
        stats={{
          threads: threads.length,
          unread: threads.reduce((a, t) => a + (t.unread || 0), 0),
          muted: Object.values(states).filter((v) => v?.muted).length,
          online: threads.filter((t) => t.other?.id && visibleOnline.has(t.other.id)).length,
        }}
        blockedIds={[...blocked]}
        onUnblock={(id) => unblockUser(id)}
        onUnmuteAll={unmuteAll}
      />
      <AlertDialog open={!!blockConfirm} onOpenChange={(o) => { if (!o) setBlockConfirm(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Block {blockConfirm?.name}?</AlertDialogTitle>
            <AlertDialogDescription>
              They won't be able to reach you, and you won't see their new messages. You can unblock them anytime from this conversation.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (!blockConfirm) return;
                const { userId: uid, name } = blockConfirm;
                setBlockConfirm(null);
                blockUser(uid, name);
              }}
            >
              Block
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <Footer />
    </div>
  );
}
