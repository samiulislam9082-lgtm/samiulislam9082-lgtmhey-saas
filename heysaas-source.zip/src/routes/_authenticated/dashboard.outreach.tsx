import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Download, Plus, Trash2, Mail, Copy, Users } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/outreach")({
  head: () => ({ meta: [{ title: "Outreach CRM — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: OutreachPage,
});

type Stage = "queued" | "contacted" | "replied" | "meeting" | "closed" | "passed";
type Kind = "founder" | "investor" | "journalist" | "creator" | "acquirer" | "other";

type Contact = {
  id: string;
  name: string;
  email: string;
  company: string;
  kind: Kind;
  stage: Stage;
  notes: string;
  lastTouched: string;
};

const STAGES: Stage[] = ["queued", "contacted", "replied", "meeting", "closed", "passed"];
const KINDS: Kind[] = ["founder", "investor", "journalist", "creator", "acquirer", "other"];

const stageTone: Record<Stage, string> = {
  queued: "bg-white/5 text-white/70",
  contacted: "bg-cyan-500/15 text-cyan-200",
  replied: "bg-teal-500/15 text-teal-200",
  meeting: "bg-amber-500/15 text-amber-200",
  closed: "bg-emerald-500/15 text-emerald-200",
  passed: "bg-white/5 text-white/40",
};

function OutreachPage() {
  const [uid, setUid] = useState<string | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [filter, setFilter] = useState<"all" | Stage>("all");
  const [q, setQ] = useState("");
  const [draft, setDraft] = useState<Partial<Contact>>({ kind: "founder", stage: "queued" });

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUid(user.id);
      try {
        const raw = localStorage.getItem(`hs.outreach.${user.id}`);
        if (raw) setContacts(JSON.parse(raw));
      } catch {}
    })();
  }, []);

  const persist = (next: Contact[]) => {
    setContacts(next);
    if (uid) localStorage.setItem(`hs.outreach.${uid}`, JSON.stringify(next));
  };

  const add = () => {
    if (!draft.name || !draft.email) { toast.error("Name and email required"); return; }
    const c: Contact = {
      id: crypto.randomUUID(),
      name: draft.name!, email: draft.email!, company: draft.company ?? "",
      kind: (draft.kind as Kind) ?? "founder",
      stage: (draft.stage as Stage) ?? "queued",
      notes: draft.notes ?? "",
      lastTouched: new Date().toISOString(),
    };
    persist([c, ...contacts]);
    setDraft({ kind: "founder", stage: "queued" });
    toast.success("Contact added");
  };

  const setStage = (id: string, stage: Stage) => {
    persist(contacts.map((c) => c.id === id ? { ...c, stage, lastTouched: new Date().toISOString() } : c));
  };
  const remove = (id: string) => persist(contacts.filter((c) => c.id !== id));

  const filtered = useMemo(() => {
    return contacts.filter((c) => {
      if (filter !== "all" && c.stage !== filter) return false;
      if (q && !(`${c.name} ${c.email} ${c.company}`.toLowerCase().includes(q.toLowerCase()))) return false;
      return true;
    });
  }, [contacts, filter, q]);

  const counts = useMemo(() => {
    const base: Record<string, number> = { all: contacts.length };
    STAGES.forEach((s) => { base[s] = contacts.filter((c) => c.stage === s).length; });
    return base;
  }, [contacts]);

  const reply = contacts.filter((c) => c.stage === "replied" || c.stage === "meeting" || c.stage === "closed").length;
  const rate = contacts.length ? Math.round((reply / contacts.length) * 100) : 0;

  const exportCsv = () => {
    const header = ["name","email","company","kind","stage","lastTouched","notes"];
    const rows = contacts.map((c) => header.map((h) => JSON.stringify((c as any)[h] ?? "")).join(","));
    const blob = new Blob([[header.join(","), ...rows].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "outreach.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <div className="hs-noir hs-dash-shell flex-1">
        <div className="hs-dash-canvas" aria-hidden="true">
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--one" />
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--two" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col lg:flex-row gap-8 relative">
          <DashboardSidebar />
          <main id="main" className="flex-1 min-w-0 space-y-6">
            <BackButton />
            <DashHero
              eyebrow="Marketing · Outreach"
              title="A quiet ledger for every conversation."
              description="Track founders, journalists, and prospective acquirers you've reached out to. Stored on this device — never leaves your browser."
              signature="overview"
              actions={
                <>
                  <Button variant="outline" size="sm" onClick={exportCsv}><Download className="w-4 h-4 mr-2" />Export CSV</Button>
                  <Badge variant="secondary">{contacts.length} contacts · {rate}% reply rate</Badge>
                </>
              }
            />

            <Card className="p-5">
              <h3 className="text-sm font-medium mb-3 flex items-center gap-2"><Plus className="w-4 h-4" /> Add contact</h3>
              <div className="grid gap-3 md:grid-cols-4">
                <Input placeholder="Name" value={draft.name ?? ""} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
                <Input placeholder="Email" type="email" value={draft.email ?? ""} onChange={(e) => setDraft({ ...draft, email: e.target.value })} />
                <Input placeholder="Company" value={draft.company ?? ""} onChange={(e) => setDraft({ ...draft, company: e.target.value })} />
                <Select value={draft.kind as string} onValueChange={(v) => setDraft({ ...draft, kind: v as Kind })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{KINDS.map((k) => <SelectItem key={k} value={k}>{k}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <Textarea className="mt-3" placeholder="Notes (context, angle, next step)…" value={draft.notes ?? ""} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} />
              <div className="mt-3 flex justify-end"><Button onClick={add}><Plus className="w-4 h-4 mr-2" />Add</Button></div>
            </Card>

            <div className="flex flex-wrap gap-2 items-center">
              {(["all", ...STAGES] as const).map((s) => (
                <button key={s} onClick={() => setFilter(s as any)}
                  className={`px-3 py-1.5 rounded-full text-xs border ${filter === s ? "bg-white/10 border-white/20" : "border-white/10 hover:bg-white/5"}`}>
                  {s} <span className="opacity-60 ml-1">{counts[s] ?? 0}</span>
                </button>
              ))}
              <Input className="ml-auto max-w-xs" placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>

            <Card className="p-0 overflow-hidden">
              {filtered.length === 0 ? (
                <div className="p-10 text-center text-sm text-muted-foreground">
                  <Users className="w-8 h-8 mx-auto opacity-40 mb-2" />
                  No contacts yet. Add your first prospect above.
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {filtered.map((c) => (
                    <div key={c.id} className="p-4 flex flex-wrap items-start gap-4">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="font-medium truncate">{c.name}</div>
                          <Badge variant="outline" className="text-[10px]">{c.kind}</Badge>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] ${stageTone[c.stage]}`}>{c.stage}</span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1 flex items-center gap-3 flex-wrap">
                          <a href={`mailto:${c.email}`} className="hover:underline flex items-center gap-1"><Mail className="w-3 h-3" />{c.email}</a>
                          {c.company && <span>{c.company}</span>}
                          <span>Touched {new Date(c.lastTouched).toLocaleDateString()}</span>
                        </div>
                        {c.notes && <p className="text-xs text-muted-foreground mt-2 whitespace-pre-wrap">{c.notes}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <Select value={c.stage} onValueChange={(v) => setStage(c.id, v as Stage)}>
                          <SelectTrigger className="h-8 w-32 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>{STAGES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                        </Select>
                        <Button variant="ghost" size="icon" aria-label="Copy" onClick={() => { navigator.clipboard.writeText(c.email); toast.success("Email copied"); }}><Copy className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => remove(c.id)}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
