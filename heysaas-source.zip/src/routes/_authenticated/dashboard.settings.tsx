import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { BackButton } from "@/components/site/BackButton";
import { ImageUploader } from "@/components/site/ImageUploader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Loader2, LogOut } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { exportMyData, deleteMyAccount } from "@/lib/account.functions";
import { getNotificationPrefs, updateNotificationPrefs } from "@/lib/notification-prefs.functions";
import { Switch } from "@/components/ui/switch";
import { lovable } from "@/integrations/lovable";
import { ReferralsPanel, WebsiteSharePanel, ProfileQrPanel } from "@/components/site/ShareAndReferrals";

export const Route = createFileRoute("/_authenticated/dashboard/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Hey SaaS" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SettingsPage,
});

type Profile = {
  id: string;
  username: string | null;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  cover_url: string | null;
  location: string | null;
  country: string | null;
  website_url: string | null;
  twitter_handle: string | null;
  github_handle: string | null;
  linkedin_handle: string | null;
};

function SettingsPage() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Profile | null>(null);

  useEffect(() => {
    (async () => {
      const { data: sess } = await supabase.auth.getSession();
      const u = sess.session?.user;
      if (!u) return;
      setUserId(u.id);
      setEmail(u.email ?? "");
      const { data } = await supabase
        .from("profiles")
        .select("id, username, display_name, bio, avatar_url, cover_url, location, country, website_url, twitter_handle, github_handle, linkedin_handle")
        .eq("id", u.id)
        .maybeSingle();
      setForm((data as Profile) ?? null);
      setLoading(false);
    })();
  }, []);

  function update<K extends keyof Profile>(key: K, value: Profile[K]) {
    setForm((f) => (f ? { ...f, [key]: value } : f));
  }

  async function save() {
    if (!form || !userId) return;
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        display_name: form.display_name,
        bio: form.bio,
        avatar_url: form.avatar_url,
        cover_url: form.cover_url,
        location: form.location,
        country: form.country,
        website_url: form.website_url,
        twitter_handle: form.twitter_handle,
        github_handle: form.github_handle,
        linkedin_handle: form.linkedin_handle,
      })
      .eq("id", userId);
    setSaving(false);
    if (error) {
      toast.error("Couldn't save. Try again.");
      return;
    }
    toast.success("Profile updated");
  }

  async function handleSignOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0 max-w-3xl">
            <BackButton />
            <DashHero
              signature="settings"
              eyebrow="Preferences"
              title="Settings"
              description="Fine-tune your founder profile, security, notifications and how the marketplace behaves for you."
            />
            <DashRibbon variant="settings" />
            <DashBodyBlock variant="settings" />


            {loading || !form ? (
              <div className="mt-12 flex justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <Tabs defaultValue="profile" className="mt-8">
                <TabsList className="rounded-full flex-wrap h-auto">
                  <TabsTrigger value="profile" className="rounded-full">Profile</TabsTrigger>
                  <TabsTrigger value="account" className="rounded-full">Account</TabsTrigger>
                  <TabsTrigger value="referrals" className="rounded-full">Referrals</TabsTrigger>
                  <TabsTrigger value="share" className="rounded-full">Share</TabsTrigger>
                  <TabsTrigger value="qr" className="rounded-full">QR code</TabsTrigger>

                  <TabsTrigger value="notifications" className="rounded-full">Notifications</TabsTrigger>
                  <TabsTrigger value="accessibility" className="rounded-full">Accessibility</TabsTrigger>
                  <TabsTrigger value="danger" className="rounded-full">Danger</TabsTrigger>
                </TabsList>


                <TabsContent value="profile" className="mt-8 space-y-8">
                  <section className="grid gap-6 md:grid-cols-[200px_1fr]">
                    <div>
                      <Label className="mb-2 block">Avatar</Label>
                      <ImageUploader
                        bucket="avatars"
                        userId={userId!}
                        value={form.avatar_url}
                        onChange={(v) => update("avatar_url", v)}
                        aspect="square"
                        label="Change"
                      />
                    </div>
                    <div>
                      <Label className="mb-2 block">Cover</Label>
                      <ImageUploader
                        bucket="covers"
                        userId={userId!}
                        value={form.cover_url}
                        onChange={(v) => update("cover_url", v)}
                        aspect="wide"
                        label="Change"
                      />
                    </div>
                  </section>

                  <section className="space-y-4">
                    <div>
                      <Label>Username</Label>
                      <Input value={form.username ?? ""} disabled className="mt-1.5" />
                      <p className="mt-1.5 text-xs text-muted-foreground">
                        Your public handle. Contact support to change.
                      </p>
                    </div>
                    <div>
                      <Label>Display name</Label>
                      <Input
                        value={form.display_name ?? ""}
                        onChange={(e) => update("display_name", e.target.value)}
                        className="mt-1.5"
                      />
                    </div>
                    <div>
                      <Label>Bio</Label>
                      <Textarea
                        value={form.bio ?? ""}
                        onChange={(e) => update("bio", e.target.value)}
                        rows={4}
                        maxLength={300}
                        className="mt-1.5"
                      />
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <Label>Location</Label>
                        <Input
                          value={form.location ?? ""}
                          onChange={(e) => update("location", e.target.value)}
                          placeholder="San Francisco, CA"
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <Label>Country</Label>
                        <Input
                          value={form.country ?? ""}
                          onChange={(e) => update("country", e.target.value)}
                          placeholder="USA"
                          className="mt-1.5"
                        />
                      </div>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <h2 className="font-display text-xl">Links</h2>
                    <div>
                      <Label>Website</Label>
                      <Input
                        value={form.website_url ?? ""}
                        onChange={(e) => update("website_url", e.target.value)}
                        placeholder="https://yoursite.com"
                        className="mt-1.5"
                      />
                    </div>
                    <div className="grid gap-4 md:grid-cols-3">
                      <div>
                        <Label>Twitter</Label>
                        <Input
                          value={form.twitter_handle ?? ""}
                          onChange={(e) => update("twitter_handle", e.target.value.replace(/^@/, ""))}
                          placeholder="handle"
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <Label>GitHub</Label>
                        <Input
                          value={form.github_handle ?? ""}
                          onChange={(e) => update("github_handle", e.target.value)}
                          placeholder="handle"
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <Label>LinkedIn</Label>
                        <Input
                          value={form.linkedin_handle ?? ""}
                          onChange={(e) => update("linkedin_handle", e.target.value)}
                          placeholder="handle"
                          className="mt-1.5"
                        />
                      </div>
                    </div>
                  </section>

                  <div className="flex items-center justify-end gap-3 pt-4">
                    <Button
                      onClick={save}
                      disabled={saving}
                      className="rounded-full bg-foreground text-background hover:opacity-90"
                    >
                      {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                      Save changes
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="account" className="mt-8 space-y-8">
                  <div>
                    <Label>Email</Label>
                    <Input value={email} disabled className="mt-1.5" />
                    <p className="mt-1.5 text-xs text-muted-foreground">
                      Contact support to change your email.
                    </p>
                  </div>

                  <ConnectionsSection />

                  <Button
                    variant="outline"
                    onClick={handleSignOut}
                    className="rounded-full"
                  >
                    <LogOut className="h-4 w-4 mr-2" /> Sign out
                  </Button>
                </TabsContent>


                <TabsContent value="referrals" className="mt-8">
                  <ReferralsPanel />
                </TabsContent>

                <TabsContent value="share" className="mt-8">
                  <WebsiteSharePanel />
                </TabsContent>

                <TabsContent value="qr" className="mt-8">
                  <ProfileQrPanel />
                </TabsContent>


                <TabsContent value="notifications" className="mt-8">
                  <NotificationPrefsSection />
                </TabsContent>

                <TabsContent value="accessibility" className="mt-8">
                  <AccessibilitySection />
                </TabsContent>


                <TabsContent value="danger" className="mt-8 space-y-6">
                  <DangerZone />
                </TabsContent>
              </Tabs>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function DangerZone() {
  const navigate = useNavigate();
  const doExport = useServerFn(exportMyData);
  const doDelete = useServerFn(deleteMyAccount);
  const [busy, setBusy] = useState<"export" | "delete" | null>(null);

  async function handleExport() {
    setBusy("export");
    try {
      const json = await doExport({ data: undefined });
      const blob = new Blob([typeof json === "string" ? json : JSON.stringify(json, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `hey-saas-export-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Export ready.");
    } catch (e) {
      toast.error((e as Error).message || "Export failed.");
    } finally {
      setBusy(null);
    }
  }

  async function handleDelete() {
    if (!confirm("Permanently delete your account? This cannot be undone.")) return;
    if (!confirm("This will delete every listing, message, and swap. Continue?")) return;
    setBusy("delete");
    try {
      await doDelete({ data: undefined });
      await supabase.auth.signOut();
      toast.success("Account deleted.");
      navigate({ to: "/" });
    } catch (e) {
      toast.error((e as Error).message || "Delete failed.");
      setBusy(null);
    }
  }

  return (
    <>
      <div className="rounded-2xl border border-hairline bg-surface p-6">
        <h3 className="font-display text-lg">Export your data</h3>
        <p className="mt-1 text-sm text-muted-foreground">Download a copy of your profile, listings, and swap history.</p>
        <Button variant="outline" className="mt-4 rounded-full" onClick={handleExport} disabled={busy !== null}>
          {busy === "export" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Request export
        </Button>
      </div>
      <div className="rounded-2xl border border-red-500/30 bg-red-500/5 p-6">
        <h3 className="font-display text-lg text-red-400">Delete account</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Permanently remove your account and all owned content. This cannot be undone.
        </p>
        <Button variant="outline" className="mt-4 rounded-full border-red-500/40 text-red-400 hover:bg-red-500/10" onClick={handleDelete} disabled={busy !== null}>
          {busy === "delete" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Delete account
        </Button>
      </div>
    </>
  );
}

type IdentityRow = {
  id: string;
  provider: string;
  identity_data?: Record<string, any> | null;
  created_at?: string | null;
};

function ConnectionsSection() {
  const [identities, setIdentities] = useState<IdentityRow[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [linking, setLinking] = useState(false);

  async function refresh() {
    const { data } = await supabase.auth.getUser();
    const list = (data.user?.identities ?? []) as unknown as IdentityRow[];
    setIdentities(list);
  }

  useEffect(() => {
    refresh();
  }, []);

  const google = identities?.find((i) => i.provider === "google");
  const canUnlink = (identities?.length ?? 0) > 1;

  async function linkGoogle() {
    if (linking) return;
    setLinking(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if ((result as any)?.error) {
        toast.error(((result as any).error as Error).message ?? "Couldn't connect Google.");
        return;
      }
      await refresh();
      toast.success("Google account connected.");
    } catch (e: any) {
      toast.error(e?.message ?? "Couldn't connect Google.");
    } finally {
      setLinking(false);
    }
  }

  async function unlinkGoogle() {
    if (!google) return;
    if (!canUnlink) {
      toast.error("Set a password or add another sign-in method before unlinking Google.");
      return;
    }
    if (!confirm("Disconnect this Google account? You'll need another method to sign in next time.")) return;
    setBusy(google.id);
    try {
      // `unlinkIdentity` needs the identity object as returned by getUserIdentities.
      const { data } = await supabase.auth.getUserIdentities();
      const target = data?.identities?.find((i) => i.provider === "google");
      if (!target) throw new Error("Google identity not found.");
      const { error } = await supabase.auth.unlinkIdentity(target);
      if (error) throw error;
      toast.success("Google account disconnected.");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message ?? "Couldn't disconnect Google.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="space-y-3">
      <div>
        <h2 className="font-display text-xl">Connected accounts</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Sign-in methods linked to your Hey SaaS account.
        </p>
      </div>

      <div className="rounded-2xl border border-hairline bg-surface p-5">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-hairline bg-background">
              <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden>
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"/>
              </svg>
            </span>
            <div className="min-w-0">
              <div className="text-sm font-medium">Google</div>
              {identities === null ? (
                <div className="text-xs text-muted-foreground">Checking…</div>
              ) : google ? (
                <div className="text-xs text-muted-foreground truncate">
                  Connected as {(google.identity_data?.email as string) || (google.identity_data?.name as string) || "your Google account"}
                </div>
              ) : (
                <div className="text-xs text-muted-foreground">Not connected</div>
              )}
            </div>
          </div>

          {identities !== null && (
            google ? (
              <Button
                variant="outline"
                size="sm"
                className="rounded-full"
                onClick={unlinkGoogle}
                disabled={busy === google.id || !canUnlink}
                title={canUnlink ? undefined : "Add another sign-in method before unlinking"}
              >
                {busy === google.id ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                Disconnect
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                className="rounded-full"
                onClick={linkGoogle}
                disabled={linking}
              >
                {linking ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                Connect
              </Button>
            )
          )}
        </div>
        {identities !== null && google && !canUnlink && (
          <p className="mt-3 text-xs text-muted-foreground">
            Google is currently your only sign-in method. Set a password first if you want to disconnect it.
          </p>
        )}
      </div>
    </section>
  );
}


type NotifPrefs = {
  email_prefs: Record<string, boolean>;
  inapp_prefs: Record<string, boolean>;
  quiet_hours_enabled: boolean;
  quiet_hours_start: number;
  quiet_hours_end: number;
  timezone: string;
};

const NOTIF_TYPES: Array<{ id: string; label: string; desc: string }> = [
  { id: "new_message", label: "New messages", desc: "Someone sends you a message in a swap room" },
  { id: "swap_update", label: "Swap updates", desc: "Status changes, ratings, disputes" },
  { id: "offer", label: "Offers", desc: "New swap proposals or replies" },
  { id: "payment", label: "Payments", desc: "Fee receipts, refunds, failures" },
  { id: "system", label: "System & account", desc: "Security alerts, admin actions" },
  { id: "digest", label: "Saved-search digest", desc: "Daily email when new listings match" },
  { id: "promo", label: "Product news", desc: "Occasional updates and tips" },
];

function NotificationPrefsSection() {
  const getPrefs = useServerFn(getNotificationPrefs);
  const savePrefs = useServerFn(updateNotificationPrefs);
  const [prefs, setPrefs] = useState<NotifPrefs | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const p = await getPrefs({});
      setPrefs(p as any);
    })();
  }, []);

  async function persist(patch: Partial<NotifPrefs>) {
    if (!prefs) return;
    const next = { ...prefs, ...patch };
    setPrefs(next);
    setSaving(true);
    try {
      await savePrefs({ data: patch as any });
    } catch (e) {
      toast.error((e as Error).message || "Couldn't save");
    } finally {
      setSaving(false);
    }
  }

  if (!prefs) {
    return <div className="py-8 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>;
  }

  const tz = typeof Intl !== "undefined" ? Intl.DateTimeFormat().resolvedOptions().timeZone : "UTC";

  return (
    <div className="space-y-8">
      <section>
        <div className="flex items-baseline justify-between mb-3">
          <h2 className="font-display text-xl">Delivery per event</h2>
          {saving && <span className="text-xs text-muted-foreground">Saving…</span>}
        </div>
        <div className="rounded-2xl border border-hairline overflow-hidden">
          <div className="grid grid-cols-[1fr_auto_auto] gap-4 px-4 py-2 bg-surface text-xs uppercase tracking-wider text-muted-foreground">
            <div>Event</div><div>In-app</div><div>Email</div>
          </div>
          {NOTIF_TYPES.map((t) => (
            <div key={t.id} className="grid grid-cols-[1fr_auto_auto] gap-4 px-4 py-3 border-t border-hairline items-center">
              <div>
                <div className="text-sm font-medium">{t.label}</div>
                <div className="text-xs text-muted-foreground">{t.desc}</div>
              </div>
              <Switch
                checked={prefs.inapp_prefs[t.id] ?? true}
                onCheckedChange={(v) => persist({ inapp_prefs: { ...prefs.inapp_prefs, [t.id]: v } })}
              />
              <Switch
                checked={prefs.email_prefs[t.id] ?? true}
                onCheckedChange={(v) => persist({ email_prefs: { ...prefs.email_prefs, [t.id]: v } })}
              />
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="font-display text-xl mb-3">Quiet hours</h2>
        <div className="rounded-2xl border border-hairline p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Silence non-urgent alerts overnight</div>
              <div className="text-xs text-muted-foreground">During quiet hours, in-app pings are batched and non-critical emails are held.</div>
            </div>
            <Switch checked={prefs.quiet_hours_enabled} onCheckedChange={(v) => persist({ quiet_hours_enabled: v })} />
          </div>
          {prefs.quiet_hours_enabled && (
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-hairline">
              <div>
                <Label className="text-xs">Start</Label>
                <select
                  className="mt-1.5 w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm"
                  value={prefs.quiet_hours_start}
                  onChange={(e) => persist({ quiet_hours_start: Number(e.target.value) })}
                >
                  {Array.from({ length: 24 }, (_, h) => <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>)}
                </select>
              </div>
              <div>
                <Label className="text-xs">End</Label>
                <select
                  className="mt-1.5 w-full rounded-md border border-hairline bg-background px-3 py-2 text-sm"
                  value={prefs.quiet_hours_end}
                  onChange={(e) => persist({ quiet_hours_end: Number(e.target.value) })}
                >
                  {Array.from({ length: 24 }, (_, h) => <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <Label className="text-xs">Timezone</Label>
                <div className="mt-1.5 flex items-center gap-2">
                  <Input value={prefs.timezone} onChange={(e) => setPrefs({ ...prefs, timezone: e.target.value })} onBlur={() => persist({ timezone: prefs.timezone })} className="h-9" />
                  {prefs.timezone !== tz && (
                    <Button variant="outline" size="sm" onClick={() => persist({ timezone: tz })}>Use {tz}</Button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

// ---------- Accessibility / Motion ----------
import { useMotionPreference, type MotionPreference } from "@/lib/motion";

function AccessibilitySection() {
  const [pref, reduced, setPref] = useMotionPreference();
  const options: { value: MotionPreference; label: string; desc: string }[] = [
    { value: "system", label: "Match system", desc: "Follow your OS 'Reduce motion' setting." },
    { value: "full", label: "Full animations", desc: "Enable transitions, reveals, and counters." },
    { value: "reduced", label: "Reduced motion", desc: "Minimize motion, disable smooth scrolling." },
  ];
  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h3 className="font-display text-2xl">Motion</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Currently applied: <span className="font-medium text-foreground">{reduced ? "Reduced" : "Full"}</span>
        </p>
      </div>
      <div role="radiogroup" aria-label="Motion preference" className="grid gap-3">
        {options.map((o) => {
          const active = pref === o.value;
          return (
            <button
              key={o.value}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => setPref(o.value)}
              className={
                "text-left rounded-2xl border p-4 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring " +
                (active
                  ? "border-violet/60 bg-violet/5"
                  : "border-hairline bg-surface hover:border-foreground/25")
              }
            >
              <div className="flex items-center justify-between">
                <div className="font-medium">{o.label}</div>
                <span
                  className={
                    "h-4 w-4 rounded-full border " +
                    (active ? "border-violet bg-violet" : "border-muted-foreground/50")
                  }
                  aria-hidden
                />
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{o.desc}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
