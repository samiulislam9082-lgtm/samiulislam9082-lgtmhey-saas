import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { markNotificationRead, markAllNotificationsRead } from "@/lib/notifications.functions";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, CheckCheck, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard/notifications")({
  head: () => ({ meta: [{ title: "Notifications — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: NotificationsPage,
});

type N = { id: string; type: string; title: string; body: string | null; link: string | null; read_at: string | null; created_at: string };

const FILTERS = [
  { id: "all", label: "All" },
  { id: "unread", label: "Unread" },
  { id: "swap", label: "Swaps", match: (t: string) => t.startsWith("swap") || t.includes("offer") },
  { id: "message", label: "Messages", match: (t: string) => t.includes("message") },
  { id: "payment", label: "Payments", match: (t: string) => t.includes("payment") || t.includes("fee") },
  { id: "system", label: "System", match: (t: string) => t.includes("system") || t.includes("admin") || t.includes("report") },
] as const;

function NotificationsPage() {
  const [items, setItems] = useState<N[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");
  const markOne = useServerFn(markNotificationRead);
  const markAll = useServerFn(markAllNotificationsRead);

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase
      .from("notifications")
      .select("id, type, title, body, link, read_at, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(200);
    setItems((data || []) as N[]);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const unread = items.filter((i) => !i.read_at).length;

  const filtered = useMemo(() => {
    if (filter === "all") return items;
    if (filter === "unread") return items.filter((i) => !i.read_at);
    const f = FILTERS.find((x) => x.id === filter);
    if (!f || !("match" in f)) return items;
    return items.filter((i) => f.match!(i.type ?? ""));
  }, [items, filter]);

  async function deleteOne(id: string) {
    const prev = items;
    setItems(items.filter((i) => i.id !== id));
    const { error } = await supabase.from("notifications").delete().eq("id", id);
    if (error) { setItems(prev); toast.error("Couldn't delete"); }
  }

  async function clearRead() {
    const ids = items.filter((i) => i.read_at).map((i) => i.id);
    if (!ids.length) return;
    const prev = items;
    setItems(items.filter((i) => !i.read_at));
    const { error } = await supabase.from("notifications").delete().in("id", ids);
    if (error) { setItems(prev); toast.error("Couldn't clear"); }
    else toast.success(`Cleared ${ids.length} read`);
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="notifications"
              eyebrow={unread > 0 ? `${unread} unread` : "All caught up"}
              title="Notifications"
              description="Swap invites, message pings, safety-fee receipts and platform news — quietly curated."
              actions={
                <div className="flex items-center gap-2">
                  {items.some((i) => i.read_at) && (
                    <Button variant="ghost" size="sm" onClick={clearRead} className="rounded-full">
                      <Trash2 className="h-4 w-4 mr-2" />Clear read
                    </Button>
                  )}
                  {unread > 0 && (
                    <Button variant="outline" size="sm" onClick={async () => { await markAll({}); load(); }} className="rounded-full">
                      <CheckCheck className="h-4 w-4 mr-2" />Mark all read
                    </Button>
                  )}
                </div>
              }
            />
            <DashRibbon variant="notifications" />
            <DashBodyBlock variant="notifications" />


            <div className="mt-8 hs-seg overflow-x-auto max-w-full">
              {FILTERS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setFilter(t.id)}
                  className={`hs-seg-item ${filter === t.id ? "active" : ""}`}
                >
                  {t.label}
                  {t.id === "unread" && unread > 0 && <span className="ml-1.5 opacity-80">({unread})</span>}
                </button>
              ))}
            </div>

            <div className="mt-6">
              {loading ? (
                <div className="flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
              ) : filtered.length === 0 ? (
                <div className="hs-empty">
                  <div className="hs-empty-icon"><Bell className="h-6 w-6" /></div>
                  <p className="mt-5 font-display text-3xl">{items.length === 0 ? "You're all caught up." : "Nothing in this filter."}</p>
                  <p className="mt-2 text-sm text-muted-foreground">We'll ping you the moment a swap, message or receipt lands.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filtered.map((n) => (
                    <div key={n.id} className="group relative">
                      <NotifCard n={n} onMark={() => !n.read_at && markOne({ data: { id: n.id } })} />
                      <button
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); deleteOne(n.id); }}
                        className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-full hover:bg-destructive/15 text-muted-foreground hover:text-destructive"
                        aria-label="Delete notification"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function NotifCard({ n, onMark }: { n: N; onMark: () => void }) {
  const body = (
    <Card className={`p-4 pr-12 hover:border-violet/40 transition-colors ${!n.read_at ? "bg-violet/5 border-violet/30" : ""}`}>
      <div className="flex items-start gap-3">
        <div className={`h-2 w-2 mt-2 rounded-full ${!n.read_at ? "bg-violet-glow shadow-[0_0_10px_var(--violet-glow)]" : "bg-transparent"}`} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-3">
            <div className="font-medium text-sm">{n.title}</div>
            <div className="text-xs text-muted-foreground shrink-0">{new Date(n.created_at).toLocaleDateString()}</div>
          </div>
          {n.body && <div className="text-sm text-muted-foreground mt-1">{n.body}</div>}
        </div>
      </div>
    </Card>
  );
  return n.link ? <Link to={n.link} onClick={onMark}>{body}</Link> : <div>{body}</div>;
}
