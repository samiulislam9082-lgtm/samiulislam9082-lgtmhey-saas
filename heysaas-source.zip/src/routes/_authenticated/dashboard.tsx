import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: () => (
    <div className="hs-noir">
      <Outlet />
    </div>
  ),
});
