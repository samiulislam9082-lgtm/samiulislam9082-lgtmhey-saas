import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, Users, Gift, Share2, Twitter, Linkedin, Mail } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/referrals")({
  head: () => ({ meta: [{ title: "Referrals — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: ReferralsPage,
});

function ReferralsPage() {
  const [userId, setUserId] = useState<string | null>(null);
  const [signedIn, setSignedIn] = useState<number>(0);
  const [listed, setListed] = useState<number>(0);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      // Best-effort: count profiles referred by this user, if column exists.
      const { count: sc } = await supabase
        .from("profiles")
        .select("id", { count: "exact", head: true })
        .eq("referred_by" as any, user.id);
      setSignedIn(sc ?? 0);
      const { count: lc } = await supabase
        .from("saas_listings")
        .select("id", { count: "exact", head: true })
        .in(
          "owner_id" as any,
          (await supabase.from("profiles").select("id").eq("referred_by" as any, user.id)).data?.map((p: any) => p.id) ?? ["00000000-0000-0000-0000-000000000000"]
        );
      setListed(lc ?? 0);
    })();
  }, []);

  const link = useMemo(() => {
    const base = typeof window !== "undefined" ? window.location.origin : "https://heysaas.co";
    return userId ? `${base}/?ref=${userId}` : `${base}/`;
  }, [userId]);

  const share = {
    x: `https://twitter.com/intent/tweet?text=${encodeURIComponent("I'm swapping SaaS on Hey SaaS — join me:")}&url=${encodeURIComponent(link)}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(link)}`,
    email: `mailto:?subject=${encodeURIComponent("Swap SaaS with me on Hey SaaS")}&body=${encodeURIComponent(`Join Hey SaaS — the marketplace where founders swap SaaS instead of paying cash. ${link}`)}`,
  };

  function copy() {
    navigator.clipboard.writeText(link);
    toast.success("Referral link copied");
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="overview"
              eyebrow="Growth loop"
              title="Refer founders, earn credits"
              description="Every founder who signs up with your link earns you $25 in promotion credits. Every SaaS they list adds $50."
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <Stat icon={Users} label="Founders signed up" value={signedIn} />
              <Stat icon={Gift} label="SaaS they listed" value={listed} />
              <Stat icon={Share2} label="Credits earned" value={`$${signedIn * 25 + listed * 50}`} />
            </div>

            <Card className="p-5 mt-6">
              <div className="text-sm text-muted-foreground mb-2">Your unique referral link</div>
              <div className="flex flex-col sm:flex-row gap-2">
                <Input readOnly value={link} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
                <Button onClick={copy}><Copy className="h-4 w-4 mr-2" /> Copy</Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-4">
                <a href={share.x} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:border-primary/50">
                  <Twitter className="h-4 w-4" /> Share on X
                </a>
                <a href={share.linkedin} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:border-primary/50">
                  <Linkedin className="h-4 w-4" /> Share on LinkedIn
                </a>
                <a href={share.email} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:border-primary/50">
                  <Mail className="h-4 w-4" /> Email a founder
                </a>
              </div>
            </Card>

            <Card className="p-5 mt-6">
              <div className="font-medium mb-2">How rewards work</div>
              <ol className="list-decimal pl-5 space-y-1 text-sm text-muted-foreground">
                <li>Founder signs up via your link — you get <span className="text-primary font-medium">$25</span> in Hey SaaS credit.</li>
                <li>They publish their first SaaS listing — you get an extra <span className="text-primary font-medium">$50</span>.</li>
                <li>Credits apply automatically to promotions and safety fees at checkout.</li>
                <li>No cap. Refer as many founders as you like — payouts compound.</li>
              </ol>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: number | string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground mb-2">
        <Icon className="h-4 w-4 text-primary" /> {label}
      </div>
      <div className="text-3xl font-display italic">{value}</div>
    </Card>
  );
}
