import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Eye, Bookmark, TrendingUp, Plus, Trash2, ExternalLink, Radio } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/competitor-watch")({
  head: () => ({ meta: [{ title: "Competitor watch — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: CompetitorWatchPage,
});

type Snap = { views: number; bookmarks: number; ts: string };
type Watched = { id: string; listing_id: string; name: string; slug: string; snapshots: Snap[] };

function CompetitorWatchPage() {
  const [uid, setUid] = useState<string | null>(null);
  const [watched, setWatched] = useState<Watched[]>([]);
  const [available, setAvailable] = useState<{ id: string; name: string; slug: string; view_count: number; bookmark_count: number }[]>([]);
  const [q, setQ] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUid(user.id);
      try { const raw = localStorage.getItem(`hs.competitors.${user.id}`); if (raw) setWatched(JSON.parse(raw)); } catch {}
      const { data } = await supabase.from("saas_listings").select("id, name, slug, view_count, bookmark_count").eq("status", "live").neq("owner_id", user.id).order("view_count", { ascending: false }).limit(200);
      setAvailable((data as any) ?? []);
    })();
  }, []);

  const persist = (n: Watched[]) => { setWatched(n); if (uid) localStorage.setItem(`hs.competitors.${uid}`, JSON.stringify(n)); };

  const addWatch = (l: { id: string; name: string; slug: string; view_count: number; bookmark_count: number }) => {
    if (watched.some((w) => w.listing_id === l.id)) { toast.error("Already watching"); return; }
    persist([{ id: crypto.randomUUID(), listing_id: l.id, name: l.name, slug: l.slug, snapshots: [{ views: l.view_count ?? 0, bookmarks: l.bookmark_count ?? 0, ts: new Date().toISOString() }] }, ...watched]);
    toast.success(`Watching ${l.name}`);
  };

  const remove = (id: string) => persist(watched.filter((w) => w.id !== id));

  const refreshAll = async () => {
    if (watched.length === 0) return;
    setRefreshing(true);
    const ids = watched.map((w) => w.listing_id);
    const { data } = await supabase.from("saas_listings").select("id, view_count, bookmark_count").in("id", ids);
    const byId = new Map((data ?? []).map((r: any) => [r.id, r]));
    const now = new Date().toISOString();
    const updated = watched.map((w) => {
      const r = byId.get(w.listing_id);
      if (!r) return w;
      const snap: Snap = { views: r.view_count ?? 0, bookmarks: r.bookmark_count ?? 0, ts: now };
      return { ...w, snapshots: [...w.snapshots.slice(-29), snap] };
    });
    persist(updated);
    setRefreshing(false);
    toast.success("Snapshot captured");
  };

  const filteredAvail = useMemo(() => {
    if (!q) return available.slice(0, 12);
    return available.filter((a) => a.name.toLowerCase().includes(q.toLowerCase())).slice(0, 20);
  }, [available, q]);

  const delta = (w: Watched, k: keyof Snap) => {
    if (w.snapshots.length < 2) return 0;
    const first = w.snapshots[0][k] as number;
    const last = w.snapshots[w.snapshots.length - 1][k] as number;
    return last - first;
  };

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <div className="hs-noir hs-dash-shell flex-1">
        <div className="hs-dash-canvas" aria-hidden="true">
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--one" />
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--two" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col lg:flex-row gap-8 relative">
          <DashboardSidebar />
          <main id="main" className="flex-1 min-w-0 space-y-6">
            <BackButton />
            <DashHero
              eyebrow="Marketing · Radar"
              title="Watch the listings you're competing with."
              description="Pin up to a dozen rivals, then check back weekly. We store snapshots so you can see who's actually moving the needle."
              signature="overview"
              actions={
                <>
                  <Button variant="outline" size="sm" onClick={refreshAll} disabled={refreshing || watched.length === 0}>
                    <Radio className="w-4 h-4 mr-2" />{refreshing ? "Capturing…" : "Capture snapshot"}
                  </Button>
                  <Badge variant="secondary">{watched.length} on radar</Badge>
                </>
              }
            />

            <Card className="p-5">
              <div className="flex items-center justify-between gap-3 mb-3">
                <h3 className="text-sm font-medium">Add a competitor</h3>
                <Input placeholder="Search marketplace…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
              </div>
              {filteredAvail.length === 0 ? (
                <p className="text-xs text-muted-foreground">No matches.</p>
              ) : (
                <div className="grid gap-2 md:grid-cols-2">
                  {filteredAvail.map((l) => (
                    <div key={l.id} className="flex items-center gap-3 p-3 rounded-lg border border-white/5 hover:bg-white/5">
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium truncate">{l.name}</div>
                        <div className="text-[11px] text-muted-foreground">{l.view_count ?? 0} views · {l.bookmark_count ?? 0} bookmarks</div>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => addWatch(l)}><Plus className="w-3 h-3 mr-1" />Watch</Button>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {watched.length === 0 ? (
              <Card className="p-10 text-center text-sm text-muted-foreground">
                <Radio className="w-8 h-8 mx-auto opacity-40 mb-2" />
                Pin a few competitors above to start tracking.
              </Card>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {watched.map((w) => {
                  const last = w.snapshots[w.snapshots.length - 1];
                  const dv = delta(w, "views"), db = delta(w, "bookmarks");
                  return (
                    <Card key={w.id} className="p-5">
                      <div className="flex items-start gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="font-medium truncate">{w.name}</div>
                          <div className="text-xs text-muted-foreground">Since {new Date(w.snapshots[0].ts).toLocaleDateString()} · {w.snapshots.length} snapshots</div>
                        </div>
                        <Link to="/l/$slug" params={{ slug: w.slug }} className="text-cyan-300 text-xs hover:underline flex items-center gap-1">
                          Open <ExternalLink className="w-3 h-3" />
                        </Link>
                      </div>
                      <div className="mt-4 grid grid-cols-2 gap-3">
                        <div className="p-3 rounded-lg bg-white/[0.03] border border-white/5">
                          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground"><Eye className="w-3 h-3" /> Views</div>
                          <div className="mt-1 font-display text-2xl">{last.views}</div>
                          <div className={`text-[11px] ${dv > 0 ? "text-emerald-300" : dv < 0 ? "text-rose-300" : "text-muted-foreground"}`}>
                            <TrendingUp className="w-3 h-3 inline mr-1" />{dv > 0 ? "+" : ""}{dv}
                          </div>
                        </div>
                        <div className="p-3 rounded-lg bg-white/[0.03] border border-white/5">
                          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-muted-foreground"><Bookmark className="w-3 h-3" /> Bookmarks</div>
                          <div className="mt-1 font-display text-2xl">{last.bookmarks}</div>
                          <div className={`text-[11px] ${db > 0 ? "text-emerald-300" : db < 0 ? "text-rose-300" : "text-muted-foreground"}`}>
                            <TrendingUp className="w-3 h-3 inline mr-1" />{db > 0 ? "+" : ""}{db}
                          </div>
                        </div>
                      </div>
                      <div className="mt-3 flex justify-end">
                        <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => remove(w.id)}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
