import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: AdminOverview,
});

type Kpis = {
  founders: number;
  listings: number;
  liveListings: number;
  draftListings: number;
  openReports: number;
  totalReports: number;
  disputes: number;
  swapsCompleted: number;
  swapsCompletedWeek: number;
  paymentsRevenueCents: number;
  activePromotions: number;
  newsletter: number;
};

function AdminOverview() {
  const [k, setK] = useState<Kpis | null>(null);

  useEffect(() => {
    (async () => {
      const weekAgo = new Date(Date.now() - 7 * 864e5).toISOString();
      const nowIso = new Date().toISOString();
      const [
        foundersC,
        listingsC,
        liveC,
        draftC,
        openReportsC,
        totalReportsC,
        disputesC,
        completedC,
        completedWeekC,
        payments,
        activePromosC,
        newsletterC,
      ] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("saas_listings").select("id", { count: "exact", head: true }),
        supabase.from("saas_listings").select("id", { count: "exact", head: true }).eq("status", "live"),
        supabase.from("saas_listings").select("id", { count: "exact", head: true }).eq("status", "draft"),
        supabase.from("reports").select("id", { count: "exact", head: true }).eq("status", "open"),
        supabase.from("reports").select("id", { count: "exact", head: true }),
        supabase.from("swap_requests").select("id", { count: "exact", head: true }).eq("status", "disputed"),
        supabase.from("swap_requests").select("id", { count: "exact", head: true }).eq("status", "completed"),
        supabase
          .from("swap_requests")
          .select("id", { count: "exact", head: true })
          .eq("status", "completed")
          .gte("completed_at", weekAgo),
        supabase.from("payments").select("amount_cents, status").eq("status", "succeeded"),
        supabase
          .from("promotions")
          .select("id", { count: "exact", head: true })
          .lte("starts_at", nowIso)
          .gte("ends_at", nowIso),
        supabase.from("newsletter_subscribers").select("id", { count: "exact", head: true }),
      ]);

      const revenue = (payments.data ?? []).reduce((s: number, r: any) => s + (r.amount_cents ?? 0), 0);

      setK({
        founders: foundersC.count ?? 0,
        listings: listingsC.count ?? 0,
        liveListings: liveC.count ?? 0,
        draftListings: draftC.count ?? 0,
        openReports: openReportsC.count ?? 0,
        totalReports: totalReportsC.count ?? 0,
        disputes: disputesC.count ?? 0,
        swapsCompleted: completedC.count ?? 0,
        swapsCompletedWeek: completedWeekC.count ?? 0,
        paymentsRevenueCents: revenue,
        activePromotions: activePromosC.count ?? 0,
        newsletter: newsletterC.count ?? 0,
      });
    })();
  }, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-4xl">Admin overview</h1>
          <p className="mt-2 text-sm text-muted-foreground">Live platform health. Refresh the page to update.</p>
        </div>
      </div>

      {!k ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-28 rounded-2xl border border-hairline bg-surface animate-pulse" />
          ))}
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Founders" value={k.founders} to="/admin/founders" />
            <Stat label="Live listings" value={k.liveListings} sub={`${k.listings} total · ${k.draftListings} draft`} to="/admin/listings" />
            <Stat label="Swaps completed" value={k.swapsCompleted} sub={`${k.swapsCompletedWeek} in last 7 days`} />
            <Stat label="Revenue" value={`$${(k.paymentsRevenueCents / 100).toLocaleString(undefined, { maximumFractionDigits: 0 })}`} sub="Safety fees + promotions" />
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Open reports" value={k.openReports} sub={`${k.totalReports} lifetime`} to="/admin/reports" tone={k.openReports > 0 ? "warn" : undefined} />
            <Stat label="Active disputes" value={k.disputes} to="/admin/disputes" tone={k.disputes > 0 ? "warn" : undefined} />
            <Stat label="Active promotions" value={k.activePromotions} />
            <Stat label="Newsletter" value={k.newsletter} />
          </div>
        </>
      )}
    </div>
  );
}

function Stat({
  label,
  value,
  sub,
  to,
  tone,
}: {
  label: string;
  value: number | string;
  sub?: string;
  to?: string;
  tone?: "warn";
}) {
  const inner = (
    <Card className={`p-6 h-full ${tone === "warn" ? "border-amber-500/40" : ""}`}>
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-2 font-display text-4xl tabular-nums">{value}</div>
      {sub && <div className="mt-2 text-xs text-muted-foreground">{sub}</div>}
    </Card>
  );
  if (to) {
    return (
      <Link to={to} className="block transition-transform hover:-translate-y-0.5">
        {inner}
      </Link>
    );
  }
  return inner;
}
