import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { retryWebhookDelivery } from "@/lib/support-webhooks.functions";
import { CheckCircle2, XCircle, MinusCircle, RefreshCw, Filter, Clock, RotateCw, Eye, Download, Copy, X, Skull, CalendarDays, Search } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/support-webhooks")({
  head: () => ({ meta: [{ title: "Webhook deliveries — Admin" }, { name: "robots", content: "noindex" }] }),
  component: WebhookDeliveries,
});

type DeliveryStatus = "sent" | "failed" | "not_configured" | "pending" | "retrying" | "dead_letter";

type Delivery = {
  id: string;
  channel: "slack" | "teams";
  kind: "ticket" | "alert" | "test";
  status: DeliveryStatus;
  http_status: number | null;
  error: string | null;
  ticket_id: string | null;
  alert_id: string | null;
  meta: Record<string, unknown> | null;
  payload: unknown | null;
  target: string | null;
  failure_reason: string | null;
  dead_lettered_at: string | null;
  created_at: string;
  attempt_count: number | null;
  max_attempts: number | null;
  next_attempt_at: string | null;
  last_attempt_at: string | null;
};


type ChannelFilter = "all" | "slack" | "teams";
type StatusFilter = "all" | DeliveryStatus;
type KindFilter = "all" | "ticket" | "alert" | "test";
type DateField = "created_at" | "last_attempt_at" | "next_attempt_at";
type RangePreset = "all" | "1h" | "24h" | "7d" | "30d" | "custom";

const RANGE_HOURS: Record<Exclude<RangePreset, "all" | "custom">, number> = {
  "1h": 1, "24h": 24, "7d": 24 * 7, "30d": 24 * 30,
};

const DATE_FIELD_LABEL: Record<DateField, string> = {
  created_at: "Sent",
  last_attempt_at: "Last attempt",
  next_attempt_at: "Next retry",
};

function toLocalInput(d: Date) {
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60_000).toISOString().slice(0, 16);
}

function WebhookDeliveries() {
  const [rows, setRows] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState(true);
  const [channel, setChannel] = useState<ChannelFilter>("all");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [kind, setKind] = useState<KindFilter>("all");
  const [dateField, setDateField] = useState<DateField>("created_at");
  const [rangePreset, setRangePreset] = useState<RangePreset>("all");
  const [customFrom, setCustomFrom] = useState<string>(toLocalInput(new Date(Date.now() - 7 * 86400_000)));
  const [customTo, setCustomTo] = useState<string>(toLocalInput(new Date()));
  const [retrying, setRetrying] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkRunning, setBulkRunning] = useState(false);
  const [bulkProgress, setBulkProgress] = useState<{ done: number; total: number } | null>(null);
  const [viewing, setViewing] = useState<Delivery | null>(null);
  const [search, setSearch] = useState<string>("");

  const retry = useServerFn(retryWebhookDelivery);

  const dateBounds = useMemo<{ from: Date | null; to: Date | null }>(() => {
    if (rangePreset === "all") return { from: null, to: null };
    if (rangePreset === "custom") {
      const from = customFrom ? new Date(customFrom) : null;
      const to = customTo ? new Date(customTo) : null;
      return { from, to };
    }
    const to = new Date();
    const from = new Date(to.getTime() - RANGE_HOURS[rangePreset] * 3600_000);
    return { from, to };
  }, [rangePreset, customFrom, customTo]);

  const load = async () => {
    setLoading(true);
    let q = supabase
      .from("support_webhook_deliveries")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(500);
    // Server-side filter only when using created_at, which the base ordering already indexes on.
    if (dateField === "created_at") {
      if (dateBounds.from) q = q.gte("created_at", dateBounds.from.toISOString());
      if (dateBounds.to) q = q.lte("created_at", dateBounds.to.toISOString());
    }
    const { data } = await q;
    setRows((data as Delivery[]) ?? []);
    setSelected(new Set());
    setLoading(false);
  };

  useEffect(() => { void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [dateField, rangePreset, customFrom, customTo]);

  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return rows.filter(r => {
      if (channel !== "all" && r.channel !== channel) return false;
      if (status !== "all" && r.status !== status) return false;
      if (kind !== "all" && r.kind !== kind) return false;
      if (dateField !== "created_at" && (dateBounds.from || dateBounds.to)) {
        const v = r[dateField];
        if (!v) return false;
        const t = new Date(v).getTime();
        if (dateBounds.from && t < dateBounds.from.getTime()) return false;
        if (dateBounds.to && t > dateBounds.to.getTime()) return false;
      }
      if (needle) {
        const hay = [
          r.channel, r.kind, r.status,
          r.http_status != null ? String(r.http_status) : "",
          r.error ?? "",
          r.failure_reason ?? "",
          r.target ?? "",
          r.ticket_id ?? "",
          r.alert_id ?? "",
          r.payload != null ? JSON.stringify(r.payload) : "",
          r.meta != null ? JSON.stringify(r.meta) : "",
        ].join(" \u0001 ").toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
  }, [rows, channel, status, kind, dateField, dateBounds, search]);



  const isRetryable = (r: Delivery) => r.status === "failed" || r.status === "retrying" || r.status === "pending" || r.status === "dead_letter";
  const retryableFiltered = useMemo(() => filtered.filter(isRetryable), [filtered]);
  const selectedRetryable = useMemo(
    () => retryableFiltered.filter(r => selected.has(r.id)),
    [retryableFiltered, selected]
  );
  const allSelected = retryableFiltered.length > 0 && retryableFiltered.every(r => selected.has(r.id));

  const toggleAll = () => {
    setSelected(prev => {
      if (allSelected) {
        const next = new Set(prev);
        for (const r of retryableFiltered) next.delete(r.id);
        return next;
      }
      const next = new Set(prev);
      for (const r of retryableFiltered) next.add(r.id);
      return next;
    });
  };

  const toggleOne = (id: string) =>
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });

  const stats = useMemo(() => {
    const s: Record<DeliveryStatus | "total", number> = {
      total: rows.length, sent: 0, failed: 0, not_configured: 0, pending: 0, retrying: 0, dead_letter: 0,
    };
    for (const r of rows) s[r.status] = (s[r.status] ?? 0) + 1;
    return s;
  }, [rows]);

  const doRetry = async (id: string) => {
    setRetrying(id);
    try {
      const res = await retry({ data: { id } });
      toast.message(res.sent ? "✅ Delivered" : `Retry: ${res.finalStatus}${res.error ? ` — ${res.error}` : ""}`);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Retry failed");
    } finally {
      setRetrying(null);
    }
  };

  const bulkRetry = async (ids: string[]) => {
    if (ids.length === 0) return;
    if (!confirm(`Retry ${ids.length} webhook ${ids.length === 1 ? "delivery" : "deliveries"} now?`)) return;
    setBulkRunning(true);
    setBulkProgress({ done: 0, total: ids.length });
    let sent = 0, failed = 0;
    // Small concurrency to avoid hammering the provider
    const concurrency = 4;
    let cursor = 0;
    const worker = async () => {
      while (cursor < ids.length) {
        const i = cursor++;
        const id = ids[i];
        try {
          const res = await retry({ data: { id } });
          if (res.sent) sent++; else failed++;
        } catch { failed++; }
        setBulkProgress({ done: Math.min(i + 1, ids.length), total: ids.length });
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, ids.length) }, worker));
    setBulkRunning(false);
    setBulkProgress(null);
    toast.success(`Bulk retry complete — ${sent} delivered, ${failed} still failing`);
    await load();
  };


  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-serif tracking-tight">Webhook deliveries</h1>
          <p className="text-sm text-muted-foreground">Delivery history for Slack &amp; Microsoft Teams support webhooks. Failed deliveries retry automatically with exponential backoff (1m → 12h, up to 6 attempts).</p>
        </div>
        <button onClick={load} className="inline-flex items-center gap-1 rounded-md border border-hairline px-3 py-1.5 text-xs hover:bg-violet/10">
          <RefreshCw className="h-3 w-3" /> Refresh
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
        <Stat label="Total" value={stats.total} />
        <Stat label="Sent" value={stats.sent} tone="ok" />
        <Stat label="Retrying" value={stats.retrying} tone="warn" />
        <Stat label="Pending" value={stats.pending} tone="muted" />
        <Stat label="Failed" value={stats.failed} tone="err" />
        <Stat label="Dead-lettered" value={stats.dead_letter} tone="err" />
        <Stat label="Not configured" value={stats.not_configured} tone="muted" />
      </div>

      {stats.dead_letter > 0 && (
        <div className="rounded-xl border border-red-500/40 bg-red-500/5 p-4 flex flex-wrap items-center gap-3">
          <Skull className="h-4 w-4 text-red-400" />
          <div className="text-xs">
            <div className="font-medium">{stats.dead_letter} deliveries exhausted all retries.</div>
            <div className="text-muted-foreground">They will not retry automatically. Inspect the payload, fix the cause, then hit Retry.</div>
          </div>
          <button
            onClick={() => setStatus("dead_letter")}
            className="ml-auto inline-flex items-center gap-1 rounded-md border border-red-500/40 px-2.5 py-1 text-[11px] hover:bg-red-500/10"
          >
            View dead-letter queue
          </button>
        </div>
      )}

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={channel} onChange={v => setChannel(v as ChannelFilter)} options={["all","slack","teams"]} label="Channel" />
          <Select value={status} onChange={v => setStatus(v as StatusFilter)} options={["all","sent","retrying","pending","failed","dead_letter","not_configured"]} label="Status" />
          <Select value={kind} onChange={v => setKind(v as KindFilter)} options={["all","ticket","alert","test"]} label="Kind" />
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input
              type="search"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search channel, kind, HTTP code, error, target, IDs, payload…"
              className="w-full rounded-md border border-hairline bg-background pl-7 pr-7 py-1.5 text-xs placeholder:text-muted-foreground/70 focus:outline-none focus:ring-1 focus:ring-primary/40"
              aria-label="Search deliveries"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          <div className="ml-auto text-[11px] text-muted-foreground">{filtered.length} of {rows.length}</div>
        </div>


        <div className="flex flex-wrap items-center gap-2 mb-4 rounded-lg border border-hairline bg-background/40 px-3 py-2">
          <CalendarDays className="h-4 w-4 text-muted-foreground" />
          <label className="text-[11px] text-muted-foreground">Date field</label>
          <select
            value={dateField}
            onChange={e => setDateField(e.target.value as DateField)}
            className="rounded-md border border-hairline bg-background px-2 py-1 text-xs"
          >
            <option value="created_at">Sent</option>
            <option value="last_attempt_at">Last attempt</option>
            <option value="next_attempt_at">Next retry</option>
          </select>
          <div className="inline-flex rounded-full border border-hairline p-1 flex-wrap">
            {(["all","1h","24h","7d","30d","custom"] as RangePreset[]).map(p => (
              <button
                key={p}
                onClick={() => setRangePreset(p)}
                className={`px-2.5 py-0.5 text-[11px] rounded-full ${rangePreset === p ? "bg-secondary" : "text-muted-foreground hover:text-foreground"}`}
              >
                {p === "all" ? "All" : p === "custom" ? "Custom" : p}
              </button>
            ))}
          </div>
          {rangePreset === "custom" && (
            <div className="flex items-end gap-2">
              <label className="flex flex-col gap-0.5 text-[10px] text-muted-foreground">
                From
                <input type="datetime-local" value={customFrom} onChange={e => setCustomFrom(e.target.value)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs" />
              </label>
              <label className="flex flex-col gap-0.5 text-[10px] text-muted-foreground">
                To
                <input type="datetime-local" value={customTo} onChange={e => setCustomTo(e.target.value)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs" />
              </label>
            </div>
          )}
          {rangePreset !== "all" && dateBounds.from && dateBounds.to && (
            <span className="ml-auto text-[11px] text-muted-foreground">
              {DATE_FIELD_LABEL[dateField]}: {dateBounds.from.toLocaleString()} → {dateBounds.to.toLocaleString()}
              <button onClick={() => setRangePreset("all")} className="ml-2 inline-flex items-center gap-0.5 rounded border border-hairline px-1.5 py-0.5 hover:bg-secondary">
                <X className="h-3 w-3"/> Clear
              </button>
            </span>
          )}
        </div>


        <div className="flex flex-wrap items-center gap-2 mb-3 rounded-lg border border-hairline bg-background/40 px-3 py-2">
          <span className="text-[11px] text-muted-foreground">
            {selectedRetryable.length} selected
            {bulkProgress ? ` — retrying ${bulkProgress.done}/${bulkProgress.total}` : ""}
          </span>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <button
              onClick={() => bulkRetry(selectedRetryable.map(r => r.id))}
              disabled={bulkRunning || selectedRetryable.length === 0}
              className="inline-flex items-center gap-1 rounded-md border border-hairline px-2.5 py-1 text-[11px] hover:bg-violet/10 disabled:opacity-50"
            >
              <RotateCw className={`h-3 w-3 ${bulkRunning ? "animate-spin" : ""}`} />
              Retry selected
            </button>
            <button
              onClick={() => bulkRetry(retryableFiltered.map(r => r.id))}
              disabled={bulkRunning || retryableFiltered.length === 0}
              className="inline-flex items-center gap-1 rounded-md border border-hairline px-2.5 py-1 text-[11px] hover:bg-violet/10 disabled:opacity-50"
              title="Retry every failed / retrying / pending row matching current filters"
            >
              <RotateCw className={`h-3 w-3 ${bulkRunning ? "animate-spin" : ""}`} />
              Retry all failed in view ({retryableFiltered.length})
            </button>
          </div>
        </div>

        {loading ? (
          <p className="text-xs text-muted-foreground">Loading…</p>
        ) : filtered.length === 0 ? (
          <p className="text-xs text-muted-foreground">No deliveries match these filters.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wider text-muted-foreground border-b border-hairline">
                  <th className="py-2 pr-3 w-6">
                    <input
                      type="checkbox"
                      aria-label="Select all retryable in view"
                      checked={allSelected}
                      onChange={toggleAll}
                      disabled={retryableFiltered.length === 0}
                    />
                  </th>
                  <th className="py-2 pr-3">When</th>
                  <th className="py-2 pr-3">Channel</th>
                  <th className="py-2 pr-3">Kind</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2 pr-3">Attempts</th>
                  <th className="py-2 pr-3">Next retry</th>
                  <th className="py-2 pr-3">HTTP</th>
                  <th className="py-2 pr-3">Error</th>
                  <th className="py-2 pr-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(r => {
                  const retryable = isRetryable(r);
                  return (
                    <tr key={r.id} className="border-b border-hairline/50 align-top">
                      <td className="py-2 pr-3">
                        <input
                          type="checkbox"
                          aria-label="Select delivery"
                          checked={selected.has(r.id)}
                          onChange={() => toggleOne(r.id)}
                          disabled={!retryable}
                        />
                      </td>
                      <td className="py-2 pr-3 whitespace-nowrap text-muted-foreground">{new Date(r.created_at).toLocaleString()}</td>
                      <td className="py-2 pr-3"><ChannelBadge channel={r.channel} /></td>
                      <td className="py-2 pr-3 capitalize">{r.kind}</td>
                      <td className="py-2 pr-3"><StatusBadge status={r.status} /></td>
                      <td className="py-2 pr-3 tabular-nums text-muted-foreground">{r.attempt_count ?? 0}/{r.max_attempts ?? 0}</td>
                      <td className="py-2 pr-3 whitespace-nowrap text-muted-foreground">
                        {r.next_attempt_at
                          ? <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3"/>{new Date(r.next_attempt_at).toLocaleTimeString()}</span>
                          : "—"}
                      </td>
                      <td className="py-2 pr-3 tabular-nums">{r.http_status ?? "—"}</td>
                      <td className="py-2 pr-3 max-w-xs">
                        {r.failure_reason ? (
                          <span className="inline-flex items-center rounded-full border border-red-500/40 bg-red-500/10 px-2 py-0.5 text-[10px] font-medium text-red-300 capitalize mb-1">
                            {r.failure_reason.replace(/_/g, " ")}
                          </span>
                        ) : null}
                        {r.error ? <code className="block whitespace-pre-wrap break-all text-[10px] text-red-400">{r.error}</code> : (!r.failure_reason && <span className="text-muted-foreground">—</span>)}
                      </td>
                      <td className="py-2 pr-3">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => setViewing(r)}
                            className="inline-flex items-center gap-1 rounded-md border border-hairline px-2 py-1 text-[10px] hover:bg-violet/10"
                            title="Inspect payload"
                          >
                            <Eye className="h-3 w-3"/> View
                          </button>
                          {retryable ? (
                            <button
                              onClick={() => doRetry(r.id)}
                              disabled={retrying === r.id || bulkRunning}
                              className="inline-flex items-center gap-1 rounded-md border border-hairline px-2 py-1 text-[10px] hover:bg-violet/10 disabled:opacity-50"
                            >
                              <RotateCw className={`h-3 w-3 ${retrying === r.id ? "animate-spin" : ""}`}/> Retry
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {viewing && <DetailsPanel delivery={viewing} onClose={() => setViewing(null)} />}
    </div>
  );
}

type AttemptEntry = {
  n?: number;
  at?: string;
  outcome?: string;
  http_status?: number | null;
  duration_ms?: number | null;
  error?: string | null;
  response_body?: string | null;
  response_headers?: Record<string, string> | null;
};

function DetailsPanel({ delivery, onClose }: { delivery: Delivery; onClose: () => void }) {
  const [tab, setTab] = useState<"overview" | "request" | "response" | "timeline">("overview");

  const meta = (delivery.meta && typeof delivery.meta === "object" ? delivery.meta : {}) as Record<string, unknown>;
  const attempts = useMemo<AttemptEntry[]>(
    () => (Array.isArray(meta.attempts) ? (meta.attempts as AttemptEntry[]) : []),
    [meta]
  );
  const lastAttempt = attempts[attempts.length - 1];
  const requestHeaders = (meta.request_headers && typeof meta.request_headers === "object"
    ? meta.request_headers
    : { "Content-Type": "application/json" }) as Record<string, string>;

  const payloadJson = useMemo(
    () => JSON.stringify(delivery.payload ?? { note: "No payload recorded for this delivery." }, null, 2),
    [delivery]
  );
  const filename = `webhook-${delivery.channel}-${delivery.kind}-${delivery.id.slice(0, 8)}.json`;

  const copy = async (text: string, label: string) => {
    try { await navigator.clipboard.writeText(text); toast.success(`${label} copied`); }
    catch { toast.error("Copy failed"); }
  };

  const download = () => {
    const blob = new Blob([payloadJson], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  const tabs: Array<{ id: typeof tab; label: string; count?: number }> = [
    { id: "overview", label: "Overview" },
    { id: "request", label: "Request" },
    { id: "response", label: "Response" },
    { id: "timeline", label: "Timeline", count: attempts.length },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Webhook delivery details"
    >
      <div
        className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-2xl border border-hairline bg-surface shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-hairline p-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-sm font-serif">Delivery to {delivery.channel === "slack" ? "Slack" : "Microsoft Teams"}</h2>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground rounded-full border border-hairline px-2 py-0.5">{delivery.kind}</span>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground rounded-full border border-hairline px-2 py-0.5">{delivery.status.replace("_", "-")}</span>
              {delivery.failure_reason && (
                <span className="inline-flex items-center gap-1 rounded-full border border-red-500/40 bg-red-500/10 px-2 py-0.5 text-[10px] font-medium text-red-300 capitalize">
                  <Skull className="h-3 w-3" /> {delivery.failure_reason.replace(/_/g, " ")}
                </span>
              )}
            </div>
            <p className="mt-1 text-[11px] text-muted-foreground truncate">
              {new Date(delivery.created_at).toLocaleString()} · HTTP {delivery.http_status ?? "—"} · attempts {delivery.attempt_count ?? 0}/{delivery.max_attempts ?? 0}
              {delivery.dead_lettered_at && ` · dead-lettered ${new Date(delivery.dead_lettered_at).toLocaleString()}`}
            </p>
          </div>
          <button onClick={onClose} aria-label="Close" className="rounded-md border border-hairline p-1.5 hover:bg-violet/10">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex items-center gap-1 border-b border-hairline px-2 pt-2 overflow-x-auto">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-3 py-1.5 text-[11px] rounded-t-md border-b-2 -mb-px whitespace-nowrap ${
                tab === t.id
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}{typeof t.count === "number" ? ` (${t.count})` : ""}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-auto">
          {tab === "overview" && (
            <div className="p-4 space-y-3 text-[12px]">
              <KV k="Delivery ID" v={delivery.id} mono />
              <KV k="Channel" v={delivery.channel} />
              <KV k="Kind" v={delivery.kind} />
              <KV k="Status" v={delivery.status} />
              <KV k="HTTP status" v={delivery.http_status != null ? String(delivery.http_status) : "—"} />
              <KV k="Attempts" v={`${delivery.attempt_count ?? 0} / ${delivery.max_attempts ?? 0}`} />
              <KV k="Created" v={new Date(delivery.created_at).toLocaleString()} />
              <KV k="Last attempt" v={delivery.last_attempt_at ? new Date(delivery.last_attempt_at).toLocaleString() : "—"} />
              <KV k="Next retry" v={delivery.next_attempt_at ? new Date(delivery.next_attempt_at).toLocaleString() : "—"} />
              <KV k="Dead-lettered" v={delivery.dead_lettered_at ? new Date(delivery.dead_lettered_at).toLocaleString() : "—"} />
              <KV k="Failure reason" v={delivery.failure_reason ?? "—"} />
              <KV k="Ticket ID" v={delivery.ticket_id ?? "—"} mono />
              <KV k="Alert ID" v={delivery.alert_id ?? "—"} mono />
              <KV k="Target" v={delivery.target ?? "—"} mono />
              {delivery.error && (
                <div className="rounded-md border border-red-500/30 bg-red-500/5 p-3">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Last error</div>
                  <code className="block whitespace-pre-wrap break-all text-[11px] text-red-400">{delivery.error}</code>
                </div>
              )}
            </div>
          )}

          {tab === "request" && (
            <div className="p-4 space-y-4">
              <Section title="Request line">
                <pre className="rounded-md bg-background/60 p-3 text-[11px] font-mono whitespace-pre-wrap break-all">
POST {delivery.target ?? "—"}
                </pre>
              </Section>
              <Section title="Request headers" onCopy={() => copy(JSON.stringify(requestHeaders, null, 2), "Request headers")}>
                <HeadersTable headers={requestHeaders} />
              </Section>
              <Section
                title="Request body"
                onCopy={() => copy(payloadJson, "Request body")}
                actions={
                  <button onClick={download} className="inline-flex items-center gap-1 rounded-md border border-hairline px-2 py-1 text-[10px] hover:bg-violet/10">
                    <Download className="h-3 w-3" /> {filename}
                  </button>
                }
              >
                <pre className="rounded-md bg-background/60 p-3 text-[11px] font-mono whitespace-pre-wrap break-all max-h-[40vh] overflow-auto">
{payloadJson}
                </pre>
              </Section>
            </div>
          )}

          {tab === "response" && (
            <div className="p-4 space-y-4">
              {!lastAttempt ? (
                <p className="text-[12px] text-muted-foreground">No response recorded yet. The delivery has not been attempted.</p>
              ) : (
                <>
                  <div className="flex flex-wrap gap-2 text-[11px]">
                    <Badge tone={lastAttempt.outcome === "sent" ? "ok" : "err"}>{lastAttempt.outcome ?? "unknown"}</Badge>
                    <Badge tone="muted">HTTP {lastAttempt.http_status ?? "—"}</Badge>
                    <Badge tone="muted">{lastAttempt.duration_ms != null ? `${lastAttempt.duration_ms} ms` : "—"}</Badge>
                    {lastAttempt.at && <Badge tone="muted">{new Date(lastAttempt.at).toLocaleString()}</Badge>}
                  </div>
                  <Section
                    title="Response headers"
                    onCopy={() => copy(JSON.stringify(lastAttempt.response_headers ?? {}, null, 2), "Response headers")}
                  >
                    {lastAttempt.response_headers && Object.keys(lastAttempt.response_headers).length > 0
                      ? <HeadersTable headers={lastAttempt.response_headers} />
                      : <p className="text-[11px] text-muted-foreground">No response headers captured.</p>}
                  </Section>
                  <Section
                    title="Response body"
                    onCopy={lastAttempt.response_body ? () => copy(lastAttempt.response_body!, "Response body") : undefined}
                  >
                    {lastAttempt.response_body
                      ? <pre className="rounded-md bg-background/60 p-3 text-[11px] font-mono whitespace-pre-wrap break-all max-h-[40vh] overflow-auto">{lastAttempt.response_body}</pre>
                      : <p className="text-[11px] text-muted-foreground">Empty body.</p>}
                  </Section>
                  {lastAttempt.error && (
                    <Section title="Transport error">
                      <code className="block whitespace-pre-wrap break-all text-[11px] text-red-400 rounded-md border border-red-500/30 bg-red-500/5 p-3">{lastAttempt.error}</code>
                    </Section>
                  )}
                </>
              )}
            </div>
          )}

          {tab === "timeline" && (
            <div className="p-4">
              {attempts.length === 0 ? (
                <p className="text-[12px] text-muted-foreground">
                  No per-attempt timeline recorded yet. Newer deliveries capture each attempt automatically; older rows only show summary counters.
                </p>
              ) : (
                <ol className="relative border-l border-hairline pl-4 space-y-4">
                  {attempts.map((a, i) => {
                    const tone = a.outcome === "sent" ? "ok" : a.outcome === "dead_letter" ? "err" : "warn";
                    const dot = tone === "ok" ? "bg-emerald-500" : tone === "err" ? "bg-red-500" : "bg-amber-500";
                    return (
                      <li key={`${a.n ?? i}-${a.at ?? i}`} className="relative">
                        <span className={`absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full ring-2 ring-surface ${dot}`} />
                        <div className="flex flex-wrap items-center gap-2 text-[11px]">
                          <span className="font-medium">Attempt {a.n ?? i + 1}</span>
                          <Badge tone={tone}>{a.outcome ?? "unknown"}</Badge>
                          <Badge tone="muted">HTTP {a.http_status ?? "—"}</Badge>
                          {a.duration_ms != null && <Badge tone="muted">{a.duration_ms} ms</Badge>}
                          {a.at && <span className="ml-auto text-muted-foreground">{new Date(a.at).toLocaleString()}</span>}
                        </div>
                        {(a.error || a.response_body) && (
                          <pre className="mt-2 rounded-md bg-background/60 p-2 text-[10.5px] font-mono whitespace-pre-wrap break-all max-h-40 overflow-auto">
{a.error ? `Error: ${a.error}\n` : ""}{a.response_body ?? ""}
                          </pre>
                        )}
                      </li>
                    );
                  })}
                  {delivery.next_attempt_at && delivery.status === "retrying" && (
                    <li className="relative">
                      <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full ring-2 ring-surface bg-violet animate-pulse" />
                      <div className="flex flex-wrap items-center gap-2 text-[11px]">
                        <span className="font-medium">Next retry</span>
                        <Badge tone="muted">scheduled</Badge>
                        <span className="ml-auto text-muted-foreground">{new Date(delivery.next_attempt_at).toLocaleString()}</span>
                      </div>
                    </li>
                  )}
                </ol>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function KV({ k, v, mono }: { k: string; v: string; mono?: boolean }) {
  return (
    <div className="grid grid-cols-[140px_1fr] gap-3 items-start">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground pt-0.5">{k}</div>
      <div className={`text-[12px] break-all ${mono ? "font-mono" : ""}`}>{v}</div>
    </div>
  );
}

function Section({ title, children, onCopy, actions }: { title: string; children: React.ReactNode; onCopy?: () => void; actions?: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-1.5">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{title}</div>
        <div className="ml-auto flex items-center gap-1.5">
          {actions}
          {onCopy && (
            <button onClick={onCopy} className="inline-flex items-center gap-1 rounded-md border border-hairline px-2 py-1 text-[10px] hover:bg-violet/10">
              <Copy className="h-3 w-3" /> Copy
            </button>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}

function HeadersTable({ headers }: { headers: Record<string, string> }) {
  const entries = Object.entries(headers);
  if (entries.length === 0) return <p className="text-[11px] text-muted-foreground">No headers.</p>;
  return (
    <div className="rounded-md border border-hairline overflow-hidden">
      <table className="w-full text-[11px]">
        <tbody>
          {entries.map(([k, v]) => (
            <tr key={k} className="border-b border-hairline last:border-b-0">
              <td className="px-3 py-1.5 font-mono text-muted-foreground align-top w-1/3 break-all">{k}</td>
              <td className="px-3 py-1.5 font-mono break-all">{v}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Badge({ tone, children }: { tone: "ok" | "err" | "warn" | "muted"; children: React.ReactNode }) {
  const cls =
    tone === "ok" ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400" :
    tone === "err" ? "border-red-500/40 bg-red-500/10 text-red-300" :
    tone === "warn" ? "border-amber-500/40 bg-amber-500/10 text-amber-300" :
    "border-hairline text-muted-foreground";
  return <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] capitalize ${cls}`}>{children}</span>;
}


function Stat({ label, value, tone }: { label: string; value: number; tone?: "ok" | "err" | "muted" | "warn" }) {
  const color = tone === "ok" ? "text-emerald-500" : tone === "err" ? "text-red-500" : tone === "warn" ? "text-amber-500" : tone === "muted" ? "text-muted-foreground" : "text-foreground";
  return (
    <div className="rounded-xl border border-hairline bg-surface p-4">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`text-2xl font-serif ${color}`}>{value}</div>
    </div>
  );
}

function Select({ value, onChange, options, label }: { value: string; onChange: (v: string) => void; options: string[]; label: string }) {
  return (
    <label className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
      <span>{label}:</span>
      <select value={value} onChange={e => onChange(e.target.value)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs text-foreground capitalize">
        {options.map(o => <option key={o} value={o}>{o.replace("_", " ")}</option>)}
      </select>
    </label>
  );
}

function ChannelBadge({ channel }: { channel: "slack" | "teams" }) {
  const cls = channel === "slack" ? "bg-[#4A154B]/20 text-[#ECB22E] border-[#ECB22E]/30" : "bg-[#464EB8]/20 text-[#7B83EB] border-[#7B83EB]/30";
  return <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-medium capitalize ${cls}`}>{channel}</span>;
}

function StatusBadge({ status }: { status: Delivery["status"] }) {
  if (status === "sent") return <span className="inline-flex items-center gap-1 text-emerald-500"><CheckCircle2 className="h-3 w-3"/> sent</span>;
  if (status === "failed") return <span className="inline-flex items-center gap-1 text-red-500"><XCircle className="h-3 w-3"/> failed</span>;
  if (status === "dead_letter") return <span className="inline-flex items-center gap-1 text-red-400 font-medium"><Skull className="h-3 w-3"/> dead-letter</span>;
  if (status === "retrying") return <span className="inline-flex items-center gap-1 text-amber-500"><RotateCw className="h-3 w-3"/> retrying</span>;
  if (status === "pending") return <span className="inline-flex items-center gap-1 text-violet"><Clock className="h-3 w-3"/> pending</span>;
  return <span className="inline-flex items-center gap-1 text-muted-foreground"><MinusCircle className="h-3 w-3"/> not configured</span>;
}
