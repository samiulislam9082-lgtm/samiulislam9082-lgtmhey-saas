import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2, Save } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/support-topics")({
  head: () => ({ meta: [{ title: "Support topics — Admin" }, { name: "robots", content: "noindex" }] }),
  component: TopicsAdmin,
});

type Topic = {
  id: string;
  slug: string;
  label: string;
  description: string | null;
  active: boolean;
  sort_order: number;
  suggested_flow: string;
  eta_hours: number | null;
};
type Rule = {
  id: string;
  topic_slug: string;
  pattern: string;
  priority: number;
  active: boolean;
};

function TopicsAdmin() {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [t, r] = await Promise.all([
      supabase.from("support_topics").select("*").order("sort_order"),
      supabase.from("support_topic_rules").select("*").order("priority"),
    ]);
    setTopics((t.data as Topic[]) ?? []);
    setRules((r.data as Rule[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { void load(); }, []);

  const saveTopic = async (t: Topic) => {
    const { error } = await supabase.from("support_topics").update({
      label: t.label, description: t.description, active: t.active,
      sort_order: t.sort_order, suggested_flow: t.suggested_flow, eta_hours: t.eta_hours,
    }).eq("id", t.id);
    if (error) return toast.error(error.message);
    toast.success("Topic saved");
  };
  const addTopic = async () => {
    const slug = prompt("New topic slug (lowercase, underscores):")?.trim();
    if (!slug) return;
    const { error } = await supabase.from("support_topics").insert({ slug, label: slug, sort_order: 500 });
    if (error) return toast.error(error.message);
    void load();
  };
  const delTopic = async (id: string) => {
    if (!confirm("Delete topic and its rules?")) return;
    await supabase.from("support_topics").delete().eq("id", id);
    void load();
  };
  const addRule = async (slug: string) => {
    const pattern = prompt(`Regex pattern for topic "${slug}":`)?.trim();
    if (!pattern) return;
    const { error } = await supabase.from("support_topic_rules").insert({ topic_slug: slug, pattern });
    if (error) return toast.error(error.message);
    void load();
  };
  const saveRule = async (r: Rule) => {
    const { error } = await supabase.from("support_topic_rules").update({
      pattern: r.pattern, priority: r.priority, active: r.active,
    }).eq("id", r.id);
    if (error) return toast.error(error.message);
    toast.success("Rule saved");
  };
  const delRule = async (id: string) => {
    await supabase.from("support_topic_rules").delete().eq("id", id);
    void load();
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-serif tracking-tight">Support topics</h1>
          <p className="text-sm text-muted-foreground">Manage the topic list and matching rules used for analytics classification.</p>
        </div>
        <button onClick={addTopic} className="inline-flex items-center gap-1 rounded-md bg-violet px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-violet-glow">
          <Plus className="h-3 w-3" /> New topic
        </button>
      </div>

      {loading ? <p className="text-xs text-muted-foreground">Loading…</p> : (
        <div className="space-y-4">
          {topics.map((t) => (
            <div key={t.id} className="rounded-2xl border border-hairline bg-surface p-4 space-y-3">
              <div className="grid gap-2 md:grid-cols-6 items-end">
                <div><div className="text-[10px] uppercase text-muted-foreground">Slug</div><div className="font-mono text-xs">{t.slug}</div></div>
                <label className="md:col-span-2"><div className="text-[10px] uppercase text-muted-foreground">Label</div>
                  <input value={t.label} onChange={(e) => setTopics(ts => ts.map(x => x.id===t.id?{...x,label:e.target.value}:x))} className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs"/>
                </label>
                <label><div className="text-[10px] uppercase text-muted-foreground">Flow</div>
                  <select value={t.suggested_flow} onChange={(e) => setTopics(ts => ts.map(x => x.id===t.id?{...x,suggested_flow:e.target.value}:x))} className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs">
                    <option value="chat">chat</option><option value="ticket">ticket</option>
                  </select>
                </label>
                <label><div className="text-[10px] uppercase text-muted-foreground">ETA (h)</div>
                  <input type="number" value={t.eta_hours ?? ""} onChange={(e) => setTopics(ts => ts.map(x => x.id===t.id?{...x,eta_hours:e.target.value?parseInt(e.target.value):null}:x))} className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs"/>
                </label>
                <label><div className="text-[10px] uppercase text-muted-foreground">Order</div>
                  <input type="number" value={t.sort_order} onChange={(e) => setTopics(ts => ts.map(x => x.id===t.id?{...x,sort_order:parseInt(e.target.value)||0}:x))} className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs"/>
                </label>
              </div>
              <div className="flex items-center gap-2">
                <label className="inline-flex items-center gap-1 text-xs"><input type="checkbox" checked={t.active} onChange={(e)=>setTopics(ts=>ts.map(x=>x.id===t.id?{...x,active:e.target.checked}:x))}/> Active</label>
                <button onClick={() => saveTopic(t)} className="ml-auto inline-flex items-center gap-1 rounded-md border border-hairline bg-background px-2 py-1 text-[11px] hover:bg-violet/10"><Save className="h-3 w-3"/> Save</button>
                <button onClick={() => delTopic(t.id)} className="inline-flex items-center gap-1 rounded-md border border-hairline bg-background px-2 py-1 text-[11px] text-destructive hover:bg-destructive/10"><Trash2 className="h-3 w-3"/></button>
              </div>

              <div className="pt-2 border-t border-hairline">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[11px] font-medium text-muted-foreground">Matching rules (regex)</div>
                  <button onClick={() => addRule(t.slug)} className="text-[11px] text-violet hover:underline">+ Add rule</button>
                </div>
                <div className="space-y-1.5">
                  {rules.filter(r => r.topic_slug===t.slug).map((r) => (
                    <div key={r.id} className="grid grid-cols-12 gap-1.5 items-center">
                      <input value={r.pattern} onChange={(e)=>setRules(rs=>rs.map(x=>x.id===r.id?{...x,pattern:e.target.value}:x))} className="col-span-7 rounded-md border border-hairline bg-background px-2 py-1 font-mono text-[11px]"/>
                      <input type="number" value={r.priority} onChange={(e)=>setRules(rs=>rs.map(x=>x.id===r.id?{...x,priority:parseInt(e.target.value)||0}:x))} className="col-span-2 rounded-md border border-hairline bg-background px-2 py-1 text-[11px]"/>
                      <label className="col-span-1 inline-flex items-center text-[11px]"><input type="checkbox" checked={r.active} onChange={(e)=>setRules(rs=>rs.map(x=>x.id===r.id?{...x,active:e.target.checked}:x))}/></label>
                      <button onClick={() => saveRule(r)} className="col-span-1 rounded-md border border-hairline px-1 py-1 text-[10px]"><Save className="h-3 w-3"/></button>
                      <button onClick={() => delRule(r.id)} className="col-span-1 rounded-md border border-hairline px-1 py-1 text-[10px] text-destructive"><Trash2 className="h-3 w-3"/></button>
                    </div>
                  ))}
                  {rules.filter(r=>r.topic_slug===t.slug).length===0 && (<p className="text-[11px] text-muted-foreground">No rules yet.</p>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
