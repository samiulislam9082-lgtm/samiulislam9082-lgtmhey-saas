import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  wsGetMyListing,
  wsUpdateListing,
  wsGetOrCreateDnsVerification,
  wsVerifyDns,
  wsSetListingStatus,
} from "@/lib/websites.functions";
import { WsSidebar } from "@/components/websites/WebSwapShell";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { ShieldCheck, ShieldAlert, Copy, RefreshCw, Loader2, Globe } from "lucide-react";

export const Route = createFileRoute("/_authenticated/websites/dashboard/listings/$id")({
  component: EditListingPage,
});

function EditListingPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const get = useServerFn(wsGetMyListing);
  const update = useServerFn(wsUpdateListing);
  const getDns = useServerFn(wsGetOrCreateDnsVerification);
  const verify = useServerFn(wsVerifyDns);
  const setStatus = useServerFn(wsSetListingStatus);
  const qc = useQueryClient();

  const { data: listing, refetch } = useQuery({ queryKey: ["ws", "my-listing", id], queryFn: () => get({ data: { id } }) });

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [askingPrice, setAskingPrice] = useState("");
  const [saving, setSaving] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [dns, setDns] = useState<{ txt_token: string; status: string; domain: string } | null>(null);
  const [dnsLoading, setDnsLoading] = useState(false);

  useEffect(() => {
    if (listing) {
      setTitle(listing.title);
      setDescription(listing.description ?? "");
      setAskingPrice(listing.asking_price_usd?.toString() ?? "");
    }
  }, [listing]);

  async function save() {
    setSaving(true);
    try {
      await update({
        data: {
          id,
          patch: {
            title: title.trim(),
            description: description.trim() || null,
            asking_price_usd: askingPrice ? Number(askingPrice) : null,
          },
        },
      });
      toast.success("Saved.");
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  }

  async function loadDns() {
    setDnsLoading(true);
    try {
      const r = await getDns({ data: { listing_id: id } });
      setDns(r);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not create token.");
    } finally {
      setDnsLoading(false);
    }
  }

  async function runVerify() {
    setVerifying(true);
    try {
      const r = await verify({ data: { listing_id: id } });
      if (r.verified) {
        toast.success("Ownership verified! You can now publish.");
        refetch();
        qc.invalidateQueries({ queryKey: ["ws", "my-listings"] });
      } else {
        toast.error("TXT record not found yet. DNS can take a few minutes to a few hours to propagate.");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Verification failed.");
    } finally {
      setVerifying(false);
    }
  }

  async function publish() {
    try {
      await setStatus({ data: { id, status: "live" } });
      toast.success("Listing published.");
      refetch();
      qc.invalidateQueries({ queryKey: ["ws", "my-listings"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed.");
    }
  }

  if (!listing) {
    return <div className="mx-auto max-w-7xl px-4 py-16 text-emerald-100/60">Loading…</div>;
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 flex gap-8">
      <WsSidebar />
      <div className="flex-1 min-w-0 max-w-3xl space-y-6">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold text-white">{listing.title}</h1>
          <Badge className="bg-zinc-500/20 text-zinc-300 border-zinc-600/40">{listing.status}</Badge>
        </div>
        <p className="text-emerald-100/60 text-sm">{listing.domain}</p>

        {/* DNS verification */}
        <section className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-6">
          <div className="flex items-center gap-2 mb-2">
            {listing.ownership_verified ? (
              <>
                <ShieldCheck className="h-5 w-5 text-emerald-400" />
                <h2 className="text-lg font-semibold text-white">Ownership verified</h2>
              </>
            ) : (
              <>
                <ShieldAlert className="h-5 w-5 text-amber-400" />
                <h2 className="text-lg font-semibold text-white">Verify domain ownership</h2>
              </>
            )}
          </div>

          {listing.ownership_verified ? (
            <p className="text-sm text-emerald-100/70">Your domain ownership is verified. You can publish the listing.</p>
          ) : (
            <>
              <p className="text-sm text-emerald-100/70 mb-4">
                Add a TXT record to your domain <span className="text-emerald-300">{listing.domain}</span> to prove you control it. Listings can't be published without this.
              </p>
              {!dns ? (
                <Button onClick={loadDns} disabled={dnsLoading} className="bg-emerald-500 hover:bg-emerald-400 text-black">
                  {dnsLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Generate verification token"}
                </Button>
              ) : (
                <div className="space-y-3">
                  <div className="rounded-lg bg-black/40 border border-emerald-900/60 p-4 font-mono text-xs text-emerald-100 space-y-1">
                    <div><span className="text-emerald-500/70">Type:</span> TXT</div>
                    <div><span className="text-emerald-500/70">Host/Name:</span> @ (or {listing.domain})</div>
                    <div className="flex items-start gap-2">
                      <div className="flex-1"><span className="text-emerald-500/70">Value:</span> {dns.txt_token}</div>
                      <button
                        onClick={() => { navigator.clipboard.writeText(dns.txt_token); toast.success("Copied."); }}
                        className="text-emerald-400 hover:text-emerald-300"
                        aria-label="Copy"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-emerald-100/60">
                    Log in to your DNS provider (Cloudflare, Namecheap, GoDaddy, Route 53, etc.), add a TXT record with the value above, then click Verify. DNS propagation can take a few minutes.
                  </p>
                  <div className="flex gap-2">
                    <Button onClick={runVerify} disabled={verifying} className="bg-emerald-500 hover:bg-emerald-400 text-black">
                      {verifying ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Checking…</> : <><RefreshCw className="h-4 w-4 mr-2" /> Verify now</>}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </section>

        {/* Basic edit */}
        <section className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-6 space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2"><Globe className="h-5 w-5 text-emerald-400" /> Listing details</h2>
          <div>
            <Label className="text-emerald-100">Title</Label>
            <Input className="mt-1.5 bg-black/40 border-emerald-900/60 text-emerald-50" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div>
            <Label className="text-emerald-100">Description</Label>
            <Textarea rows={6} className="mt-1.5 bg-black/40 border-emerald-900/60 text-emerald-50" value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div>
            <Label className="text-emerald-100">Asking price (USD)</Label>
            <Input type="number" className="mt-1.5 bg-black/40 border-emerald-900/60 text-emerald-50" value={askingPrice} onChange={(e) => setAskingPrice(e.target.value)} />
          </div>
          <div className="flex gap-2 pt-2">
            <Button onClick={save} disabled={saving} className="bg-emerald-500 hover:bg-emerald-400 text-black">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
            </Button>
            {listing.ownership_verified && listing.status !== "live" && (
              <Button variant="outline" className="border-emerald-500/40 text-emerald-200 bg-transparent hover:bg-emerald-500/10" onClick={publish}>
                Publish listing
              </Button>
            )}
            <Button variant="ghost" className="text-emerald-100/70 hover:text-white" onClick={() => navigate({ to: "/websites/dashboard/listings" })}>
              Back
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
}
