import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsListThreads } from "@/lib/websites.functions";
import { WsSidebar } from "@/components/websites/WebSwapShell";
import { MessageSquare, Globe, Search } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Input } from "@/components/ui/input";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/_authenticated/websites/dashboard/messages/")({
  component: MessagesPage,
});

function MessagesPage() {
  const list = useServerFn(wsListThreads);
  const { data, isLoading } = useQuery({ queryKey: ["ws", "threads"], queryFn: () => list() });
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    if (!data) return [];
    const needle = q.trim().toLowerCase();
    if (!needle) return data;
    return data.filter((t) => {
      const l = (t as unknown as { ws_listings: { title?: string; domain?: string } }).ws_listings;
      return (l?.title || "").toLowerCase().includes(needle) || (l?.domain || "").toLowerCase().includes(needle);
    });
  }, [data, q]);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 flex gap-8">
      <WsSidebar />
      <div className="flex-1 min-w-0">
        <div className="flex items-end justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-semibold text-white tracking-tight">Messages</h1>
            <p className="text-sm text-emerald-100/50 mt-1">Buyer and seller conversations tied to your listings.</p>
          </div>
        </div>

        <div className="relative mb-4">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-emerald-100/40" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search conversations…" className="pl-9 bg-white/[0.03] border-white/5 text-emerald-50 placeholder:text-emerald-100/30 h-11" />
        </div>

        {isLoading ? (
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 rounded-2xl border border-white/5 bg-white/[0.02] p-4 animate-pulse">
                <div className="h-12 w-12 rounded-xl bg-white/[0.04]" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-1/3 bg-white/[0.05] rounded" />
                  <div className="h-3 w-2/3 bg-white/[0.04] rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : !filtered || filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-white/10 p-16 text-center">
            <div className="mx-auto h-14 w-14 rounded-2xl bg-emerald-500/10 border border-emerald-400/20 grid place-items-center mb-4">
              <MessageSquare className="h-6 w-6 text-emerald-300" />
            </div>
            <div className="text-white font-medium mb-1">{q ? "No matches" : "No conversations yet"}</div>
            <p className="text-sm text-emerald-100/50 max-w-sm mx-auto">
              {q ? "Try a different search." : "When a buyer messages you or you reach out about a listing, the thread will appear here."}
            </p>
          </div>
        ) : (
          <div className="rounded-2xl border border-white/5 bg-white/[0.02] overflow-hidden divide-y divide-white/5">
            {filtered.map((t) => {
              const l = (t as unknown as { ws_listings: { id: string; title: string; domain: string; screenshots: string[] } }).ws_listings;
              return (
                <Link
                  key={t.id}
                  to="/websites/dashboard/messages/$threadId"
                  params={{ threadId: t.id }}
                  className="group flex items-center gap-4 px-4 py-3.5 hover:bg-white/[0.03] transition"
                >
                  <div className="h-12 w-12 rounded-xl bg-black/40 overflow-hidden shrink-0 grid place-items-center ring-1 ring-white/5">
                    {l?.screenshots?.[0] ? (
                      <img src={l.screenshots[0]} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <Globe className="h-5 w-5 text-emerald-500/40" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="text-white font-medium truncate">{l?.title ?? "Untitled listing"}</div>
                    </div>
                    <div className="text-xs text-emerald-100/50 truncate">{l?.domain}</div>
                  </div>
                  {t.last_message_at && (
                    <div className="text-[11px] text-emerald-100/40 shrink-0 tabular-nums">
                      {formatDistanceToNow(new Date(t.last_message_at), { addSuffix: false })}
                    </div>
                  )}
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
