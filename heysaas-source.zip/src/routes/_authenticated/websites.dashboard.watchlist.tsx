import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsListWatchlist, wsBulkRemoveWatchlist, wsSetWatchlistNotify, wsToggleWatchlist } from "@/lib/websites.functions";
import { WsSidebar } from "@/components/websites/WebSwapShell";
import { Heart, Globe, Bell, BellOff, Trash2, CheckSquare, Square } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/websites/dashboard/watchlist")({
  component: WatchlistPage,
});

function WatchlistPage() {
  const list = useServerFn(wsListWatchlist);
  const bulkRemove = useServerFn(wsBulkRemoveWatchlist);
  const setNotify = useServerFn(wsSetWatchlistNotify);
  const toggle = useServerFn(wsToggleWatchlist);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["ws", "watchlist"], queryFn: () => list() });
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const items = useMemo(() => (data as any[] | undefined) ?? [], [data]);
  const allSelected = items.length > 0 && selected.size === items.length;

  const invalidate = () => qc.invalidateQueries({ queryKey: ["ws", "watchlist"] });

  const removeMut = useMutation({
    mutationFn: (ids: string[]) => bulkRemove({ data: { listing_ids: ids } }),
    onSuccess: (r: any) => { toast.success(`Removed ${r.removed} from watchlist`); setSelected(new Set()); invalidate(); },
    onError: (e: any) => toast.error(e.message ?? "Couldn't remove"),
  });
  const notifyMut = useMutation({
    mutationFn: (v: { ids: string[]; notify: boolean }) => setNotify({ data: { listing_ids: v.ids, notify: v.notify } }),
    onSuccess: (_r, v) => { toast.success(v.notify ? "Notifications on" : "Notifications off"); invalidate(); },
    onError: (e: any) => toast.error(e.message ?? "Couldn't update"),
  });
  const toggleOneMut = useMutation({
    mutationFn: (id: string) => toggle({ data: { listing_id: id } }),
    onSuccess: () => invalidate(),
  });

  function toggleSel(id: string) {
    const s = new Set(selected);
    if (s.has(id)) s.delete(id); else s.add(id);
    setSelected(s);
  }
  function selectAll() {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(items.map((w) => w.ws_listings.id)));
  }

  const selectedIds = Array.from(selected);
  const selectedItems = items.filter((w) => selected.has(w.ws_listings.id));
  const allNotifying = selectedItems.length > 0 && selectedItems.every((w) => w.notify);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 flex gap-8">
      <WsSidebar />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <h1 className="text-3xl font-bold text-white">Watchlist</h1>
          {items.length > 0 && (
            <button onClick={selectAll} className="text-xs text-emerald-100/70 hover:text-emerald-100 inline-flex items-center gap-2">
              {allSelected ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
              {allSelected ? "Deselect all" : "Select all"}
            </button>
          )}
        </div>

        {selected.size > 0 && (
          <div className="mb-4 flex items-center gap-2 flex-wrap rounded-xl border border-emerald-500/30 bg-emerald-500/5 px-3 py-2 sticky top-4 z-10 backdrop-blur">
            <span className="text-sm text-emerald-100">{selected.size} selected</span>
            <div className="flex-1" />
            <button
              onClick={() => notifyMut.mutate({ ids: selectedIds, notify: !allNotifying })}
              disabled={notifyMut.isPending}
              className="text-xs rounded-full border border-emerald-500/40 px-3 py-1.5 text-emerald-100 hover:bg-emerald-500/10 inline-flex items-center gap-1.5"
            >
              {allNotifying ? <><BellOff className="h-3.5 w-3.5" />Mute alerts</> : <><Bell className="h-3.5 w-3.5" />Enable alerts</>}
            </button>
            <button
              onClick={() => { if (confirm(`Remove ${selected.size} from watchlist?`)) removeMut.mutate(selectedIds); }}
              disabled={removeMut.isPending}
              className="text-xs rounded-full border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-red-300 hover:bg-red-500/20 inline-flex items-center gap-1.5"
            >
              <Trash2 className="h-3.5 w-3.5" />Remove
            </button>
            <button onClick={() => setSelected(new Set())} className="text-xs text-emerald-100/70 hover:text-emerald-100 px-2">Cancel</button>
          </div>
        )}

        {isLoading ? (
          <div className="text-emerald-100/60">Loading…</div>
        ) : items.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-emerald-900/60 p-12 text-center text-emerald-100/60">
            <Heart className="h-8 w-8 text-emerald-500/50 mx-auto mb-3" />
            You haven't saved any listings yet.
          </div>
        ) : (
          <div className="space-y-2">
            {items.map((w: any) => {
              const l = w.ws_listings;
              const visible = l.status === "live" && l.ownership_verified;
              const isSel = selected.has(l.id);
              return (
                <div
                  key={l.id}
                  className={`flex items-center gap-3 rounded-xl border p-3 transition ${isSel ? "border-emerald-400/60 bg-emerald-500/10" : "border-emerald-900/60 bg-emerald-950/30 hover:border-emerald-500/40"} ${!visible ? "opacity-60" : ""}`}
                >
                  <button onClick={() => toggleSel(l.id)} aria-label="Select" className="text-emerald-100/70 hover:text-emerald-100">
                    {isSel ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
                  </button>
                  <Link to="/websites/$id" params={{ id: l.id }} className="flex items-center gap-4 flex-1 min-w-0">
                    <div className="h-14 w-20 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center">
                      {l.screenshots?.[0] ? <img src={l.screenshots[0]} alt="" className="h-full w-full object-cover" /> : <Globe className="h-5 w-5 text-emerald-500/40" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-white font-medium truncate">{l.title}</div>
                      <div className="text-xs text-emerald-100/50">{l.domain}{!visible && " · no longer available"}</div>
                    </div>
                    <div className="text-emerald-300 font-semibold text-sm shrink-0">
                      {l.asking_price_usd != null ? `$${Number(l.asking_price_usd).toLocaleString()}` : "—"}
                    </div>
                  </Link>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => notifyMut.mutate({ ids: [l.id], notify: !w.notify })}
                      title={w.notify ? "Alerts on — click to mute" : "Alerts off — click to enable"}
                      className={`p-2 rounded-full border transition ${w.notify ? "border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10" : "border-emerald-900/60 text-emerald-100/40 hover:text-emerald-100"}`}
                    >
                      {w.notify ? <Bell className="h-3.5 w-3.5" /> : <BellOff className="h-3.5 w-3.5" />}
                    </button>
                    <button
                      onClick={() => toggleOneMut.mutate(l.id)}
                      title="Remove"
                      className="p-2 rounded-full border border-emerald-900/60 text-emerald-100/40 hover:text-red-300 hover:border-red-500/40 transition"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
