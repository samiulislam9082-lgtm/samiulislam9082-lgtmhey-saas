import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Loader2, Star } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/embeds")({
  head: () => ({ meta: [{ title: "Embeds & Badges — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: EmbedsPage,
});

type Listing = { id: string; name: string; slug: string; status: string };

function EmbedsPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [slug, setSlug] = useState("");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data } = await supabase.from("saas_listings").select("id, name, slug, status").eq("owner_id", user.id).eq("status", "live");
      setListings(data ?? []);
      if (data?.[0]) setSlug(data[0].slug);
      setLoading(false);
    })();
  }, []);

  const base = typeof window !== "undefined" ? window.location.origin : "https://heysaas.app";
  const url = slug ? `${base}/l/${slug}?utm_source=badge&utm_medium=embed&utm_campaign=featured-on-heysaas` : "";

  const badgeHtml = useMemo(() => `<a href="${url}" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:8px;padding:8px 14px;border-radius:999px;background:#0d1f2b;color:#5cbdb9;font-family:system-ui,sans-serif;font-size:13px;font-weight:600;text-decoration:none;border:1px solid #0f4c5c;">
  <span style="font-size:14px">★</span> Featured on Hey SaaS
</a>`, [url]);

  const cardHtml = useMemo(() => `<a href="${url}" target="_blank" rel="noopener" style="display:block;max-width:380px;padding:16px 18px;border-radius:12px;background:#08131a;border:1px solid #0f4c5c;color:#e6f6f4;font-family:system-ui,sans-serif;text-decoration:none;">
  <div style="font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:#5cbdb9;margin-bottom:6px">Open to swap · Hey SaaS</div>
  <div style="font-size:16px;font-weight:600;margin-bottom:4px">Trade this SaaS with a founder you trust</div>
  <div style="font-size:13px;color:#96b3b1">$19 safety fee · verified profiles · escrowed handover</div>
</a>`, [url]);

  const oembed = useMemo(() => `<script async src="${base}/embed.js" data-heysaas="${slug}"></script>`, [base, slug]);

  function copy(text: string) { navigator.clipboard.writeText(text); toast.success("Copied"); }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="listings"
              eyebrow="Marketing desk"
              title="Embeds & badges"
              description="Drop a 'Featured on Hey SaaS' badge on your marketing site to signal trust and drive proposals."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : listings.length === 0 ? (
              <Card className="p-6 text-sm text-muted-foreground mt-6">
                No live listings yet. Publish one to unlock embeds.
              </Card>
            ) : (
              <>
                <Card className="p-5 mt-6">
                  <label className="text-sm font-medium">Listing</label>
                  <select
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {listings.map((l) => <option key={l.id} value={l.slug}>{l.name}</option>)}
                  </select>
                </Card>

                <Snippet
                  title="Pill badge"
                  preview={<div dangerouslySetInnerHTML={{ __html: badgeHtml }} />}
                  code={badgeHtml}
                  onCopy={() => copy(badgeHtml)}
                  hint="Drop into your footer or an 'as featured on' rail. Renders as a self-contained HTML anchor."
                />
                <Snippet
                  title="Trust card"
                  preview={<div dangerouslySetInnerHTML={{ __html: cardHtml }} />}
                  code={cardHtml}
                  onCopy={() => copy(cardHtml)}
                  hint="Larger card for the sidebar of a blog post or a 'partners' section."
                />
                <Snippet
                  title="Auto-updating widget (script)"
                  preview={<div className="text-xs text-muted-foreground italic">Renders live stats (views, proposals, updated hourly).</div>}
                  code={oembed}
                  onCopy={() => copy(oembed)}
                  hint="One-line script tag; pulls the latest state from Hey SaaS on every page load."
                />

                <Card className="mt-6 p-5">
                  <div className="text-sm font-medium mb-2 flex items-center gap-2"><Star className="h-4 w-4 text-primary" /> Why founders embed the badge</div>
                  <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                    <li>Signals to visitors that you're open to strategic swaps or exits.</li>
                    <li>Drives qualified inbound: badge clickers convert to proposals ~3× the average.</li>
                    <li>Backlink to your Hey SaaS profile improves SEO for your listing page.</li>
                  </ul>
                </Card>
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Snippet({ title, preview, code, onCopy, hint }: { title: string; preview: React.ReactNode; code: string; onCopy: () => void; hint: string }) {
  return (
    <Card className="p-5 mt-4">
      <div className="flex items-center justify-between mb-3">
        <div className="font-medium">{title}</div>
        <Button size="sm" variant="outline" onClick={onCopy}><Copy className="h-3 w-3 mr-1" /> Copy</Button>
      </div>
      <div className="rounded-md border border-border p-4 bg-background/40 mb-3">{preview}</div>
      <pre className="text-xs font-mono bg-muted/30 rounded-md p-3 overflow-x-auto whitespace-pre-wrap break-all">{code}</pre>
      <div className="text-xs text-muted-foreground mt-2">{hint}</div>
    </Card>
  );
}
