import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { BackButton } from "@/components/site/BackButton";
import { Kpi } from "@/components/ui/kpi";
import {
  Plus,
  Repeat,
  Inbox,
  Sparkles,
  MessageSquare,
  Bell,
  Bookmark,
  BarChart3,
  Settings,
  Compass,
  ArrowRight,
  CheckCircle2,
  Circle,
  Globe,
} from "lucide-react";


export const Route = createFileRoute("/_authenticated/dashboard/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Hey SaaS" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Dashboard,
});

type Profile = {
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  bio: string | null;
};

type Stats = {
  listings: number;
  liveListings: number;
  swaps: number;
  proposals: number;
  unreadMessages: number;
  unreadNotifications: number;
  bookmarks: number;
};

type ListingRow = { id: string; slug: string; name: string; status: string | null; interested_count: number | null; created_at: string };

function Dashboard() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [email, setEmail] = useState("");
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<ListingRow[]>([]);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setEmail(user.email ?? "");

      const [{ data: p }, listings, liveListings, swaps, proposals, msgs, notifs, bms, recentRes] = await Promise.all([
        supabase.from("profiles").select("display_name, username, avatar_url, bio").eq("id", user.id).maybeSingle(),
        supabase.from("saas_listings").select("id", { count: "exact", head: true }).eq("owner_id", user.id),
        supabase.from("saas_listings").select("id", { count: "exact", head: true }).eq("owner_id", user.id).eq("status", "live"),
        supabase.from("swap_requests").select("id", { count: "exact", head: true }).or(`proposer_id.eq.${user.id},recipient_id.eq.${user.id}`).eq("status", "accepted"),
        supabase.from("swap_requests").select("id", { count: "exact", head: true }).eq("recipient_id", user.id).eq("status", "pending"),
        supabase.from("notifications").select("id", { count: "exact", head: true }).eq("user_id", user.id).is("read_at", null).ilike("type", "%message%"),
        supabase.from("notifications").select("id", { count: "exact", head: true }).eq("user_id", user.id).is("read_at", null),
        supabase.from("bookmarks").select("id", { count: "exact", head: true }).eq("user_id", user.id),
        supabase.from("saas_listings").select("id, slug, name, status, interested_count, created_at").eq("owner_id", user.id).order("created_at", { ascending: false }).limit(4),
      ]);

      setProfile(p as Profile | null);
      setStats({
        listings: listings.count ?? 0,
        liveListings: liveListings.count ?? 0,
        swaps: swaps.count ?? 0,
        proposals: proposals.count ?? 0,
        unreadMessages: msgs.count ?? 0,
        unreadNotifications: notifs.count ?? 0,
        bookmarks: bms.count ?? 0,
      });
      setRecent((recentRes.data ?? []) as ListingRow[]);
    })();
  }, []);

  const name = profile?.display_name || email.split("@")[0] || "Founder";
  const profileComplete = !!(profile?.display_name && profile?.username && profile?.bio && profile?.avatar_url);

  const setupSteps = [
    { key: "profile", label: "Complete your founder profile", done: profileComplete, to: "/dashboard/settings", cta: "Edit profile" },
    { key: "listing", label: "List your first SaaS", done: (stats?.listings ?? 0) > 0, to: "/list", cta: "Create listing" },
    { key: "live", label: "Publish a listing to go live", done: (stats?.liveListings ?? 0) > 0, to: "/dashboard/listings", cta: "Manage listings" },
  ];

  const kpis = [
    { icon: Sparkles, label: "Live listings", value: stats?.liveListings ?? 0, sub: `${stats?.listings ?? 0} total`, to: "/dashboard/listings", spark: [0, 1, 1, 2, 2, 3, stats?.liveListings ?? 0] },
    { icon: Repeat, label: "Active swaps", value: stats?.swaps ?? 0, sub: "In progress", to: "/dashboard/swaps", spark: [0, 0, 1, 1, 2, 2, stats?.swaps ?? 0] },
    { icon: Inbox, label: "New proposals", value: stats?.proposals ?? 0, sub: "Awaiting reply", to: "/dashboard/swaps", spark: [0, 1, 0, 1, 2, 1, stats?.proposals ?? 0] },
    { icon: Bookmark, label: "Bookmarks", value: stats?.bookmarks ?? 0, sub: "Saved SaaS", to: "/dashboard/bookmarks", spark: [0, 1, 2, 2, 3, 4, stats?.bookmarks ?? 0] },
  ];


  const quick = [
    { icon: Plus, label: "List a SaaS", to: "/list", tone: "primary" as const },
    { icon: Compass, label: "Explore", to: "/explore" },
    { icon: MessageSquare, label: "Messages", to: "/dashboard/messages", badge: stats?.unreadMessages },
    { icon: Bell, label: "Notifications", to: "/dashboard/notifications", badge: stats?.unreadNotifications },
    { icon: BarChart3, label: "Analytics", to: "/dashboard/analytics" },
    { icon: Globe, label: "WebSwap", to: "/websites" },
    { icon: Settings, label: "Settings", to: "/dashboard/settings" },
  ];

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-8 md:py-12">

        <div className="flex gap-8 lg:gap-10">
          <DashboardSidebar />

          <div className="flex-1 min-w-0">
            <BackButton fallback="/" />

            {/* Editorial greeting hero */}
            <DashHero
              signature="overview"
              eyebrow="Founder command center"
              title={`Hey, ${name}.`}
              description="Your swap desk, live. Track proposals, unlock messages, and steer every listing from one calm surface."
              actions={
                <>
                  <Link
                    to="/explore"
                    className="inline-flex items-center gap-2 rounded-full border border-hairline bg-surface-elevated/60 px-4 py-2 text-sm text-foreground/90 hover:text-foreground hover:border-violet/40 transition-colors"
                  >
                    <Compass className="h-4 w-4" /> Explore
                  </Link>
                  <Link
                    to="/list"
                    className="inline-flex items-center gap-2 rounded-full bg-violet px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors"
                  >
                    <Plus className="h-4 w-4" /> List your SaaS
                  </Link>
                </>
              }
            />
            <DashRibbon variant="overview" />
            <DashBodyBlock variant="overview" />



            {/* Quick actions */}
            <nav aria-label="Quick actions" className="mt-8">
              <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                {quick.map((q) => (
                  <Link
                    key={q.label}
                    to={q.to}
                    className={`relative shrink-0 inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                      q.tone === "primary"
                        ? "border-violet/40 bg-violet/10 text-violet-glow hover:bg-violet/20"
                        : "border-hairline bg-surface text-foreground hover:bg-surface-elevated"
                    }`}
                  >
                    <q.icon className="h-4 w-4" aria-hidden="true" />
                    {q.label}
                    {q.badge && q.badge > 0 ? (
                      <span className="ml-1 inline-flex h-5 min-w-[20px] items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground">
                        {q.badge > 99 ? "99+" : q.badge}
                      </span>
                    ) : null}
                  </Link>
                ))}
              </div>
            </nav>

            {/* KPIs */}
            <section aria-labelledby="kpi-heading" className="mt-8">
              <h2 id="kpi-heading" className="sr-only">Summary</h2>
              <div className="grid gap-3 sm:gap-4 grid-cols-2 lg:grid-cols-4">
                {kpis.map((c) => (
                  <Kpi
                    key={c.label}
                    label={c.label}
                    value={c.value}
                    format="compact"
                    icon={c.icon}
                    sub={c.sub}
                    spark={c.spark}
                    to={c.to}
                  />
                ))}
              </div>
            </section>


            <div className="mt-10 grid gap-6 lg:grid-cols-3">
              {/* Setup */}
              <section aria-labelledby="setup-heading" className="lg:col-span-2 hs-form-card relative overflow-hidden p-6 sm:p-8">
                <div className="relative z-10 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <span className="hs-dash-eyebrow">
                      <span className="hs-dash-eyebrow-dot" aria-hidden />
                      Launch checklist
                    </span>
                    <h2 id="setup-heading" className="mt-3 font-display text-2xl md:text-3xl">Get set up</h2>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {setupSteps.filter((s) => s.done).length} of {setupSteps.length} complete — a live listing unlocks proposals within hours.
                    </p>
                  </div>
                  <div className="hidden sm:flex flex-col items-end gap-2">
                    <span className="font-display text-2xl bg-linear-to-r from-violet-glow to-foreground bg-clip-text text-transparent">
                      {Math.round((setupSteps.filter((s) => s.done).length / setupSteps.length) * 100)}%
                    </span>
                    <div className="w-28 h-1.5 rounded-full bg-secondary overflow-hidden" aria-hidden="true">
                      <div
                        className="h-full bg-linear-to-r from-violet to-violet-glow transition-all shadow-[0_0_12px_var(--violet-glow)]"
                        style={{ width: `${(setupSteps.filter((s) => s.done).length / setupSteps.length) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
                <ol className="relative z-10 mt-6 space-y-3">
                  {setupSteps.map((s, i) => (
                    <li
                      key={s.key}
                      className={`group grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 rounded-2xl border p-4 transition-colors ${
                        s.done
                          ? "border-violet/25 bg-violet/[0.06]"
                          : "border-hairline bg-background/40 hover:border-violet/30"
                      }`}
                    >
                      <div className={`grid place-items-center h-9 w-9 rounded-full border ${s.done ? "border-violet/40 bg-violet/15" : "border-hairline bg-surface-elevated"}`}>
                        {s.done ? (
                          <CheckCircle2 className="h-4 w-4 text-violet-glow" aria-label="Complete" />
                        ) : (
                          <Circle className="h-4 w-4 text-muted-foreground" aria-label="Incomplete" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground/80">Step {String(i + 1).padStart(2, "0")}</div>
                        <div className={`mt-0.5 text-sm font-medium truncate ${s.done ? "line-through text-muted-foreground" : ""}`}>
                          {s.label}
                        </div>
                      </div>
                      <Link
                        to={s.to}
                        className="shrink-0 inline-flex items-center gap-1.5 rounded-full border border-hairline bg-surface-elevated/60 px-3 py-1.5 text-xs font-medium hover:border-violet/40 hover:text-foreground transition-colors"
                      >
                        {s.cta} <ArrowRight className="h-3 w-3" />
                      </Link>
                    </li>
                  ))}
                </ol>
              </section>

              {/* Recent listings */}
              <section aria-labelledby="recent-heading" className="hs-form-card relative overflow-hidden p-6 sm:p-8">
                <div className="relative z-10 flex items-center justify-between gap-2">
                  <div>
                    <span className="hs-dash-eyebrow">
                      <span className="hs-dash-eyebrow-dot" aria-hidden />
                      Ledger
                    </span>
                    <h2 id="recent-heading" className="mt-3 font-display text-2xl">Your listings</h2>
                  </div>
                  <Link to="/dashboard/listings" className="text-xs text-violet-glow hover:text-foreground transition-colors">
                    View all →
                  </Link>
                </div>
                {recent.length === 0 ? (
                  <div className="hs-empty mt-6">
                    <div className="hs-empty-icon"><Sparkles className="h-5 w-5" aria-hidden="true" /></div>
                    <p className="hs-empty-title">No listings yet</p>
                    <p className="hs-empty-desc">Publish your first SaaS to start collecting proposals from vetted founders.</p>
                    <Link
                      to="/list"
                      className="mt-5 inline-flex items-center gap-2 rounded-full bg-violet px-4 py-2 text-xs font-semibold text-primary-foreground hover:bg-violet-glow transition-colors"
                    >
                      <Plus className="h-3.5 w-3.5" /> Create listing
                    </Link>
                  </div>
                ) : (
                  <ul className="relative z-10 mt-5 space-y-2">
                    {recent.map((r) => (
                      <li key={r.id}>
                        <Link
                          to="/saas/$slug"
                          params={{ slug: r.slug }}
                          className="group grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border border-hairline bg-background/40 p-3 hover:border-violet/40 hover:bg-background/60 transition-colors"
                        >
                          <div className="hs-swap-logo h-9 w-9 text-[11px]">
                            {(r.name || "?").slice(0, 2).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-medium truncate">{r.name}</div>
                            <div className="mt-0.5 flex items-center gap-2 text-[11px] text-muted-foreground">
                              <span className={`inline-flex h-1.5 w-1.5 rounded-full ${r.status === "live" ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.7)]" : "bg-muted-foreground/50"}`} aria-hidden />
                              <span className="capitalize">{r.status ?? "draft"}</span>
                              <span aria-hidden>·</span>
                              <span>{r.interested_count ?? 0} interested</span>
                            </div>
                          </div>
                          <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-violet-glow group-hover:translate-x-0.5 transition-all shrink-0" aria-hidden="true" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>

          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
