import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Receipt, Download } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/payments")({
  head: () => ({ meta: [{ title: "Payments — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: Page,
});

type PaymentRow = {
  id: string;
  amount_cents: number;
  currency: string;
  status: string;
  created_at: string;
  paid_at: string | null;
  swap_request_id: string;
  stripe_checkout_session_id: string | null;
};

const TABS = [
  { id: "all", label: "All" },
  { id: "paid", label: "Paid" },
  { id: "pending", label: "Pending" },
  { id: "refunded", label: "Refunded" },
  { id: "failed", label: "Failed" },
];

function Page() {
  const [rows, setRows] = useState<PaymentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("all");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from("payments")
        .select("id, amount_cents, currency, status, created_at, paid_at, swap_request_id, stripe_checkout_session_id")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      setRows((data ?? []) as PaymentRow[]);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => tab === "all" ? rows : rows.filter((r) => r.status === tab), [rows, tab]);
  const paidTotal = rows.filter((r) => r.status === "paid").reduce((s, r) => s + r.amount_cents, 0);

  function exportCsv() {
    const header = ["Date", "Amount", "Currency", "Status", "Swap ID", "Session ID"];
    const lines = [header.join(",")];
    for (const r of filtered) {
      lines.push([
        new Date(r.created_at).toISOString(),
        (r.amount_cents / 100).toFixed(2),
        r.currency.toUpperCase(),
        r.status,
        r.swap_request_id,
        r.stripe_checkout_session_id ?? "",
      ].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","));
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `heysaas-payments-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="payments"
              eyebrow="Ledger · $19 safety fee"
              title="Payments"
              description="Every safety fee you've paid on Hey SaaS — receipts, refunds, and pending charges in one place."
              actions={rows.length > 0 ? (
                <Button variant="outline" size="sm" onClick={exportCsv} className="rounded-full">
                  <Download className="h-4 w-4 mr-2" />Export CSV
                </Button>
              ) : undefined}
            />
            <DashRibbon variant="payments" />
            <DashBodyBlock variant="payments" />

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="hs-stat">
                <div className="flex items-center gap-3">
                  <span className="hs-stat-icon"><Receipt className="h-4 w-4" /></span>
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Total paid</span>
                </div>
                <div className="mt-4 hs-stat-value">${(paidTotal / 100).toFixed(2)}</div>
              </div>
              <div className="hs-stat">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Transactions</div>
                <div className="mt-4 hs-stat-value">{rows.length}</div>
              </div>
              <div className="hs-stat">
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Pending</div>
                <div className="mt-4 hs-stat-value">{rows.filter((r) => r.status === "pending").length}</div>
              </div>
            </div>

            <div className="mt-8 hs-seg overflow-x-auto max-w-full">
              {TABS.map((t) => {
                const c = t.id === "all" ? rows.length : rows.filter((r) => r.status === t.id).length;
                return (
                  <button
                    key={t.id}
                    onClick={() => setTab(t.id)}
                    className={`hs-seg-item ${tab === t.id ? "active" : ""}`}
                  >
                    {t.label} <span className="opacity-70 ml-1">({c})</span>
                  </button>
                );
              })}
            </div>

            <div className="mt-6">
              {loading ? (
                <div className="py-16 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
              ) : filtered.length === 0 ? (
                <div className="hs-empty">
                  <div className="hs-empty-icon"><Receipt className="h-6 w-6" /></div>
                  <p className="mt-5 font-display text-3xl">{rows.length === 0 ? "No payments yet." : "Nothing here."}</p>
                  <p className="mt-2 text-sm text-muted-foreground">Safety fees appear here once you agree to a swap.</p>
                </div>
              ) : (
                <div className="rounded-2xl border border-hairline overflow-hidden bg-surface/60 backdrop-blur">
                  <table className="w-full text-sm">
                    <thead className="bg-surface-elevated/60 text-muted-foreground text-[10px] uppercase tracking-widest">
                      <tr><th className="text-left px-5 py-4">Date</th><th className="text-left px-5 py-4">Amount</th><th className="text-left px-5 py-4">Status</th><th className="text-left px-5 py-4">Swap</th><th className="text-left px-5 py-4">Receipt</th></tr>
                    </thead>
                    <tbody>
                      {filtered.map((r) => (
                        <tr key={r.id} className="border-t border-hairline hover:bg-surface-elevated/40 transition-colors">
                          <td className="px-5 py-4 text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</td>
                          <td className="px-5 py-4 font-medium tabular-nums">${(r.amount_cents / 100).toFixed(2)} {r.currency.toUpperCase()}</td>
                          <td className="px-5 py-4"><StatusBadge status={r.status} /></td>
                          <td className="px-5 py-4"><Link to="/dashboard/swaps/$id" params={{ id: r.swap_request_id }} className="text-violet hover:underline">Open swap</Link></td>
                          <td className="px-5 py-4">{r.status === "paid" ? <Link to="/dashboard/payments/$id" params={{ id: r.id }} className="text-violet hover:underline">View</Link> : <span className="text-muted-foreground">—</span>}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    paid: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
    pending: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    refunded: "bg-sky-500/15 text-sky-400 border-sky-500/30",
    failed: "bg-red-500/15 text-red-400 border-red-500/30",
  };
  return <Badge variant="outline" className={`rounded-full ${map[status] || ""}`}>{status}</Badge>;
}
