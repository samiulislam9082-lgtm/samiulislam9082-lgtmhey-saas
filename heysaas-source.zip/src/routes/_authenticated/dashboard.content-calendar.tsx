import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Copy, Calendar as CalendarIcon, Check } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/content-calendar")({
  head: () => ({ meta: [{ title: "Content calendar — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: ContentCalendarPage,
});

type Channel = "twitter" | "linkedin" | "reddit" | "hn" | "producthunt" | "email" | "blog" | "other";
type Post = { id: string; date: string; channel: Channel; title: string; body: string; status: "idea" | "scheduled" | "published" };

const CHANNELS: Channel[] = ["twitter", "linkedin", "reddit", "hn", "producthunt", "email", "blog", "other"];
const channelTone: Record<Channel, string> = {
  twitter: "bg-sky-500/15 text-sky-200",
  linkedin: "bg-blue-500/15 text-blue-200",
  reddit: "bg-orange-500/15 text-orange-200",
  hn: "bg-amber-500/15 text-amber-200",
  producthunt: "bg-rose-500/15 text-rose-200",
  email: "bg-emerald-500/15 text-emerald-200",
  blog: "bg-violet-500/15 text-violet-200",
  other: "bg-white/10 text-white/70",
};

const IDEAS = [
  "Weekly changelog thread — 3 wins, 1 miss, next week's bet",
  "Behind the scenes: the boring architecture decision that saved you time",
  "Ship a public teardown of a competitor's onboarding",
  "Post 5 numbers from your dashboard people don't usually share",
  "Reply to 10 tweets from your ICP with useful context, no pitch",
  "Publish your pricing page rationale (why not $9? why not $99?)",
  "Founder story: the week you almost quit",
  "AMA in a niche subreddit or Slack community",
];

function ContentCalendarPage() {
  const [uid, setUid] = useState<string | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [draft, setDraft] = useState<Partial<Post>>({ channel: "twitter", status: "idea", date: new Date().toISOString().slice(0,10) });
  const [filter, setFilter] = useState<"all" | Post["status"]>("all");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUid(user.id);
      try {
        const raw = localStorage.getItem(`hs.calendar.${user.id}`);
        if (raw) setPosts(JSON.parse(raw));
      } catch {}
    })();
  }, []);

  const persist = (next: Post[]) => {
    setPosts(next);
    if (uid) localStorage.setItem(`hs.calendar.${uid}`, JSON.stringify(next));
  };

  const add = () => {
    if (!draft.title) { toast.error("Title required"); return; }
    const p: Post = {
      id: crypto.randomUUID(),
      date: draft.date ?? new Date().toISOString().slice(0,10),
      channel: (draft.channel as Channel) ?? "twitter",
      title: draft.title!, body: draft.body ?? "",
      status: (draft.status as Post["status"]) ?? "idea",
    };
    persist([p, ...posts]);
    setDraft({ channel: "twitter", status: "idea", date: new Date().toISOString().slice(0,10) });
    toast.success("Added to calendar");
  };

  const setStatus = (id: string, status: Post["status"]) => persist(posts.map((p) => p.id === id ? { ...p, status } : p));
  const remove = (id: string) => persist(posts.filter((p) => p.id !== id));

  const grouped = useMemo(() => {
    const filtered = filter === "all" ? posts : posts.filter((p) => p.status === filter);
    const sorted = [...filtered].sort((a, b) => a.date.localeCompare(b.date));
    const map: Record<string, Post[]> = {};
    sorted.forEach((p) => { (map[p.date] ??= []).push(p); });
    return map;
  }, [posts, filter]);

  const cadence = posts.filter((p) => p.status === "published").length;
  const scheduled = posts.filter((p) => p.status === "scheduled").length;

  const seedIdea = (text: string) => setDraft({ ...draft, title: text });

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <div className="hs-noir hs-dash-shell flex-1">
        <div className="hs-dash-canvas" aria-hidden="true">
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--one" />
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--two" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col lg:flex-row gap-8 relative">
          <DashboardSidebar />
          <main id="main" className="flex-1 min-w-0 space-y-6">
            <BackButton />
            <DashHero
              eyebrow="Marketing · Content"
              title="Plan the drum you keep beating."
              description="Consistency beats brilliance. Sketch a week of posts in ten minutes, then ship them one by one."
              signature="overview"
              actions={
                <>
                  <Badge variant="secondary">{cadence} shipped · {scheduled} scheduled</Badge>
                </>
              }
            />

            <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
              <div className="space-y-6">
                <Card className="p-5">
                  <h3 className="text-sm font-medium mb-3 flex items-center gap-2"><Plus className="w-4 h-4" /> New post</h3>
                  <div className="grid gap-3 md:grid-cols-3">
                    <Input type="date" value={draft.date ?? ""} onChange={(e) => setDraft({ ...draft, date: e.target.value })} />
                    <Select value={draft.channel as string} onValueChange={(v) => setDraft({ ...draft, channel: v as Channel })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{CHANNELS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select value={draft.status as string} onValueChange={(v) => setDraft({ ...draft, status: v as Post["status"] })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="idea">Idea</SelectItem>
                        <SelectItem value="scheduled">Scheduled</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Input className="mt-3" placeholder="Hook / title" value={draft.title ?? ""} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
                  <Textarea className="mt-3" rows={3} placeholder="Draft copy…" value={draft.body ?? ""} onChange={(e) => setDraft({ ...draft, body: e.target.value })} />
                  <div className="mt-3 flex justify-end"><Button onClick={add}><Plus className="w-4 h-4 mr-2" />Add</Button></div>
                </Card>

                <div className="flex flex-wrap gap-2">
                  {(["all","idea","scheduled","published"] as const).map((s) => (
                    <button key={s} onClick={() => setFilter(s)}
                      className={`px-3 py-1.5 rounded-full text-xs border ${filter === s ? "bg-white/10 border-white/20" : "border-white/10 hover:bg-white/5"}`}>
                      {s}
                    </button>
                  ))}
                </div>

                {Object.keys(grouped).length === 0 ? (
                  <Card className="p-10 text-center text-sm text-muted-foreground">
                    <CalendarIcon className="w-8 h-8 mx-auto opacity-40 mb-2" />
                    No posts yet. Grab a prompt from the right and start.
                  </Card>
                ) : (
                  <div className="space-y-4">
                    {Object.entries(grouped).map(([date, list]) => (
                      <Card key={date} className="p-4">
                        <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">
                          {new Date(date).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}
                        </div>
                        <div className="space-y-3">
                          {list.map((p) => (
                            <div key={p.id} className="flex items-start gap-3 p-3 rounded-lg border border-white/5 bg-white/[0.02]">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] shrink-0 ${channelTone[p.channel]}`}>{p.channel}</span>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-medium">{p.title}</div>
                                {p.body && <div className="text-xs text-muted-foreground mt-1 whitespace-pre-wrap">{p.body}</div>}
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <Select value={p.status} onValueChange={(v) => setStatus(p.id, v as any)}>
                                  <SelectTrigger className="h-7 w-28 text-xs"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="idea">Idea</SelectItem>
                                    <SelectItem value="scheduled">Scheduled</SelectItem>
                                    <SelectItem value="published">Published</SelectItem>
                                  </SelectContent>
                                </Select>
                                <Button variant="ghost" size="icon" aria-label="Copy" onClick={() => { navigator.clipboard.writeText(`${p.title}\n\n${p.body}`); toast.success("Copied"); }}><Copy className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="icon" aria-label="Delete" onClick={() => remove(p.id)}><Trash2 className="w-4 h-4" /></Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>

              <Card className="p-5 h-fit sticky top-24">
                <h3 className="text-sm font-medium mb-3">Prompt bank</h3>
                <p className="text-xs text-muted-foreground mb-4">Tap one to seed the composer.</p>
                <div className="space-y-2">
                  {IDEAS.map((idea) => (
                    <button key={idea} onClick={() => seedIdea(idea)}
                      className="w-full text-left text-xs p-3 rounded-lg border border-white/5 hover:bg-white/5 hover:border-white/10 transition-colors flex items-start gap-2">
                      <Check className="w-3 h-3 mt-0.5 opacity-40 shrink-0" />
                      <span>{idea}</span>
                    </button>
                  ))}
                </div>
              </Card>
            </div>
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
