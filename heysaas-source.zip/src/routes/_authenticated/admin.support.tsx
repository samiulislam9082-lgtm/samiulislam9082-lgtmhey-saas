import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BarChart3, MessageSquare, AlertTriangle, TicketCheck, Users, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/support")({
  head: () => ({ meta: [{ title: "Support Analytics — Admin" }, { name: "robots", content: "noindex" }] }),
  component: SupportAnalytics,
});

type Ev = {
  id: string;
  session_id: string;
  event_type: string;
  topic: string | null;
  error_code: string | null;
  status: number | null;
  created_at: string;
};

const RANGES = [
  { key: "24h", label: "24h", hours: 24 },
  { key: "7d", label: "7d", hours: 24 * 7 },
  { key: "30d", label: "30d", hours: 24 * 30 },
] as const;

function SupportAnalytics() {
  const [range, setRange] = useState<(typeof RANGES)[number]["key"]>("7d");
  const [events, setEvents] = useState<Ev[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const hours = RANGES.find((r) => r.key === range)!.hours;
    const since = new Date(Date.now() - hours * 3600_000).toISOString();
    setLoading(true);
    supabase
      .from("support_chat_events")
      .select("id, session_id, event_type, topic, error_code, status, created_at")
      .gte("created_at", since)
      .order("created_at", { ascending: false })
      .limit(5000)
      .then(({ data }) => {
        setEvents((data as Ev[]) ?? []);
        setLoading(false);
      });
  }, [range]);

  const stats = useMemo(() => {
    const sessions = new Set(events.map((e) => e.session_id));
    const opened = events.filter((e) => e.event_type === "chat_opened").length;
    const messages = events.filter((e) => e.event_type === "message_sent" || e.event_type === "quick_reply_clicked" || e.event_type === "faq_ask_ai").length;
    const errors = events.filter((e) => e.event_type === "chat_error");
    const tickets = events.filter((e) => e.event_type === "ticket_submitted").length;
    const escalations = events.filter((e) => e.event_type === "escalation_started").length;
    const followUps = events.filter((e) => e.event_type === "follow_up_requested").length;

    // Per-topic aggregation
    type Row = { topic: string; messages: number; escalations: number; tickets: number };
    const perTopic: Record<string, Row> = {};
    const bump = (topic: string, key: keyof Omit<Row, "topic">) => {
      perTopic[topic] ??= { topic, messages: 0, escalations: 0, tickets: 0 };
      perTopic[topic][key]++;
    };
    for (const e of events) {
      if (!e.topic) continue;
      if (["message_sent", "quick_reply_clicked", "faq_ask_ai"].includes(e.event_type)) bump(e.topic, "messages");
      if (["escalation_started", "follow_up_requested"].includes(e.event_type)) bump(e.topic, "escalations");
      if (e.event_type === "ticket_submitted") bump(e.topic, "tickets");
    }
    const topicRows = Object.values(perTopic).sort((a, b) => b.messages - a.messages);

    const errorCount: Record<string, number> = {};
    for (const e of errors) {
      const k = e.error_code ?? "unknown";
      errorCount[k] = (errorCount[k] ?? 0) + 1;
    }
    const errorRows = Object.entries(errorCount).sort((a, b) => b[1] - a[1]);

    return {
      sessions: sessions.size, opened, messages, errors: errors.length,
      tickets, escalations, followUps, topicRows, errorRows,
      errorRate: messages > 0 ? errors.length / messages : 0,
      escalationRate: messages > 0 ? (escalations + followUps) / messages : 0,
      ticketConversion: (escalations + followUps) > 0 ? tickets / (escalations + followUps) : 0,
    };
  }, [events]);

  const topicMax = stats.topicRows[0]?.messages ?? 1;
  const errMax = stats.errorRows[0]?.[1] ?? 1;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-serif tracking-tight">Support chat analytics</h1>
          <p className="text-sm text-muted-foreground">Usage, hot topics, and AI errors. Click a topic to drill down.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-full border border-hairline bg-background p-1">
            {RANGES.map((r) => (
              <button key={r.key} onClick={() => setRange(r.key)}
                className={`px-3 py-1 text-xs rounded-full transition ${range === r.key ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                {r.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <Kpi icon={Users} label="Sessions" value={stats.sessions} />
        <Kpi icon={MessageSquare} label="Chats opened" value={stats.opened} />
        <Kpi icon={BarChart3} label="Messages" value={stats.messages} />
        <Kpi icon={AlertTriangle} label="Errors" value={stats.errors} accent={stats.errors > 0 ? "warn" : undefined} />
        <Kpi icon={TicketCheck} label="Escalations" value={stats.escalations + stats.followUps} />
        <Kpi icon={TicketCheck} label="Tickets" value={stats.tickets} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MiniStat label="Error rate" value={`${(stats.errorRate*100).toFixed(1)}%`} tone={stats.errorRate>0.05?"warn":"ok"}/>
        <MiniStat label="Escalation rate" value={`${(stats.escalationRate*100).toFixed(1)}%`}/>
        <MiniStat label="Escalation → ticket" value={`${(stats.ticketConversion*100).toFixed(0)}%`}/>
        <MiniStat label="Follow-ups" value={stats.followUps.toString()}/>
      </div>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div>
            <h2 className="text-sm font-medium">Topic escalation & ticket conversion</h2>
            <p className="text-[11px] text-muted-foreground">Rates per topic. Click a row to drill down.</p>
          </div>
          <div className="text-[11px] text-muted-foreground">
            Overall: <span className="text-foreground">{(stats.escalationRate*100).toFixed(1)}%</span> escalate ·
            <span className="text-foreground"> {(stats.ticketConversion*100).toFixed(0)}%</span> convert to ticket
          </div>
        </div>
        {loading ? (<p className="text-xs text-muted-foreground">Loading…</p>) : stats.topicRows.length === 0 ? (
          <p className="text-xs text-muted-foreground">No topic data yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="text-left text-muted-foreground">
                <tr>
                  <th className="py-2 pr-4">Topic</th>
                  <th className="py-2 pr-4 text-right">Messages</th>
                  <th className="py-2 pr-4 text-right">Escalations</th>
                  <th className="py-2 pr-4 text-right">Tickets</th>
                  <th className="py-2 pr-4">Escalation rate</th>
                  <th className="py-2 pr-4">Ticket conversion</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-hairline">
                {stats.topicRows.slice(0, 20).map((r) => {
                  const escRate = r.messages ? r.escalations / r.messages : 0;
                  const tktRate = r.escalations ? r.tickets / r.escalations : 0;
                  return (
                    <tr key={r.topic} className="hover:bg-muted/20 transition">
                      <td className="py-2 pr-4">
                        <Link to="/admin/support-drilldown/$topic" params={{ topic: r.topic }} className="capitalize inline-flex items-center gap-1 hover:underline">
                          {r.topic.replace(/_/g, " ")} <ArrowRight className="h-3 w-3"/>
                        </Link>
                      </td>
                      <td className="py-2 pr-4 text-right tabular-nums">{r.messages}</td>
                      <td className="py-2 pr-4 text-right tabular-nums">{r.escalations}</td>
                      <td className="py-2 pr-4 text-right tabular-nums">{r.tickets}</td>
                      <td className="py-2 pr-4 min-w-[140px]">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 flex-1 rounded-full bg-muted/40 overflow-hidden">
                            <div className={`h-full ${escRate>0.25?"bg-amber-500":"bg-violet"}`} style={{ width: `${Math.min(100, escRate*100)}%` }}/>
                          </div>
                          <span className={`tabular-nums text-[11px] ${escRate>0.25?"text-amber-500":"text-muted-foreground"}`}>{(escRate*100).toFixed(0)}%</span>
                        </div>
                      </td>
                      <td className="py-2 pr-4 min-w-[140px]">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 flex-1 rounded-full bg-muted/40 overflow-hidden">
                            <div className="h-full bg-emerald-500" style={{ width: `${Math.min(100, tktRate*100)}%` }}/>
                          </div>
                          <span className="tabular-nums text-[11px] text-muted-foreground">{(tktRate*100).toFixed(0)}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-4">Top topics by volume <span className="text-[10px] text-muted-foreground">(click to drill down)</span></h2>
          {loading ? (<p className="text-xs text-muted-foreground">Loading…</p>) : stats.topicRows.length === 0 ? (
            <p className="text-xs text-muted-foreground">No topic data yet.</p>
          ) : (
            <ul className="space-y-2">
              {stats.topicRows.slice(0, 12).map((r) => (
                <li key={r.topic} className="text-xs">
                  <Link to="/admin/support-drilldown/$topic" params={{ topic: r.topic }} className="block hover:bg-muted/20 rounded-md p-1.5 -mx-1.5 transition">
                    <div className="flex justify-between mb-1 items-center">
                      <span className="capitalize">{r.topic.replace(/_/g, " ")}</span>
                      <span className="text-muted-foreground">{r.messages} msgs <ArrowRight className="inline h-3 w-3"/></span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted/40 overflow-hidden">
                      <div className="h-full bg-violet" style={{ width: `${(r.messages / topicMax) * 100}%` }} />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-1">Errors</h2>
          <p className="text-[11px] text-muted-foreground mb-4">
            Error rate: <span className={stats.errorRate > 0.05 ? "text-amber-500" : "text-foreground"}>{(stats.errorRate * 100).toFixed(1)}%</span> of AI replies
          </p>
          {loading ? (<p className="text-xs text-muted-foreground">Loading…</p>) : stats.errorRows.length === 0 ? (
            <p className="text-xs text-muted-foreground">No errors in this window.</p>
          ) : (
            <ul className="space-y-2">
              {stats.errorRows.map(([k, v]) => (
                <li key={k} className="text-xs">
                  <div className="flex justify-between mb-1">
                    <span className="capitalize">{k.replace(/_/g, " ")}</span>
                    <span className="text-muted-foreground">{v}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted/40 overflow-hidden">
                    <div className={`h-full ${k === "rate_limited" || k === "credits_exhausted" ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${(v / errMax) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <h2 className="text-sm font-medium mb-4">Recent events</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="text-left text-muted-foreground">
              <tr>
                <th className="py-2 pr-4">When</th>
                <th className="py-2 pr-4">Event</th>
                <th className="py-2 pr-4">Topic</th>
                <th className="py-2 pr-4">Error</th>
                <th className="py-2 pr-4">Session</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-hairline">
              {events.slice(0, 50).map((e) => (
                <tr key={e.id}>
                  <td className="py-2 pr-4 whitespace-nowrap text-muted-foreground">{new Date(e.created_at).toLocaleString()}</td>
                  <td className="py-2 pr-4">{e.event_type}</td>
                  <td className="py-2 pr-4 capitalize">{e.topic?.replace(/_/g, " ") ?? "—"}</td>
                  <td className="py-2 pr-4">{e.error_code ? <span className="text-rose-500">{e.error_code}</span> : "—"}</td>
                  <td className="py-2 pr-4 font-mono text-[10px] text-muted-foreground">{e.session_id.slice(0, 12)}…</td>
                </tr>
              ))}
              {!loading && events.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-muted-foreground">
                    No events yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function Kpi({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: typeof Users;
  label: string;
  value: number;
  accent?: "warn";
}) {
  return (
    <div className="rounded-xl border border-hairline bg-surface p-4">
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </div>
      <div className={`mt-2 text-2xl font-serif ${accent === "warn" ? "text-amber-500" : ""}`}>{value.toLocaleString()}</div>
    </div>
  );
}

function MiniStat({ label, value, tone }: { label: string; value: string; tone?: "warn" | "ok" }) {
  return (
    <div className="rounded-xl border border-hairline bg-surface p-4">
      <div className="text-[11px] uppercase text-muted-foreground">{label}</div>
      <div className={`mt-1 text-lg font-serif ${tone === "warn" ? "text-amber-500" : ""}`}>{value}</div>
    </div>
  );
}
