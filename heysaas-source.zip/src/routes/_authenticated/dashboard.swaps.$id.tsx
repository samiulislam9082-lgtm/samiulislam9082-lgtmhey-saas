import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { createFeeCheckout, confirmSwap, disputeSwap } from "@/lib/payments.functions";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Loader2, Shield, CheckCircle2, AlertTriangle, MessageSquare, ArrowRight } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard/swaps/$id")({
  head: () => ({ meta: [{ title: "Swap Room — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: SwapRoom,
});

type Swap = {
  id: string;
  status: string;
  initiator_id: string;
  recipient_id: string;
  initiator_confirmed_at: string | null;
  recipient_confirmed_at: string | null;
  note: string | null;
  fee_deadline_at: string | null;
  created_at: string;
  initiator_listing: { id: string; name: string; slug: string; logo_url: string | null; tagline: string | null } | null;
  recipient_listing: { id: string; name: string; slug: string; logo_url: string | null; tagline: string | null } | null;
};

type Msg = { id: string; sender_id: string; body: string; created_at: string };

function SwapRoom() {
  const { id } = Route.useParams();
  const router = useRouter();
  const [userId, setUserId] = useState<string | null>(null);
  const [swap, setSwap] = useState<Swap | null>(null);
  const [threadId, setThreadId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);
  const [disputeReason, setDisputeReason] = useState("");
  const [busy, setBusy] = useState(false);

  const payFee = useServerFn(createFeeCheckout);
  const confirm = useServerFn(confirmSwap);
  const dispute = useServerFn(disputeSwap);

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setUserId(user.id);
    const { data } = await supabase
      .from("swap_requests")
      .select(`
        id, status, initiator_id, recipient_id, initiator_confirmed_at, recipient_confirmed_at, note, fee_deadline_at, created_at,
        initiator_listing:saas_listings!swap_requests_initiator_listing_id_fkey ( id, name, slug, logo_url, tagline ),
        recipient_listing:saas_listings!swap_requests_recipient_listing_id_fkey ( id, name, slug, logo_url, tagline )
      `)
      .eq("id", id)
      .maybeSingle();
    setSwap(data as Swap | null);
    const { data: t } = await supabase.from("threads").select("id").eq("swap_request_id", id).maybeSingle();
    setThreadId(t?.id ?? null);
    if (t?.id) {
      const { data: m } = await supabase.from("messages").select("id, sender_id, body, created_at").eq("thread_id", t.id).order("created_at");
      setMessages(m || []);
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, [id]);

  useEffect(() => {
    if (!threadId) return;
    const ch = supabase
      .channel(`thread:${threadId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `thread_id=eq.${threadId}` }, (payload) => {
        setMessages((prev) => [...prev, payload.new as Msg]);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [threadId]);

  async function handlePay() {
    setBusy(true);
    try {
      const res = await payFee({ data: { swap_id: id } });
      if (res.mode === "stripe") window.location.href = res.url;
      else { toast.success("Fee paid (dev mode)"); await load(); }
    } catch (e: any) { toast.error(e.message); }
    setBusy(false);
  }

  async function handleConfirm() {
    setBusy(true);
    try {
      await confirm({ data: { swap_id: id } });
      toast.success("Confirmation recorded");
      await load();
      router.invalidate();
    } catch (e: any) { toast.error(e.message); }
    setBusy(false);
  }

  async function handleDispute() {
    if (disputeReason.trim().length < 10) { toast.error("Give a bit more detail (10+ chars)"); return; }
    setBusy(true);
    try {
      await dispute({ data: { swap_id: id, reason: disputeReason } });
      toast.success("Dispute opened — admins will review");
      setDisputeReason("");
      await load();
    } catch (e: any) { toast.error(e.message); }
    setBusy(false);
  }

  async function handleSend() {
    if (!msg.trim() || !threadId) return;
    const body = msg;
    setMsg("");
    const { sendMessage } = await import("@/lib/messages.functions");
    try {
      await sendMessage({ data: { thread_id: threadId, body } });
    } catch (e: any) { toast.error(e.message); setMsg(body); }
  }

  if (loading || !swap || !userId) return <FullPage><div className="flex items-center justify-center py-24"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div></FullPage>;

  const isInitiator = swap.initiator_id === userId;
  const iConfirmed = isInitiator ? !!swap.initiator_confirmed_at : !!swap.recipient_confirmed_at;
  const partnerConfirmed = isInitiator ? !!swap.recipient_confirmed_at : !!swap.initiator_confirmed_at;
  const canPay = ["matched_fee_pending", "fee_paid_one_side"].includes(swap.status);
  const feePaidByMe = swap.status === "confirmed" || swap.status === "completed" || (swap.status === "fee_paid_one_side" && false); // simplified
  const roomUnlocked = ["confirmed", "completed", "disputed"].includes(swap.status);

  const myListing = isInitiator ? swap.initiator_listing : swap.recipient_listing;
  const theirListing = isInitiator ? swap.recipient_listing : swap.initiator_listing;

  return (
    <FullPage>
      <div className="mb-6 flex items-center gap-2 text-sm text-muted-foreground">
        <Link to="/dashboard/swaps" className="hover:text-foreground">Swaps</Link>
        <ArrowRight className="h-3 w-3" />
        <span>Swap Room</span>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <h1 className="font-display text-3xl">Swap Room</h1>
              <StatusBadge status={swap.status} />
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <ListingBlock listing={myListing} label="Your SaaS" />
              <ListingBlock listing={theirListing} label="Their SaaS" />
            </div>
            {swap.note && (
              <div className="mt-6 rounded-2xl border bg-muted/30 p-4 text-sm">
                <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Proposal note</div>
                {swap.note}
              </div>
            )}
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4"><MessageSquare className="h-4 w-4" /><h2 className="font-medium">Messages</h2></div>
            {!roomUnlocked ? (
              <p className="text-sm text-muted-foreground">Messaging unlocks after both parties pay the $19 safety fee.</p>
            ) : (
              <>
                <div className="max-h-96 overflow-y-auto space-y-3 mb-4 pr-2">
                  {messages.length === 0 && <p className="text-sm text-muted-foreground">No messages yet — say hi 👋</p>}
                  {messages.map((m) => (
                    <div key={m.id} className={`flex ${m.sender_id === userId ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${m.sender_id === userId ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>
                        {m.body}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Textarea value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Type a message…" className="min-h-[60px]" onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleSend(); }} />
                  <Button onClick={handleSend} disabled={!msg.trim()}>Send</Button>
                </div>
              </>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-3"><Shield className="h-4 w-4 text-primary" /><h3 className="font-medium">Safety fee</h3></div>
            <p className="text-sm text-muted-foreground mb-4">$19 non-refundable fee from each side. Prevents ghosting.</p>
            {canPay && (
              <Button className="w-full" onClick={handlePay} disabled={busy}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Pay $19 safety fee"}
              </Button>
            )}
            {swap.status === "confirmed" && <div className="text-sm text-emerald-500 flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Both sides paid</div>}
            {swap.status === "completed" && <div className="text-sm text-emerald-500 flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> Swap complete</div>}
          </Card>

          {swap.status === "confirmed" && (
            <Card className="p-6">
              <h3 className="font-medium mb-2">Complete the swap</h3>
              <p className="text-sm text-muted-foreground mb-4">Once you've received access to their SaaS, mark it complete.</p>
              <div className="text-xs text-muted-foreground mb-3">
                You: {iConfirmed ? "✓ Confirmed" : "Pending"} · Partner: {partnerConfirmed ? "✓ Confirmed" : "Pending"}
              </div>
              <Button className="w-full" onClick={handleConfirm} disabled={busy || iConfirmed}>
                {iConfirmed ? "You confirmed" : "I received access"}
              </Button>
            </Card>
          )}

          {roomUnlocked && swap.status !== "completed" && swap.status !== "disputed" && (
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full"><AlertTriangle className="h-4 w-4 mr-2" />Open dispute</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Open a dispute</DialogTitle></DialogHeader>
                <p className="text-sm text-muted-foreground">Describe what went wrong. An admin will review within 48 hours.</p>
                <Textarea value={disputeReason} onChange={(e) => setDisputeReason(e.target.value)} placeholder="What happened?" rows={5} />
                <DialogFooter><Button onClick={handleDispute} disabled={busy}>Submit dispute</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>
    </FullPage>
  );
}

function FullPage({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-12">{children}</main>
      <Footer />
    </div>
  );
}

function ListingBlock({ listing, label }: { listing: Swap["initiator_listing"]; label: string }) {
  if (!listing) return <div className="rounded-2xl border p-4 text-sm text-muted-foreground">Missing listing</div>;
  return (
    <Link to="/saas/$slug" params={{ slug: listing.slug }} className="block rounded-2xl border p-4 hover:border-primary/50 transition-colors">
      <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{label}</div>
      <div className="flex items-center gap-3">
        {listing.logo_url ? <img src={listing.logo_url} className="h-10 w-10 rounded-lg object-cover" alt="" /> : <div className="h-10 w-10 rounded-lg bg-secondary" />}
        <div className="min-w-0">
          <div className="font-medium truncate">{listing.name}</div>
          {listing.tagline && <div className="text-xs text-muted-foreground truncate">{listing.tagline}</div>}
        </div>
      </div>
    </Link>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    pending: { label: "Pending", cls: "bg-amber-500/15 text-amber-400" },
    accepted: { label: "Accepted", cls: "bg-blue-500/15 text-blue-400" },
    matched_fee_pending: { label: "Fee pending", cls: "bg-amber-500/15 text-amber-400" },
    fee_paid_one_side: { label: "1/2 paid", cls: "bg-amber-500/15 text-amber-400" },
    confirmed: { label: "Confirmed", cls: "bg-emerald-500/15 text-emerald-400" },
    completed: { label: "Completed", cls: "bg-emerald-500/15 text-emerald-400" },
    disputed: { label: "Disputed", cls: "bg-red-500/15 text-red-400" },
    declined: { label: "Declined", cls: "bg-muted text-muted-foreground" },
    cancelled: { label: "Cancelled", cls: "bg-muted text-muted-foreground" },
  };
  const m = map[status] || { label: status, cls: "bg-muted text-muted-foreground" };
  return <Badge className={`${m.cls} border-0`}>{m.label}</Badge>;
}
