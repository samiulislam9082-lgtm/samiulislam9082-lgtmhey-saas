import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Copy, Mail } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/email-templates")({
  head: () => ({ meta: [{ title: "Email templates — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: EmailTemplatesPage,
});

type Tmpl = { id: string; name: string; use: string; subject: string; body: string };

const LIBRARY: Tmpl[] = [
  { id: "intro-swap", name: "Cold swap intro", use: "Reach out to a founder whose SaaS you'd like to swap for",
    subject: "Quick swap idea: {{yourSaaS}} ↔ {{theirSaaS}}",
    body: `Hey {{firstName}},

I saw {{theirSaaS}} on Hey SaaS — really thoughtful positioning. I run {{yourSaaS}} ({{yourURL}}), currently at {{yourMRR}} MRR with {{yourUsers}} users.

We're a natural fit for a swap because {{reason}}. Both products land at a similar stage and the audiences barely overlap, so this is asymmetric upside for both of us.

Open to a 15-minute call this week? Happy to send my dashboards first.

— {{yourName}}`,
  },
  { id: "warm-followup", name: "Follow-up (no reply)", use: "Second touch after 4–5 days of silence",
    subject: "Re: swap idea — one more thought",
    body: `Hey {{firstName}},

Circling back on my note. No pressure — I know inbox archaeology is real.

One more angle: I'd be happy to route my newsletter (~{{yourAudience}} founders) to {{theirSaaS}} as part of a swap. That's a fair trade for {{yourAsk}} and takes 20 minutes of your time.

If it's a no, a quick "not now" helps me plan.

— {{yourName}}`,
  },
  { id: "acquirer-intro", name: "Warm acquirer intro", use: "Reply to someone who liked your listing",
    subject: "Great to connect — {{yourSaaS}} deck + numbers",
    body: `Hi {{firstName}},

Thanks for reaching out on {{yourSaaS}}. Quick snapshot:

• MRR: {{yourMRR}} (LTM growth {{growth}})
• Users: {{yourUsers}} paying, {{churn}}% monthly churn
• Stack: {{stack}}, {{hosting}}
• Time commitment: {{hours}}h/week

Sharing a light data room here: {{dataRoomLink}}. Happy to jump on a call once you've had a look. What's your availability {{when}}?

— {{yourName}}`,
  },
  { id: "launch-blast", name: "Product Hunt launch blast", use: "Send to your list the morning of launch",
    subject: "We're live on Product Hunt — a favor?",
    body: `Hey friend,

{{yourSaaS}} is live on Product Hunt today: {{phLink}}

If it's helped you in any way, an upvote and a one-line comment about what you use it for would make an enormous difference in the next few hours.

I'll owe you one.

— {{yourName}}`,
  },
  { id: "testimonial-ask", name: "Testimonial request", use: "Ask a happy user for a quote you can showcase",
    subject: "Tiny ask — one line about {{yourSaaS}}?",
    body: `Hey {{firstName}},

Quick one — you mentioned {{quote}} a while back. Would you be open to letting me quote that (or a fresher version) on the {{yourSaaS}} listing page?

Even a single sentence is gold. I'll link back to {{theirCompany}} of course.

Thanks either way,
{{yourName}}`,
  },
  { id: "press-pitch", name: "Journalist pitch", use: "Pitch a niche publication",
    subject: "Story idea: {{angle}} — data + founder available",
    body: `Hi {{firstName}},

I read your piece on {{recentArticle}} — the angle on {{point}} was sharp.

I'm building {{yourSaaS}}, and I've got a story that fits your beat: {{angle}}. Specifically:

• {{proofPoint1}}
• {{proofPoint2}}
• {{proofPoint3}}

Happy to share the raw data and go on record. Would a 20-minute call this week work?

— {{yourName}}`,
  },
  { id: "reactivation", name: "Reactivation email", use: "Win back a lapsed trial or churned user",
    subject: "We rebuilt the part you disliked",
    body: `Hey {{firstName}},

When you left {{yourSaaS}} you told us {{painPoint}}. That stuck with us — and we spent the last {{time}} rebuilding it.

Here's what's different: {{whatChanged}}

I'd love your eyes on it. I've extended your account for 30 days, no card needed: {{loginLink}}

— {{yourName}}`,
  },
  { id: "referral-ask", name: "Referral ask", use: "Ask a delighted customer for an intro",
    subject: "Would you introduce me to one person?",
    body: `Hi {{firstName}},

You mentioned {{yourSaaS}} has been useful for {{useCase}}. If that's still true, would you be willing to introduce me to one person in your network who'd get similar value?

I'll do the writing — just forward this note (edited however you like) and CC me. Zero cost to you, means the world to me.

— {{yourName}}`,
  },
];

const USES = Array.from(new Set(LIBRARY.map((t) => t.use)));

function renderTemplate(body: string, vars: Record<string, string>) {
  return body.replace(/\{\{(\w+)\}\}/g, (_, k) => vars[k] || `{{${k}}}`);
}

function EmailTemplatesPage() {
  const [activeId, setActiveId] = useState<string>(LIBRARY[0].id);
  const [filter, setFilter] = useState<string>("all");
  const [vars, setVars] = useState<Record<string, string>>({});

  const active = LIBRARY.find((t) => t.id === activeId)!;
  const shown = filter === "all" ? LIBRARY : LIBRARY.filter((t) => t.use === filter);

  const detectedVars = useMemo(() => {
    const set = new Set<string>();
    [active.subject, active.body].forEach((s) => {
      const m = s.match(/\{\{(\w+)\}\}/g) ?? [];
      m.forEach((v) => set.add(v.replace(/[{}]/g, "")));
    });
    return Array.from(set);
  }, [active]);

  const renderedSubject = renderTemplate(active.subject, vars);
  const renderedBody = renderTemplate(active.body, vars);

  const copy = (text: string, label: string) => { navigator.clipboard.writeText(text); toast.success(`${label} copied`); };
  const mailto = () => {
    const url = `mailto:?subject=${encodeURIComponent(renderedSubject)}&body=${encodeURIComponent(renderedBody)}`;
    window.location.href = url;
  };

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <div className="hs-noir hs-dash-shell flex-1">
        <div className="hs-dash-canvas" aria-hidden="true">
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--one" />
          <span className="hs-dash-canvas-blob hs-dash-canvas-blob--two" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-6 flex flex-col lg:flex-row gap-8 relative">
          <DashboardSidebar />
          <main id="main" className="flex-1 min-w-0 space-y-6">
            <BackButton />
            <DashHero
              eyebrow="Marketing · Templates"
              title="The emails founders actually reply to."
              description="A curated library of cold intros, follow-ups, and asks — battle-tested wording you can fill in and send in a minute."
              signature="overview"
              actions={
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger className="h-9 w-64"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All templates</SelectItem>
                    {USES.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                  </SelectContent>
                </Select>
              }
            />

            <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
              <div className="space-y-2">
                {shown.map((t) => (
                  <button key={t.id} onClick={() => setActiveId(t.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${activeId === t.id ? "bg-white/10 border-white/20" : "border-white/5 hover:bg-white/5"}`}>
                    <div className="text-sm font-medium">{t.name}</div>
                    <div className="text-[11px] text-muted-foreground mt-1">{t.use}</div>
                  </button>
                ))}
              </div>

              <div className="space-y-6">
                <Card className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge variant="secondary">{active.name}</Badge>
                    <span className="text-xs text-muted-foreground">{active.use}</span>
                  </div>

                  {detectedVars.length > 0 && (
                    <div className="mb-4">
                      <div className="text-[11px] uppercase tracking-widest text-muted-foreground mb-2">Fill the blanks</div>
                      <div className="grid gap-2 md:grid-cols-2">
                        {detectedVars.map((v) => (
                          <div key={v}>
                            <label className="text-[10px] text-muted-foreground">{v}</label>
                            <Input value={vars[v] ?? ""} onChange={(e) => setVars({ ...vars, [v]: e.target.value })} placeholder={`{{${v}}}`} />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-[11px] uppercase tracking-widest text-muted-foreground">Subject</label>
                    <div className="mt-1 flex gap-2">
                      <Input readOnly value={renderedSubject} />
                      <Button variant="outline" size="icon" aria-label="Copy subject" onClick={() => copy(renderedSubject, "Subject")}><Copy className="w-4 h-4" /></Button>
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="text-[11px] uppercase tracking-widest text-muted-foreground">Body</label>
                    <Textarea readOnly value={renderedBody} rows={14} className="mt-1 font-mono text-xs" />
                  </div>

                  <div className="mt-4 flex gap-2 justify-end flex-wrap">
                    <Button variant="outline" onClick={() => copy(renderedBody, "Body")}><Copy className="w-4 h-4 mr-2" />Copy body</Button>
                    <Button variant="outline" onClick={() => copy(`Subject: ${renderedSubject}\n\n${renderedBody}`, "Email")}><Copy className="w-4 h-4 mr-2" />Copy all</Button>
                    <Button onClick={mailto}><Mail className="w-4 h-4 mr-2" />Open in mail client</Button>
                  </div>
                </Card>
              </div>
            </div>
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
