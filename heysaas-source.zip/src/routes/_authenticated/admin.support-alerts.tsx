import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AlertTriangle, Check, Save, Send } from "lucide-react";
import { sendTestWebhook } from "@/lib/support-webhooks.functions";

export const Route = createFileRoute("/_authenticated/admin/support-alerts")({
  head: () => ({ meta: [{ title: "Support alerts — Admin" }, { name: "robots", content: "noindex" }] }),
  component: AlertsAdmin,
});

type Alert = {
  id: string;
  kind: string;
  count: number;
  threshold: number;
  window_minutes: number;
  acknowledged_at: string | null;
  created_at: string;
};

function AlertsAdmin() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [cfg, setCfg] = useState({ errors: 5, window_minutes: 10, cooldown_minutes: 30 });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [a, c] = await Promise.all([
      supabase.from("support_alerts").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("platform_config").select("value").eq("key", "support_alert_threshold").maybeSingle(),
    ]);
    setAlerts((a.data as Alert[]) ?? []);
    if (c.data?.value) setCfg((prev) => ({ ...prev, ...(c.data!.value as Record<string, number>) }));
    setLoading(false);
  };
  useEffect(() => { void load(); }, []);

  const saveCfg = async () => {
    if (cfg.errors < 1) return toast.error("Errors threshold must be at least 1");
    if (cfg.window_minutes < 10 || cfg.window_minutes > 30) return toast.error("Lookback window must be between 10 and 30 minutes");
    if (cfg.cooldown_minutes < 1) return toast.error("Cooldown must be at least 1 minute");
    const { error } = await supabase.from("platform_config").update({ value: cfg as never }).eq("key", "support_alert_threshold");
    if (error) return toast.error(error.message);
    toast.success("Threshold saved");
  };
  const ack = async (id: string) => {
    const { data: u } = await supabase.auth.getUser();
    await supabase.from("support_alerts").update({ acknowledged_at: new Date().toISOString(), acknowledged_by: u.user?.id }).eq("id", id);
    void load();
  };

  const testWebhook = useServerFn(sendTestWebhook);
  const [testing, setTesting] = useState<null | "slack" | "teams" | "both">(null);
  const runTest = async (channel: "slack" | "teams" | "both") => {
    setTesting(channel);
    try {
      const res = await testWebhook({ data: { channel } });
      toast.message(`Queued ${res.queued} test delivery${res.queued === 1 ? "" : "s"} · check the Webhooks tab for status`);

    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Test failed");
    } finally { setTesting(null); }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif tracking-tight">Support alerts</h1>
        <p className="text-sm text-muted-foreground">Automatic alerts when rate-limit or credit errors spike.</p>
      </div>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <h2 className="text-sm font-medium mb-3">Webhook test</h2>
        <p className="text-[11px] text-muted-foreground mb-3">Send a test alert to the configured Slack and/or Microsoft Teams incoming webhooks. Add <code>SLACK_TICKET_WEBHOOK_URL</code> and/or <code>TEAMS_TICKET_WEBHOOK_URL</code> as secrets to enable delivery.</p>
        <div className="flex flex-wrap gap-2">
          <button disabled={!!testing} onClick={() => runTest("slack")} className="inline-flex items-center gap-1 rounded-md border border-hairline px-3 py-1.5 text-xs hover:bg-violet/10 disabled:opacity-50"><Send className="h-3 w-3"/> {testing==="slack"?"Sending…":"Test Slack"}</button>
          <button disabled={!!testing} onClick={() => runTest("teams")} className="inline-flex items-center gap-1 rounded-md border border-hairline px-3 py-1.5 text-xs hover:bg-violet/10 disabled:opacity-50"><Send className="h-3 w-3"/> {testing==="teams"?"Sending…":"Test Teams"}</button>
          <button disabled={!!testing} onClick={() => runTest("both")} className="inline-flex items-center gap-1 rounded-md bg-violet px-3 py-1.5 text-xs text-primary-foreground hover:bg-violet-glow disabled:opacity-50"><Send className="h-3 w-3"/> {testing==="both"?"Sending…":"Test both"}</button>
        </div>
      </section>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <h2 className="text-sm font-medium mb-1">Threshold &amp; lookback window</h2>
        <p className="text-[11px] text-muted-foreground mb-3">Fires an alert when rate-limit or credit errors in the lookback window meet the threshold. Lookback window must be between 10 and 30 minutes.</p>
        <div className="grid grid-cols-3 gap-3 max-w-lg">
          <label className="space-y-1"><div className="text-[10px] uppercase text-muted-foreground">Errors (min 1)</div>
            <input type="number" min={1} value={cfg.errors} onChange={(e)=>setCfg({...cfg, errors: parseInt(e.target.value)||0})} className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs"/></label>
          <label className="space-y-1"><div className="text-[10px] uppercase text-muted-foreground">Window (10–30 min)</div>
            <input type="number" min={10} max={30} value={cfg.window_minutes} onChange={(e)=>setCfg({...cfg, window_minutes: parseInt(e.target.value)||0})} className={`w-full rounded-md border bg-background px-2 py-1 text-xs ${cfg.window_minutes<10||cfg.window_minutes>30?"border-red-500/60":"border-hairline"}`}/></label>
          <label className="space-y-1"><div className="text-[10px] uppercase text-muted-foreground">Cooldown (min)</div>
            <input type="number" min={1} value={cfg.cooldown_minutes} onChange={(e)=>setCfg({...cfg, cooldown_minutes: parseInt(e.target.value)||0})} className="w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs"/></label>
        </div>
        <button onClick={saveCfg} className="mt-3 inline-flex items-center gap-1 rounded-md bg-violet px-3 py-1.5 text-xs text-primary-foreground hover:bg-violet-glow"><Save className="h-3 w-3"/> Save</button>
        <p className="text-[11px] text-muted-foreground mt-2">Checked every 5 minutes. Cooldown prevents repeat alerts within the given interval.</p>
      </section>

      <section className="rounded-2xl border border-hairline bg-surface p-5">
        <h2 className="text-sm font-medium mb-3">Recent alerts</h2>
        {loading ? <p className="text-xs text-muted-foreground">Loading…</p> : alerts.length===0 ? <p className="text-xs text-muted-foreground">No alerts yet.</p> : (
          <ul className="space-y-2">
            {alerts.map(a => (
              <li key={a.id} className={`flex items-center gap-3 rounded-lg border p-3 ${a.acknowledged_at?"border-hairline opacity-70":"border-amber-500/40 bg-amber-500/5"}`}>
                <AlertTriangle className={`h-4 w-4 ${a.acknowledged_at?"text-muted-foreground":"text-amber-500"}`}/>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium">{a.count} errors in {a.window_minutes} min (threshold {a.threshold})</div>
                  <div className="text-[10px] text-muted-foreground">{new Date(a.created_at).toLocaleString()}</div>
                </div>
                {!a.acknowledged_at && <button onClick={()=>ack(a.id)} className="rounded-md border border-hairline px-2 py-1 text-[11px] hover:bg-violet/10"><Check className="h-3 w-3 inline"/> Acknowledge</button>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
