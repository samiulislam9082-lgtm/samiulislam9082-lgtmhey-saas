import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, BellOff, Bell, MailOpen, Eye, Trash2, History } from "lucide-react";
import { listMessageAudit, clearMessageAudit } from "@/lib/message-audit.functions";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/dashboard/audit")({
  head: () => ({ meta: [{ title: "Activity log — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: AuditPage,
});

type Entry = {
  id: string;
  action: "mute" | "unmute" | "mark_unread" | "mark_read";
  thread_ids: string[];
  details: Record<string, any>;
  created_at: string;
};

const ICONS: Record<Entry["action"], any> = {
  mute: BellOff,
  unmute: Bell,
  mark_unread: MailOpen,
  mark_read: Eye,
};

const LABELS: Record<Entry["action"], string> = {
  mute: "Muted",
  unmute: "Unmuted",
  mark_unread: "Marked unread",
  mark_read: "Marked read",
};

function AuditPage() {
  const listFn = useServerFn(listMessageAudit);
  const clearFn = useServerFn(clearMessageAudit);
  const [rows, setRows] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try { setRows((await listFn()) as Entry[]); }
    catch (e: any) { toast.error(e?.message ?? "Failed to load activity"); }
    finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="audit"
              eyebrow="Timeline"
              title="Activity log"
              description="A record of your bulk mute, unmute, and mark-unread actions on Messages."
              actions={rows.length > 0 ? (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2 rounded-full"><Trash2 className="h-3.5 w-3.5" /> Clear log</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Clear activity log?</AlertDialogTitle>
                      <AlertDialogDescription>This permanently deletes your local activity history. It doesn't undo any actions.</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={async () => {
                        try { await clearFn(); toast.success("Cleared"); load(); }
                        catch (e: any) { toast.error(e?.message ?? "Failed"); }
                      }}>Clear</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              ) : undefined}
            />
            <DashRibbon variant="audit" />
            <DashBodyBlock variant="audit" />


            <div className="mt-8">
              {loading ? (
                <div className="flex justify-center py-16"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
              ) : rows.length === 0 ? (
                <div className="hs-empty">
                  <div className="hs-empty-icon"><History className="h-6 w-6" /></div>
                  <p className="mt-5 font-display text-3xl">No activity yet.</p>
                  <p className="mt-2 text-sm text-muted-foreground">Bulk actions on Messages will appear here as a tidy timeline.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {rows.map((r) => {
                    const Icon = ICONS[r.action];
                    const bulk = !!r.details?.bulk || r.thread_ids.length > 1;
                    return (
                      <Card key={r.id} className="p-4 flex items-center gap-4 hover:border-violet/40 transition-colors">
                        <div className="h-10 w-10 rounded-2xl inline-flex items-center justify-center shrink-0 border border-hairline bg-gradient-to-br from-violet/20 to-violet-glow/10 text-violet-glow">
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">{LABELS[r.action]}</span>
                            <Badge variant="outline" className="text-[10px]">{r.thread_ids.length} thread{r.thread_ids.length === 1 ? "" : "s"}</Badge>
                            {bulk && <Badge variant="secondary" className="text-[10px]">Bulk</Badge>}
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">{new Date(r.created_at).toLocaleString()}</div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
