import { createFileRoute, Outlet, useRouterState } from "@tanstack/react-router";
import { WebSwapShell } from "@/components/websites/WebSwapShell";

export const Route = createFileRoute("/_authenticated/websites/dashboard")({
  component: DashboardLayout,
});

function DashboardLayout() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  // Thread view is a full-viewport messaging surface — bypass shell chrome.
  const isThreadView = /^\/websites\/dashboard\/messages\/[^/]+$/.test(path);
  if (isThreadView) {
    return <Outlet />;
  }
  return (
    <WebSwapShell variant="app">
      <Outlet />
    </WebSwapShell>
  );
}
