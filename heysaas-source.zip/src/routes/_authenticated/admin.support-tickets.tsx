import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Paperclip } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/support-tickets")({
  head: () => ({ meta: [{ title: "Support tickets — Admin" }, { name: "robots", content: "noindex" }] }),
  component: AdminTickets,
});

type T = {
  id: string; subject: string; email: string; name: string; status: string;
  priority: string; source: string; created_at: string; attachment_path: string | null;
};

const statusTone: Record<string,string> = {
  new: "border-violet/60 bg-violet/10 text-violet",
  open: "border-amber-500/60 bg-amber-500/10 text-amber-400",
  pending: "border-blue-500/60 bg-blue-500/10 text-blue-400",
  resolved: "border-emerald-500/60 bg-emerald-500/10 text-emerald-400",
};
const priorityTone: Record<string,string> = {
  urgent: "text-red-400", high: "text-orange-400", normal: "text-muted-foreground", low: "text-muted-foreground/70",
};

function AdminTickets() {
  const [rows, setRows] = useState<T[]>([]);
  const [status, setStatus] = useState("all");
  const [priority, setPriority] = useState("all");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    let sel = supabase.from("support_tickets").select("id, subject, email, name, status, priority, source, created_at, attachment_path").order("created_at", { ascending: false }).limit(200);
    if (status !== "all") sel = sel.eq("status", status);
    if (priority !== "all") sel = sel.eq("priority", priority);
    if (q.trim()) sel = sel.or(`subject.ilike.%${q}%,email.ilike.%${q}%,name.ilike.%${q}%`);
    sel.then(({ data }) => { setRows((data as T[]) ?? []); setLoading(false); });
  }, [status, priority, q]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif tracking-tight">Support tickets</h1>
        <p className="text-sm text-muted-foreground">Track lifecycle: new → open → pending → resolved.</p>
      </div>
      <div className="flex flex-wrap gap-2 items-center rounded-xl border border-hairline bg-surface p-3">
        <select value={status} onChange={(e)=>setStatus(e.target.value)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs">
          {["all","new","open","pending","resolved"].map(s=><option key={s} value={s}>{s}</option>)}
        </select>
        <select value={priority} onChange={(e)=>setPriority(e.target.value)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs">
          {["all","urgent","high","normal","low"].map(s=><option key={s} value={s}>{s}</option>)}
        </select>
        <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Search subject / email / name" className="flex-1 min-w-40 rounded-md border border-hairline bg-background px-2 py-1 text-xs"/>
      </div>

      {loading ? <p className="text-xs text-muted-foreground">Loading…</p> : (
        <div className="overflow-x-auto rounded-2xl border border-hairline">
          <table className="w-full text-xs">
            <thead className="bg-surface text-left text-muted-foreground"><tr>
              <th className="p-3">Subject</th><th className="p-3">From</th><th className="p-3">Status</th><th className="p-3">Priority</th><th className="p-3">Source</th><th className="p-3">When</th>
            </tr></thead>
            <tbody className="divide-y divide-hairline">
              {rows.map(t=>(
                <tr key={t.id} className="hover:bg-muted/20">
                  <td className="p-3">
                    <Link to="/admin/support-tickets/$id" params={{ id: t.id }} className="hover:underline flex items-center gap-1">
                      {t.attachment_path && <Paperclip className="h-3 w-3 text-muted-foreground"/>}
                      {t.subject}
                    </Link>
                  </td>
                  <td className="p-3"><div>{t.name}</div><div className="text-[10px] text-muted-foreground">{t.email}</div></td>
                  <td className="p-3"><span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${statusTone[t.status]}`}>{t.status}</span></td>
                  <td className={`p-3 capitalize ${priorityTone[t.priority]}`}>{t.priority}</td>
                  <td className="p-3 text-muted-foreground">{t.source}</td>
                  <td className="p-3 text-muted-foreground whitespace-nowrap">{new Date(t.created_at).toLocaleString()}</td>
                </tr>
              ))}
              {rows.length===0 && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No tickets.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
