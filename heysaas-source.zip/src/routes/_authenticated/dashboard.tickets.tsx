import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BackButton } from "@/components/site/BackButton";
import { Paperclip } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/tickets")({
  head: () => ({ meta: [{ title: "My tickets — HeySaaS" }, { name: "robots", content: "noindex" }] }),
  component: MyTickets,
});

type T = { id: string; subject: string; status: string; priority: string; created_at: string; attachment_path: string | null };

const statusTone: Record<string,string> = {
  new: "border-violet/60 bg-violet/10 text-violet",
  open: "border-amber-500/60 bg-amber-500/10 text-amber-400",
  pending: "border-blue-500/60 bg-blue-500/10 text-blue-400",
  resolved: "border-emerald-500/60 bg-emerald-500/10 text-emerald-400",
};

function MyTickets() {
  const [rows, setRows] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    supabase.from("support_tickets").select("id, subject, status, priority, created_at, attachment_path").order("created_at",{ ascending:false }).then(({ data }) => {
      setRows((data as T[]) ?? []); setLoading(false);
    });
  }, []);
  return (
    <div className="space-y-6">
      <BackButton/>
      <div>
        <h1 className="text-2xl font-serif tracking-tight">My support tickets</h1>
        <p className="text-sm text-muted-foreground">Track the status of your support requests.</p>
      </div>
      {loading ? <p className="text-xs text-muted-foreground">Loading…</p> : rows.length===0 ? (
        <p className="text-xs text-muted-foreground rounded-xl border border-hairline bg-surface p-8 text-center">You haven't submitted any tickets yet.</p>
      ) : (
        <ul className="space-y-2">
          {rows.map(t => (
            <li key={t.id}>
              <Link to="/dashboard/tickets/$id" params={{ id: t.id }} className="flex items-center gap-3 rounded-xl border border-hairline bg-surface p-4 hover:border-violet/60">
                {t.attachment_path && <Paperclip className="h-3.5 w-3.5 text-muted-foreground"/>}
                <div className="flex-1 min-w-0">
                  <div className="text-sm truncate">{t.subject}</div>
                  <div className="text-[10px] text-muted-foreground">{new Date(t.created_at).toLocaleString()} · {t.priority}</div>
                </div>
                <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${statusTone[t.status]}`}>{t.status}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
