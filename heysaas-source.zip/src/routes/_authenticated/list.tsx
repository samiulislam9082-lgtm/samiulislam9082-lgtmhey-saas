import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { ImageUploader } from "@/components/site/ImageUploader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Save, Rocket, X } from "lucide-react";
import { toast } from "sonner";
import { MRR_BUCKETS } from "@/lib/marketplace-filters";

export const Route = createFileRoute("/_authenticated/list")({
  head: () => ({
    meta: [
      { title: "List your SaaS — Hey SaaS" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ListWizard,
});

type Category = { id: string; name: string; slug: string };

type Draft = {
  id: string | null;
  name: string;
  tagline: string;
  category_id: string | null;
  description: string;
  website_url: string;
  launch_year: string;
  country: string;
  pricing_model: string;
  mrr_range: string;
  arr_range: string;
  user_count_range: string;
  tech_stack: string; // comma separated in form
  tag_slugs: string; // comma separated
  reason_for_swap: string;
  looking_for: string;
  logo_url: string | null;
  cover_url: string | null;
  screenshots: string[];
  demo_video_url: string;
};

const EMPTY: Draft = {
  id: null, name: "", tagline: "", category_id: null, description: "", website_url: "",
  launch_year: "", country: "", pricing_model: "", mrr_range: "", arr_range: "",
  user_count_range: "", tech_stack: "", tag_slugs: "", reason_for_swap: "", looking_for: "",
  logo_url: null, cover_url: null, screenshots: [], demo_video_url: "",
};

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
}

function ListWizard() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const lastSavedRef = useRef<string>("");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);
      const { data: cats } = await supabase.from("categories").select("id, name, slug").order("sort_order");
      setCategories((cats ?? []) as Category[]);

      // Load latest draft if any
      const { data: existing } = await supabase
        .from("saas_listings")
        .select("*")
        .eq("owner_id", user.id)
        .eq("status", "draft")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (existing) {
        setDraft({
          id: existing.id,
          name: existing.name ?? "",
          tagline: existing.tagline ?? "",
          category_id: existing.category_id,
          description: existing.description ?? "",
          website_url: existing.website_url ?? "",
          launch_year: existing.launch_year ? String(existing.launch_year) : "",
          country: existing.country ?? "",
          pricing_model: existing.pricing_model ?? "",
          mrr_range: existing.mrr_range ?? "",
          arr_range: existing.arr_range ?? "",
          user_count_range: existing.user_count_range ?? "",
          tech_stack: (existing.tech_stack ?? []).join(", "),
          tag_slugs: (existing.tag_slugs ?? []).join(", "),
          reason_for_swap: existing.reason_for_swap ?? "",
          looking_for: existing.looking_for ?? "",
          logo_url: existing.logo_url,
          cover_url: existing.cover_url,
          screenshots: Array.isArray(existing.screenshots) ? (existing.screenshots as string[]) : [],
          demo_video_url: existing.demo_video_url ?? "",
        });
      }
    })();
  }, []);

  const saveDraft = useCallback(async (d: Draft, uid: string): Promise<string | null> => {
    if (!d.name.trim()) return d.id;
    const shared = {
      name: d.name.trim(),
      tagline: d.tagline || null,
      category_id: d.category_id,
      description: d.description || null,
      website_url: d.website_url || null,
      launch_year: d.launch_year ? Number(d.launch_year) : null,
      country: d.country || null,
      pricing_model: (d.pricing_model || null) as any,
      mrr_range: d.mrr_range || null,
      arr_range: d.arr_range || null,
      user_count_range: d.user_count_range || null,
      tech_stack: d.tech_stack.split(",").map((s) => s.trim()).filter(Boolean),
      tag_slugs: d.tag_slugs.split(",").map((s) => slugify(s)).filter(Boolean),
      reason_for_swap: d.reason_for_swap || null,
      looking_for: d.looking_for || null,
      logo_url: d.logo_url,
      cover_url: d.cover_url,
      screenshots: d.screenshots,
      demo_video_url: d.demo_video_url || null,
    };
    if (d.id) {
      const { error } = await supabase.from("saas_listings").update(shared).eq("id", d.id);
      if (error) throw error;
      return d.id;
    } else {
      const slug = `${slugify(d.name)}-${Math.random().toString(36).slice(2, 6)}`;
      const { data, error } = await supabase
        .from("saas_listings")
        .insert({ owner_id: uid, slug, ...shared })
        .select("id")
        .single();
      if (error) throw error;
      return data.id;
    }
  }, []);

  // Autosave every 5s when dirty
  useEffect(() => {
    if (!userId) return;
    const t = setInterval(async () => {
      const snap = JSON.stringify(draft);
      if (snap === lastSavedRef.current || !draft.name.trim()) return;
      setSaving(true);
      try {
        const id = await saveDraft(draft, userId);
        if (id && !draft.id) setDraft((d) => ({ ...d, id }));
        lastSavedRef.current = snap;
      } catch (e) {
        console.error(e);
      } finally {
        setSaving(false);
      }
    }, 5000);
    return () => clearInterval(t);
  }, [draft, userId, saveDraft]);

  async function publish() {
    if (!userId) return;
    if (!draft.name.trim() || !draft.tagline.trim() || !draft.category_id || !draft.description.trim()) {
      toast.error("Name, tagline, category, and description are required.");
      return;
    }
    setPublishing(true);
    try {
      const id = await saveDraft(draft, userId);
      if (!id) throw new Error("Save failed");
      const { error } = await supabase.from("saas_listings").update({ status: "live" }).eq("id", id);
      if (error) throw error;
      toast.success("Your SaaS is live!");
      const { data: fresh } = await supabase.from("saas_listings").select("slug").eq("id", id).single();
      if (fresh?.slug) navigate({ to: "/saas/$slug", params: { slug: fresh.slug } });
      else navigate({ to: "/dashboard/listings" });
    } catch (err: any) {
      toast.error(err?.message ?? "Could not publish");
    } finally {
      setPublishing(false);
    }
  }

  async function addScreenshot(path: string | null) {
    if (!path) return;
    setDraft((d) => ({ ...d, screenshots: [...d.screenshots, path].slice(0, 5) }));
  }

  function removeScreenshot(i: number) {
    setDraft((d) => ({ ...d, screenshots: d.screenshots.filter((_, idx) => idx !== i) }));
  }

  if (!userId) {
    return (
      <div className="min-h-dvh flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="hs-dash-hero px-6 py-8 sm:px-10 sm:py-10">
          <div className="hs-dash-hero-orb hs-dash-hero-orb--a" aria-hidden />
          <div className="hs-dash-hero-orb hs-dash-hero-orb--b" aria-hidden />
          <div className="relative z-10 flex items-end justify-between gap-6 flex-wrap">
            <div>
              <span className="hs-dash-eyebrow"><span className="hs-dash-eyebrow-dot" aria-hidden />New listing</span>
              <h1 className="mt-4 font-display text-4xl md:text-5xl leading-[1.05] tracking-tight">List your SaaS.</h1>
              <p className="mt-3 text-[15px] text-muted-foreground max-w-lg">One editorial page. Autosaved every few seconds. Publish when you're ready — no fee to list.</p>
            </div>
            <div className="text-xs text-muted-foreground inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1.5">
              {saving ? <><Loader2 className="h-3 w-3 animate-spin" /> Saving…</> : draft.id ? <><Save className="h-3 w-3" /> Draft saved</> : "Draft not saved yet"}
            </div>
          </div>
        </div>

        <div className="mt-10 space-y-10">
          {/* Section: Basics */}
          <Section title="Basics" desc="What is it called and what does it do?">
            <Field label="Name *"><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Acme AI" /></Field>
            <Field label="Tagline *"><Input value={draft.tagline} onChange={(e) => setDraft({ ...draft, tagline: e.target.value })} placeholder="One line that sells it" maxLength={140} /></Field>
            <Field label="Category *">
              <Select value={draft.category_id ?? ""} onValueChange={(v) => setDraft({ ...draft, category_id: v })}>
                <SelectTrigger><SelectValue placeholder="Pick a category" /></SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Website"><Input value={draft.website_url} onChange={(e) => setDraft({ ...draft, website_url: e.target.value })} placeholder="https://…" /></Field>
          </Section>

          {/* Section: Media */}
          <Section title="Media" desc="Logo, cover, and up to 5 screenshots.">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <Label>Logo</Label>
                <ImageUploader bucket="logos" userId={userId} value={draft.logo_url} onChange={(p) => setDraft({ ...draft, logo_url: p })} aspect="square" maxDim={512} />
              </div>
              <div>
                <Label>Cover</Label>
                <ImageUploader bucket="covers" userId={userId} value={draft.cover_url} onChange={(p) => setDraft({ ...draft, cover_url: p })} aspect="wide" maxDim={1600} />
              </div>
            </div>
            <div>
              <Label className="mb-2 block">Screenshots ({draft.screenshots.length}/5)</Label>
              <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
                {draft.screenshots.map((path, i) => (
                  <ScreenshotThumb key={path + i} path={path} onRemove={() => removeScreenshot(i)} />
                ))}
                {draft.screenshots.length < 5 && (
                  <ImageUploader
                    bucket="screenshots"
                    userId={userId}
                    value={null}
                    onChange={addScreenshot}
                    aspect="wide"
                    label="Add screenshot"
                    maxDim={1600}
                  />
                )}
              </div>
            </div>
            <Field label="Demo video URL"><Input value={draft.demo_video_url} onChange={(e) => setDraft({ ...draft, demo_video_url: e.target.value })} placeholder="YouTube, Loom, etc." /></Field>
          </Section>

          {/* Section: Details */}
          <Section title="The pitch" desc="Sell it. Markdown supported.">
            <Field label="Description *">
              <Textarea rows={8} value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} placeholder="What does it do? Who is it for? Why is it a good swap candidate?" />
            </Field>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Tech stack (comma-separated)"><Input value={draft.tech_stack} onChange={(e) => setDraft({ ...draft, tech_stack: e.target.value })} placeholder="React, Postgres, Stripe" /></Field>
              <Field label="Tags (comma-separated)"><Input value={draft.tag_slugs} onChange={(e) => setDraft({ ...draft, tag_slugs: e.target.value })} placeholder="ai, b2b, api" /></Field>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Launch year"><Input type="number" value={draft.launch_year} onChange={(e) => setDraft({ ...draft, launch_year: e.target.value })} placeholder="2024" /></Field>
              <Field label="Country"><Input value={draft.country} onChange={(e) => setDraft({ ...draft, country: e.target.value })} placeholder="Germany" /></Field>
            </div>
          </Section>

          <Section title="Numbers" desc="Ranges — self-reported.">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Pricing model">
                <Select value={draft.pricing_model} onValueChange={(v) => setDraft({ ...draft, pricing_model: v })}>
                  <SelectTrigger><SelectValue placeholder="Pick one" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="free">Free</SelectItem>
                    <SelectItem value="freemium">Freemium</SelectItem>
                    <SelectItem value="subscription">Subscription</SelectItem>
                    <SelectItem value="one_time">One-time</SelectItem>
                    <SelectItem value="usage_based">Usage based</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="MRR range">
                <Select value={draft.mrr_range || undefined} onValueChange={(v) => setDraft({ ...draft, mrr_range: v })}>
                  <SelectTrigger><SelectValue placeholder="Pick an MRR bucket" /></SelectTrigger>
                  <SelectContent>
                    {MRR_BUCKETS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="ARR range"><Input value={draft.arr_range} onChange={(e) => setDraft({ ...draft, arr_range: e.target.value })} placeholder="$12k–$60k" /></Field>
              <Field label="Users"><Input value={draft.user_count_range} onChange={(e) => setDraft({ ...draft, user_count_range: e.target.value })} placeholder="500–1000" /></Field>
            </div>
          </Section>

          <Section title="Swap preferences" desc="Help match with the right founder.">
            <Field label="Why are you open to swap?"><Textarea rows={3} value={draft.reason_for_swap} onChange={(e) => setDraft({ ...draft, reason_for_swap: e.target.value })} /></Field>
            <Field label="What are you looking for?"><Textarea rows={3} value={draft.looking_for} onChange={(e) => setDraft({ ...draft, looking_for: e.target.value })} placeholder="AI tools, B2B SaaS, marketing automation…" /></Field>
          </Section>
        </div>

        <div className="mt-10 hs-publish-bar flex items-center justify-between gap-4 sticky bottom-4">
          <div className="text-sm text-muted-foreground">
            {draft.id ? <Badge variant="outline" className="rounded-full">Draft</Badge> : "Type a name to start saving."}
          </div>
          <div className="flex gap-2">
            <Link to="/dashboard/listings"><Button variant="outline" className="rounded-full">Save & exit</Button></Link>
            <Button onClick={publish} disabled={publishing} className="rounded-full bg-foreground text-background hover:opacity-90">
              {publishing ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Publishing…</> : <><Rocket className="h-4 w-4 mr-2" />Publish</>}
            </Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Section({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <section className="hs-form-card space-y-5">
      <div>
        <h2 className="hs-form-title">{title}</h2>
        <p className="hs-form-desc">{desc}</p>
      </div>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

import { useSignedImage } from "@/hooks/useSignedImage";
function ScreenshotThumb({ path, onRemove }: { path: string; onRemove: () => void }) {
  const url = useSignedImage("screenshots", path);
  return (
    <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-hairline bg-background">
      {url && <img src={url} alt="" className="h-full w-full object-cover" />}
      <button
        type="button"
        onClick={onRemove}
        className="absolute right-2 top-2 inline-flex h-7 w-7 items-center justify-center rounded-full bg-background/80 text-foreground backdrop-blur hover:bg-background"
        aria-label="Remove screenshot"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
