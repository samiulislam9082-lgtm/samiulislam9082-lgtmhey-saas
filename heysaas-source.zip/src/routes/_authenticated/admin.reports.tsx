import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { resolveReport } from "@/lib/admin.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/reports")({
  component: ReportsQueue,
});

function ReportsQueue() {
  const [items, setItems] = useState<any[]>([]);
  const resolve = useServerFn(resolveReport);
  async function load() {
    const { data } = await supabase.from("reports").select("*").order("created_at", { ascending: false }).limit(200);
    setItems(data || []);
  }
  useEffect(() => { load(); }, []);
  async function act(id: string, status: "resolved" | "dismissed") {
    try { await resolve({ data: { id, status } }); toast.success(`Report ${status}`); load(); } catch (e: any) { toast.error(e.message); }
  }
  return (
    <div>
      <h1 className="font-display text-4xl mb-6">Reports</h1>
      <div className="space-y-3">
        {items.map((r) => (
          <Card key={r.id} className="p-4">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline">{r.target_type}</Badge>
                  <Badge className={r.status === "open" ? "bg-amber-500/20 text-amber-400 border-0" : "bg-muted"}>{r.status}</Badge>
                  <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString()}</span>
                </div>
                <div className="text-sm font-medium">{r.reason}</div>
                {r.details && <div className="text-sm text-muted-foreground mt-1">{r.details}</div>}
                <div className="text-xs text-muted-foreground mt-2 font-mono">target: {r.target_id}</div>
              </div>
              {r.status === "open" && (
                <div className="flex gap-2 shrink-0">
                  <Button size="sm" onClick={() => act(r.id, "resolved")}>Resolve</Button>
                  <Button size="sm" variant="outline" onClick={() => act(r.id, "dismissed")}>Dismiss</Button>
                </div>
              )}
            </div>
          </Card>
        ))}
        {items.length === 0 && <Card className="p-12 text-center text-muted-foreground">No reports.</Card>}
      </div>
    </div>
  );
}
