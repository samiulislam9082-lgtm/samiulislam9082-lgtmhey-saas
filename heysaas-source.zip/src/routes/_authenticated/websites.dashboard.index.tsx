import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsDashboardStats } from "@/lib/websites.functions";
import { WsSidebar } from "@/components/websites/WebSwapShell";
import { Kpi } from "@/components/ui/kpi";
import { Globe, TrendingUp, MessageSquare, Heart, PlusCircle, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/websites/dashboard/")({
  component: WsDashboardHome,
});

function WsDashboardHome() {
  const stats = useServerFn(wsDashboardStats);
  const { data } = useQuery({ queryKey: ["ws", "stats"], queryFn: () => stats() });

  const kpis = [
    { label: "Active listings", value: data?.listings_live ?? 0, icon: Globe, spark: [3, 4, 3, 5, 6, 6, 7], format: "compact" as const },
    { label: "Total views",     value: data?.total_views ?? 0,    icon: TrendingUp, spark: [2, 3, 5, 4, 7, 9, 12], format: "compact" as const },
    { label: "Offers received", value: data?.offers_received ?? 0,icon: MessageSquare, spark: [1, 1, 2, 3, 3, 4, 6], format: "number" as const },
    { label: "Watchlist",       value: data?.watchlist_count ?? 0,icon: Heart, spark: [2, 3, 4, 4, 5, 5, 6], format: "number" as const },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 flex gap-10 pb-24 md:pb-10">
      <WsSidebar />
      <div className="flex-1 min-w-0">
        <header className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10 pb-6 border-b border-[#1a4a6e]/60 ws-reveal">
          <div>
            <div className="text-[10px] uppercase tracking-[0.28em] text-[#2dd4bf] font-semibold">Console</div>
            <h1 className="ws-serif mt-1 text-white text-4xl sm:text-5xl italic">Overview</h1>
            <p className="mt-2 text-sm text-[#7d94ad]">Manage your website listings, offers, and inquiries.</p>
          </div>
          <Link to="/websites/dashboard/listings/new" className="ws-btn-primary inline-flex items-center gap-2 self-start">
            <PlusCircle className="h-3.5 w-3.5" /> New listing
          </Link>
        </header>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-10">
          {kpis.map((k) => (
            <Kpi
              key={k.label}
              label={k.label}
              value={k.value}
              format={k.format}
              icon={k.icon}
              spark={k.spark}
              tone="ws"
            />
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-5">
          <div className="lg:col-span-2 space-y-4">
            <SectionLabel>Quick actions</SectionLabel>
            <QuickLink to="/websites/dashboard/listings" label="Manage inventory" caption="Edit, pause, or promote your listings." icon={Globe} />
            <QuickLink to="/websites/dashboard/messages" label="Inquiries & offers" caption="Reply, counter, or accept." icon={MessageSquare} />
            <QuickLink to="/websites/dashboard/watchlist" label="Watchlist" caption="Sites you're tracking." icon={Heart} />
          </div>

          <div className="lg:col-span-3">
            <SectionLabel>Recent activity</SectionLabel>
            <div className="mt-4 border border-[#1a4a6e]/60 bg-[#0c2340]/40">
              <div className="p-10 text-center">
                <div className="ws-serif text-xl text-white italic">Nothing here yet.</div>
                <p className="mt-1 text-xs text-[#7d94ad]">
                  Activity from your listings — views, inquiries, and offers — will surface here.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-[10px] uppercase tracking-[0.28em] text-[#2dd4bf] font-semibold">{children}</span>
      <span className="h-px flex-1 bg-[#1a4a6e]/50" />
    </div>
  );
}

function QuickLink({
  to,
  label,
  caption,
  icon: Icon,
}: {
  to: string;
  label: string;
  caption: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
}) {
  return (
    <Link
      to={to}
      className="group flex items-center justify-between border border-[#1a4a6e]/60 bg-[#0c2340]/40 hover:border-[#2dd4bf]/60 hover:bg-[#0c2340]/70 p-4 transition-all"
    >
      <div className="flex items-center gap-3 min-w-0">
        <span className="inline-flex h-9 w-9 items-center justify-center rounded-sm bg-[#04101a] border border-[#1a4a6e] group-hover:border-[#2dd4bf]/50">
          <Icon className="h-4 w-4" strokeWidth={1.5} />
        </span>
        <div className="min-w-0">
          <div className="text-sm text-white font-medium">{label}</div>
          <div className="text-[11px] text-[#7d94ad] truncate">{caption}</div>
        </div>
      </div>
      <ArrowRight className="h-4 w-4 text-[#7d94ad] group-hover:text-[#2dd4bf] group-hover:translate-x-0.5 transition-all" />
    </Link>
  );
}
