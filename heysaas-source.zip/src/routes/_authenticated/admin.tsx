import { createFileRoute, Link, Outlet, redirect, useLocation } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Shield, Flag, Users, Package, AlertTriangle, ScrollText, LifeBuoy, MessageSquare, Ticket, Bell, Tags, Send, FlaskConical } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  beforeLoad: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw redirect({ to: "/auth" });
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" });
    if (!isAdmin) throw redirect({ to: "/dashboard" });
  },
  component: AdminLayout,
});

const nav = [
  { to: "/admin", label: "Overview", icon: Shield, exact: true },
  { to: "/admin/reports", label: "Reports", icon: Flag },
  { to: "/admin/disputes", label: "Disputes", icon: AlertTriangle },
  { to: "/admin/founders", label: "Founders", icon: Users },
  { to: "/admin/listings", label: "Listings", icon: Package },
  { to: "/admin/support", label: "Support analytics", icon: LifeBuoy },
  { to: "/admin/support-tickets", label: "Support tickets", icon: Ticket },
  { to: "/admin/support-feedback", label: "Feedback", icon: MessageSquare },
  { to: "/admin/support-topics", label: "Topics", icon: Tags },
  { to: "/admin/support-tester", label: "Rules tester", icon: FlaskConical },
  { to: "/admin/support-alerts", label: "Alerts", icon: Bell },
  { to: "/admin/support-webhooks", label: "Webhooks", icon: Send },
  { to: "/admin/audit", label: "Audit log", icon: ScrollText },
];

function AdminLayout() {
  const loc = useLocation();
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex gap-10">
          <aside className="hidden lg:block w-56 shrink-0">
            <div className="sticky top-24 space-y-1">
              <div className="text-xs uppercase tracking-wider text-muted-foreground px-4 py-2">Admin</div>
              {nav.map((n) => {
                const active = n.exact ? loc.pathname === n.to : loc.pathname.startsWith(n.to);
                return (
                  <Link key={n.to} to={n.to} className={`flex items-center gap-3 rounded-full px-4 py-2.5 text-sm transition-colors ${active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>
                    <n.icon className="h-4 w-4" />{n.label}
                  </Link>
                );
              })}
            </div>
          </aside>
          <div className="flex-1 min-w-0"><Outlet /></div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
