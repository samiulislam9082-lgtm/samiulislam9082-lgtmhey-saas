import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { getTicketAttachmentUrl, updateTicketStatus } from "@/lib/support-tickets.functions";
import { toast } from "sonner";
import { ArrowLeft, Paperclip, Download } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/support-tickets/$id")({
  head: () => ({ meta: [{ title: "Ticket — Admin" }, { name: "robots", content: "noindex" }] }),
  component: AdminTicketDetail,
});

type T = {
  id: string; subject: string; message: string; email: string; name: string;
  status: string; priority: string; source: string; created_at: string;
  transcript: unknown; attachment_path: string | null; attachment_name: string | null;
  attachment_size: number | null; attachment_mime: string | null;
};
type Ev = { id: string; event_type: string; from_status: string | null; to_status: string | null; note: string | null; created_at: string };

const STATUSES = ["new","open","pending","resolved"] as const;

function AdminTicketDetail() {
  const { id } = Route.useParams();
  const [t, setT] = useState<T | null>(null);
  const [events, setEvents] = useState<Ev[]>([]);
  const [note, setNote] = useState("");
  const [attUrl, setAttUrl] = useState<{ url: string | null; mime: string | null; name: string | null } | null>(null);
  const getUrl = useServerFn(getTicketAttachmentUrl);
  const updateStatus = useServerFn(updateTicketStatus);

  const load = async () => {
    const [ticket, evs] = await Promise.all([
      supabase.from("support_tickets").select("*").eq("id", id).maybeSingle(),
      supabase.from("support_ticket_events").select("*").eq("ticket_id", id).order("created_at"),
    ]);
    setT(ticket.data as T);
    setEvents((evs.data as Ev[]) ?? []);
  };
  useEffect(() => { void load(); }, [id]);

  useEffect(() => {
    if (!t?.attachment_path) return;
    getUrl({ data: { ticket_id: id } }).then((r) => setAttUrl(r as never)).catch(()=>{});
  }, [t?.attachment_path, id, getUrl]);

  const setStatus = async (status: typeof STATUSES[number]) => {
    try {
      await updateStatus({ data: { ticket_id: id, status, note: note.trim() || undefined } });
      setNote("");
      toast.success(`Marked ${status}`);
      void load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  };

  if (!t) return <p className="text-xs text-muted-foreground">Loading…</p>;
  const transcript = Array.isArray(t.transcript) ? t.transcript as { role: string; content: string }[] : [];

  return (
    <div className="space-y-6 max-w-4xl">
      <Link to="/admin/support-tickets" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"><ArrowLeft className="h-3 w-3"/> All tickets</Link>
      <div>
        <h1 className="text-2xl font-serif tracking-tight">{t.subject}</h1>
        <p className="text-sm text-muted-foreground">From {t.name} &lt;{t.email}&gt; · {t.priority} · {new Date(t.created_at).toLocaleString()}</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {STATUSES.map(s => (
          <button key={s} onClick={()=>setStatus(s)} disabled={t.status===s}
            className={`rounded-full border px-3 py-1 text-xs capitalize ${t.status===s?"border-violet/60 bg-violet/15 text-violet":"border-hairline hover:bg-violet/10"}`}>{s}</button>
        ))}
      </div>

      <section className="rounded-2xl border border-hairline bg-surface p-5 space-y-2">
        <h2 className="text-sm font-medium">Message</h2>
        <div className="whitespace-pre-wrap text-sm">{t.message}</div>
      </section>

      {t.attachment_path && (
        <section className="rounded-2xl border border-hairline bg-surface p-5">
          <h2 className="text-sm font-medium mb-3 flex items-center gap-1"><Paperclip className="h-3.5 w-3.5"/> Attachment</h2>
          <div className="text-xs text-muted-foreground mb-2">{t.attachment_name} · {((t.attachment_size ?? 0)/1024).toFixed(0)} KB · {t.attachment_mime}</div>
          {attUrl?.url ? (
            <>
              {t.attachment_mime?.startsWith("image/") ? (
                <img src={attUrl.url} alt={t.attachment_name ?? ""} className="max-h-96 rounded-md border border-hairline"/>
              ) : t.attachment_mime === "application/pdf" ? (
                <iframe src={attUrl.url} className="w-full h-96 rounded-md border border-hairline" title="pdf preview"/>
              ) : (
                <p className="text-xs text-muted-foreground">No inline preview.</p>
              )}
              <a href={attUrl.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 mt-3 text-xs text-violet hover:underline">
                <Download className="h-3 w-3"/> Download (link valid 10 min)
              </a>
            </>
          ) : <p className="text-xs text-muted-foreground">Fetching secure URL…</p>}
        </section>
      )}

      {transcript.length > 0 && (
        <section className="rounded-2xl border border-hairline bg-surface p-5 space-y-2">
          <h2 className="text-sm font-medium">Chat transcript</h2>
          <div className="space-y-1.5 text-xs max-h-96 overflow-y-auto">
            {transcript.map((m, i) => (
              <div key={i}><span className="text-muted-foreground">{m.role}:</span> {m.content}</div>
            ))}
          </div>
        </section>
      )}

      <section className="rounded-2xl border border-hairline bg-surface p-5 space-y-3">
        <h2 className="text-sm font-medium">Timeline</h2>
        <ul className="space-y-2 text-xs">
          {events.map(e => (
            <li key={e.id} className="border-l-2 border-hairline pl-3">
              <div className="text-muted-foreground text-[10px]">{new Date(e.created_at).toLocaleString()}</div>
              <div>{e.event_type === "status_changed" ? `Status: ${e.from_status ?? "—"} → ${e.to_status}` : e.event_type === "created" ? "Ticket created" : e.event_type}</div>
              {e.note && <div className="text-muted-foreground italic">"{e.note}"</div>}
            </li>
          ))}
          {events.length===0 && <li className="text-muted-foreground">No events.</li>}
        </ul>
        <div className="pt-3 border-t border-hairline">
          <label className="text-[11px] font-medium text-muted-foreground">Add note (attach to next status change)</label>
          <textarea value={note} onChange={(e)=>setNote(e.target.value)} rows={2} className="mt-1 w-full rounded-md border border-hairline bg-background px-2 py-1 text-xs"/>
        </div>
      </section>
    </div>
  );
}
