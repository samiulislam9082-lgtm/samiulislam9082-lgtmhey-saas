import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { resolveDispute } from "@/lib/admin.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/disputes")({
  component: Disputes,
});

function Disputes() {
  const [items, setItems] = useState<any[]>([]);
  const resolve = useServerFn(resolveDispute);
  async function load() {
    const { data } = await supabase
      .from("swap_requests")
      .select(`id, status, initiator_id, recipient_id, created_at,
        initiator_listing:saas_listings!swap_requests_initiator_listing_id_fkey(name),
        recipient_listing:saas_listings!swap_requests_recipient_listing_id_fkey(name)`)
      .eq("status", "disputed")
      .order("created_at", { ascending: false });
    setItems(data || []);
  }
  useEffect(() => { load(); }, []);
  async function act(id: string, resolution: any) {
    try { await resolve({ data: { swap_id: id, resolution } }); toast.success("Dispute resolved"); load(); } catch (e: any) { toast.error(e.message); }
  }
  return (
    <div>
      <h1 className="font-display text-4xl mb-6">Disputes</h1>
      <div className="space-y-3">
        {items.map((s) => (
          <Card key={s.id} className="p-4">
            <div className="text-sm font-medium">{s.initiator_listing?.name} ↔ {s.recipient_listing?.name}</div>
            <div className="text-xs text-muted-foreground mt-1 font-mono">swap: {s.id}</div>
            <div className="flex gap-2 mt-3 flex-wrap">
              <Button size="sm" onClick={() => act(s.id, "refund_both")}>Refund both</Button>
              <Button size="sm" variant="outline" onClick={() => act(s.id, "refund_initiator")}>Refund initiator</Button>
              <Button size="sm" variant="outline" onClick={() => act(s.id, "refund_recipient")}>Refund recipient</Button>
              <Button size="sm" variant="outline" onClick={() => act(s.id, "no_refund")}>No refund</Button>
            </div>
          </Card>
        ))}
        {items.length === 0 && <Card className="p-12 text-center text-muted-foreground">No open disputes.</Card>}
      </div>
    </div>
  );
}
