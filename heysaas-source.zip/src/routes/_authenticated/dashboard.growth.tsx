import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Loader2, Eye, Bookmark, MessageSquare, Repeat, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/growth")({
  head: () => ({ meta: [{ title: "Growth — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: GrowthPage,
});

type Funnel = { views: number; bookmarks: number; proposals: number; swaps: number };
type ListingStat = { id: string; name: string; views: number; interested: number; proposals: number };

function GrowthPage() {
  const [loading, setLoading] = useState(true);
  const [funnel, setFunnel] = useState<Funnel>({ views: 0, bookmarks: 0, proposals: 0, swaps: 0 });
  const [best, setBest] = useState<ListingStat[]>([]);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data: listings } = await supabase
        .from("saas_listings")
        .select("id, name, views, interested_count")
        .eq("owner_id", user.id);
      const ids = (listings ?? []).map((l: any) => l.id);
      const views = (listings ?? []).reduce((a: number, l: any) => a + (l.views ?? 0), 0);
      const interested = (listings ?? []).reduce((a: number, l: any) => a + (l.interested_count ?? 0), 0);
      let bookmarks = 0;
      let proposals = 0;
      let swaps = 0;
      if (ids.length) {
        const [{ count: bc }, { count: pc }, { count: sc }] = await Promise.all([
          supabase.from("bookmarks").select("id", { count: "exact", head: true }).in("listing_id" as any, ids),
          supabase.from("swap_requests").select("id", { count: "exact", head: true }).eq("recipient_id", user.id),
          supabase.from("swap_requests").select("id", { count: "exact", head: true })
            .or(`initiator_id.eq.${user.id},recipient_id.eq.${user.id}`).eq("status", "completed"),
        ]);
        bookmarks = bc ?? 0;
        proposals = pc ?? 0;
        swaps = sc ?? 0;
      }
      setFunnel({ views, bookmarks: bookmarks || interested, proposals, swaps });
      setBest(
        (listings ?? [])
          .map((l: any) => ({ id: l.id, name: l.name, views: l.views ?? 0, interested: l.interested_count ?? 0, proposals: 0 }))
          .sort((a: ListingStat, b: ListingStat) => b.views - a.views)
          .slice(0, 5)
      );
      setLoading(false);
    })();
  }, []);

  const steps = [
    { icon: Eye, label: "Views", value: funnel.views, hint: "Impressions on Explore, category pages, and direct links." },
    { icon: Bookmark, label: "Bookmarks", value: funnel.bookmarks, hint: "Founders who saved your listing for later." },
    { icon: MessageSquare, label: "Proposals", value: funnel.proposals, hint: "Swap requests you've received." },
    { icon: Repeat, label: "Deals closed", value: funnel.swaps, hint: "Fully completed swaps this year." },
  ];

  const rate = (a: number, b: number) => (b > 0 ? ((a / b) * 100).toFixed(1) + "%" : "—");

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="analytics"
              eyebrow="Marketing funnel"
              title="Growth insights"
              description="See how founders move from a first impression to a closed swap — and where you're leaking attention."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-6">
                  {steps.map((s, i) => (
                    <Card key={s.label} className="p-5">
                      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground mb-2">
                        <s.icon className="h-4 w-4 text-primary" /> {s.label}
                      </div>
                      <div className="text-3xl font-display italic">{s.value.toLocaleString()}</div>
                      {i > 0 && (
                        <div className="text-[11px] text-muted-foreground mt-1 inline-flex items-center gap-1">
                          <ArrowRight className="h-3 w-3" /> {rate(s.value, steps[i - 1].value)} of previous
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">{s.hint}</p>
                    </Card>
                  ))}
                </div>

                <Card className="p-5 mt-6">
                  <div className="font-medium mb-3">Top listings by attention</div>
                  {best.length === 0 ? (
                    <div className="text-sm text-muted-foreground">List a SaaS to start collecting funnel data.</div>
                  ) : (
                    <div className="divide-y divide-border">
                      {best.map((l) => (
                        <div key={l.id} className="py-3 flex items-center gap-4">
                          <div className="flex-1 min-w-0 truncate">{l.name}</div>
                          <div className="text-xs text-muted-foreground tabular-nums w-24 text-right">{l.views} views</div>
                          <div className="text-xs text-muted-foreground tabular-nums w-24 text-right">{l.interested} saved</div>
                        </div>
                      ))}
                    </div>
                  )}
                </Card>

                <Card className="p-5 mt-6">
                  <div className="font-medium mb-2">What to try next</div>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-muted-foreground">
                    <li>If <b>view → bookmark</b> is under 3%, refresh your cover image and tagline.</li>
                    <li>If <b>bookmark → proposal</b> is under 8%, add proof (revenue, users, screenshots) to your listing.</li>
                    <li>If <b>proposal → deal</b> is under 20%, respond within 24h and offer a call in your first reply.</li>
                  </ul>
                </Card>
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
