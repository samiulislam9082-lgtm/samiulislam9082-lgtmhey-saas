import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";
import { supabase } from "@/integrations/supabase/client";
import { Eye, Sparkles, Repeat, Users, Loader2, BarChart3 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/analytics")({
  head: () => ({
    meta: [{ title: "Analytics — Hey SaaS" }, { name: "robots", content: "noindex" }],
  }),
  component: Page,
});

type Stats = {
  totalViews: number;
  totalInterest: number;
  totalSwaps: number;
  followers: number;
  listings: { id: string; name: string; views: number; interested_count: number }[];
};

function Page() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const [{ data: listings }, { count: followers }, { count: completed }] = await Promise.all([
        supabase.from("saas_listings").select("id, name, views, interested_count").eq("owner_id", user.id),
        supabase.from("follows").select("follower_id", { count: "exact", head: true }).eq("following_id", user.id),
        supabase.from("swap_requests").select("id", { count: "exact", head: true }).or(`initiator_id.eq.${user.id},recipient_id.eq.${user.id}`).eq("status", "completed"),
      ]);
      const ls = (listings ?? []) as any[];
      setStats({
        totalViews: ls.reduce((a, b) => a + (b.views || 0), 0),
        totalInterest: ls.reduce((a, b) => a + (b.interested_count || 0), 0),
        totalSwaps: completed || 0,
        followers: followers || 0,
        listings: ls.sort((a, b) => (b.views || 0) - (a.views || 0)),
      });
      setLoading(false);
    })();
  }, []);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="analytics"
              eyebrow="Signal · Live"
              title="Analytics"
              description="Traffic and engagement across every listing in your founder workspace."
            />
            <DashRibbon variant="analytics" />
            <DashBodyBlock variant="analytics" />

            {loading || !stats ? (
              <div className="mt-16 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : (
              <>
                <div className="mt-8 grid gap-4 grid-cols-2 md:grid-cols-4">
                  <StatCard icon={<Eye className="h-4 w-4" />} label="Total views" value={stats.totalViews} />
                  <StatCard icon={<Sparkles className="h-4 w-4" />} label="Interest signals" value={stats.totalInterest} />
                  <StatCard icon={<Repeat className="h-4 w-4" />} label="Completed swaps" value={stats.totalSwaps} />
                  <StatCard icon={<Users className="h-4 w-4" />} label="Followers" value={stats.followers} />
                </div>

                <div className="mt-12 flex items-baseline justify-between gap-3">
                  <h2 className="font-display text-3xl">Per-listing performance</h2>
                  <span className="text-[11px] uppercase tracking-widest text-muted-foreground">Sorted by views</span>
                </div>
                {stats.listings.length === 0 ? (
                  <div className="hs-empty mt-6">
                    <div className="hs-empty-icon"><BarChart3 className="h-6 w-6" /></div>
                    <p className="mt-5 font-display text-3xl">Nothing to chart, yet.</p>
                    <p className="mt-2 text-sm text-muted-foreground">List a SaaS to start collecting views, interest signals and swap intent.</p>
                  </div>
                ) : (
                  <div className="mt-6 rounded-2xl border border-hairline overflow-hidden bg-surface/60 backdrop-blur">
                    <table className="w-full text-sm">
                      <thead className="bg-surface-elevated/60 text-muted-foreground text-[10px] uppercase tracking-widest">
                        <tr><th className="text-left px-5 py-4">Listing</th><th className="text-left px-5 py-4">Views</th><th className="text-left px-5 py-4">Interest</th></tr>
                      </thead>
                      <tbody>
                        {stats.listings.map((l) => (
                          <tr key={l.id} className="border-t border-hairline hover:bg-surface-elevated/40 transition-colors">
                            <td className="px-5 py-4 font-medium">{l.name}</td>
                            <td className="px-5 py-4 tabular-nums">{l.views}</td>
                            <td className="px-5 py-4 tabular-nums">{l.interested_count}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="hs-stat">
      <div className="flex items-center gap-3">
        <span className="hs-stat-icon">{icon}</span>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</span>
      </div>
      <div className="mt-4 hs-stat-value">{value.toLocaleString()}</div>
      <svg className="hs-stat-spark" width="72" height="24" viewBox="0 0 72 24" fill="none" aria-hidden>
        <path d="M2 18 L14 12 L26 16 L38 6 L50 10 L62 4 L70 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}
