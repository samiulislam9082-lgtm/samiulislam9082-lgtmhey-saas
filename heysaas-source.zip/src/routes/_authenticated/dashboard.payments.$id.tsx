import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Loader2, Printer, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/payments/$id")({
  head: () => ({ meta: [{ title: "Receipt — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: InvoicePage,
});

type Payment = {
  id: string;
  amount_cents: number;
  currency: string;
  status: string;
  created_at: string;
  paid_at: string | null;
  swap_request_id: string;
  stripe_payment_intent_id: string | null;
  stripe_checkout_session_id: string | null;
  user_id: string;
};

function InvoicePage() {
  const { id } = Route.useParams();
  const [payment, setPayment] = useState<Payment | null>(null);
  const [profile, setProfile] = useState<{ display_name: string | null; username: string | null } | null>(null);
  const [email, setEmail] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setEmail(user.email ?? "");
      const [{ data: p }, { data: pr }] = await Promise.all([
        supabase.from("payments").select("*").eq("id", id).eq("user_id", user.id).maybeSingle(),
        supabase.from("profiles").select("display_name, username").eq("id", user.id).maybeSingle(),
      ]);
      setPayment(p as Payment | null);
      setProfile(pr as any);
      setLoading(false);
    })();
  }, [id]);

  if (loading) return <div className="min-h-dvh flex items-center justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>;
  if (!payment) return <div className="min-h-dvh flex items-center justify-center text-muted-foreground">Receipt not found.</div>;

  const invoiceNo = `HS-${payment.id.slice(0, 8).toUpperCase()}`;
  const dt = new Date(payment.paid_at ?? payment.created_at);

  return (
    <div className="min-h-dvh bg-background">
      <div className="mx-auto max-w-3xl px-6 py-10 print:py-0">
        <div className="flex items-center justify-between mb-6 print:hidden">
          <Link to="/dashboard/payments" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />Back to payments
          </Link>
          <Button onClick={() => window.print()} className="rounded-full">
            <Printer className="h-4 w-4 mr-2" />Print / Save PDF
          </Button>
        </div>

        <div className="rounded-2xl border border-hairline bg-surface p-10 print:border-0 print:p-0 print:bg-transparent">
          <div className="flex items-start justify-between">
            <div>
              <div style={{ fontFamily: "Pacifico, cursive" }} className="text-3xl">HeySaaS</div>
              <div className="mt-1 text-xs text-muted-foreground">SaaS Swap Marketplace</div>
            </div>
            <div className="text-right">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Receipt</div>
              <div className="font-mono text-sm mt-1">{invoiceNo}</div>
              <div className={`inline-block mt-2 text-xs px-2 py-0.5 rounded-full border ${payment.status === "paid" ? "text-emerald-400 border-emerald-500/40" : "text-amber-400 border-amber-500/40"}`}>{payment.status.toUpperCase()}</div>
            </div>
          </div>

          <div className="mt-10 grid grid-cols-2 gap-6 text-sm">
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Billed to</div>
              <div className="mt-1 font-medium">{profile?.display_name || profile?.username || "Founder"}</div>
              <div className="text-muted-foreground">{email}</div>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Payment date</div>
              <div className="mt-1">{dt.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}</div>
              <div className="text-muted-foreground text-xs mt-2">Method: Stripe</div>
            </div>
          </div>

          <div className="mt-8 border-t border-hairline pt-6">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase tracking-wider text-muted-foreground">
                <tr><th className="text-left pb-2">Description</th><th className="text-right pb-2">Amount</th></tr>
              </thead>
              <tbody>
                <tr className="border-t border-hairline">
                  <td className="py-3">
                    HeySaaS safety fee
                    <div className="text-xs text-muted-foreground">Swap #{payment.swap_request_id.slice(0, 8)}</div>
                  </td>
                  <td className="py-3 text-right">${(payment.amount_cents / 100).toFixed(2)} {payment.currency.toUpperCase()}</td>
                </tr>
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-hairline">
                  <td className="pt-4 font-medium">Total</td>
                  <td className="pt-4 text-right font-display text-xl">${(payment.amount_cents / 100).toFixed(2)} {payment.currency.toUpperCase()}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="mt-10 pt-6 border-t border-hairline text-xs text-muted-foreground space-y-1">
            {payment.stripe_payment_intent_id && <div>Payment intent: <span className="font-mono">{payment.stripe_payment_intent_id}</span></div>}
            {payment.stripe_checkout_session_id && <div>Session: <span className="font-mono">{payment.stripe_checkout_session_id}</span></div>}
            <div className="mt-4">Thank you for using HeySaaS. This receipt serves as proof of payment for the safety fee associated with your swap.</div>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          body { background: white !important; color: black !important; }
          .bg-background, .bg-surface { background: white !important; }
          .text-muted-foreground { color: #555 !important; }
        }
      `}</style>
    </div>
  );
}
