import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ThumbsUp, ThumbsDown, Check, AlertTriangle, Filter } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/support-feedback")({
  head: () => ({ meta: [{ title: "Support feedback — Admin" }, { name: "robots", content: "noindex" }] }),
  component: FeedbackAdmin,
});

type F = {
  id: string;
  session_id: string;
  conversation_id: string | null;
  user_id: string | null;
  rating: "up" | "down";
  reason: string | null;
  comment: string | null;
  topic: string | null;
  message_excerpt: string | null;
  user_question: string | null;
  is_report: boolean;
  report_explanation: string | null;
  resolved_at: string | null;
  created_at: string;
};

function FeedbackAdmin() {
  const [rows, setRows] = useState<F[]>([]);
  const [loading, setLoading] = useState(true);
  const [sentiment, setSentiment] = useState<"all"|"up"|"down">("all");
  const [reason, setReason] = useState<string>("all");
  const [status, setStatus] = useState<"all"|"open"|"resolved"|"reports">("all");
  const [conv, setConv] = useState("");

  const load = async () => {
    setLoading(true);
    let q = supabase.from("support_message_feedback").select("*").order("created_at", { ascending: false }).limit(500);
    if (sentiment !== "all") q = q.eq("rating", sentiment);
    if (reason !== "all") q = q.eq("reason", reason);
    if (status === "resolved") q = q.not("resolved_at", "is", null);
    if (status === "open") q = q.is("resolved_at", null);
    if (status === "reports") q = q.eq("is_report", true);
    if (conv.trim()) q = q.eq("conversation_id", conv.trim());
    const { data } = await q;
    setRows((data as F[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { void load(); }, [sentiment, reason, status, conv]);

  const toggleResolved = async (r: F) => {
    const patch = r.resolved_at ? { resolved_at: null, resolved_by: null } : { resolved_at: new Date().toISOString() };
    const { error } = await supabase.from("support_message_feedback").update(patch).eq("id", r.id);
    if (error) return toast.error(error.message);
    void load();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-serif tracking-tight">Support feedback</h1>
        <p className="text-sm text-muted-foreground">Review 👍/👎 on AI answers, reports, and flagged responses.</p>
      </div>

      <div className="flex flex-wrap gap-2 items-center rounded-xl border border-hairline bg-surface p-3">
        <Filter className="h-4 w-4 text-muted-foreground"/>
        <select value={sentiment} onChange={(e)=>setSentiment(e.target.value as never)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs">
          <option value="all">All ratings</option><option value="up">👍 Positive</option><option value="down">👎 Negative</option>
        </select>
        <select value={reason} onChange={(e)=>setReason(e.target.value)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs">
          <option value="all">All reasons</option>
          {["inaccurate","unclear","incomplete","off_topic","other"].map(r=><option key={r} value={r}>{r}</option>)}
        </select>
        <select value={status} onChange={(e)=>setStatus(e.target.value as never)} className="rounded-md border border-hairline bg-background px-2 py-1 text-xs">
          <option value="all">All</option><option value="open">Unresolved</option><option value="resolved">Resolved</option><option value="reports">Reports only</option>
        </select>
        <input value={conv} onChange={(e)=>setConv(e.target.value)} placeholder="Conversation ID" className="rounded-md border border-hairline bg-background px-2 py-1 text-xs w-56"/>
      </div>

      {loading ? <p className="text-xs text-muted-foreground">Loading…</p> : rows.length===0 ? <p className="text-xs text-muted-foreground">No feedback matches.</p> : (
        <ul className="space-y-3">
          {rows.map((r) => (
            <li key={r.id} className={`rounded-xl border p-4 space-y-2 ${r.is_report ? "border-rose-500/40 bg-rose-500/5" : "border-hairline bg-surface"}`}>
              <div className="flex items-center gap-2 text-xs">
                {r.rating === "up" ? <ThumbsUp className="h-3.5 w-3.5 text-emerald-500"/> : <ThumbsDown className="h-3.5 w-3.5 text-rose-500"/>}
                {r.is_report && <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-medium text-rose-400"><AlertTriangle className="h-3 w-3"/> Report</span>}
                {r.topic && <span className="rounded-full bg-violet/10 px-2 py-0.5 text-[10px] text-violet capitalize">{r.topic.replace(/_/g," ")}</span>}
                {r.reason && <span className="text-[10px] text-muted-foreground">reason: {r.reason}</span>}
                <span className="ml-auto text-[10px] text-muted-foreground">{new Date(r.created_at).toLocaleString()}</span>
              </div>
              {r.user_question && <div className="text-xs"><span className="text-muted-foreground">Q:</span> {r.user_question}</div>}
              {r.message_excerpt && <div className="text-xs text-muted-foreground line-clamp-3"><span className="text-foreground">A:</span> {r.message_excerpt}</div>}
              {r.comment && <div className="text-xs italic text-foreground/80">"{r.comment}"</div>}
              {r.report_explanation && <div className="text-xs text-rose-400"><strong>Report:</strong> {r.report_explanation}</div>}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] font-mono text-muted-foreground">{r.session_id.slice(0,10)}…</span>
                <button onClick={() => toggleResolved(r)} className={`ml-auto inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] ${r.resolved_at ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400" : "border-hairline hover:bg-violet/10"}`}>
                  <Check className="h-3 w-3"/> {r.resolved_at ? "Resolved" : "Mark resolved"}
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
