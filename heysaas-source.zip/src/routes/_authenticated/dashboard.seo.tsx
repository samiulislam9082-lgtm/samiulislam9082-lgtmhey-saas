import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, CheckCircle2, AlertTriangle, Search } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/seo")({
  head: () => ({ meta: [{ title: "SEO Toolkit — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: SeoPage,
});

type Listing = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  tag_slugs: string[] | null;
};

function SeoPage() {
  const [rows, setRows] = useState<Listing[]>([]);
  const [id, setId] = useState<string>("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data } = await supabase
        .from("saas_listings")
        .select("id, slug, name, tagline, description, tag_slugs")
        .eq("owner_id", user.id);
      setRows((data ?? []) as Listing[]);
      setId((data ?? [])[0]?.id ?? "");
      setLoading(false);
    })();
  }, []);

  const current = useMemo(() => rows.find((r) => r.id === id) ?? null, [rows, id]);

  const checks = useMemo(() => {
    if (!current) return [];
    const title = `${current.name}${current.tagline ? ` — ${current.tagline}` : ""}`;
    const desc = (current.description ?? current.tagline ?? "").trim();
    const slugOk = /^[a-z0-9-]{3,60}$/.test(current.slug ?? "");
    const tags = current.tag_slugs?.length ?? 0;
    return [
      { ok: title.length >= 30 && title.length <= 60, label: "Meta title length", detail: `${title.length}/60 chars — sweet spot is 45–60.` },
      { ok: desc.length >= 110 && desc.length <= 160, label: "Meta description length", detail: `${desc.length}/160 chars — Google shows ~155.` },
      { ok: slugOk, label: "Clean URL slug", detail: `/${current.slug} — lowercase, 3–60 chars, hyphens only.` },
      { ok: tags >= 3, label: "Tag coverage", detail: `${tags} tag(s) — aim for 3+ to appear in more saved-search matches.` },
      { ok: /\b(saas|tool|platform|app)\b/i.test(title), label: "Category keyword in title", detail: "Include a category word (SaaS, tool, platform) for better SERP match." },
      { ok: !!current.tagline && current.tagline.length >= 20, label: "Compelling tagline", detail: "Taglines under 20 chars rarely earn a click — describe the outcome." },
    ];
  }, [current]);

  const score = useMemo(() => {
    if (!checks.length) return 0;
    return Math.round((checks.filter((c) => c.ok).length / checks.length) * 100);
  }, [checks]);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="analytics"
              eyebrow="SEO toolkit"
              title="Make your listing findable"
              description="Real search-facing checks — title length, meta description, slug quality, tag coverage. Fix each red mark to lift your Explore rank."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : rows.length === 0 ? (
              <Card className="p-6 text-sm text-muted-foreground mt-6">
                No listings yet — publish one to run SEO checks.
              </Card>
            ) : (
              <>
                <Card className="p-5 mt-6 flex flex-col md:flex-row md:items-center gap-4 justify-between">
                  <div className="flex items-center gap-3">
                    <Search className="h-5 w-5 text-primary" />
                    <div className="text-sm text-muted-foreground">Auditing</div>
                    <Select value={id} onValueChange={setId}>
                      <SelectTrigger className="w-[280px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {rows.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="text-right">
                    <div className="text-xs uppercase tracking-widest text-muted-foreground">SEO score</div>
                    <div className="text-3xl font-display italic">{score}<span className="text-base text-muted-foreground">/100</span></div>
                  </div>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                  {checks.map((c) => (
                    <Card key={c.label} className="p-4 flex gap-3">
                      {c.ok ? (
                        <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="font-medium">{c.label}</div>
                        <div className="text-xs text-muted-foreground mt-1">{c.detail}</div>
                      </div>
                    </Card>
                  ))}
                </div>

                {current && (
                  <Card className="p-5 mt-6">
                    <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Google preview</div>
                    <div className="rounded-md bg-muted/40 p-4 max-w-2xl">
                      <div className="text-xs text-muted-foreground truncate">heysaas.co › {current.slug}</div>
                      <div className="text-primary text-lg leading-snug mt-1 truncate">{current.name}{current.tagline ? ` — ${current.tagline}` : ""}</div>
                      <div className="text-sm text-muted-foreground mt-1 line-clamp-2">{current.description ?? current.tagline ?? ""}</div>
                    </div>
                  </Card>
                )}
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
