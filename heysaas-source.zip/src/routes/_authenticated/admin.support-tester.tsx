import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { classifyTopic } from "@/lib/support-analytics";
import { FlaskConical, PlayCircle, AlertCircle, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/support-tester")({
  head: () => ({ meta: [{ title: "Rules tester — Admin" }, { name: "robots", content: "noindex" }] }),
  component: TesterPage,
});

type Rule = { id: string; topic_slug: string; pattern: string; priority: number; active: boolean };
type Topic = { slug: string; label: string; suggested_flow: string; eta_hours: number | null; active: boolean };

const SAMPLE = `User: Hi, I paid the $19 safety fee yesterday and I still can't access the swap room. This is urgent, my launch is tomorrow!
Bot: Sorry to hear that. Can you share the listing URL?
User: Sure, it's about a payment issue and the stripe receipt shows charged but nothing unlocked. Please help ASAP.`;

const URGENCY = [
  { level: "urgent" as const, re: /\b(urgent|asap|emergency|immediately|right now|critical|down|outage)\b/i },
  { level: "high" as const, re: /\b(soon|today|blocker|blocked|can'?t (access|use|login)|stuck|broken|not working)\b/i },
  { level: "low" as const, re: /\b(whenever|no rush|low priority|fyi|just wondering|curious)\b/i },
];

function detectPriority(text: string): "low" | "normal" | "high" | "urgent" {
  for (const u of URGENCY) if (u.re.test(text)) return u.level;
  return "normal";
}

type MatchResult = {
  rule: Rule;
  matches: string[];
};

function TesterPage() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [text, setText] = useState(SAMPLE);
  const [loading, setLoading] = useState(true);
  const [ran, setRan] = useState(false);

  useEffect(() => {
    (async () => {
      const [r, t] = await Promise.all([
        supabase.from("support_topic_rules").select("*").order("priority"),
        supabase.from("support_topics").select("slug,label,suggested_flow,eta_hours,active"),
      ]);
      setRules((r.data as Rule[]) ?? []);
      setTopics((t.data as Topic[]) ?? []);
      setLoading(false);
    })();
  }, []);

  const topicMap = useMemo(() => new Map(topics.map((t) => [t.slug, t])), [topics]);

  const result = useMemo(() => {
    if (!ran) return null;
    const active = rules.filter((r) => r.active);
    const matched: MatchResult[] = [];
    const errors: { rule: Rule; error: string }[] = [];
    for (const r of active) {
      try {
        const re = new RegExp(r.pattern, "i");
        const m = text.match(new RegExp(r.pattern, "gi"));
        if (re.test(text)) matched.push({ rule: r, matches: m ? Array.from(new Set(m)).slice(0, 8) : [] });
      } catch (e) {
        errors.push({ rule: r, error: (e as Error).message });
      }
    }
    matched.sort((a, b) => a.rule.priority - b.rule.priority);
    const winner = matched[0]?.rule ?? null;
    const winnerTopic = winner ? topicMap.get(winner.topic_slug) ?? null : null;
    const fallback = classifyTopic(text);
    const priority = detectPriority(text);

    const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
    const turns = lines.filter((l) => /^(user|bot|assistant|agent|support|customer)\s*[:>-]/i.test(l)).length || lines.length;
    const words = text.trim().split(/\s+/).filter(Boolean).length;
    const chars = text.length;
    const errorish = /(error|fail|failed|500|400|401|403|404|timeout|crash)/i.test(text);
    const moneyish = /(refund|charge|charged|receipt|invoice|payment|stripe|\$\d+)/i.test(text);
    const suggestedFlow = winnerTopic?.suggested_flow ?? (priority === "urgent" || priority === "high" ? "ticket" : "chat");
    const eta = winnerTopic?.eta_hours ?? null;

    return {
      matched,
      errors,
      winner,
      winnerTopic,
      fallback,
      priority,
      metrics: { turns, words, chars, errorish, moneyish, suggestedFlow, eta },
    };
  }, [ran, rules, text, topicMap]);

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-serif tracking-tight flex items-center gap-2">
            <FlaskConical className="h-6 w-6 text-violet" /> Rules tester
          </h1>
          <p className="text-sm text-muted-foreground">Paste a sample transcript and preview which topic, priority, and metrics your rules would produce.</p>
        </div>
        <Link to="/admin/support-topics" className="text-xs text-violet hover:underline">Manage rules →</Link>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          <label className="text-[11px] uppercase tracking-wider text-muted-foreground">Sample transcript</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={16}
            placeholder="Paste a chat transcript or user message…"
            className="w-full rounded-2xl border border-hairline bg-surface p-4 font-mono text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-violet/40"
          />
          <div className="flex items-center gap-2">
            <button
              onClick={() => setRan(true)}
              disabled={loading || !text.trim()}
              className="inline-flex items-center gap-1.5 rounded-md bg-violet px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-violet-glow disabled:opacity-50"
            >
              <PlayCircle className="h-3.5 w-3.5" /> Run test
            </button>
            <button
              onClick={() => { setText(SAMPLE); setRan(false); }}
              className="rounded-md border border-hairline px-3 py-1.5 text-xs hover:bg-secondary"
            >
              Reset to sample
            </button>
            <button
              onClick={() => { setText(""); setRan(false); }}
              className="rounded-md border border-hairline px-3 py-1.5 text-xs hover:bg-secondary"
            >
              Clear
            </button>
            <span className="ml-auto text-[11px] text-muted-foreground">
              {loading ? "Loading rules…" : `${rules.filter(r => r.active).length} active rules`}
            </span>
          </div>
        </div>

        <div className="space-y-4">
          {!result ? (
            <div className="rounded-2xl border border-dashed border-hairline p-8 text-center text-sm text-muted-foreground">
              Run the test to see classification, priority, and metrics.
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Card label="Topic">
                  {result.winner ? (
                    <div>
                      <div className="text-lg font-medium">{result.winnerTopic?.label ?? result.winner.topic_slug}</div>
                      <div className="text-[11px] font-mono text-muted-foreground">{result.winner.topic_slug}</div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-lg font-medium text-muted-foreground">No rule matched</div>
                      <div className="text-[11px] text-muted-foreground">Fallback: <span className="font-mono">{result.fallback}</span></div>
                    </div>
                  )}
                </Card>
                <Card label="Priority">
                  <PriorityPill p={result.priority} />
                </Card>
                <Card label="Suggested flow">
                  <div className="text-lg font-medium capitalize">{result.metrics.suggestedFlow}</div>
                  {result.metrics.eta != null && (
                    <div className="text-[11px] text-muted-foreground">ETA ~{result.metrics.eta}h</div>
                  )}
                </Card>
                <Card label="Fallback classifier">
                  <div className="text-lg font-mono">{result.fallback}</div>
                  <div className="text-[11px] text-muted-foreground">Legacy regex</div>
                </Card>
              </div>

              <div className="rounded-2xl border border-hairline bg-surface p-4">
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Metrics</div>
                <div className="grid grid-cols-4 gap-3 text-center">
                  <Metric label="Turns" value={result.metrics.turns} />
                  <Metric label="Words" value={result.metrics.words} />
                  <Metric label="Chars" value={result.metrics.chars} />
                  <Metric label="Rules hit" value={result.matched.length} />
                </div>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {result.metrics.errorish && <Chip>error signals</Chip>}
                  {result.metrics.moneyish && <Chip>money/billing signals</Chip>}
                  {!result.metrics.errorish && !result.metrics.moneyish && <Chip muted>no strong signals</Chip>}
                </div>
              </div>

              <div className="rounded-2xl border border-hairline bg-surface p-4">
                <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-2">Matched rules ({result.matched.length})</div>
                {result.matched.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No active rule matched. Consider adding a rule or check patterns.</p>
                ) : (
                  <ul className="space-y-2">
                    {result.matched.map((m, i) => (
                      <li key={m.rule.id} className="rounded-md border border-hairline bg-background p-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            {i === 0 && <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />}
                            <code className="text-[11px] font-mono truncate">{m.rule.pattern}</code>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-[10px] text-muted-foreground">prio {m.rule.priority}</span>
                            <span className="text-[10px] rounded-full bg-violet/10 text-violet px-2 py-0.5">{m.rule.topic_slug}</span>
                          </div>
                        </div>
                        {m.matches.length > 0 && (
                          <div className="mt-1.5 flex flex-wrap gap-1">
                            {m.matches.map((mm, idx) => (
                              <span key={idx} className="text-[10px] rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 px-1.5 py-0.5 font-mono">
                                {mm}
                              </span>
                            ))}
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {result.errors.length > 0 && (
                <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4">
                  <div className="flex items-center gap-2 text-xs text-destructive mb-2">
                    <AlertCircle className="h-3.5 w-3.5" /> Invalid patterns ({result.errors.length})
                  </div>
                  <ul className="space-y-1 text-[11px] font-mono">
                    {result.errors.map((e) => (
                      <li key={e.rule.id}>
                        <span className="text-muted-foreground">{e.rule.topic_slug}:</span> {e.rule.pattern} — <span className="text-destructive">{e.error}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Card({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-hairline bg-surface p-4">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">{label}</div>
      {children}
    </div>
  );
}
function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="text-lg font-medium tabular-nums">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
function Chip({ children, muted }: { children: React.ReactNode; muted?: boolean }) {
  return (
    <span className={`text-[10px] rounded-full px-2 py-0.5 ${muted ? "bg-secondary text-muted-foreground" : "bg-violet/10 text-violet"}`}>
      {children}
    </span>
  );
}
function PriorityPill({ p }: { p: "low" | "normal" | "high" | "urgent" }) {
  const styles: Record<string, string> = {
    urgent: "bg-red-500/15 text-red-500",
    high: "bg-amber-500/15 text-amber-500",
    normal: "bg-secondary text-foreground",
    low: "bg-muted text-muted-foreground",
  };
  return <span className={`inline-block rounded-full px-3 py-1 text-sm font-medium capitalize ${styles[p]}`}>{p}</span>;
}
