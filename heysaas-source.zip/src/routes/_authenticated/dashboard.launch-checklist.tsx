import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Check, Circle, Loader2, ExternalLink } from "lucide-react";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/dashboard/launch-checklist")({
  head: () => ({ meta: [{ title: "Launch checklist — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: LaunchChecklistPage,
});

type Listing = {
  id: string; name: string; slug: string; status: string;
  tagline: string | null; description: string | null;
  logo_url: string | null; cover_url: string | null;
  screenshots: any; tech_stack: string[]; tag_slugs: string[];
  category_id: string | null; mrr_range: string | null;
  country: string | null; reason_for_swap: string | null;
  looking_for: string | null; website_url: string | null;
};

function LaunchChecklistPage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [selected, setSelected] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data } = await supabase
        .from("saas_listings")
        .select("id, name, slug, status, tagline, description, logo_url, cover_url, screenshots, tech_stack, tag_slugs, category_id, mrr_range, country, reason_for_swap, looking_for, website_url")
        .eq("owner_id", user.id);
      setListings((data as any) ?? []);
      if (data?.[0]) setSelected(data[0] as any);
      setLoading(false);
    })();
  }, []);

  const checks = useMemo(() => {
    if (!selected) return [];
    const shots = Array.isArray(selected.screenshots) ? selected.screenshots.length : 0;
    return [
      { group: "Essentials", label: "Logo uploaded", pass: !!selected.logo_url, tip: "A crisp square logo. Increases click-through in the grid ~40%." },
      { group: "Essentials", label: "Cover image uploaded", pass: !!selected.cover_url, tip: "Used as the OG image when shared on social." },
      { group: "Essentials", label: "Tagline set (≥ 20 chars)", pass: !!selected.tagline && selected.tagline.length >= 20, tip: "The first 8 words drive the click." },
      { group: "Essentials", label: "Description ≥ 200 chars", pass: !!selected.description && selected.description.length >= 200, tip: "Explains what you built and who it's for." },
      { group: "Essentials", label: "Website URL set", pass: !!selected.website_url, tip: "Founders need to try it before proposing." },
      { group: "Discovery", label: "Category chosen", pass: !!selected.category_id, tip: "Appears in category filters and homepage rails." },
      { group: "Discovery", label: "3+ tags", pass: (selected.tag_slugs ?? []).length >= 3, tip: "Improves saved-search matches." },
      { group: "Discovery", label: "3+ tech-stack items", pass: (selected.tech_stack ?? []).length >= 3, tip: "Founders filter by stack — be discoverable." },
      { group: "Discovery", label: "Country set", pass: !!selected.country, tip: "Powers the geo filter and world-map rails." },
      { group: "Trust", label: "MRR range disclosed", pass: !!selected.mrr_range, tip: "Serious founders skip listings without any traction band." },
      { group: "Trust", label: "3+ screenshots", pass: shots >= 3, tip: "Founders bounce fast without visual proof." },
      { group: "Signal", label: "Reason for swap explained", pass: !!selected.reason_for_swap && selected.reason_for_swap.length >= 40, tip: "Clarifies why you're listing and pre-empts questions." },
      { group: "Signal", label: "Looking-for is specific", pass: !!selected.looking_for && selected.looking_for.length >= 40, tip: "Filter out mismatched proposals early." },
      { group: "Launch", label: "Listing is LIVE", pass: selected.status === "live", tip: "Draft listings don't appear in Explore." },
    ];
  }, [selected]);

  const passed = checks.filter((c) => c.pass).length;
  const score = checks.length ? Math.round((passed / checks.length) * 100) : 0;

  const grouped = useMemo(() => {
    const g: Record<string, typeof checks> = {};
    for (const c of checks) { (g[c.group] ??= [] as any).push(c); }
    return g;
  }, [checks]);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="listings"
              eyebrow="Marketing desk"
              title="Launch checklist"
              description="Walk through the fields that move the needle before you hit publish or run a campaign."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : !selected ? (
              <Card className="p-6 text-sm text-muted-foreground mt-6">Create a listing first to run the checklist.</Card>
            ) : (
              <>
                <Card className="p-5 mt-6">
                  <label className="text-sm font-medium">Listing</label>
                  <select
                    value={selected.id}
                    onChange={(e) => setSelected(listings.find((l) => l.id === e.target.value) ?? null)}
                    className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {listings.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                  </select>
                </Card>

                <Card className="p-6 mt-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider">Launch readiness</div>
                      <div className="text-3xl font-display italic mt-1">{score}<span className="text-muted-foreground text-xl">/100</span></div>
                    </div>
                    <Badge variant={score >= 90 ? "default" : score >= 60 ? "secondary" : "outline"}>
                      {passed}/{checks.length} complete
                    </Badge>
                  </div>
                  <Progress value={score} className="h-2" />
                  <div className="mt-3">
                    <Link
                      to="/dashboard/listings"
                      className="text-sm text-primary hover:underline inline-flex items-center gap-1"
                    >
                      Edit listing <ExternalLink className="h-3 w-3" />
                    </Link>
                  </div>
                </Card>

                {Object.entries(grouped).map(([group, items]) => (
                  <Card key={group} className="p-5 mt-4">
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">{group}</div>
                    <ul className="space-y-3">
                      {items.map((c) => (
                        <li key={c.label} className="flex items-start gap-3">
                          {c.pass ? (
                            <span className="mt-0.5 h-5 w-5 rounded-full bg-primary/15 border border-primary/40 flex items-center justify-center"><Check className="h-3 w-3 text-primary" /></span>
                          ) : (
                            <Circle className="h-5 w-5 text-muted-foreground/60 mt-0.5" />
                          )}
                          <div className="min-w-0 flex-1">
                            <div className={c.pass ? "text-foreground" : "text-foreground font-medium"}>{c.label}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">{c.tip}</div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </Card>
                ))}
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
