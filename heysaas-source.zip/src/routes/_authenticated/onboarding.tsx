import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAvatarUrl } from "@/hooks/useAvatarUrl";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, Check, Loader2, Upload } from "lucide-react";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({
    meta: [
      { title: "Welcome — Hey SaaS" },
      { name: "description", content: "Set up your founder profile in under a minute." },
    ],
  }),
  component: OnboardingPage,
});

const STEPS = ["Username", "Display name", "Bio", "Avatar"] as const;

function OnboardingPage() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const avatarPreview = useAvatarUrl(avatarUrl);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    (async () => {
      const { data: sess } = await supabase.auth.getSession();
      const u = sess.session?.user;
      if (!u) return;
      setUserId(u.id);
      const { data: p } = await supabase
        .from("profiles")
        .select("username, display_name, bio, avatar_url")
        .eq("id", u.id)
        .maybeSingle();
      if (p?.username) {
        // Already onboarded — go to dashboard
        navigate({ to: "/dashboard", replace: true });
        return;
      }
      setDisplayName((p?.display_name as string) || (u.user_metadata?.display_name as string) || "");
      setBio((p?.bio as string) || "");
      setAvatarUrl((p?.avatar_url as string) || null);
    })();
  }, [navigate]);

  const validateUsername = async (val: string) => {
    setUsernameError(null);
    if (!/^[a-z0-9_]{3,20}$/.test(val)) {
      setUsernameError("3–20 chars, lowercase letters, numbers, underscores.");
      return false;
    }
    setCheckingUsername(true);
    const { data, error } = await (supabase as any).rpc("is_username_available", {
      _username: val,
      _user_id: userId,
    });
    setCheckingUsername(false);
    if (error) {
      setUsernameError("Could not check that username. Try again.");
      return false;
    }
    if (data === false) {
      setUsernameError("That username is taken or too similar to an existing one.");
      return false;
    }
    return true;
  };

  const onAvatarUpload = async (file: File) => {
    if (!userId) {
      toast.error("Session not ready — please refresh.");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Max 2MB.");
      return;
    }
    setLoading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const path = `${userId}/avatar-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("avatars").upload(path, file, {
        upsert: true,
        contentType: file.type,
      });
      if (error) {
        toast.error(`Avatar upload failed: ${error.message}`);
        return;
      }
      // Store the storage path in avatar_url; signed URLs generated on read.
      setAvatarUrl(path);
      toast.success("Avatar uploaded.");
    } catch (e: any) {
      toast.error(e?.message || "Avatar upload failed.");
    } finally {
      setLoading(false);
    }
  };

  const next = async () => {
    if (step === 0) {
      const ok = await validateUsername(username);
      if (!ok) return;
    }
    if (step === 1 && !displayName.trim()) {
      toast.error("Display name required.");
      return;
    }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const finish = async () => {
    if (!userId) return;
    setLoading(true);
    const { error } = await supabase
      .from("profiles")
      .upsert(
        {
          id: userId,
          username,
          display_name: displayName.trim(),
          bio: bio.trim() || null,
          avatar_url: avatarUrl,
        } as any,
        { onConflict: "id" },
      );
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Profile ready. Let's swap.");
    navigate({ to: "/dashboard", replace: true });
  };

  const initials = (displayName || "F").slice(0, 2).toUpperCase();

  return (
    <div className="min-h-dvh bg-background flex flex-col">
      <main id="main" className="flex-1 mx-auto w-full max-w-xl px-4 sm:px-6 py-16 md:py-24">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-6">
            {STEPS.map((_, i) => (
              <div
                key={i}
                className={`h-1 flex-1 rounded-full transition-colors ${
                  i <= step ? "bg-violet" : "bg-hairline"
                }`}
              />
            ))}
          </div>
          <p className="text-xs uppercase tracking-widest text-muted-foreground">
            Step {step + 1} of {STEPS.length}
          </p>
          <h1 className="font-display text-4xl md:text-5xl mt-2">{STEPS[step]}</h1>
        </div>

        <div className="rounded-2xl border border-hairline bg-surface p-6 md:p-8">
          {step === 0 && (
            <div className="space-y-3">
              <Label htmlFor="username">Choose a username</Label>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">heysaas.app/@</span>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase().trim())}
                  placeholder="yourname"
                  autoFocus
                />
              </div>
              {usernameError && <p className="text-sm text-destructive">{usernameError}</p>}
              <p className="text-xs text-muted-foreground">
                This is your public founder URL. Choose wisely — you can change it later in settings.
              </p>
            </div>
          )}
          {step === 1 && (
            <div className="space-y-3">
              <Label htmlFor="display">Display name</Label>
              <Input
                id="display"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Jane Doe"
                autoFocus
              />
              <p className="text-xs text-muted-foreground">Shown on your listings and profile.</p>
            </div>
          )}
          {step === 2 && (
            <div className="space-y-3">
              <Label htmlFor="bio">One-line bio</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Building AI tools for solo founders. 3x shipped, 2x swapped."
                maxLength={160}
                rows={3}
                autoFocus
              />
              <p className="text-xs text-muted-foreground">
                {bio.length}/160 · Optional — you can skip.
              </p>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20 border border-hairline">
                  {avatarPreview ? <AvatarImage src={avatarPreview} /> : null}
                  <AvatarFallback className="bg-background text-lg">{initials}</AvatarFallback>
                </Avatar>
                <div>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => fileRef.current?.click()}
                    disabled={loading}
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="h-4 w-4 mr-2" />
                    )}
                    Upload avatar
                  </Button>
                  <p className="text-xs text-muted-foreground mt-2">PNG/JPG, up to 2MB. Optional.</p>
                </div>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && onAvatarUpload(e.target.files[0])}
                />
              </div>
            </div>
          )}

          <div className="flex justify-between items-center mt-8">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0 || loading}
            >
              <ArrowLeft className="h-4 w-4 mr-2" /> Back
            </Button>
            {step < STEPS.length - 1 ? (
              <Button type="button" onClick={next} disabled={loading || checkingUsername}>
                {checkingUsername ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : null}
                Continue <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button type="button" onClick={finish} disabled={loading}>
                {loading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Check className="h-4 w-4 mr-2" />
                )}
                Finish
              </Button>
            )}
          </div>
        </div>

        {step === 3 && (
          <button
            type="button"
            onClick={finish}
            className="mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors"
            disabled={loading}
          >
            Skip for now →
          </button>
        )}
      </main>
    </div>
  );
}
