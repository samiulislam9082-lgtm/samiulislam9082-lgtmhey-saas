import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { respondToSwap } from "@/lib/swaps.functions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight, MessageSquare, Inbox } from "lucide-react";
import { toast } from "sonner";
import { BackButton } from "@/components/site/BackButton";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";

export const Route = createFileRoute("/_authenticated/dashboard/swaps")({
  head: () => ({ meta: [{ title: "Swaps — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: SwapsInbox,
});

type Swap = {
  id: string;
  status: string;
  initiator_id: string;
  recipient_id: string;
  note: string | null;
  created_at: string;
  initiator_listing: { id: string; name: string; slug: string; logo_url: string | null } | null;
  recipient_listing: { id: string; name: string; slug: string; logo_url: string | null } | null;
};

const TABS = [
  { id: "incoming", label: "Incoming" },
  { id: "outgoing", label: "Outgoing" },
  { id: "active", label: "Active" },
  { id: "past", label: "Past" },
];

function SwapsInbox() {
  const [tab, setTab] = useState("incoming");
  const [userId, setUserId] = useState<string | null>(null);
  const [swaps, setSwaps] = useState<Swap[]>([]);
  const [loading, setLoading] = useState(true);
  const respond = useServerFn(respondToSwap);

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    setUserId(user.id);
    const { data } = await supabase
      .from("swap_requests")
      .select(`
        id, status, initiator_id, recipient_id, note, created_at,
        initiator_listing:saas_listings!swap_requests_initiator_listing_id_fkey ( id, name, slug, logo_url ),
        recipient_listing:saas_listings!swap_requests_recipient_listing_id_fkey ( id, name, slug, logo_url )
      `)
      .or(`initiator_id.eq.${user.id},recipient_id.eq.${user.id}`)
      .order("created_at", { ascending: false });
    setSwaps((data ?? []) as unknown as Swap[]);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  const filtered = swaps.filter((s) => {
    if (!userId) return false;
    const active = ["accepted", "matched_fee_pending", "fee_paid_one_side", "confirmed"].includes(s.status);
    const past = ["completed", "declined", "cancelled", "expired", "refunded", "disputed"].includes(s.status);
    if (tab === "incoming") return s.recipient_id === userId && s.status === "pending";
    if (tab === "outgoing") return s.initiator_id === userId && s.status === "pending";
    if (tab === "active") return active;
    if (tab === "past") return past;
    return true;
  });

  async function act(id: string, action: "accept" | "decline" | "cancel") {
    try {
      await respond({ data: { swap_id: id, action } });
      toast.success("Done");
      load();
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
  }

  const counts = {
    incoming: swaps.filter((s) => userId && s.recipient_id === userId && s.status === "pending").length,
    outgoing: swaps.filter((s) => userId && s.initiator_id === userId && s.status === "pending").length,
    active: swaps.filter((s) => ["accepted","matched_fee_pending","fee_paid_one_side","confirmed"].includes(s.status)).length,
    past: swaps.filter((s) => ["completed","declined","cancelled","expired","refunded","disputed"].includes(s.status)).length,
  } as Record<string, number>;

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
      <BackButton />
      <DashHero
              signature="swaps"
        eyebrow="Swap inbox"
        title="Swaps."
        description="Every proposal, live trade, and closed deal — all in one editorial view."
        meta={
          <div className="hs-seg">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`hs-seg-item inline-flex items-center gap-1.5 ${tab === t.id ? "active" : ""}`}
              >
                {t.label}
                {counts[t.id] > 0 && (
                  <span className={`text-[10px] px-1.5 py-[1px] rounded-full ${tab === t.id ? "bg-white/25 text-white" : "bg-foreground/10 text-muted-foreground"}`}>{counts[t.id]}</span>
                )}
              </button>
            ))}
          </div>
        }
      />
      <DashRibbon variant="swaps" />
            <DashBodyBlock variant="swaps" />


      <div className="mt-8 space-y-3 px-1">
        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : filtered.length === 0 ? (
          <div className="hs-empty">
            <div className="hs-empty-icon"><Inbox className="h-7 w-7" /></div>
            <p className="mt-5 font-display text-3xl">No swaps here.</p>
            <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">Explore listings and propose a swap — the room lights up as soon as the other founder replies.</p>
            <Link to="/explore"><Button className="mt-6 rounded-full bg-foreground text-background hover:opacity-90 px-6">Explore SaaS</Button></Link>
          </div>
        ) : (
          filtered.map((s) => {
            const isIncoming = userId === s.recipient_id;
            const mine = isIncoming ? s.recipient_listing : s.initiator_listing;
            const theirs = isIncoming ? s.initiator_listing : s.recipient_listing;
            return (
              <div key={s.id} className="hs-swap-row">
                <div className="flex items-center gap-4 flex-wrap">
                  <SwapSide label="You offer" listing={mine} />
                  <span className="hs-swap-arrow shrink-0"><ArrowRight className="h-4 w-4" /></span>
                  <SwapSide label={isIncoming ? "You get" : "They give"} listing={theirs} />
                  <div className="ml-auto flex items-center gap-2">
                    <StatusBadge status={s.status} />
                  </div>
                </div>
                {s.note && (
                  <p className="mt-4 text-sm text-muted-foreground border-l-2 border-hairline pl-3">"{s.note}"</p>
                )}
                <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <span>{new Date(s.created_at).toLocaleString()}</span>
                  <div className="ml-auto flex gap-2">
                    {s.status === "pending" && isIncoming && (
                      <>
                        <Button variant="outline" size="sm" className="rounded-full" onClick={() => act(s.id, "decline")}>Decline</Button>
                        <Button size="sm" className="rounded-full bg-foreground text-background hover:opacity-90" onClick={() => act(s.id, "accept")}>Accept</Button>
                      </>
                    )}
                    {s.status === "pending" && !isIncoming && (
                      <Button variant="outline" size="sm" className="rounded-full" onClick={() => act(s.id, "cancel")}>Cancel</Button>
                    )}
                    {(["matched_fee_pending", "fee_paid_one_side"].includes(s.status)) && (
                      <Link to="/dashboard/swaps/$id" params={{ id: s.id }}>
                        <Button size="sm" className="rounded-full bg-primary text-primary-foreground hover:opacity-90">Pay $19 safety fee</Button>
                      </Link>
                    )}
                    {(["confirmed", "completed", "disputed"].includes(s.status)) && (
                      <Link to="/dashboard/swaps/$id" params={{ id: s.id }}>
                        <Button size="sm" variant="outline" className="rounded-full">Open Swap Room</Button>
                      </Link>
                    )}
                    <Link to="/dashboard/messages"><Button size="sm" variant="ghost" className="rounded-full"><MessageSquare className="h-3.5 w-3.5 mr-1" />Chat</Button></Link>

                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function SwapSide({ label, listing }: { label: string; listing: Swap["initiator_listing"] }) {
  if (!listing) return <div className="text-sm text-muted-foreground">—</div>;
  const initial = listing.name.charAt(0).toUpperCase();
  return (
    <div className="min-w-0 flex items-center gap-3">
      <div className="hs-swap-logo shrink-0">
        {listing.logo_url ? (
          <img src={listing.logo_url} alt="" className="h-full w-full object-cover" />
        ) : (
          <span>{initial}</span>
        )}
      </div>
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">{label}</div>
        <Link to="/saas/$slug" params={{ slug: listing.slug }} className="mt-0.5 inline-flex items-center gap-1.5 hover:underline">
          <span className="font-medium truncate">{listing.name}</span>
        </Link>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: string }> = {
    pending: { label: "Pending", tone: "bg-muted text-muted-foreground" },
    accepted: { label: "Accepted", tone: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
    countered: { label: "Countered", tone: "bg-sky-500/15 text-sky-400 border-sky-500/30" },
    matched_fee_pending: { label: "Fee pending", tone: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
    fee_paid_one_side: { label: "One side paid", tone: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
    confirmed: { label: "Confirmed", tone: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30" },
    completed: { label: "Completed", tone: "bg-violet/20 text-violet border-violet/30" },
    declined: { label: "Declined", tone: "bg-muted text-muted-foreground" },
    cancelled: { label: "Cancelled", tone: "bg-muted text-muted-foreground" },
    expired: { label: "Expired", tone: "bg-muted text-muted-foreground" },
    refunded: { label: "Refunded", tone: "bg-muted text-muted-foreground" },
    disputed: { label: "Disputed", tone: "bg-destructive/15 text-destructive border-destructive/30" },
  };
  const c = map[status] ?? { label: status, tone: "" };
  return <Badge variant="outline" className={`rounded-full ${c.tone}`}>{c.label}</Badge>;
}
