import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsListMyListings, wsSetListingStatus, wsDeleteListing } from "@/lib/websites.functions";
import { WsSidebar } from "@/components/websites/WebSwapShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, ShieldCheck, ShieldAlert, Globe } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/_authenticated/websites/dashboard/listings/")({
  component: MyListingsPage,
});

function MyListingsPage() {
  const list = useServerFn(wsListMyListings);
  const setStatus = useServerFn(wsSetListingStatus);
  const del = useServerFn(wsDeleteListing);
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["ws", "my-listings"], queryFn: () => list() });

  async function publish(id: string) {
    try {
      await setStatus({ data: { id, status: "live" } });
      toast.success("Listing is live.");
      qc.invalidateQueries({ queryKey: ["ws", "my-listings"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to publish.");
    }
  }
  async function pause(id: string) {
    await setStatus({ data: { id, status: "paused" } });
    toast.success("Listing paused.");
    qc.invalidateQueries({ queryKey: ["ws", "my-listings"] });
  }
  async function remove(id: string) {
    if (!confirm("Delete this listing? This cannot be undone.")) return;
    await del({ data: { id } });
    toast.success("Listing deleted.");
    qc.invalidateQueries({ queryKey: ["ws", "my-listings"] });
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 flex gap-8">
      <WsSidebar />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-white">My listings</h1>
          <Link to="/websites/dashboard/listings/new" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 text-black font-medium hover:bg-emerald-400">
            <PlusCircle className="h-4 w-4" /> New
          </Link>
        </div>

        {isLoading ? (
          <div className="text-emerald-100/60">Loading…</div>
        ) : !data || data.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-emerald-900/60 p-12 text-center">
            <Globe className="h-8 w-8 text-emerald-500/50 mx-auto mb-3" />
            <p className="text-emerald-100/70">You haven't listed anything yet.</p>
            <Link to="/websites/dashboard/listings/new" className="mt-4 inline-block text-emerald-300 hover:text-emerald-200">
              Create your first listing →
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {data.map((l) => (
              <div key={l.id} className="rounded-2xl border border-emerald-900/60 bg-emerald-950/30 p-5 flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="h-20 w-32 rounded-lg bg-black/40 shrink-0 overflow-hidden flex items-center justify-center">
                  {l.screenshots?.[0] ? <img src={l.screenshots[0]} alt="" className="h-full w-full object-cover" /> : <Globe className="h-6 w-6 text-emerald-500/40" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-white font-semibold truncate">{l.title}</span>
                    <StatusBadge status={l.status} verified={l.ownership_verified} />
                  </div>
                  <div className="text-xs text-emerald-100/50 mt-1">{l.domain} · {l.views_count} views</div>
                </div>
                <div className="flex flex-wrap gap-2 sm:justify-end">
                  <Link
                    to="/websites/dashboard/listings/$id"
                    params={{ id: l.id }}
                    className="text-sm px-3 py-1.5 rounded-md border border-emerald-900/60 text-emerald-100 hover:bg-emerald-500/10"
                  >
                    Edit
                  </Link>
                  {l.status !== "live" && l.ownership_verified && (
                    <Button size="sm" className="bg-emerald-500 hover:bg-emerald-400 text-black" onClick={() => publish(l.id)}>
                      Publish
                    </Button>
                  )}
                  {l.status === "live" && (
                    <Button size="sm" variant="outline" className="border-emerald-900/60 bg-transparent text-emerald-100" onClick={() => pause(l.id)}>
                      Pause
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="text-red-400 hover:bg-red-500/10 hover:text-red-300" onClick={() => remove(l.id)}>
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status, verified }: { status: string; verified: boolean }) {
  const map: Record<string, { label: string; cls: string }> = {
    draft: { label: "Draft", cls: "bg-zinc-500/20 text-zinc-300 border-zinc-600/40" },
    pending_verification: { label: "Pending verification", cls: "bg-amber-500/20 text-amber-300 border-amber-500/30" },
    live: { label: "Live", cls: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" },
    paused: { label: "Paused", cls: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
    sold: { label: "Sold", cls: "bg-purple-500/20 text-purple-300 border-purple-500/30" },
    removed: { label: "Removed", cls: "bg-red-500/20 text-red-300 border-red-500/30" },
  };
  const m = map[status] ?? map.draft;
  return (
    <div className="flex items-center gap-1.5">
      <Badge className={`text-xs border ${m.cls}`}>{m.label}</Badge>
      {verified ? (
        <span className="inline-flex items-center gap-1 text-xs text-emerald-400"><ShieldCheck className="h-3 w-3" /> verified</span>
      ) : (
        <span className="inline-flex items-center gap-1 text-xs text-amber-400"><ShieldAlert className="h-3 w-3" /> unverified</span>
      )}
    </div>
  );
}
