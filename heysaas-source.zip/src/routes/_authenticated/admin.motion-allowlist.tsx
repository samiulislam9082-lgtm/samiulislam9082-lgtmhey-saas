import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import {
  scrollAllowlist,
  findScrollAllowlistMatch,
  type ScrollAllowlistKind,
} from "@/config/motion-scroll-allowlist";
import { BackButton } from "@/components/site/BackButton";
import { toast } from "sonner";
import {
  getCandidates,
  subscribeCandidates,
  removeCandidate,
  clearCandidates,
  type CandidateRule,
} from "@/lib/motion-candidates";
import {
  listSnapshots,
  saveSnapshot,
  deleteSnapshot,
  updateSnapshot,
  clearSnapshots,
  subscribeSnapshots,
  diffSnapshots,
  type ProbeSnapshot,
  type DiffSummary,
} from "@/lib/motion-probe-snapshots";
import { useServerFn } from "@tanstack/react-start";
import {
  listRemoteSnapshots,
  upsertRemoteSnapshot,
  deleteRemoteSnapshot,
  clearRemoteSnapshots,
} from "@/lib/motion-snapshots.functions";
import {
  parseAllowlistJson,
  diffAgainstConfig,
  attemptAutoFix,
  getSavedOverlay,
  saveOverlay,
  clearOverlay,
  toTsSnippet,
  listOverlayHistory,
  pushOverlayHistory,
  deleteOverlayHistoryEntry,
  clearOverlayHistory,
  type ImportDiff,
  type ImportIssue,
  type OverlayHistoryEntry,
} from "@/lib/motion-allowlist-import";

import {
  validateAllowlistRules,
  type AllowlistValidationIssue,
} from "@/lib/motion-allowlist-validate.functions";
import type { ScrollAllowlistRule } from "@/config/motion-scroll-allowlist";
import { AllowlistIssuesPanel } from "@/components/admin/AllowlistIssuesPanel";
import { DiffXlsxExportDialog } from "@/components/admin/DiffXlsxExportDialog";






export const Route = createFileRoute("/_authenticated/admin/motion-allowlist")({
  validateSearch: zodValidator(
    z.object({
      ruleId: fallback(z.string(), "").default(""),
      status: fallback(z.string(), "all").default("all"),
      jump: fallback(z.string(), "").default(""),
      sig: fallback(z.string(), "").default(""),
    }),
  ),
  head: () => ({
    meta: [
      { title: "Motion scroll allowlist · HeySaaS admin" },
      {
        name: "description",
        content:
          "Inspect sanctioned CSS scroll-behavior and scroll-snap rules and live-test selectors against the current page DOM.",
      },
    ],
  }),
  component: MotionAllowlistAdmin,
});

type Probe = { selector: string; kind: ScrollAllowlistKind };

function MotionAllowlistAdmin() {
  const [probe, setProbe] = useState<Probe>({
    selector: "[data-carousel]",
    kind: "scroll-snap",
  });
  const [result, setResult] = useState<string>("");
  const [pathname, setPathname] = useState<string>(
    typeof location !== "undefined" ? location.pathname : "/"
  );
  const [probeRows, setProbeRows] = useState<
    Array<{ index: number; tag: string; id: string; classes: string; ruleId: string | null; selector: string; kind: ScrollAllowlistKind }>
  >([]);
  const [probeMeta, setProbeMeta] = useState<{ total: number; ranAt: string } | null>(null);
  const [highlight, setHighlight] = useState(false);
  const [persistHighlights, setPersistHighlights] = useState(false);
  const [highlightThickness, setHighlightThickness] = useState<number>(() => {
    if (typeof window === "undefined") return 2;
    const raw = window.localStorage.getItem("mal:highlightThickness");
    const n = raw ? Number(raw) : NaN;
    return Number.isFinite(n) ? Math.max(1, Math.min(8, Math.round(n))) : 2;
  }); // px, 1..8
  const [highlightOpacity, setHighlightOpacity] = useState<number>(() => {
    if (typeof window === "undefined") return 1;
    const raw = window.localStorage.getItem("mal:highlightOpacity");
    const n = raw ? Number(raw) : NaN;
    return Number.isFinite(n) ? Math.max(0.2, Math.min(1, n)) : 1;
  }); // 0.2..1
  const highlightThicknessRef = useRef(highlightThickness);
  const highlightOpacityRef = useRef(highlightOpacity);
  highlightThicknessRef.current = highlightThickness;
  highlightOpacityRef.current = highlightOpacity;
  useEffect(() => {
    try {
      window.localStorage.setItem("mal:highlightThickness", String(highlightThickness));
    } catch {}
  }, [highlightThickness]);
  useEffect(() => {
    try {
      window.localStorage.setItem("mal:highlightOpacity", String(highlightOpacity));
    } catch {}
  }, [highlightOpacity]);

  // Tooltip appearance controls (persisted). Themes affect the highlight tooltip only.
  type TooltipTheme = "dark" | "light" | "highContrast";
  const [tooltipTheme, setTooltipTheme] = useState<TooltipTheme>(() => {
    if (typeof window === "undefined") return "dark";
    const raw = window.localStorage.getItem("mal:tooltipTheme");
    return raw === "light" || raw === "highContrast" ? raw : "dark";
  });
  const [tooltipFontSize, setTooltipFontSize] = useState<number>(() => {
    if (typeof window === "undefined") return 11;
    const raw = window.localStorage.getItem("mal:tooltipFontSize");
    const n = raw ? Number(raw) : NaN;
    return Number.isFinite(n) ? Math.max(9, Math.min(20, Math.round(n))) : 11;
  }); // px, 9..20
  const [tooltipMaxWidth, setTooltipMaxWidth] = useState<number>(() => {
    if (typeof window === "undefined") return 360;
    const raw = window.localStorage.getItem("mal:tooltipMaxWidth");
    const n = raw ? Number(raw) : NaN;
    return Number.isFinite(n) ? Math.max(200, Math.min(720, Math.round(n))) : 360;
  }); // px, 200..720
  const tooltipThemeRef = useRef(tooltipTheme);
  const tooltipFontSizeRef = useRef(tooltipFontSize);
  const tooltipMaxWidthRef = useRef(tooltipMaxWidth);
  tooltipThemeRef.current = tooltipTheme;
  tooltipFontSizeRef.current = tooltipFontSize;
  tooltipMaxWidthRef.current = tooltipMaxWidth;
  useEffect(() => {
    try { window.localStorage.setItem("mal:tooltipTheme", tooltipTheme); } catch {}
  }, [tooltipTheme]);
  useEffect(() => {
    try { window.localStorage.setItem("mal:tooltipFontSize", String(tooltipFontSize)); } catch {}
  }, [tooltipFontSize]);
  useEffect(() => {
    try { window.localStorage.setItem("mal:tooltipMaxWidth", String(tooltipMaxWidth)); } catch {}
  }, [tooltipMaxWidth]);


  // Per (pathname, kind) overrides for outline thickness/opacity.
  type OutlineOverride = { thickness?: number; opacity?: number };
  const [outlineOverrides, setOutlineOverrides] = useState<Record<string, OutlineOverride>>(() => {
    if (typeof window === "undefined") return {};
    try {
      const raw = window.localStorage.getItem("mal:outlineOverrides");
      return raw ? (JSON.parse(raw) as Record<string, OutlineOverride>) : {};
    } catch {
      return {};
    }
  });
  useEffect(() => {
    try {
      window.localStorage.setItem("mal:outlineOverrides", JSON.stringify(outlineOverrides));
    } catch {}
  }, [outlineOverrides]);
  const outlineOverridesRef = useRef(outlineOverrides);
  outlineOverridesRef.current = outlineOverrides;
  const overrideKey = (p: string, k: string) => `${p}::${k}`;

  const [candidates, setCandidates] = useState<CandidateRule[]>([]);
  useEffect(() => {
    setCandidates(getCandidates());
    return subscribeCandidates(() => setCandidates(getCandidates()));
  }, []);
  // Clean up highlights when leaving the page.
  useEffect(() => () => clearHighlights(), []);



  const [snapshots, setSnapshots] = useState<ProbeSnapshot[]>([]);
  const [compareId, setCompareId] = useState<string | "">("");
  const [syncing, setSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);
  const listRemote = useServerFn(listRemoteSnapshots);
  const upsertRemote = useServerFn(upsertRemoteSnapshot);
  const deleteRemote = useServerFn(deleteRemoteSnapshot);
  const clearRemote = useServerFn(clearRemoteSnapshots);

  useEffect(() => {
    setSnapshots(listSnapshots());
    return subscribeSnapshots(() => setSnapshots(listSnapshots()));
  }, []);

  const syncSnapshots = async (opts: { silent?: boolean } = {}) => {
    setSyncing(true);
    setSyncError(null);
    try {
      // Push any local-only snapshots first so this device's runs are backed up.
      const local = listSnapshots();
      for (const s of local) {
        try {
          await upsertRemote({
            data: {
              id: s.id,
              ranAt: s.ranAt,
              pathname: s.pathname,
              selector: s.selector,
              kind: s.kind,
              total: s.total,
              rows: s.rows,
            },
          });
        } catch {
          // continue; individual failures logged via toast in caller
        }
      }
      // Pull the merged remote set and merge into localStorage.
      const remote = (await listRemote()) as Array<
        ProbeSnapshot & { deviceLabel?: string | null; ownerId?: string }
      >;
      for (const r of remote) {
        saveSnapshot({
          ranAt: r.ranAt,
          pathname: r.pathname,
          selector: r.selector,
          kind: r.kind,
          total: r.total,
          rows: r.rows,
        });
      }
      setLastSyncedAt(new Date().toISOString());
      if (!opts.silent) toast.success(`Synced ${remote.length} snapshot(s)`);
    } catch (e: any) {
      const msg = e?.message ?? "Sync failed";
      setSyncError(msg);
      if (!opts.silent) toast.error(msg);
    } finally {
      setSyncing(false);
    }
  };

  // Auto-sync once on mount.
  useEffect(() => {
    void syncSnapshots({ silent: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);



  const currentSnapshot = snapshots[0] ?? null;
  const previousSnapshot = useMemo<ProbeSnapshot | null>(() => {
    if (!currentSnapshot) return null;
    if (compareId) return snapshots.find((s) => s.id === compareId) ?? null;
    return snapshots.find((s, i) => i > 0 && s.selector === currentSnapshot.selector && s.kind === currentSnapshot.kind) ?? null;
  }, [snapshots, compareId, currentSnapshot]);
  const diff = useMemo<DiffSummary | null>(
    () => (currentSnapshot ? diffSnapshots(previousSnapshot, currentSnapshot) : null),
    [previousSnapshot, currentSnapshot]
  );

  // ── Diff export filters ───────────────────────────────────────────────
  // Narrow the rows that end up in the JSON/CSV export by rule-id substring
  // (case-insensitive) and by sanctioned (rule matched) vs leak (no rule).
  // The on-screen diff table still shows the full set; only the export payload
  // is filtered so operators can share a scoped subset without re-running.
  const routeSearch = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const [diffFilterRuleId, setDiffFilterRuleId] = useState(routeSearch.ruleId ?? "");
  const initialStatus = (["all", "sanctioned", "leak"].includes(routeSearch.status ?? "all")
    ? routeSearch.status
    : "all") as "all" | "sanctioned" | "leak";
  const [diffFilterStatus, setDiffFilterStatus] = useState<"all" | "sanctioned" | "leak">(initialStatus);
  // Persist filters to the URL so shared/reloaded links preserve the export scope.
  useEffect(() => {
    const nextRuleId = diffFilterRuleId.trim();
    const nextStatus = diffFilterStatus;
    if ((routeSearch.ruleId ?? "") === nextRuleId && (routeSearch.status ?? "all") === nextStatus) return;
    navigate({
      search: (prev: { ruleId?: string; status?: string }) => ({
        ...prev,
        ruleId: nextRuleId || undefined,
        status: nextStatus === "all" ? undefined : nextStatus,
      }),
      replace: true,
    });
  }, [diffFilterRuleId, diffFilterStatus, navigate, routeSearch.ruleId, routeSearch.status]);

  // Deep-link: react to ?jump=added|changed by scrolling & flashing rows once
  // the diff table is present. Runs whenever the URL param changes so revisits
  // and shared URLs land on the intended row group.
  useEffect(() => {
    const jump = routeSearch.jump;
    if (!jump || !diff) return;
    if (jump !== "added" && jump !== "changed" && jump !== "removed") return;
    // give the table a tick to mount after diff arrives
    const t = window.setTimeout(() => jumpToDiffRow(jump), 60);
    return () => window.clearTimeout(t);
  }, [routeSearch.jump, diff]);

  // Deep-link: focus a specific diff row by signature. Moves keyboard focus
  // onto the row and announces its match context (status + before/after rule
  // ids) via a polite sr-only live region so screen readers explain what the
  // shared URL is highlighting.
  useEffect(() => {
    const sig = routeSearch.sig;
    if (!sig || !diff) return;

    // Locate the entry so the announcement can include human-readable context.
    const entry = diff.entries.find((x) => x.signature === sig);
    const beforeId = entry?.before?.ruleId ?? null;
    const afterId = entry?.after?.ruleId ?? null;
    const statusLabel =
      entry?.status === "added"
        ? "newly added match"
        : entry?.status === "removed"
          ? "removed match"
          : entry?.status === "changed"
            ? "rule-changed match"
            : "match";
    const message = entry
      ? `Focused ${statusLabel} for signature ${sig}. ${
          beforeId ? `Previously matched rule ${beforeId}.` : "No previous rule."
        } ${afterId ? `Now matches rule ${afterId}.` : "No current rule."}`
      : `Signature ${sig} not found in the current diff.`;

    // Ensure a single sr-only live region exists in the document.
    const LIVE_ID = "motion-allowlist-sig-live-region";
    let liveEl = document.getElementById(LIVE_ID);
    if (!liveEl) {
      liveEl = document.createElement("div");
      liveEl.id = LIVE_ID;
      liveEl.setAttribute("role", "status");
      liveEl.setAttribute("aria-live", "polite");
      liveEl.setAttribute("aria-atomic", "true");
      liveEl.className = "sr-only";
      document.body.appendChild(liveEl);
    }

    const t = window.setTimeout(() => {
      if (typeof document === "undefined") return;
      const safe = sig.replace(/[^a-z0-9_-]/gi, "_");
      const row = document.getElementById(`diff-row-${safe}`);
      if (!row) {
        // Entry exists in the diff but the DOM row is missing — active filters
        // are hiding it. Preserve the filters (per the shared URL intent) but
        // surface a one-click action to clear them.
        const hiddenByFilter =
          !!entry && (diffFilterRuleId.trim() !== "" || diffFilterStatus !== "all");
        const hint = hiddenByFilter
          ? " Row is hidden by active filters."
          : "";
        if (liveEl) liveEl.textContent = message + hint;
        if (hiddenByFilter) {
          toast.message("Focused row hidden by current filters", {
            description: "Filters from the shared URL are active. Clear them to reveal this row.",
            action: {
              label: "Clear filters",
              onClick: () => {
                setDiffFilterRuleId("");
                setDiffFilterStatus("all");
              },
            },
          });
        }
        return;
      }
      row.scrollIntoView({ behavior: "smooth", block: "center" });
      // Make the row programmatically focusable and label it for AT.
      if (!row.hasAttribute("tabindex")) row.setAttribute("tabindex", "-1");
      row.setAttribute("aria-label", message);
      try {
        (row as HTMLElement).focus({ preventScroll: true });
      } catch {
        (row as HTMLElement).focus();
      }
      row.style.transition = "box-shadow 400ms ease";
      const prev = row.style.boxShadow;
      row.style.boxShadow = "0 0 0 3px rgba(245, 158, 11, 0.7)";
      // Clear then set so the live region re-announces even if the message
      // text is identical to a prior focus event.
      if (liveEl) {
        liveEl.textContent = "";
        window.setTimeout(() => {
          if (liveEl) liveEl.textContent = message;
        }, 30);
      }
      window.setTimeout(() => {
        row.style.boxShadow = prev;
      }, 2400);
    }, 80);
    return () => window.clearTimeout(t);
  }, [routeSearch.sig, diff]);


  const filteredDiffChanged = useMemo(() => {
    if (!diff) return [] as DiffSummary["entries"];
    const q = diffFilterRuleId.trim().toLowerCase();
    return diff.entries.filter((e) => {
      if (e.status === "unchanged") return false;
      const ref = e.after ?? e.before;
      const ruleId = (e.after?.ruleId ?? e.before?.ruleId ?? "").toLowerCase();
      if (q && !ruleId.includes(q)) return false;
      if (diffFilterStatus !== "all") {
        const sanctioned = !!(e.after?.ruleId || e.before?.ruleId);
        if (diffFilterStatus === "sanctioned" && !sanctioned) return false;
        if (diffFilterStatus === "leak" && sanctioned) return false;
      }
      void ref;
      return true;
    });
  }, [diff, diffFilterRuleId, diffFilterStatus]);

  // Full diff (added + removed + rule-changed + unchanged) with the same
  // rule-id / status filters applied. Used by the "Export full" buttons so
  // consumers can audit every entry, not just deltas.
  const filteredDiffAll = useMemo(() => {
    if (!diff) return [] as DiffSummary["entries"];
    const q = diffFilterRuleId.trim().toLowerCase();
    return diff.entries.filter((e) => {
      const ruleId = (e.after?.ruleId ?? e.before?.ruleId ?? "").toLowerCase();
      if (q && !ruleId.includes(q)) return false;
      if (diffFilterStatus !== "all") {
        const sanctioned = !!(e.after?.ruleId || e.before?.ruleId);
        if (diffFilterStatus === "sanctioned" && !sanctioned) return false;
        if (diffFilterStatus === "leak" && sanctioned) return false;
      }
      return true;
    });
  }, [diff, diffFilterRuleId, diffFilterStatus]);



  // ── Selector syntax validation ────────────────────────────────────────
  function validateSelector(sel: string): string | null {
    const trimmed = sel.trim();
    if (!trimmed) return "Selector is required.";
    if (trimmed.length > 500) return "Selector is too long (max 500 chars).";
    if (typeof document === "undefined") return null;
    try {
      document.createDocumentFragment().querySelector(trimmed);
      return null;
    } catch (e) {
      return (e as Error).message || "Invalid CSS selector syntax.";
    }
  }
  const probeSelectorError = useMemo(
    () => validateSelector(probe.selector),
    [probe.selector]
  );
  // ── Import overlay (JSON upload → preview → save) ────────────────────
  const importInputRef = useRef<HTMLInputElement>(null);
  const [importFileName, setImportFileName] = useState<string | null>(null);
  const [importRawText, setImportRawText] = useState<string>("");
  const [importRules, setImportRules] = useState<ScrollAllowlistRule[] | null>(null);
  const [importDiff, setImportDiff] = useState<ImportDiff | null>(null);
  const [importIssues, setImportIssues] = useState<ImportIssue[]>([]);
  const [overlay, setOverlay] = useState<ScrollAllowlistRule[]>([]);
  const [overlayHistory, setOverlayHistory] = useState<OverlayHistoryEntry[]>(
    [],
  );
  const [serverIssues, setServerIssues] = useState<AllowlistValidationIssue[]>([]);
  const [validating, setValidating] = useState(false);
  const validateOnServer = useServerFn(validateAllowlistRules);
  useEffect(() => {
    setOverlay(getSavedOverlay());
    setOverlayHistory(listOverlayHistory());
  }, []);

  function recordOverlayHistory(
    rules: ScrollAllowlistRule[],
    note: string,
  ) {
    pushOverlayHistory(rules, note);
    setOverlayHistory(listOverlayHistory());
  }

  function applyHistoryEntry(entry: OverlayHistoryEntry) {
    // Snapshot the current overlay first so the revert itself is undoable,
    // then swap in the historical rules.
    recordOverlayHistory(
      overlay,
      `Auto-snapshot before revert to ${new Date(entry.savedAt).toLocaleString()}`,
    );
    const next = entry.rules.map((r) => ({ ...r }));
    saveOverlay(next);
    setOverlay(next);
    recordOverlayHistory(
      next,
      `Reverted to ${new Date(entry.savedAt).toLocaleString()} (${entry.ruleCount} rule${entry.ruleCount === 1 ? "" : "s"})`,
    );
    queueMicrotask(() => {
      if (probeMeta) runProbe({ selector: probe.selector, kind: probe.kind });
      if (highlight) applyHighlights(false);
    });
    toast.success(
      `Reverted overlay to snapshot from ${new Date(entry.savedAt).toLocaleString()}`,
    );
  }


  // Merge shipped rules with the local overlay (overlay wins by id). This is
  // the source of truth for the probe, highlight preview, selector tester,
  // and every "is this a sanctioned rule?" lookup on this page — so newly
  // imported rules take effect immediately without a page reload.
  const mergedRules = useMemo<ScrollAllowlistRule[]>(() => {
    const byId = new Map<string, ScrollAllowlistRule>();
    for (const r of scrollAllowlist) byId.set(r.id, r);
    for (const r of overlay) byId.set(r.id, r);
    return Array.from(byId.values());
  }, [overlay]);
  // Ref mirror so callbacks (highlight tooltip, probe re-runs) always read
  // the latest merged rules without needing to re-bind.
  const mergedRulesRef = useRef<ScrollAllowlistRule[]>(mergedRules);
  mergedRulesRef.current = mergedRules;

  const conflictingRuleId = useMemo(() => {
    const t = probe.selector.trim();
    if (!t) return null;
    return (
      mergedRules.find((r) => r.kind === probe.kind && r.selector === t)?.id ?? null
    );
  }, [probe.selector, probe.kind, mergedRules]);

  // Validate every merged rule's own selector — surfaces malformed rules by
  // id so the config author (or the current overlay) knows exactly which
  // one to fix. Re-runs when the overlay changes.
  const invalidRules = useMemo(() => {
    if (typeof document === "undefined") return [] as { id: string; error: string }[];
    return mergedRules
      .map((r) => {
        try {
          document.createDocumentFragment().querySelector(r.selector);
          return null;
        } catch (e) {
          return { id: r.id, error: (e as Error).message };
        }
      })
      .filter((x): x is { id: string; error: string } => x !== null);
  }, [mergedRules]);



  function resetImport() {
    setImportRules(null);
    setImportDiff(null);
    setImportIssues([]);
    setImportFileName(null);
    setImportRawText("");
    setServerIssues([]);
    if (importInputRef.current) importInputRef.current.value = "";
  }

  function reparseImportText(text: string) {
    const { rules, issues } = parseAllowlistJson(text);
    setImportIssues(issues);
    setServerIssues([]);
    if (rules.length === 0) {
      setImportRules(null);
      setImportDiff(null);
      return;
    }
    setImportRules(rules);
    setImportDiff(diffAgainstConfig(rules));
  }

  async function handleImportFile(file: File) {
    setImportFileName(file.name);
    const text = await file.text();
    setImportRawText(text);
    reparseImportText(text);
  }

  function autoFixImportIssue(iss: ImportIssue) {
    if (!importRawText) return { ok: false, description: "No raw file to patch" };
    const patched = attemptAutoFix(importRawText, iss);
    if (!patched) return { ok: false, description: "No safe auto-fix available for this issue" };
    setImportRawText(patched.text);
    reparseImportText(patched.text);
    return { ok: true, description: patched.description };
  }

  /**
   * Inline before/after preview for an import issue. Runs the same auto-fix
   * pipeline as `autoFixImportIssue` but does not mutate any state — it just
   * parses the current raw text and the patched text and returns the rule
   * object at the issue's index from both sides so the panel can render a
   * before/after diff and the operator can confirm before applying.
   */
  function previewImportFix(iss: ImportIssue) {
    if (!importRawText) return null;
    const patched = attemptAutoFix(importRawText, iss);
    if (!patched) return null;
    function pickRule(text: string): unknown {
      try {
        const parsed = JSON.parse(text);
        const arr = Array.isArray(parsed)
          ? parsed
          : Array.isArray((parsed as { rules?: unknown[] }).rules)
            ? (parsed as { rules: unknown[] }).rules
            : null;
        if (!arr) return parsed;
        if (iss.id) {
          const byId = arr.find(
            (r) => r && typeof r === "object" && (r as { id?: unknown }).id === iss.id,
          );
          if (byId) return byId;
        }
        return arr[iss.index] ?? null;
      } catch {
        return null;
      }
    }
    return {
      before: pickRule(importRawText),
      after: pickRule(patched.text),
      description: patched.description,
    };
  }

  function isImportIssueFixable(iss: ImportIssue) {
    const m = iss.message.toLowerCase();
    return (
      m.includes("missing string `id`") ||
      m.includes("duplicate id") ||
      m.includes("invalid `kind`") ||
      m.includes("missing string `reason`") ||
      m.includes("`routes` must be an array") ||
      m.includes("`requirehtmlattr.name` must be a string")
    );
  }


  async function confirmSaveOverlay() {
    if (!importRules) return;
    // Merge incoming rules over any prior overlay by id.
    const byId = new Map<string, ScrollAllowlistRule>();
    for (const r of overlay) byId.set(r.id, r);
    for (const r of importRules) byId.set(r.id, r);
    const next = Array.from(byId.values());

    // Server-side gate: parse every selector on the server and reject the save
    // if any rule is malformed, so invalid rules never reach the stored
    // overlay (and thus never reach the paste-ready TS snippet or any future
    // backend persistence).
    setValidating(true);
    setServerIssues([]);
    try {
      const result = await validateOnServer({ data: { rules: next } });
      if (!result.ok) {
        setServerIssues(result.issues);
        toast.error(
          `Save blocked — ${result.issues.length} server-side issue${
            result.issues.length === 1 ? "" : "s"
          }`,
          { description: "Fix the highlighted rules and try again." },
        );
        return;
      }
    } catch (e) {
      const msg = (e as Error).message || "Server validation failed";
      setServerIssues([{ index: -1, message: msg }]);
      toast.error("Server validation failed", { description: msg });
      return;
    } finally {
      setValidating(false);
    }

    saveOverlay(next);
    setOverlay(next);
    recordOverlayHistory(
      next,
      `Save to overlay from ${importFileName ?? "import"} — ${next.length} rule${next.length === 1 ? "" : "s"}`,
    );

    // Apply the newly imported rules to the probe + highlight preview
    // immediately — no page reload needed. The merged rules memo has already
    // recomputed via setOverlay, but the probe rows / highlight styles need
    // an explicit refresh to reflect the new ruleId assignments.
    // We defer to the next microtask so mergedRulesRef sees the new overlay.
    queueMicrotask(() => {
      if (probeMeta) runProbe({ selector: probe.selector, kind: probe.kind });
      if (highlight) applyHighlights(false);
    });
    toast.success(
      `Saved ${next.length} rule${next.length === 1 ? "" : "s"} to overlay — applied to probe & highlights`,
    );
    resetImport();
  }



  function copyMergedTsSnippet() {
    // Merge shipped config + overlay (overlay wins by id) for a paste-ready snippet.
    const byId = new Map<string, ScrollAllowlistRule>();
    for (const r of scrollAllowlist) byId.set(r.id, r);
    for (const r of overlay) byId.set(r.id, r);
    const snippet = toTsSnippet(Array.from(byId.values()));
    navigator.clipboard?.writeText(snippet).catch(() => {});
  }


  const rulesByKind = useMemo(() => {
    return scrollAllowlist.reduce<Record<string, typeof scrollAllowlist>>(
      (acc, r) => {
        (acc[r.kind] ||= []).push(r);
        return acc;
      },
      {}
    );
  }, []);

  type TooltipThemeSpec = {
    bg: string;
    fg: string;
    border: string;
    btnBg: string;
    btnFg: string;
    btnBorder: string;
    shadow: string;
  };
  function tooltipThemeSpec(theme: "dark" | "light" | "highContrast"): TooltipThemeSpec {
    if (theme === "light") {
      return {
        bg: "rgba(248,250,252,0.98)",
        fg: "rgb(15,23,42)",
        border: "rgba(15,23,42,0.15)",
        btnBg: "rgba(226,232,240,0.9)",
        btnFg: "rgb(15,23,42)",
        btnBorder: "rgba(15,23,42,0.2)",
        shadow: "0 6px 20px rgba(15,23,42,0.15)",
      };
    }
    if (theme === "highContrast") {
      return {
        bg: "rgb(0,0,0)",
        fg: "rgb(255,255,0)",
        border: "rgb(255,255,0)",
        btnBg: "rgb(0,0,0)",
        btnFg: "rgb(255,255,0)",
        btnBorder: "rgb(255,255,0)",
        shadow: "0 0 0 2px rgb(255,255,0)",
      };
    }
    return {
      bg: "rgba(15,23,42,0.95)",
      fg: "rgb(226,232,240)",
      border: "rgba(148,163,184,0.25)",
      btnBg: "rgba(30,41,59,0.9)",
      btnFg: "rgb(226,232,240)",
      btnBorder: "rgba(148,163,184,0.4)",
      shadow: "0 6px 20px rgba(0,0,0,0.35)",
    };
  }

  function applyTooltipAppearance(tip: HTMLDivElement) {
    const theme = tooltipThemeSpec(tooltipThemeRef.current);
    const fs = Math.max(9, Math.min(20, Math.round(tooltipFontSizeRef.current)));
    const mw = Math.max(200, Math.min(720, Math.round(tooltipMaxWidthRef.current)));
    tip.style.maxWidth = `${mw}px`;
    tip.style.background = theme.bg;
    tip.style.color = theme.fg;
    tip.style.border = `1px solid ${theme.border}`;
    tip.style.boxShadow = theme.shadow;
    tip.style.font = `500 ${fs}px/1.4 ui-sans-serif, system-ui, -apple-system, sans-serif`;
    tip.querySelectorAll<HTMLButtonElement>("button").forEach((b) => {
      b.style.background = theme.btnBg;
      b.style.color = theme.btnFg;
      b.style.border = `1px solid ${theme.btnBorder}`;
      b.style.font = `600 ${Math.max(9, fs - 1)}px/1.2 ui-sans-serif, system-ui, -apple-system, sans-serif`;
    });
  }

  function ensureHighlightTooltip(): HTMLDivElement {
    let tip = document.getElementById(
      "allowlist-highlight-tooltip"
    ) as HTMLDivElement | null;
    if (tip) return tip;
    tip = document.createElement("div");
    tip.id = "allowlist-highlight-tooltip";
    tip.setAttribute("data-allowlist-admin-ui", "");
    tip.setAttribute("role", "tooltip");
    tip.setAttribute("aria-live", "polite");
    tip.setAttribute("aria-atomic", "true");
    Object.assign(tip.style, {
      position: "fixed",
      zIndex: "2147483647",
      // The tip itself doesn't block hover, but its interactive children re-enable it.
      pointerEvents: "none",
      padding: "6px 8px",
      borderRadius: "6px",
      whiteSpace: "pre-wrap",
      wordBreak: "break-word",
      opacity: "0",
      transform: "translate(-9999px,-9999px)",
      transition: "opacity 80ms ease-out",
      display: "flex",
      flexDirection: "column",
      gap: "6px",
    } as CSSStyleDeclaration);

    const label = document.createElement("span");
    label.id = "allowlist-highlight-tooltip-label";
    label.setAttribute("data-allowlist-admin-ui", "");
    tip.appendChild(label);

    const actions = document.createElement("div");
    actions.setAttribute("data-allowlist-admin-ui", "");
    Object.assign(actions.style, {
      display: "flex",
      gap: "6px",
      pointerEvents: "auto",
    } as CSSStyleDeclaration);

    const mkBtn = (id: string, text: string, ariaLabel: string) => {
      const b = document.createElement("button");
      b.type = "button";
      b.id = id;
      b.textContent = text;
      b.setAttribute("data-allowlist-admin-ui", "");
      b.setAttribute("aria-label", ariaLabel);
      Object.assign(b.style, {
        pointerEvents: "auto",
        cursor: "pointer",
        padding: "3px 7px",
        borderRadius: "4px",
      } as CSSStyleDeclaration);
      return b;
    };
    actions.appendChild(mkBtn("allowlist-tip-copy-selector", "Copy selector", "Copy element CSS selector"));
    actions.appendChild(mkBtn("allowlist-tip-copy-xpath", "Copy XPath", "Copy element XPath"));
    actions.appendChild(mkBtn("allowlist-tip-copy-rule", "Copy rule id", "Copy matched rule id"));
    actions.appendChild(mkBtn("allowlist-tip-copy-both", "Copy both", "Copy CSS selector, XPath, and matched rule id"));

    tip.appendChild(actions);

    document.body.appendChild(tip);
    applyTooltipAppearance(tip);
    return tip;
  }

  // Live-update the tooltip when appearance controls change while it's mounted.
  useEffect(() => {
    if (typeof document === "undefined") return;
    const tip = document.getElementById(
      "allowlist-highlight-tooltip"
    ) as HTMLDivElement | null;
    if (tip) applyTooltipAppearance(tip);
  }, [tooltipTheme, tooltipFontSize, tooltipMaxWidth]);



  function positionHighlightTooltip(target: HTMLElement, tip: HTMLDivElement) {
    const rect = target.getBoundingClientRect();
    const tipRect = tip.getBoundingClientRect();
    const margin = 8;
    let top = rect.top - tipRect.height - margin;
    if (top < margin) top = rect.bottom + margin;
    let left = rect.left;
    if (left + tipRect.width > window.innerWidth - margin) {
      left = Math.max(margin, window.innerWidth - tipRect.width - margin);
    }
    if (left < margin) left = margin;
    tip.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
  }

  function countSelectorMatches(selector: string): number {
    if (!selector) return 0;
    try {
      return document.querySelectorAll(selector).length;
    } catch {
      return -1;
    }
  }

  function describeSelectorMatches(target: HTMLElement, selector: string): string {
    const n = countSelectorMatches(selector);
    if (n < 0) return "selector: invalid syntax";
    if (n === 0) return "selector matches 0 elements";
    if (n === 1) return "selector matches 1 element ✓ (only this one)";
    const hits = Array.from(document.querySelectorAll(selector));
    const includesTarget = hits.includes(target);
    return `selector matches ${n} elements${includesTarget ? " (incl. this one)" : " (⚠ not this one)"}`;
  }

  function highlightTooltipText(el: HTMLElement): string {
    const tag = el.tagName.toLowerCase();
    const id = el.id ? `#${el.id}` : "";
    const classes = el.classList.length
      ? "." + Array.from(el.classList).slice(0, 6).join(".")
      : "";
    const ruleId = el.dataset.allowlistRuleId || "no rule";
    const status = el.dataset.allowlistHighlight === "allow" ? "sanctioned" : "leak";
    const selector = buildCssSelectorFor(el);
    return `<${tag}${id}${classes}>\nrule: ${ruleId}  (${status})\n${describeSelectorMatches(el, selector)}`;
  }


  // Build a stable-ish CSS selector for an element by walking up ancestors,
  // preferring #id, then tag + up to 3 stable classes, then :nth-of-type()
  // fallback for uniqueness. Caps at 5 levels or when the selector is unique.
  function buildCssSelectorFor(el: HTMLElement): string {
    const isStableClass = (c: string) =>
      !!c && !/^\d/.test(c) && !/[:[\]/\\]/.test(c) && c.length <= 40;
    const parts: string[] = [];
    let node: HTMLElement | null = el;
    let depth = 0;
    while (node && node.nodeType === 1 && depth < 5) {
      if (node.id) {
        parts.unshift(`#${CSS.escape(node.id)}`);
        break;
      }
      const tag = node.tagName.toLowerCase();
      const classes = Array.from(node.classList).filter(isStableClass).slice(0, 3);
      let seg = tag + classes.map((c) => `.${CSS.escape(c)}`).join("");
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(
          (c) => c.tagName === node!.tagName
        );
        if (siblings.length > 1) {
          seg += `:nth-of-type(${siblings.indexOf(node) + 1})`;
        }
      }
      parts.unshift(seg);
      try {
        const candidate = parts.join(" > ");
        if (document.querySelectorAll(candidate).length === 1) break;
      } catch {
        // ignore, keep walking
      }
      node = node.parentElement;
      depth++;
    }
    return parts.join(" > ");
  }

  // Build an absolute XPath for an element by walking to <html>, indexing each
  // step by its position among same-tag siblings. Prefers @id shortcuts when
  // an ancestor has a non-numeric id that resolves uniquely.
  function buildXPathFor(el: HTMLElement): string {
    if (!el || el.nodeType !== 1) return "";
    if (el === document.documentElement) return "/html";
    const segments: string[] = [];
    let node: Element | null = el;
    while (node && node.nodeType === 1 && node !== document.documentElement) {
      const tag = node.tagName.toLowerCase();
      if (node.id && !/^\d/.test(node.id)) {
        const safeId = node.id.replace(/'/g, "\\'");
        const shortcut = `//${tag}[@id='${safeId}']`;
        try {
          const res = document.evaluate(
            shortcut,
            document,
            null,
            XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
            null,
          );
          if (res.snapshotLength === 1) {
            segments.unshift(shortcut.replace(/^\/\//, ""));
            return "//" + segments.join("/");
          }
        } catch {
          // fall through to positional segment
        }
      }
      const parent: Element | null = node.parentElement;
      let index = 1;
      if (parent) {
        const sameTag = Array.from(parent.children).filter(
          (c) => c.tagName === node!.tagName,
        );
        if (sameTag.length > 1) index = sameTag.indexOf(node) + 1;
        segments.unshift(sameTag.length > 1 ? `${tag}[${index}]` : tag);
      } else {
        segments.unshift(tag);
      }
      node = parent;
    }
    return "/html/" + segments.join("/");
  }

  function countXPathMatches(xpath: string): number {
    if (!xpath) return 0;
    try {
      const res = document.evaluate(
        xpath,
        document,
        null,
        XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
        null,
      );
      return res.snapshotLength;
    } catch {
      return -1;
    }
  }

  function describeXPathMatches(target: HTMLElement, xpath: string): string {
    const n = countXPathMatches(xpath);
    if (n < 0) return "xpath: invalid";
    if (n === 0) return "xpath matches 0 elements";
    if (n === 1) return "xpath matches 1 element ✓ (only this one)";
    let includesTarget = false;
    try {
      const res = document.evaluate(
        xpath,
        document,
        null,
        XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
        null,
      );
      for (let i = 0; i < res.snapshotLength; i++) {
        if (res.snapshotItem(i) === target) {
          includesTarget = true;
          break;
        }
      }
    } catch {
      // ignore
    }
    return `xpath matches ${n} elements${includesTarget ? " (incl. this one)" : " (⚠ not this one)"}`;
  }



  const highlightHandlersRef = useRef<{
    over: (e: Event) => void;
    out: (e: Event) => void;
    move: () => void;
    click: (e: Event) => void;
    focusIn: (e: Event) => void;
    focusOut: (e: Event) => void;
    keydown: (e: KeyboardEvent) => void;
  } | null>(null);

  function setTooltipLabel(tip: HTMLDivElement, text: string) {
    const label = tip.querySelector<HTMLSpanElement>(
      "#allowlist-highlight-tooltip-label"
    );
    if (label) label.textContent = text;
    else tip.textContent = text;
  }

  function showHighlightTooltipFor(target: HTMLElement, tip: HTMLDivElement) {
    setTooltipLabel(
      tip,
      highlightTooltipText(target) + "\nEnter to copy selector · Esc to dismiss"
    );
    tip.style.opacity = "1";
    // Associate the tooltip with the currently focused/hovered element for AT.
    target.setAttribute("aria-describedby", "allowlist-highlight-tooltip");
    positionHighlightTooltip(target, tip);
  }

  function hideHighlightTooltip(target: HTMLElement | null, tip: HTMLDivElement) {
    tip.style.opacity = "0";
    tip.style.transform = "translate(-9999px,-9999px)";
    if (target && target.getAttribute("aria-describedby") === "allowlist-highlight-tooltip") {
      target.removeAttribute("aria-describedby");
    }
  }

  function attachHighlightTooltip() {
    if (typeof document === "undefined" || highlightHandlersRef.current) return;
    const tip = ensureHighlightTooltip();
    let current: HTMLElement | null = null;
    const isInsideTip = (n: Node | null): boolean => !!n && !!tip && tip.contains(n);
    const findHighlighted = (e: Event): HTMLElement | null => {
      const path = (e as MouseEvent).composedPath?.() ?? [];
      return (path.find(
        (n) => n instanceof HTMLElement && (n as HTMLElement).dataset.allowlistHighlight
      ) as HTMLElement | undefined) ?? null;
    };
    const flashCopied = (target: HTMLElement, msg: string, payload: string) => {
      setTooltipLabel(tip, `${msg}\n${payload}`);
      tip.style.opacity = "1";
      target.setAttribute("aria-describedby", "allowlist-highlight-tooltip");
      positionHighlightTooltip(target, tip);
      const prev = target.style.filter;
      target.style.filter = "brightness(1.25)";
      window.setTimeout(() => {
        target.style.filter = prev;
      }, 250);
    };
    const legacyCopy = (text: string): boolean => {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        // Keep it off-screen and non-interactive while remaining selectable.
        ta.setAttribute("readonly", "");
        ta.setAttribute("aria-hidden", "true");
        ta.style.position = "fixed";
        ta.style.top = "0";
        ta.style.left = "0";
        ta.style.width = "1px";
        ta.style.height = "1px";
        ta.style.padding = "0";
        ta.style.border = "0";
        ta.style.opacity = "0";
        ta.style.pointerEvents = "none";
        document.body.appendChild(ta);
        const activeEl = document.activeElement as HTMLElement | null;
        ta.select();
        ta.setSelectionRange(0, text.length);
        const ok = document.execCommand("copy");
        ta.remove();
        activeEl?.focus?.();
        return ok;
      } catch {
        return false;
      }
    };
    const writeClipboard = async (text: string, label: string) => {
      const secureAsync =
        typeof navigator !== "undefined" &&
        !!navigator.clipboard &&
        typeof navigator.clipboard.writeText === "function" &&
        (typeof window === "undefined" || window.isSecureContext !== false);
      if (secureAsync) {
        try {
          await navigator.clipboard.writeText(text);
          toast.success(`${label} copied`, { description: text });
          return;
        } catch {
          // fall through to legacy fallback
        }
      }
      if (legacyCopy(text)) {
        toast.success(`${label} copied`, {
          description: `${text}\n(fallback: textarea)`,
        });
        return;
      }
      toast.error(`Copy failed`, { description: text });
    };

    const copySelectorFor = (target: HTMLElement) => {
      const selector = buildCssSelectorFor(target);
      const info = describeSelectorMatches(target, selector);
      void writeClipboard(selector, "Selector");
      flashCopied(target, "copied selector ✓", `${selector}\n${info}`);
    };
    const copyXPathFor = (target: HTMLElement) => {
      const xpath = buildXPathFor(target);
      const info = describeXPathMatches(target, xpath);
      void writeClipboard(xpath, "XPath");
      flashCopied(target, "copied xpath ✓", `${xpath}\n${info}`);
    };
    const copyRuleFor = (target: HTMLElement) => {
      const ruleId = target.dataset.allowlistRuleId || "";
      if (!ruleId) {
        toast.error("No matched rule", { description: "This element is a leak (no allowlist rule)." });
        return;
      }
      void writeClipboard(ruleId, "Rule id");
      flashCopied(target, "copied rule id ✓", ruleId);
    };
    const copyBothFor = (target: HTMLElement) => {
      const selector = buildCssSelectorFor(target);
      const xpath = buildXPathFor(target);
      const ruleId = target.dataset.allowlistRuleId || "(no rule)";
      const info = describeSelectorMatches(target, selector);
      const xinfo = describeXPathMatches(target, xpath);
      const payload = `selector: ${selector}\nxpath: ${xpath}\nrule: ${ruleId}\n${info}\n${xinfo}`;
      void writeClipboard(payload, "Selector + XPath + rule id");
      flashCopied(target, "copied selector + xpath + rule ✓", payload);
    };


    const over = (e: Event) => {
      const target = findHighlighted(e);
      if (!target || target === current) return;
      if (current) hideHighlightTooltip(current, tip);
      current = target;
      showHighlightTooltipFor(target, tip);
    };
    const out = (e: Event) => {
      const to = (e as MouseEvent).relatedTarget as Node | null;
      // Keep the tip open while the pointer is over the tip (its buttons are interactive).
      if (isInsideTip(to)) return;
      if (current && (!to || !current.contains(to))) {
        hideHighlightTooltip(current, tip);
        current = null;
      }
    };
    const move = () => {
      if (current) positionHighlightTooltip(current, tip);
    };
    const click = (e: Event) => {
      const t = e.target as HTMLElement | null;
      // Tooltip action buttons — copy variants for the currently anchored element.
      if (t && isInsideTip(t) && t.tagName === "BUTTON" && current) {
        e.preventDefault();
        e.stopPropagation();
        if (t.id === "allowlist-tip-copy-selector") copySelectorFor(current);
        else if (t.id === "allowlist-tip-copy-xpath") copyXPathFor(current);
        else if (t.id === "allowlist-tip-copy-rule") copyRuleFor(current);
        else if (t.id === "allowlist-tip-copy-both") copyBothFor(current);

        return;
      }
      const target = findHighlighted(e);
      if (!target) return;
      e.preventDefault();
      e.stopPropagation();
      current = target;
      copySelectorFor(target);
    };
    const focusIn = (e: Event) => {
      const t = e.target;
      // Focusing a tooltip button shouldn't hide the tip.
      if (t instanceof HTMLElement && isInsideTip(t)) return;
      if (!(t instanceof HTMLElement) || !t.dataset.allowlistHighlight) return;
      if (current && current !== t) hideHighlightTooltip(current, tip);
      current = t;
      showHighlightTooltipFor(t, tip);
    };
    const focusOut = (e: Event) => {
      const t = e.target;
      if (!(t instanceof HTMLElement) || t !== current) return;
      // If focus moves into the tooltip's copy buttons, keep the tip anchored.
      const to = (e as FocusEvent).relatedTarget as Node | null;
      if (isInsideTip(to)) return;
      hideHighlightTooltip(current, tip);
      current = null;
    };
    const keydown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && current) {
        hideHighlightTooltip(current, tip);
        (current as HTMLElement).blur?.();
        current = null;
        return;
      }
      // Shortcut: press "C" (or "X" for XPath) while hovering/focusing a
      // highlighted element to copy without needing to click a tooltip button.
      // Ignore while typing in an input/textarea/contenteditable field, and
      // ignore modified chords so browser shortcuts (Ctrl/Cmd+C) still work.
      const key = e.key.toLowerCase();
      if ((key === "c" || key === "x") && !e.ctrlKey && !e.metaKey && !e.altKey) {
        const ae = document.activeElement as HTMLElement | null;
        const isTyping =
          !!ae &&
          (ae.tagName === "INPUT" ||
            ae.tagName === "TEXTAREA" ||
            ae.isContentEditable);
        // Prefer the currently anchored (hovered/focused) highlight.
        const target =
          current ||
          (e.target instanceof HTMLElement && e.target.dataset.allowlistHighlight
            ? (e.target as HTMLElement)
            : null);
        if (target && !isTyping) {
          e.preventDefault();
          if (key === "c") copySelectorFor(target);
          else copyXPathFor(target);
          return;
        }
      }
      const t = e.target;
      if (!(t instanceof HTMLElement) || !t.dataset.allowlistHighlight) return;
      if ((e.key === "Enter" || e.key === " ") && t === current) {
        e.preventDefault();
        copySelectorFor(t);
      }
    };

    document.addEventListener("mouseover", over, true);
    document.addEventListener("mouseout", out, true);
    document.addEventListener("click", click, true);
    document.addEventListener("focusin", focusIn, true);
    document.addEventListener("focusout", focusOut, true);
    document.addEventListener("keydown", keydown, true);
    window.addEventListener("scroll", move, true);
    window.addEventListener("resize", move);
    highlightHandlersRef.current = { over, out, move, click, focusIn, focusOut, keydown };
  }


  function detachHighlightTooltip() {
    if (typeof document === "undefined") return;
    const h = highlightHandlersRef.current;
    if (h) {
      document.removeEventListener("mouseover", h.over, true);
      document.removeEventListener("mouseout", h.out, true);
      document.removeEventListener("click", h.click, true);
      document.removeEventListener("focusin", h.focusIn, true);
      document.removeEventListener("focusout", h.focusOut, true);
      document.removeEventListener("keydown", h.keydown, true);
      window.removeEventListener("scroll", h.move, true);
      window.removeEventListener("resize", h.move);
      highlightHandlersRef.current = null;
    }
    const tip = document.getElementById("allowlist-highlight-tooltip");
    if (tip) tip.remove();
  }


  function clearHighlights() {
    if (typeof document === "undefined") return;
    document
      .querySelectorAll<HTMLElement>("[data-allowlist-highlight]")
      .forEach((el) => {
        el.style.outline = el.dataset.allowlistPrevOutline ?? "";
        el.style.outlineOffset = el.dataset.allowlistPrevOutlineOffset ?? "";
        el.style.boxShadow = el.dataset.allowlistPrevBoxShadow ?? "";
        // Restore tabindex/aria-label if we injected them for keyboard/SR support.
        if (el.dataset.allowlistPrevTabindex === "__none__") {
          el.removeAttribute("tabindex");
        } else if (el.dataset.allowlistPrevTabindex != null) {
          el.setAttribute("tabindex", el.dataset.allowlistPrevTabindex);
        }
        if (el.dataset.allowlistPrevAriaLabel === "__none__") {
          el.removeAttribute("aria-label");
        } else if (el.dataset.allowlistPrevAriaLabel != null) {
          el.setAttribute("aria-label", el.dataset.allowlistPrevAriaLabel);
        }
        if (el.getAttribute("aria-describedby") === "allowlist-highlight-tooltip") {
          el.removeAttribute("aria-describedby");
        }
        delete el.dataset.allowlistPrevOutline;
        delete el.dataset.allowlistPrevOutlineOffset;
        delete el.dataset.allowlistPrevBoxShadow;
        delete el.dataset.allowlistPrevTabindex;
        delete el.dataset.allowlistPrevAriaLabel;
        delete el.dataset.allowlistHighlight;
        delete el.dataset.allowlistRuleId;
      });
    detachHighlightTooltip();
  }

  function applyHighlights(additive = false) {
    if (!additive) clearHighlights();
    let els: HTMLElement[] = [];
    try {
      els = Array.from(document.querySelectorAll<HTMLElement>(probe.selector));
    } catch {
      return;
    }
    const ovr = outlineOverridesRef.current[`${pathname}::${probe.kind}`] ?? {};
    const thickness = Math.max(
      1,
      Math.min(8, Math.round(ovr.thickness ?? highlightThicknessRef.current))
    );
    const alpha = Math.max(0.1, Math.min(1, ovr.opacity ?? highlightOpacityRef.current));
    const glowAlpha = Math.max(0.05, alpha * 0.2);

    for (const el of els) {
      // Skip elements that live inside the admin probe UI itself.
      if (el.closest("[data-allowlist-admin-ui]")) continue;
      // In additive mode, don't clobber styles saved by a prior probe run.
      if (additive && el.dataset.allowlistHighlight) continue;
      const match = findScrollAllowlistMatch(el, probe.kind, pathname, mergedRulesRef.current);
      const rgb = match ? "16,185,129" : "244,63,94"; // emerald / rose
      el.dataset.allowlistPrevOutline = el.style.outline;
      el.dataset.allowlistPrevOutlineOffset = el.style.outlineOffset;
      el.dataset.allowlistPrevBoxShadow = el.style.boxShadow;
      el.dataset.allowlistHighlight = match ? "allow" : "leak";
      if (match?.rule.id) el.dataset.allowlistRuleId = match.rule.id;
      // Make the highlighted element keyboard-focusable so the tooltip can
      // appear on focus, and expose a concise accessible name for AT users.
      const existingTabindex = el.getAttribute("tabindex");
      el.dataset.allowlistPrevTabindex = existingTabindex ?? "__none__";
      if (existingTabindex == null) el.setAttribute("tabindex", "0");
      const existingAria = el.getAttribute("aria-label");
      el.dataset.allowlistPrevAriaLabel = existingAria ?? "__none__";
      const srLabel = `Motion allowlist ${match ? "sanctioned" : "leak"} match${
        match?.rule.id ? `, rule ${match.rule.id}` : ""
      }`;
      if (existingAria == null) el.setAttribute("aria-label", srLabel);
      el.style.outline = `${thickness}px dashed rgba(${rgb}, ${alpha})`;
      el.style.outlineOffset = "2px";
      el.style.boxShadow = `0 0 0 ${thickness * 2}px rgba(${rgb}, ${glowAlpha})`;
    }
    if (els.length || additive) attachHighlightTooltip();
  }

  function jumpToDiffRow(status: "added" | "changed" | "removed") {
    if (typeof document === "undefined") return;
    const container = document.getElementById("motion-diff-table");
    if (!container) return;
    container.scrollIntoView({ behavior: "smooth", block: "start" });
    const rows = container.querySelectorAll<HTMLTableRowElement>(
      `tr[data-diff-status="${status}"]`
    );
    if (!rows.length) return;
    const first = rows[0];
    first.scrollIntoView({ behavior: "smooth", block: "center" });
    rows.forEach((r) => {
      r.style.boxShadow = "inset 3px 0 0 0 rgb(245 158 11)";
      r.style.background = "rgba(245, 158, 11, 0.12)";
    });
    window.setTimeout(() => {
      rows.forEach((r) => {
        r.style.background = "";
        // keep the left border marker so the user can still spot them
      });
    }, 2200);
  }

  function jumpToPreviewRule(id: string | undefined | null) {
    if (typeof document === "undefined" || !id) return;
    const el = document.getElementById(`preview-rule-${id}`);
    if (!el) {
      toast.error(`Rule "${id}" is not in the current preview`);
      return;
    }
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    const prevShadow = el.style.boxShadow;
    const prevBg = el.style.background;
    el.style.boxShadow = "inset 3px 0 0 0 rgb(244 63 94)";
    el.style.background = "rgba(244, 63, 94, 0.12)";
    window.setTimeout(() => {
      el.style.boxShadow = prevShadow;
      el.style.background = prevBg;
    }, 2200);
  }



  /**
   * Compute diff(currentSnapshot vs baseline) and download it as JSON or CSV
   * so operators can share the exact regression detected by a specific
   * stored snapshot without recomputing.
   */
  function exportSnapshotDiff(baseline: ProbeSnapshot, format: "json" | "csv") {
    if (!currentSnapshot) {
      toast.error("No current snapshot to diff");
      return;
    }
    const summary = diffSnapshots(baseline, currentSnapshot);
    const meta = {
      schemaVersion: 1,
      exportKind: "motion-snapshot-diff",
      exportedAt: new Date().toISOString(),
      baseline: {
        id: baseline.id,
        ranAt: baseline.ranAt,
        pathname: baseline.pathname,
        selector: baseline.selector,
        kind: baseline.kind,
        total: baseline.total,
      },
      current: {
        id: currentSnapshot.id,
        ranAt: currentSnapshot.ranAt,
        pathname: currentSnapshot.pathname,
        selector: currentSnapshot.selector,
        kind: currentSnapshot.kind,
        total: currentSnapshot.total,
      },
      counts: {
        added: summary.added,
        removed: summary.removed,
        changed: summary.changed,
        unchanged: summary.unchanged,
      },
    };
    const safeId = baseline.id.replace(/[^a-z0-9_-]+/gi, "_").slice(0, 60);
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    if (format === "json") {
      const payload = { ...meta, entries: summary.entries };
      downloadTesterFile(
        `motion-snapshot-diff_${safeId}_${stamp}.json`,
        "application/json",
        JSON.stringify(payload, null, 2),
      );
    } else {
      const rows: Array<Array<string | number>> = [
        ["signature", "status", "beforeRuleId", "afterRuleId", "tag", "id", "classes"],
      ];
      for (const e of summary.entries) {
        const ref = e.after ?? e.before;
        rows.push([
          e.signature,
          e.status,
          e.before?.ruleId ?? "",
          e.after?.ruleId ?? "",
          ref?.tag ?? "",
          ref?.id ?? "",
          ref?.classes ?? "",
        ]);
      }
      const header = [
        `# motion-snapshot-diff`,
        `# schemaVersion=${meta.schemaVersion}`,
        `# exportedAt=${meta.exportedAt}`,
        `# baseline=${baseline.id}`,
        `# baselineRanAt=${baseline.ranAt}`,
        `# currentRanAt=${currentSnapshot.ranAt}`,
        `# added=${summary.added}`,
        `# removed=${summary.removed}`,
        `# changed=${summary.changed}`,
        `# unchanged=${summary.unchanged}`,
      ].join("\n");
      const csv =
        header +
        "\n" +
        rows
          .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
          .join("\n");
      downloadTesterFile(`motion-snapshot-diff_${safeId}_${stamp}.csv`, "text/csv", csv);
    }
    toast.success(
      `Exported diff (${summary.added} added, ${summary.changed} changed, ${summary.removed} removed)`,
    );
  }

  function runProbe(override?: { selector: string; kind: ScrollAllowlistKind }) {

    const sel = override?.selector ?? probe.selector;
    const knd = override?.kind ?? probe.kind;
    if (override) setProbe({ selector: sel, kind: knd });
    const selectorError = override
      ? validateSelector(sel)
      : probeSelectorError;
    if (selectorError) {
      setProbeRows([]);
      setProbeMeta(null);
      setResult(
        `Malformed selector — ${selectorError}\n\nExpected a valid CSS selector, e.g.\n  [data-carousel]\n  .snap-x > *\n  #hero .marquee${
          conflictingRuleId ? `\n\nRule id being tested: ${conflictingRuleId}` : ""
        }`
      );
      return;
    }

    try {
      const els = Array.from(
        document.querySelectorAll<HTMLElement>(sel)
      );
      const rows = els.map((el, i) => {
        const m = findScrollAllowlistMatch(el, knd, pathname, mergedRulesRef.current);
        return {
          index: i,
          tag: el.tagName.toLowerCase(),
          id: el.id ?? "",
          classes: (el.className && typeof el.className === "string" ? el.className : "").trim(),
          ruleId: m?.rule.id ?? null,
          selector: sel,
          kind: knd,
        };
      });
      setProbeRows(rows);
      const ranAt = new Date().toISOString();
      setProbeMeta({ total: els.length, ranAt });
      saveSnapshot({
        ranAt,
        pathname,
        selector: sel,
        kind: knd,
        total: els.length,
        rows,
      });
      // Mirror to backend so it's visible across devices.
      void upsertRemote({
        data: {
          id: ranAt,
          ranAt,
          pathname,
          selector: sel,
          kind: knd,
          total: els.length,
          rows,
        },
      }).catch((e) => {
        setSyncError(e?.message ?? "Remote save failed");
      });
      setCompareId("");
      const preview = rows
        .slice(0, 20)
        .map((r) => {
          const tag = `<${r.tag}${r.id ? "#" + r.id : ""}>`;
          return `${tag}  ${r.ruleId ? `→ allow:${r.ruleId}` : "→ no allowlist match"}`;
        })
        .join("\n");
      setResult(
        `Selector matched ${els.length} element(s) in current DOM${
          els.length > 20 ? " (showing first 20)" : ""
        }\n\n${preview || "(no elements found)"}`
      );
      if (highlight) applyHighlights(persistHighlights);
    } catch (e) {
      setProbeRows([]);
      setProbeMeta(null);
      setResult(`Error: ${(e as Error).message}`);
    }
  }


  // Local alias so all closures inside AdminMotionAllowlist keep using the
  // same download entry point regardless of where the helper is defined.
  const downloadTesterFile = downloadBlobFile;


  // --- Export filters -------------------------------------------------------
  type ExportMode = "both" | "sanctioned" | "leaks";
  const [exportMode, setExportMode] = useState<ExportMode>("both");
  const [routeFilter, setRouteFilter] = useState<Set<string>>(new Set());
  const [kindFilter, setKindFilter] = useState<Set<ScrollAllowlistKind>>(new Set());
  const [useSnapshots, setUseSnapshots] = useState(false);

  // Re-import previously exported probe JSON/CSV — metadata + row preview only.
  type ImportedProbePair = {
    ruleId: string; // "" when unmatched (leak)
    selector: string;
    kind: string;
    count: number;
  };
  // Expected values the importer knows how to read. Bump when the exporter
  // format changes so incompatible imports produce a clear warning.
  const EXPECTED_PROBE_EXPORT_KIND = "motion-allowlist-probe";
  const EXPECTED_PROBE_SCHEMA_VERSION = 1;
  const SUPPORTED_PROBE_SCHEMA_VERSIONS: readonly number[] = [1];
  type ImportCompatSeverity = "ok" | "warning" | "error";
  type ImportCompatIssue = {
    field: "schemaVersion" | "exportKind" | "exportedAt";
    severity: Exclude<ImportCompatSeverity, "ok">;
    message: string;
    expected?: string;
    actual?: string;
  };
  type ImportedProbeMeta = {
    fileName: string;
    format: "json" | "csv";
    schemaVersion: number | null;
    exportKind: string | null;
    exportedAt: string | null;
    mode?: string | null;
    source?: string | null;
    totalRows: number;
    runCount: number;
    countsByRule?: Record<string, number>;
    runs: Array<{
      ranAt: string;
      pathname: string;
      selector: string;
      kind: string;
      totalMatched: number;
      rowCount: number;
    }>;
    pairs: ImportedProbePair[];
    warnings: string[];
    compatibility: {
      severity: ImportCompatSeverity;
      issues: ImportCompatIssue[];
    };
  };
  type ImportSlot = "a" | "b";
  const [importedProbes, setImportedProbes] = useState<{
    a: ImportedProbeMeta | null;
    b: ImportedProbeMeta | null;
  }>({ a: null, b: null });
  const [importedProbeError, setImportedProbeError] = useState<{
    slot: ImportSlot;
    message: string;
  } | null>(null);

  function accumulatePair(
    map: Map<string, ImportedProbePair>,
    ruleId: string,
    selector: string,
    kind: string
  ) {
    const key = `${ruleId}\u0001${selector}\u0001${kind}`;
    const existing = map.get(key);
    if (existing) existing.count++;
    else map.set(key, { ruleId, selector, kind, count: 1 });
  }

  function computeProbeCompatibility(
    schemaVersion: number | null,
    exportKind: string | null,
    exportedAt: string | null
  ): { severity: ImportCompatSeverity; issues: ImportCompatIssue[] } {
    const issues: ImportCompatIssue[] = [];
    if (schemaVersion === null) {
      issues.push({
        field: "schemaVersion",
        severity: "error",
        message: `Missing schemaVersion — the importer expects ${EXPECTED_PROBE_SCHEMA_VERSION}.`,
        expected: String(EXPECTED_PROBE_SCHEMA_VERSION),
        actual: "—",
      });
    } else if (!SUPPORTED_PROBE_SCHEMA_VERSIONS.includes(schemaVersion)) {
      issues.push({
        field: "schemaVersion",
        severity: "error",
        message: `Unsupported schemaVersion ${schemaVersion}. Importer supports: ${SUPPORTED_PROBE_SCHEMA_VERSIONS.join(", ")}.`,
        expected: SUPPORTED_PROBE_SCHEMA_VERSIONS.join(", "),
        actual: String(schemaVersion),
      });
    } else if (schemaVersion !== EXPECTED_PROBE_SCHEMA_VERSION) {
      issues.push({
        field: "schemaVersion",
        severity: "warning",
        message: `schemaVersion ${schemaVersion} differs from the current default ${EXPECTED_PROBE_SCHEMA_VERSION}; some fields may be ignored.`,
        expected: String(EXPECTED_PROBE_SCHEMA_VERSION),
        actual: String(schemaVersion),
      });
    }
    if (!exportKind) {
      issues.push({
        field: "exportKind",
        severity: "warning",
        message: `Missing exportKind — expected "${EXPECTED_PROBE_EXPORT_KIND}".`,
        expected: EXPECTED_PROBE_EXPORT_KIND,
        actual: "—",
      });
    } else if (exportKind !== EXPECTED_PROBE_EXPORT_KIND) {
      issues.push({
        field: "exportKind",
        severity: "error",
        message: `exportKind "${exportKind}" does not match expected "${EXPECTED_PROBE_EXPORT_KIND}" — this file is likely a diff or overlay export, not a probe export.`,
        expected: EXPECTED_PROBE_EXPORT_KIND,
        actual: exportKind,
      });
    }
    if (!exportedAt) {
      issues.push({
        field: "exportedAt",
        severity: "warning",
        message: "Missing exportedAt timestamp — cannot verify export recency.",
        expected: "ISO 8601 timestamp",
        actual: "—",
      });
    } else if (Number.isNaN(Date.parse(exportedAt))) {
      issues.push({
        field: "exportedAt",
        severity: "warning",
        message: `exportedAt "${exportedAt}" is not a parseable ISO timestamp.`,
        expected: "ISO 8601 timestamp",
        actual: exportedAt,
      });
    }
    const severity: ImportCompatSeverity = issues.some((i) => i.severity === "error")
      ? "error"
      : issues.length > 0
        ? "warning"
        : "ok";
    return { severity, issues };
  }

  function parseImportedProbeJson(fileName: string, text: string): ImportedProbeMeta {
    const warnings: string[] = [];
    let data: any;
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw new Error(`Invalid JSON: ${(e as Error).message}`);
    }
    const schemaVersion =
      typeof data?.schemaVersion === "number" ? data.schemaVersion : null;
    const exportKind =
      typeof data?.exportKind === "string" ? data.exportKind : null;
    const exportedAt =
      typeof data?.exportedAt === "string" ? data.exportedAt : null;
    const compatibility = computeProbeCompatibility(schemaVersion, exportKind, exportedAt);
    for (const issue of compatibility.issues) {
      warnings.push(`[${issue.severity}] ${issue.message}`);
    }
    const runsRaw = Array.isArray(data?.runs) ? data.runs : [];
    const pairMap = new Map<string, ImportedProbePair>();
    const runs = runsRaw.map((r: any) => {
      const rows = Array.isArray(r?.rows) ? r.rows : [];
      const runSelector = String(r?.selector ?? "");
      const runKind = String(r?.kind ?? "");
      for (const row of rows) {
        accumulatePair(
          pairMap,
          String(row?.ruleId ?? ""),
          String(row?.selector ?? runSelector),
          String(row?.kind ?? runKind)
        );
      }
      return {
        ranAt: String(r?.ranAt ?? ""),
        pathname: String(r?.pathname ?? ""),
        selector: runSelector,
        kind: runKind,
        totalMatched: Number(r?.totalMatched ?? rows.length),
        rowCount: rows.length,
      };
    });
    const totalRows =
      typeof data?.totalRows === "number"
        ? data.totalRows
        : runs.reduce((a: number, r: { rowCount: number }) => a + r.rowCount, 0);
    return {
      fileName,
      format: "json",
      schemaVersion,
      exportKind,
      exportedAt,
      mode: data?.filters?.mode ?? null,
      source: data?.filters?.source ?? null,
      totalRows,
      runCount: runs.length,
      countsByRule:
        data?.countsByRule && typeof data.countsByRule === "object"
          ? data.countsByRule
          : undefined,
      runs,
      pairs: Array.from(pairMap.values()),
      warnings,
      compatibility,
    };
  }

  function parseImportedProbeCsv(fileName: string, text: string): ImportedProbeMeta {
    const warnings: string[] = [];
    const lines = text.split(/\r?\n/);
    const meta: Record<string, string> = {};
    let idx = 0;
    for (; idx < lines.length; idx++) {
      const l = lines[idx];
      if (l.startsWith("#")) {
        const m = l.slice(1).trim().match(/^([^=:]+)\s*[=:]\s*(.+)$/);
        if (m) meta[m[1].trim()] = m[2].trim();
      } else if (l.trim().length > 0) {
        break;
      }
    }
    const header = (lines[idx] ?? "").split(",");
    idx++;
    function splitCsv(row: string): string[] {
      const out: string[] = [];
      let cur = "";
      let inQ = false;
      for (let i = 0; i < row.length; i++) {
        const ch = row[i];
        if (inQ) {
          if (ch === '"' && row[i + 1] === '"') {
            cur += '"';
            i++;
          } else if (ch === '"') {
            inQ = false;
          } else cur += ch;
        } else {
          if (ch === '"') inQ = true;
          else if (ch === ",") {
            out.push(cur);
            cur = "";
          } else cur += ch;
        }
      }
      out.push(cur);
      return out;
    }
    const col = (row: string[], name: string) => {
      const i = header.indexOf(name);
      return i >= 0 ? row[i] : "";
    };
    const runsMap = new Map<
      string,
      {
        ranAt: string;
        pathname: string;
        selector: string;
        kind: string;
        rowCount: number;
      }
    >();
    const pairMap = new Map<string, ImportedProbePair>();
    let totalRows = 0;
    for (; idx < lines.length; idx++) {
      const line = lines[idx];
      if (!line || line.startsWith("#") || !line.trim()) continue;
      const row = splitCsv(line);
      const key = `${col(row, "ranAt")}|${col(row, "pathname")}|${col(row, "selector")}|${col(row, "kind")}`;
      const existing = runsMap.get(key);
      if (existing) existing.rowCount++;
      else
        runsMap.set(key, {
          ranAt: col(row, "ranAt"),
          pathname: col(row, "pathname"),
          selector: col(row, "selector"),
          kind: col(row, "kind"),
          rowCount: 1,
        });
      accumulatePair(
        pairMap,
        col(row, "ruleId"),
        col(row, "selector"),
        col(row, "kind")
      );
      totalRows++;
    }
    const schemaVersion = meta.schemaVersion ? Number(meta.schemaVersion) : null;
    const exportKind = meta.exportKind ?? null;
    const exportedAt = meta.exportedAt ?? null;
    const compatibility = computeProbeCompatibility(schemaVersion, exportKind, exportedAt);
    for (const issue of compatibility.issues) {
      warnings.push(`[${issue.severity}] ${issue.message}`);
    }
    if (totalRows === 0) warnings.push("No data rows found in CSV.");
    return {
      fileName,
      format: "csv",
      schemaVersion,
      exportKind,
      exportedAt,
      mode: meta.mode ?? null,
      source: meta.source ?? null,
      totalRows,
      runCount: runsMap.size,
      runs: Array.from(runsMap.values()).map((r) => ({ ...r, totalMatched: r.rowCount })),
      pairs: Array.from(pairMap.values()),
      warnings,
      compatibility,
    };
  }

  async function handleImportProbeFile(slot: ImportSlot, file: File) {
    setImportedProbeError(null);
    try {
      const text = await file.text();
      const isJson =
        file.name.toLowerCase().endsWith(".json") ||
        text.trimStart().startsWith("{");
      const parsed = isJson
        ? parseImportedProbeJson(file.name, text)
        : parseImportedProbeCsv(file.name, text);
      setImportedProbes((prev) => ({ ...prev, [slot]: parsed }));
      toast.success(
        `[${slot.toUpperCase()}] Loaded ${parsed.totalRows} row(s) from ${parsed.runCount} run(s)`
      );
    } catch (e) {
      setImportedProbes((prev) => ({ ...prev, [slot]: null }));
      const msg = (e as Error).message ?? "Failed to parse file";
      setImportedProbeError({ slot, message: msg });
      toast.error(`[${slot.toUpperCase()}] ${msg}`);
    }
  }

  // Diff of two imported probe exports, grouped by exportedAt (A vs B).
  type ProbeDiffRow = {
    key: string;
    ruleId: string;
    selector: string;
    kind: string;
    countA: number;
    countB: number;
    status: "added" | "removed" | "changed" | "unchanged";
  };
  const probeImportDiff = useMemo<{
    rows: ProbeDiffRow[];
    counts: {
      added: number;
      removed: number;
      changed: number;
      unchanged: number;
    };
  } | null>(() => {
    const a = importedProbes.a;
    const b = importedProbes.b;
    if (!a || !b) return null;
    const byKey = new Map<string, ProbeDiffRow>();
    const upsert = (
      p: ImportedProbePair,
      side: "a" | "b"
    ) => {
      const key = `${p.ruleId}\u0001${p.selector}\u0001${p.kind}`;
      const existing = byKey.get(key);
      if (existing) {
        if (side === "a") existing.countA = p.count;
        else existing.countB = p.count;
      } else {
        byKey.set(key, {
          key,
          ruleId: p.ruleId,
          selector: p.selector,
          kind: p.kind,
          countA: side === "a" ? p.count : 0,
          countB: side === "b" ? p.count : 0,
          status: "unchanged",
        });
      }
    };
    for (const p of a.pairs) upsert(p, "a");
    for (const p of b.pairs) upsert(p, "b");
    const counts = { added: 0, removed: 0, changed: 0, unchanged: 0 };
    const rows = Array.from(byKey.values()).map((r) => {
      if (r.countA === 0 && r.countB > 0) r.status = "added";
      else if (r.countA > 0 && r.countB === 0) r.status = "removed";
      else if (r.countA !== r.countB) r.status = "changed";
      else r.status = "unchanged";
      counts[r.status]++;
      return r;
    });
    const order = { added: 0, removed: 1, changed: 2, unchanged: 3 } as const;
    rows.sort((x, y) => {
      const d = order[x.status] - order[y.status];
      if (d !== 0) return d;
      const r = x.ruleId.localeCompare(y.ruleId);
      if (r !== 0) return r;
      return x.selector.localeCompare(y.selector);
    });
    return { rows, counts };
  }, [importedProbes]);

  function ImportedProbeCard({
    slot,
    imported,
    error,
    onFile,
    onClear,
  }: {
    slot: ImportSlot;
    imported: ImportedProbeMeta | null;
    error: string | null;
    onFile: (file: File) => void;
    onClear: () => void;
  }) {
    return (
      <div className="rounded-md border border-hairline bg-background/30 p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
              Slot {slot.toUpperCase()}
            </span>
            {imported && (
              <span className="text-[11px] text-muted-foreground">
                {imported.fileName}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <label className="cursor-pointer rounded-md border border-hairline bg-background px-2 py-1 text-[11px] hover:bg-muted">
              {imported ? "Replace…" : "Choose file…"}
              <input
                type="file"
                accept=".json,.csv,application/json,text/csv"
                className="sr-only"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onFile(f);
                  e.target.value = "";
                }}
              />
            </label>
            {imported && (
              <button
                type="button"
                onClick={onClear}
                className="rounded-md border border-hairline px-2 py-1 text-[11px] hover:bg-muted"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {error && (
          <div className="mb-2 rounded-md border border-rose-500/40 bg-rose-500/10 p-2 text-[11px] text-rose-200">
            {error}
          </div>
        )}

        {!imported && !error && (
          <p className="text-[11px] text-muted-foreground">
            No file loaded. Choose a probe export JSON or CSV.
          </p>
        )}

        {imported && (
          <div className="space-y-2 text-[11px]">
            <div className="grid gap-2 sm:grid-cols-2">
              <MetaCell label="Format" value={imported.format.toUpperCase()} />
              <MetaCell
                label="schemaVersion"
                value={
                  imported.schemaVersion === null
                    ? "—"
                    : String(imported.schemaVersion)
                }
              />
              <MetaCell
                label="exportKind"
                value={imported.exportKind ?? "—"}
                mono
              />
              <MetaCell
                label="exportedAt"
                value={
                  imported.exportedAt
                    ? new Date(imported.exportedAt).toLocaleString()
                    : "—"
                }
              />
              <MetaCell
                label="Rows / Runs"
                value={`${imported.totalRows} / ${imported.runCount}`}
              />
              <MetaCell
                label="Distinct pairs"
                value={String(imported.pairs.length)}
              />
            </div>

            {(() => {
              const { severity, issues } = imported.compatibility;
              if (severity === "ok") {
                return (
                  <div className="flex items-center gap-2 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2 py-1.5 text-[11px] text-emerald-200">
                    <span className="rounded-sm bg-emerald-500/30 px-1.5 py-0.5 font-semibold uppercase tracking-wide">
                      Compatible
                    </span>
                    <span>
                      schemaVersion {imported.schemaVersion} · exportKind{" "}
                      <code className="font-mono">{imported.exportKind}</code> — matches importer
                      expectations.
                    </span>
                  </div>
                );
              }
              const isError = severity === "error";
              const wrap = isError
                ? "border-rose-500/50 bg-rose-500/10 text-rose-200"
                : "border-amber-500/40 bg-amber-500/10 text-amber-200";
              const pill = isError
                ? "bg-rose-500/30 text-rose-100"
                : "bg-amber-500/30 text-amber-100";
              return (
                <div className={`space-y-2 rounded-md border p-2 text-[11px] ${wrap}`}>
                  <div className="flex items-center gap-2">
                    <span
                      className={`rounded-sm px-1.5 py-0.5 font-semibold uppercase tracking-wide ${pill}`}
                    >
                      {isError ? "Incompatible" : "Compatibility warning"}
                    </span>
                    <span className="opacity-80">
                      Importer expects schemaVersion {EXPECTED_PROBE_SCHEMA_VERSION} ·
                      exportKind <code className="font-mono">{EXPECTED_PROBE_EXPORT_KIND}</code>
                    </span>
                  </div>
                  <ul className="space-y-1">
                    {issues.map((iss, i) => (
                      <li
                        key={i}
                        className="rounded-sm border border-current/20 bg-black/20 p-1.5"
                      >
                        <div className="flex items-center gap-2">
                          <span className="rounded-sm bg-black/30 px-1 py-0.5 font-mono text-[10px] uppercase">
                            {iss.field}
                          </span>
                          <span className="rounded-sm bg-black/30 px-1 py-0.5 text-[10px] uppercase">
                            {iss.severity}
                          </span>
                        </div>
                        <div className="mt-1">{iss.message}</div>
                        {(iss.expected || iss.actual) && (
                          <div className="mt-1 grid grid-cols-2 gap-2 font-mono text-[10px] opacity-80">
                            <div>expected: {iss.expected ?? "—"}</div>
                            <div>actual: {iss.actual ?? "—"}</div>
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                  {isError && (
                    <div className="text-[10px] opacity-80">
                      Metadata and rows are shown read-only for inspection; treat this file as
                      an unknown format and do not rely on the parsed contents.
                    </div>
                  )}
                </div>
              );
            })()}


            {imported.runs.length > 0 && (
              <details className="rounded-md border border-hairline p-2">
                <summary className="cursor-pointer text-muted-foreground">
                  Show {imported.runs.length} run(s)
                </summary>
                <div className="mt-2 overflow-x-auto">
                  <table className="w-full text-[11px]">
                    <thead className="text-left text-muted-foreground">
                      <tr>
                        <th className="py-1 pr-2">ranAt</th>
                        <th className="py-1 pr-2">pathname</th>
                        <th className="py-1 pr-2">selector</th>
                        <th className="py-1 pr-2">kind</th>
                        <th className="py-1 pr-2 text-right">rows</th>
                      </tr>
                    </thead>
                    <tbody className="font-mono">
                      {imported.runs.map((r, i) => (
                        <tr key={i} className="border-t border-hairline/50">
                          <td className="py-1 pr-2 whitespace-nowrap">
                            {r.ranAt ? new Date(r.ranAt).toLocaleString() : "—"}
                          </td>
                          <td className="py-1 pr-2">{r.pathname || "—"}</td>
                          <td
                            className="py-1 pr-2 max-w-[16rem] truncate"
                            title={r.selector}
                          >
                            {r.selector || "—"}
                          </td>
                          <td className="py-1 pr-2">{r.kind}</td>
                          <td className="py-1 pr-2 text-right tabular-nums">
                            {r.rowCount}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </details>
            )}
          </div>
        )}
      </div>
    );
  }





  const exportSources = useMemo(() => {
    const list: ProbeSnapshot[] = [];
    if (probeMeta) {
      list.push({
        id: probeMeta.ranAt,
        ranAt: probeMeta.ranAt,
        pathname,
        selector: probe.selector,
        kind: probe.kind,
        total: probeMeta.total,
        rows: probeRows,
      });
    }
    if (useSnapshots) {
      for (const s of snapshots) if (!list.find((x) => x.id === s.id)) list.push(s);
    }
    return list;
  }, [probeMeta, probeRows, pathname, probe.selector, probe.kind, snapshots, useSnapshots]);

  const availableRoutes = useMemo(
    () => Array.from(new Set(exportSources.map((s) => s.pathname))).sort(),
    [exportSources]
  );
  const availableKinds = useMemo(
    () => Array.from(new Set(exportSources.map((s) => s.kind))) as ScrollAllowlistKind[],
    [exportSources]
  );

  const filteredSources = useMemo(() => {
    return exportSources
      .filter((s) => (routeFilter.size === 0 ? true : routeFilter.has(s.pathname)))
      .filter((s) => (kindFilter.size === 0 ? true : kindFilter.has(s.kind)))
      .map((s) => ({
        ...s,
        rows: s.rows.filter((r) =>
          exportMode === "both" ? true : exportMode === "sanctioned" ? !!r.ruleId : !r.ruleId
        ),
      }))
      .filter((s) => s.rows.length > 0);
  }, [exportSources, routeFilter, kindFilter, exportMode]);

  const filteredRowCount = filteredSources.reduce((n, s) => n + s.rows.length, 0);

  function toggleInSet<T>(
    set: Set<T>,
    v: T,
    setter: (s: Set<T>) => void
  ) {
    const next = new Set(set);
    if (next.has(v)) next.delete(v);
    else next.add(v);
    setter(next);
  }

  // Bump when the export payload shape changes in a breaking way.
  const EXPORT_SCHEMA_VERSION = 1;
  const EXPORT_KIND = "motion-allowlist-probe";

  function exportJson() {
    if (filteredSources.length === 0) return;
    const summary: Record<string, number> = {};
    for (const s of filteredSources)
      for (const r of s.rows) {
        const k = r.ruleId ?? "(no match)";
        summary[k] = (summary[k] ?? 0) + 1;
      }
    const exportedAt = new Date().toISOString();
    const payload = {
      schemaVersion: EXPORT_SCHEMA_VERSION,
      exportKind: EXPORT_KIND,
      exportedAt,
      generator: {
        app: "heysaas-admin",
        route: "/dashboard/admin/motion-allowlist",
      },
      filters: {
        mode: exportMode,
        routes: routeFilter.size ? Array.from(routeFilter) : "all",
        kinds: kindFilter.size ? Array.from(kindFilter) : "all",
        source: useSnapshots ? "current+snapshots" : "current-probe",
      },
      totalRows: filteredRowCount,
      countsByRule: summary,
      runs: filteredSources.map((s) => ({
        ranAt: s.ranAt,
        pathname: s.pathname,
        selector: s.selector,
        kind: s.kind,
        totalMatched: s.total,
        rows: s.rows,
      })),
    };
    const stamp = exportedAt.replace(/[:.]/g, "-");
    downloadTesterFile(
      `allowlist-probe-${exportMode}-v${EXPORT_SCHEMA_VERSION}-${stamp}.json`,
      "application/json",
      JSON.stringify(payload, null, 2)
    );
  }

  function exportCsv() {
    if (filteredSources.length === 0) return;
    const esc = (v: string) => `"${String(v).replace(/"/g, '""')}"`;
    const exportedAt = new Date().toISOString();
    // Prepend RFC 4180-friendly `#` comment lines carrying export metadata,
    // then a machine-parseable header + per-row schemaVersion/exportedAt cols
    // so both "skip comments" and "read every row" importers stay correct.
    const metaComments = [
      `# schemaVersion=${EXPORT_SCHEMA_VERSION}`,
      `# exportKind=${EXPORT_KIND}`,
      `# exportedAt=${exportedAt}`,
      `# mode=${exportMode}`,
      `# source=${useSnapshots ? "current+snapshots" : "current-probe"}`,
    ];
    const header = [
      "schemaVersion",
      "exportedAt",
      "ranAt",
      "pathname",
      "selector",
      "kind",
      "index",
      "tag",
      "id",
      "classes",
      "ruleId",
      "status",
    ].join(",");
    const lines: string[] = [];
    for (const s of filteredSources) {
      for (const r of s.rows) {
        lines.push(
          [
            EXPORT_SCHEMA_VERSION,
            exportedAt,
            s.ranAt,
            esc(s.pathname),
            esc(r.selector),
            r.kind,
            r.index,
            r.tag,
            esc(r.id),
            esc(r.classes),
            r.ruleId ?? "",
            r.ruleId ? "sanctioned" : "leak",
          ].join(",")
        );
      }
    }
    const stamp = exportedAt.replace(/[:.]/g, "-");
    downloadTesterFile(
      `allowlist-probe-${exportMode}-v${EXPORT_SCHEMA_VERSION}-${stamp}.csv`,
      "text/csv",
      [...metaComments, header, ...lines].join("\n")
    );
  }


  return (
    <main id="main" className="mx-auto max-w-4xl px-4 py-8">
      <BackButton />
      <header className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">
          Motion scroll allowlist
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Source of truth: <code>src/config/motion-scroll-allowlist.ts</code>.
          Frozen JSON for CI:{" "}
          <a
            className="underline decoration-dotted"
            href="/motion-scroll-allowlist.json"
            target="_blank"
            rel="noreferrer"
          >
            /motion-scroll-allowlist.json
          </a>
          .
        </p>
      </header>

      <section
        data-allowlist-admin-ui
        className="mb-8 rounded-xl border border-hairline p-4"
      >
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            Import allowlist JSON
          </h2>
          {overlay.length > 0 && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>
                {overlay.length} rule{overlay.length === 1 ? "" : "s"} staged in
                local overlay
              </span>
              <button
                type="button"
                onClick={copyMergedTsSnippet}
                className="rounded-md border border-hairline px-2 py-1 hover:bg-muted"
                title="Copy merged config + overlay as a TS snippet to paste into src/config/motion-scroll-allowlist.ts"
              >
                Copy TS snippet
              </button>
              <button
                type="button"
                onClick={() => {
                  const payload = {
                    schemaVersion: 1,
                    exportKind: "motion-allowlist-overlay",
                    exportedAt: new Date().toISOString(),
                    ruleCount: overlay.length,
                    rules: overlay,
                  };
                  const blob = new Blob([JSON.stringify(payload, null, 2)], {
                    type: "application/json",
                  });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `motion-allowlist-overlay-${new Date()
                    .toISOString()
                    .replace(/[:.]/g, "-")}.json`;
                  document.body.appendChild(a);
                  a.click();
                  a.remove();
                  URL.revokeObjectURL(url);
                  toast.success(
                    `Exported ${overlay.length} overlay rule${
                      overlay.length === 1 ? "" : "s"
                    }`,
                  );
                }}
                className="rounded-md border border-hairline px-2 py-1 hover:bg-muted"
                title="Download the current local overlay as JSON"
              >
                Export overlay JSON
              </button>
              <button
                type="button"
                onClick={() => {
                  recordOverlayHistory(
                    overlay,
                    `Snapshot before Clear overlay (${overlay.length} rule${overlay.length === 1 ? "" : "s"})`,
                  );
                  clearOverlay();
                  setOverlay([]);
                  recordOverlayHistory([], "Cleared overlay");
                }}

                className="rounded-md border border-hairline px-2 py-1 hover:bg-muted"
              >
                Clear overlay
              </button>

            </div>
          )}
        </div>

        <p className="mb-3 text-xs text-muted-foreground">
          Upload a JSON file (either a raw array of rules or the frozen{" "}
          <code>/motion-scroll-allowlist.json</code> shape). You will see a
          preview of what would be <strong>added</strong> or{" "}
          <strong>updated</strong> versus the shipped config before anything is
          saved. Nothing writes to the TS source — saving stages rules in a
          browser overlay so you can copy a paste-ready snippet for the config
          author.
        </p>

        <div className="flex flex-wrap items-center gap-2">
          <input
            ref={importInputRef}
            type="file"
            accept="application/json,.json"
            className="text-xs"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void handleImportFile(f);
            }}
          />
          {importFileName && (
            <button
              type="button"
              onClick={resetImport}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted"
            >
              Cancel import
            </button>
          )}
        </div>

        {importIssues.length > 0 && (
          <div className="mt-3">
            <AllowlistIssuesPanel
              title="Parse issues"
              fileName={importFileName}
              issues={importIssues}
              exportKind="motion-allowlist-import-issues"
              onJumpToRule={jumpToPreviewRule}
              onFix={autoFixImportIssue}
              fixable={isImportIssueFixable}
              previewFix={previewImportFix}
              helperText="Click Fix… to inline-preview the before/after change, then Apply fix to write it. Selectors must be fixed by hand."

            />

          </div>
        )}


        {importDiff && importRules && (
          <div className="mt-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <span className="rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-emerald-700 dark:text-emerald-300">
                + {importDiff.added.length} added
              </span>
              <span className="rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-amber-700 dark:text-amber-300">
                ~ {importDiff.updated.length} updated
              </span>
              <span className="rounded-md border border-hairline px-2 py-1 text-muted-foreground">
                = {importDiff.unchanged.length} unchanged
              </span>
              <span className="ml-auto text-muted-foreground">
                From <code>{importFileName}</code>
              </span>
            </div>

            {importDiff.added.length > 0 && (
              <div className="rounded-md border border-hairline p-3">
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-widest text-emerald-700 dark:text-emerald-300">
                  Added ({importDiff.added.length})
                </h3>
                <ul className="space-y-1 text-xs">
                  {importDiff.added.map((r) => (
                    <li
                      key={r.id}
                      id={`preview-rule-${r.id}`}
                      data-preview-rule-id={r.id}
                      className="rounded px-1 py-0.5 transition-colors"
                    >
                      <code>{r.id}</code>{" "}
                      <span className="text-muted-foreground">
                        · {r.kind} · {r.selector}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {importDiff.updated.length > 0 && (
              <div className="rounded-md border border-hairline p-3">
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-widest text-amber-700 dark:text-amber-300">
                  Updated ({importDiff.updated.length})
                </h3>
                <ul className="space-y-2 text-xs">
                  {importDiff.updated.map(({ before, after, changed }) => (
                    <li
                      key={after.id}
                      id={`preview-rule-${after.id}`}
                      data-preview-rule-id={after.id}
                      className="rounded border border-hairline/60 p-2 transition-colors"
                    >
                      <div>
                        <code>{after.id}</code>{" "}
                        <span className="text-muted-foreground">
                          — changed: {changed.join(", ")}
                        </span>
                      </div>
                      <div className="mt-1 grid grid-cols-1 gap-1 md:grid-cols-2">
                        <pre className="overflow-auto rounded bg-muted/40 p-2 text-[11px]">
                          before: {JSON.stringify(before, null, 2)}
                        </pre>
                        <pre className="overflow-auto rounded bg-muted/40 p-2 text-[11px]">
                          after: {JSON.stringify(after, null, 2)}
                        </pre>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}


            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={confirmSaveOverlay}
                disabled={
                  validating ||
                  importDiff.added.length + importDiff.updated.length === 0
                }
                className="rounded-md border border-hairline bg-primary px-3 py-2 text-sm text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                title="Server-side validates every selector before writing to the overlay"
              >
                {validating ? "Validating on server…" : "Save to overlay"}
              </button>
              <button
                type="button"
                onClick={resetImport}
                disabled={validating}
                className="rounded-md border border-hairline px-3 py-2 text-sm hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
              >
                Discard preview
              </button>
              {importDiff.added.length + importDiff.updated.length === 0 && (
                <span className="text-xs text-muted-foreground">
                  Nothing to save — every rule matches the shipped config.
                </span>
              )}
            </div>

            {serverIssues.length > 0 && (
              <div className="mt-2">
                <AllowlistIssuesPanel
                  title="Save blocked by server validation"
                  fileName={importFileName}
                  issues={serverIssues}
                  exportKind="motion-allowlist-validation-issues"
                  onJumpToRule={jumpToPreviewRule}
                  helperText={
                    <>
                      Every selector is parsed on the server before it can
                      reach the overlay. Fix the offending rules in the source
                      file (or in the preview above) and re-save.
                    </>
                  }
                />
              </div>
            )}

          </div>
        )}
      </section>

      <section
        data-allowlist-admin-ui
        className="mb-8 rounded-xl border border-hairline p-4"
      >
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
              Overlay rollback history
            </h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Every save, clear, or revert to the local overlay is snapshotted
              here (up to 30 entries, browser-local). Revert to any previous
              state — the current overlay is auto-snapshotted first so the
              revert is itself undoable.
            </p>
          </div>
          {overlayHistory.length > 0 && (
            <button
              type="button"
              onClick={() => {
                if (
                  !window.confirm(
                    `Delete all ${overlayHistory.length} history entries? The current overlay is not affected.`,
                  )
                )
                  return;
                clearOverlayHistory();
                setOverlayHistory([]);
                toast.success("Cleared overlay history");
              }}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted"
            >
              Clear history
            </button>
          )}
        </div>

        {overlayHistory.length === 0 ? (
          <p className="text-xs italic text-muted-foreground">
            No history yet — save or clear the overlay to record a snapshot.
          </p>
        ) : (
          <ul className="space-y-2">
            {overlayHistory.map((entry) => {
              const isCurrent =
                entry.ruleCount === overlay.length &&
                JSON.stringify(entry.rules) === JSON.stringify(overlay);
              return (
                <li
                  key={entry.id}
                  className={`rounded-md border p-3 text-xs ${
                    isCurrent
                      ? "border-emerald-500/50 bg-emerald-500/5"
                      : "border-hairline"
                  }`}
                >
                  <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                    <span className="font-mono text-[11px] text-muted-foreground">
                      {new Date(entry.savedAt).toLocaleString()}
                    </span>
                    <span className="rounded bg-muted px-1.5 py-0.5 text-[10px]">
                      {entry.ruleCount} rule
                      {entry.ruleCount === 1 ? "" : "s"}
                    </span>
                    {isCurrent && (
                      <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700 dark:text-emerald-300">
                        current
                      </span>
                    )}
                    <div className="ml-auto flex shrink-0 gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          const payload = {
                            schemaVersion: 1,
                            exportKind: "motion-allowlist-overlay",
                            exportedAt: new Date().toISOString(),
                            snapshotAt: entry.savedAt,
                            note: entry.note,
                            ruleCount: entry.ruleCount,
                            rules: entry.rules,
                          };
                          const blob = new Blob(
                            [JSON.stringify(payload, null, 2)],
                            { type: "application/json" },
                          );
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement("a");
                          a.href = url;
                          a.download = `motion-allowlist-overlay-${entry.savedAt.replace(/[:.]/g, "-")}.json`;
                          document.body.appendChild(a);
                          a.click();
                          a.remove();
                          URL.revokeObjectURL(url);
                        }}
                        className="rounded border border-hairline px-2 py-0.5 text-[11px] hover:bg-muted"
                        title="Download this snapshot as JSON"
                      >
                        Export
                      </button>
                      <button
                        type="button"
                        disabled={isCurrent}
                        onClick={() => {
                          if (
                            !window.confirm(
                              `Revert overlay to the snapshot from ${new Date(entry.savedAt).toLocaleString()}?\n\nThe current overlay will be snapshotted first.`,
                            )
                          )
                            return;
                          applyHistoryEntry(entry);
                        }}
                        className="rounded border border-hairline bg-primary/90 px-2 py-0.5 text-[11px] font-medium text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
                        title={
                          isCurrent
                            ? "This snapshot already matches the current overlay"
                            : "Restore this snapshot as the active overlay"
                        }
                      >
                        Revert
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (
                            !window.confirm(
                              "Delete this history entry? This does not change the current overlay.",
                            )
                          )
                            return;
                          deleteOverlayHistoryEntry(entry.id);
                          setOverlayHistory(listOverlayHistory());
                        }}
                        className="rounded border border-hairline px-2 py-0.5 text-[11px] hover:bg-muted"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  <div className="mt-1 leading-snug">{entry.note}</div>
                  {entry.rules.length > 0 && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-[11px] text-muted-foreground hover:text-foreground">
                        Show rule ids ({entry.rules.length})
                      </summary>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {entry.rules.map((r) => (
                          <code
                            key={r.id}
                            className="rounded bg-muted px-1.5 py-0.5 text-[10px]"
                            title={`${r.kind} · ${r.selector}`}
                          >
                            {r.id}
                          </code>
                        ))}
                      </div>
                    </details>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>






      <section data-allowlist-admin-ui className="mb-8 rounded-xl border border-hairline p-4">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
          Live selector test
        </h2>
        {invalidRules.length > 0 && (
          <div
            role="alert"
            className="mb-3 rounded-md border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-700 dark:text-rose-300"
          >
            <strong>{invalidRules.length} allowlist rule(s) have malformed selectors.</strong>{" "}
            Fix in <code>src/config/motion-scroll-allowlist.ts</code> or in the local overlay:
            <ul className="mt-1 list-disc pl-4">
              {invalidRules.map((r) => (
                <li key={r.id}>
                  <code>{r.id}</code> — {r.error}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex flex-wrap items-end gap-2">
          <label className="flex flex-1 min-w-[280px] flex-col gap-1 text-xs">
            <span className="text-muted-foreground">Selector</span>
            <input
              className={`rounded-md border bg-background px-3 py-2 font-mono text-sm ${
                probeSelectorError
                  ? "border-rose-500 focus:outline-rose-500"
                  : "border-hairline"
              }`}
              value={probe.selector}
              onChange={(e) => setProbe({ ...probe, selector: e.target.value })}
              placeholder="[data-carousel]"
              aria-invalid={probeSelectorError ? true : undefined}
              aria-describedby={probeSelectorError ? "probe-selector-error" : undefined}
            />
            {probeSelectorError && (
              <span
                id="probe-selector-error"
                role="alert"
                className="mt-1 rounded-md border border-rose-500/40 bg-rose-500/10 px-2 py-1 text-[11px] leading-snug text-rose-600 dark:text-rose-300"
              >
                <strong>Malformed selector</strong> — {probeSelectorError}
                {conflictingRuleId && (
                  <>
                    {" "}
                    (rule id: <code>{conflictingRuleId}</code>)
                  </>
                )}
                <br />
                Expected a valid CSS selector, e.g.{" "}
                <code>[data-carousel]</code>, <code>.snap-x &gt; *</code>,{" "}
                <code>#hero .marquee</code>.
              </span>
            )}
          </label>

          <label className="flex flex-col gap-1 text-xs">
            <span className="text-muted-foreground">Kind</span>
            <select
              className="rounded-md border border-hairline bg-background px-3 py-2 text-sm"
              value={probe.kind}
              onChange={(e) =>
                setProbe({ ...probe, kind: e.target.value as ScrollAllowlistKind })
              }
            >
              <option value="scroll-snap">scroll-snap</option>
              <option value="scroll-behavior-smooth">scroll-behavior:smooth</option>
            </select>
          </label>
          <label className="flex flex-col gap-1 text-xs">
            <span className="text-muted-foreground">Pathname (for routes[])</span>
            <input
              className="w-56 rounded-md border border-hairline bg-background px-3 py-2 font-mono text-sm"
              value={pathname}
              onChange={(e) => setPathname(e.target.value)}
            />
          </label>
          <button
            type="button"
            onClick={() => runProbe()}
            disabled={!!probeSelectorError}
            className="rounded-md border border-hairline bg-primary px-3 py-2 text-sm text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            title={probeSelectorError ?? "Run probe against current DOM"}
          >
            Run probe
          </button>

          <button
            type="button"
            onClick={exportJson}
            disabled={filteredRowCount === 0}
            className="rounded-md border border-hairline px-3 py-2 text-sm hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
            title={`Export ${filteredRowCount} row(s) as JSON`}
          >
            Export JSON ({filteredRowCount})
          </button>
          <button
            type="button"
            onClick={exportCsv}
            disabled={filteredRowCount === 0}
            className="rounded-md border border-hairline px-3 py-2 text-sm hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
            title={`Export ${filteredRowCount} row(s) as CSV`}
          >
            Export CSV ({filteredRowCount})
          </button>
          <label
            className={`flex items-center gap-2 rounded-md border border-hairline px-3 py-2 text-sm ${
              probeSelectorError ? "opacity-40" : ""
            }`}
            title={probeSelectorError ?? "Highlight matching elements on the page"}
          >
            <input
              type="checkbox"
              checked={highlight}
              disabled={!!probeSelectorError}
              onChange={(e) => {
                const next = e.target.checked;
                setHighlight(next);
                if (next) applyHighlights();
                else clearHighlights();
              }}
            />
            <span>Highlight matches</span>
          </label>

          <label
            className={`flex items-center gap-2 rounded-md border border-hairline px-3 py-2 text-sm ${
              highlight ? "" : "opacity-50"
            }`}
            title="Keep highlights from previous probe runs so you can accumulate results across selectors"
          >
            <input
              type="checkbox"
              checked={persistHighlights}
              disabled={!highlight}
              onChange={(e) => setPersistHighlights(e.target.checked)}
            />
            <span>Persist across runs</span>
          </label>

          <button
            type="button"
            onClick={clearHighlights}
            disabled={!highlight}
            className="rounded-md border border-hairline px-3 py-2 text-sm hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
            title="Remove highlight outlines from the page"
          >
            Clear highlights
          </button>
        </div>

        {/* Highlight appearance controls */}
        <div
          className={`mt-3 flex flex-wrap items-center gap-4 rounded-md border border-hairline bg-muted/10 p-3 text-xs ${
            highlight ? "" : "opacity-60"
          }`}
        >
          <span className="font-medium text-muted-foreground">Outline</span>
          <label className="flex items-center gap-2">
            <span>Thickness</span>
            <input
              type="range"
              min={1}
              max={8}
              step={1}
              value={highlightThickness}
              disabled={!highlight}
              onChange={(e) => {
                setHighlightThickness(Number(e.target.value));
                if (highlight) applyHighlights();
              }}
              className="w-32"
              aria-label="Highlight outline thickness in pixels"
            />
            <span className="tabular-nums w-8 text-right">{highlightThickness}px</span>
          </label>
          <label className="flex items-center gap-2">
            <span>Opacity</span>
            <input
              type="range"
              min={0.2}
              max={1}
              step={0.05}
              value={highlightOpacity}
              disabled={!highlight}
              onChange={(e) => {
                setHighlightOpacity(Number(e.target.value));
                if (highlight) applyHighlights();
              }}
              className="w-32"
              aria-label="Highlight outline opacity"
            />
            <span className="tabular-nums w-10 text-right">
              {Math.round(highlightOpacity * 100)}%
            </span>
          </label>
          <button
            type="button"
            onClick={() => {
              setHighlightThickness(2);
              setHighlightOpacity(1);
              if (highlight) applyHighlights();
            }}
            disabled={!highlight}
            className="rounded border border-hairline px-2 py-1 hover:bg-muted disabled:opacity-40"
          >
            Reset
          </button>
          <div className="flex items-center gap-1" aria-label="Highlight presets">
            <span className="text-muted-foreground">Presets</span>
            {(
              [
                { id: "subtle", label: "Subtle", thickness: 1, opacity: 0.4 },
                { id: "default", label: "Default", thickness: 2, opacity: 1 },
                { id: "high-contrast", label: "High-contrast", thickness: 5, opacity: 1 },
              ] as const
            ).map((p) => {
              const active =
                highlightThickness === p.thickness &&
                Math.abs(highlightOpacity - p.opacity) < 0.001;
              return (
                <button
                  key={p.id}
                  type="button"
                  disabled={!highlight}
                  onClick={() => {
                    setHighlightThickness(p.thickness);
                    setHighlightOpacity(p.opacity);
                    if (highlight) applyHighlights();
                  }}
                  title={`${p.thickness}px · ${Math.round(p.opacity * 100)}%`}
                  className={`rounded border px-2 py-1 hover:bg-muted disabled:opacity-40 ${
                    active
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-hairline"
                  }`}
                >
                  {p.label}
                </button>
              );
            })}
          </div>

          <div className="ml-auto flex items-center gap-3">
            <span className="text-muted-foreground">Preview</span>
            <div className="flex items-center gap-2" aria-label="Highlight preview sample">
              {[
                { label: "added", rgb: "16, 185, 129" },
                { label: "changed", rgb: "244, 63, 94" },
              ].map(({ label, rgb }) => {
                const alpha = Math.max(0.1, Math.min(1, highlightOpacity));
                const glowAlpha = Math.max(0.05, alpha * 0.35);
                return (
                  <div
                    key={label}
                    title={`${label} · ${highlightThickness}px · ${Math.round(highlightOpacity * 100)}%`}
                    className="flex h-8 w-16 items-center justify-center rounded bg-background text-[10px] text-muted-foreground"
                    style={{
                      outline: `${highlightThickness}px dashed rgba(${rgb}, ${alpha})`,
                      outlineOffset: "2px",
                      boxShadow: `0 0 0 ${highlightThickness * 2}px rgba(${rgb}, ${glowAlpha})`,
                    }}
                  >
                    {label}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Tooltip appearance controls */}
        <div
          className={`mt-3 flex flex-wrap items-center gap-4 rounded-md border border-hairline bg-muted/10 p-3 text-xs ${
            highlight ? "" : "opacity-60"
          }`}
        >
          <span className="font-medium text-muted-foreground">Tooltip</span>
          <label className="flex items-center gap-2">
            <span>Theme</span>
            <select
              value={tooltipTheme}
              disabled={!highlight}
              onChange={(e) => setTooltipTheme(e.target.value as TooltipTheme)}
              className="rounded border border-hairline bg-background px-2 py-1"
              aria-label="Tooltip color theme"
            >
              <option value="dark">Dark</option>
              <option value="light">Light</option>
              <option value="highContrast">High contrast</option>
            </select>
          </label>
          <label className="flex items-center gap-2">
            <span>Text size</span>
            <input
              type="range"
              min={9}
              max={20}
              step={1}
              value={tooltipFontSize}
              disabled={!highlight}
              onChange={(e) => setTooltipFontSize(Number(e.target.value))}
              className="w-32"
              aria-label="Tooltip text size in pixels"
            />
            <span className="tabular-nums w-10 text-right">{tooltipFontSize}px</span>
          </label>
          <label className="flex items-center gap-2">
            <span>Max width</span>
            <input
              type="range"
              min={200}
              max={720}
              step={20}
              value={tooltipMaxWidth}
              disabled={!highlight}
              onChange={(e) => setTooltipMaxWidth(Number(e.target.value))}
              className="w-40"
              aria-label="Tooltip maximum width in pixels"
            />
            <span className="tabular-nums w-14 text-right">{tooltipMaxWidth}px</span>
          </label>
          <button
            type="button"
            disabled={!highlight}
            onClick={() => {
              setTooltipTheme("dark");
              setTooltipFontSize(11);
              setTooltipMaxWidth(360);
            }}
            className="rounded border border-hairline px-2 py-1 hover:bg-muted disabled:opacity-40"
          >
            Reset
          </button>

          <div className="ml-auto flex items-center gap-2" aria-label="Tooltip preview">
            <span className="text-muted-foreground">Preview</span>
            <div
              style={{
                maxWidth: `${tooltipMaxWidth}px`,
                background: tooltipThemeSpec(tooltipTheme).bg,
                color: tooltipThemeSpec(tooltipTheme).fg,
                border: `1px solid ${tooltipThemeSpec(tooltipTheme).border}`,
                boxShadow: tooltipThemeSpec(tooltipTheme).shadow,
                font: `500 ${tooltipFontSize}px/1.4 ui-sans-serif, system-ui, -apple-system, sans-serif`,
                borderRadius: 6,
                padding: "6px 8px",
                whiteSpace: "pre-wrap",
                wordBreak: "break-word",
              }}
            >
              {`<button#save.btn.btn-primary>\nrule: allow-scroll-x-on-carousel  (sanctioned)`}
            </div>
          </div>
        </div>

        <div
          className={`mt-3 rounded-md border border-hairline bg-muted/10 p-3 text-xs ${
            highlight ? "" : "opacity-60"
          }`}
        >
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <span className="font-medium text-muted-foreground">
              Per route × kind overrides
            </span>
            <span className="text-[10px] text-muted-foreground">
              When set, they replace the global thickness/opacity for that
              exact (pathname, kind) pair.
            </span>
            <button
              type="button"
              disabled={!highlight}
              onClick={() => {
                const key = overrideKey(pathname, probe.kind);
                setOutlineOverrides((prev) => ({
                  ...prev,
                  [key]: {
                    thickness: prev[key]?.thickness ?? highlightThickness,
                    opacity: prev[key]?.opacity ?? highlightOpacity,
                  },
                }));
                if (highlight) applyHighlights();
              }}
              className="ml-auto rounded border border-hairline px-2 py-1 hover:bg-muted disabled:opacity-40"
            >
              Add / update current ({pathname} · {probe.kind})
            </button>
          </div>
          {Object.keys(outlineOverrides).length === 0 ? (
            <p className="text-[11px] italic text-muted-foreground">
              No overrides yet — using global values everywhere.
            </p>
          ) : (
            <table className="w-full border-separate border-spacing-y-1">
              <thead>
                <tr className="text-left text-[10px] uppercase tracking-wide text-muted-foreground">
                  <th className="pr-2">Route</th>
                  <th className="pr-2">Kind</th>
                  <th className="pr-2">Thickness</th>
                  <th className="pr-2">Opacity</th>
                  <th className="pr-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(outlineOverrides).map(([key, ovr]) => {
                  const [rPath, rKind] = key.split("::");
                  const isActive = key === overrideKey(pathname, probe.kind);
                  const effThick = ovr.thickness ?? highlightThickness;
                  const effOpac = ovr.opacity ?? highlightOpacity;
                  return (
                    <tr
                      key={key}
                      className={`text-[11px] ${isActive ? "bg-primary/10" : ""}`}
                    >
                      <td className="pr-2 font-mono">{rPath}</td>
                      <td className="pr-2 font-mono">{rKind}</td>
                      <td className="pr-2">
                        <input
                          type="number"
                          min={1}
                          max={8}
                          step={1}
                          value={effThick}
                          onChange={(e) => {
                            const n = Number(e.target.value);
                            setOutlineOverrides((prev) => ({
                              ...prev,
                              [key]: {
                                ...prev[key],
                                thickness: Math.max(1, Math.min(8, Math.round(n))),
                              },
                            }));
                            if (isActive && highlight) applyHighlights();
                          }}
                          className="w-14 rounded border border-hairline bg-background px-1 py-0.5 text-right tabular-nums"
                          aria-label={`Thickness for ${rPath} ${rKind}`}
                        />
                      </td>
                      <td className="pr-2">
                        <input
                          type="number"
                          min={0.2}
                          max={1}
                          step={0.05}
                          value={effOpac}
                          onChange={(e) => {
                            const n = Number(e.target.value);
                            setOutlineOverrides((prev) => ({
                              ...prev,
                              [key]: {
                                ...prev[key],
                                opacity: Math.max(0.2, Math.min(1, n)),
                              },
                            }));
                            if (isActive && highlight) applyHighlights();
                          }}
                          className="w-16 rounded border border-hairline bg-background px-1 py-0.5 text-right tabular-nums"
                          aria-label={`Opacity for ${rPath} ${rKind}`}
                        />
                      </td>
                      <td className="pr-2 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            setOutlineOverrides((prev) => {
                              const next = { ...prev };
                              delete next[key];
                              return next;
                            });
                            if (isActive && highlight) applyHighlights();
                          }}
                          className="rounded border border-rose-500/40 px-2 py-0.5 text-[11px] font-medium hover:bg-rose-500/20"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>




        {/* Re-import previously exported probe file — two slots for A/B diff */}
        <div className="mt-4 rounded-md border border-hairline bg-muted/10 p-3">
          <div className="mb-3">
            <h3 className="text-sm font-medium">Re-import probe export</h3>
            <p className="mt-0.5 text-[11px] text-muted-foreground">
              Load one or two previously exported <code>motion-allowlist-probe</code>{" "}
              JSON/CSV files. Load both to see a side-by-side diff of matched
              (ruleId × selector × kind) pairs, grouped by <code>exportedAt</code>.
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            {(["a", "b"] as ImportSlot[]).map((slot) => {
              const imported = importedProbes[slot];
              const err =
                importedProbeError?.slot === slot ? importedProbeError.message : null;
              return (
                <ImportedProbeCard
                  key={slot}
                  slot={slot}
                  imported={imported}
                  error={err}
                  onFile={(f) => handleImportProbeFile(slot, f)}
                  onClear={() => {
                    setImportedProbes((prev) => ({ ...prev, [slot]: null }));
                    if (importedProbeError?.slot === slot) setImportedProbeError(null);
                  }}
                />
              );
            })}
          </div>

          {probeImportDiff && importedProbes.a && importedProbes.b && (
            <div className="mt-4 rounded-md border border-hairline bg-background/40 p-3 text-xs">
              <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2">
                <h4 className="text-sm font-medium">Diff (A → B)</h4>
                <div className="flex flex-wrap gap-2 text-[11px]">
                  <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-emerald-200">
                    +{probeImportDiff.counts.added} added
                  </span>
                  <span className="rounded bg-rose-500/20 px-2 py-0.5 text-rose-200">
                    −{probeImportDiff.counts.removed} removed
                  </span>
                  <span className="rounded bg-amber-500/20 px-2 py-0.5 text-amber-200">
                    ~{probeImportDiff.counts.changed} changed
                  </span>
                  <span className="rounded bg-muted px-2 py-0.5 text-muted-foreground">
                    {probeImportDiff.counts.unchanged} unchanged
                  </span>
                </div>
              </div>

              {/* Group headers by exportedAt */}
              <div className="mb-3 grid gap-2 md:grid-cols-2">
                <div className="rounded border border-hairline/60 bg-muted/20 p-2">
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    A · exportedAt
                  </div>
                  <div className="font-mono">
                    {importedProbes.a.exportedAt
                      ? new Date(importedProbes.a.exportedAt).toLocaleString()
                      : "—"}
                  </div>
                  <div className="mt-0.5 text-[10px] text-muted-foreground">
                    {importedProbes.a.fileName} · {importedProbes.a.pairs.length} pair(s)
                  </div>
                </div>
                <div className="rounded border border-hairline/60 bg-muted/20 p-2">
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    B · exportedAt
                  </div>
                  <div className="font-mono">
                    {importedProbes.b.exportedAt
                      ? new Date(importedProbes.b.exportedAt).toLocaleString()
                      : "—"}
                  </div>
                  <div className="mt-0.5 text-[10px] text-muted-foreground">
                    {importedProbes.b.fileName} · {importedProbes.b.pairs.length} pair(s)
                  </div>
                </div>
              </div>

              <div className="max-h-[24rem] overflow-auto rounded border border-hairline">
                <table className="w-full text-[11px]">
                  <thead className="sticky top-0 bg-background text-left text-muted-foreground">
                    <tr>
                      <th className="py-1 pl-2 pr-2">Status</th>
                      <th className="py-1 pr-2">Rule id</th>
                      <th className="py-1 pr-2">Selector</th>
                      <th className="py-1 pr-2">Kind</th>
                      <th className="py-1 pr-2 text-right">A</th>
                      <th className="py-1 pr-2 text-right">B</th>
                      <th className="py-1 pr-2 text-right">Δ</th>
                    </tr>
                  </thead>
                  <tbody className="font-mono">
                    {probeImportDiff.rows.map((r) => {
                      const badge =
                        r.status === "added"
                          ? "bg-emerald-500/20 text-emerald-200"
                          : r.status === "removed"
                            ? "bg-rose-500/20 text-rose-200"
                            : r.status === "changed"
                              ? "bg-amber-500/20 text-amber-200"
                              : "bg-muted text-muted-foreground";
                      const delta = r.countB - r.countA;
                      return (
                        <tr key={r.key} className="border-t border-hairline/50">
                          <td className="py-1 pl-2 pr-2">
                            <span className={`rounded px-1.5 py-0.5 text-[10px] ${badge}`}>
                              {r.status}
                            </span>
                          </td>
                          <td className="py-1 pr-2">{r.ruleId || <span className="text-muted-foreground">(no match)</span>}</td>
                          <td className="py-1 pr-2 max-w-[24rem] truncate" title={r.selector}>
                            {r.selector || "—"}
                          </td>
                          <td className="py-1 pr-2">{r.kind || "—"}</td>
                          <td className="py-1 pr-2 text-right tabular-nums">{r.countA}</td>
                          <td className="py-1 pr-2 text-right tabular-nums">{r.countB}</td>
                          <td
                            className={`py-1 pr-2 text-right tabular-nums ${
                              delta > 0
                                ? "text-emerald-300"
                                : delta < 0
                                  ? "text-rose-300"
                                  : "text-muted-foreground"
                            }`}
                          >
                            {delta > 0 ? `+${delta}` : delta}
                          </td>
                        </tr>
                      );
                    })}
                    {probeImportDiff.rows.length === 0 && (
                      <tr>
                        <td colSpan={7} className="p-3 text-center text-muted-foreground">
                          No pairs found in either export.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>


        {/* Export filters */}
        <div className="mt-4 rounded-md border border-hairline bg-muted/20 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-medium">Export filters</h3>
            <span className="text-[11px] text-muted-foreground">
              {filteredRowCount} row(s) across {filteredSources.length} run(s) will be exported
            </span>
          </div>

          <div className="mt-3 grid gap-3 md:grid-cols-3">
            {/* Mode */}
            <fieldset className="rounded-md border border-hairline p-2">
              <legend className="px-1 text-[11px] uppercase tracking-wide text-muted-foreground">
                Include
              </legend>
              {(["both", "sanctioned", "leaks"] as ExportMode[]).map((m) => (
                <label key={m} className="flex items-center gap-2 py-1 text-xs">
                  <input
                    type="radio"
                    name="exportMode"
                    checked={exportMode === m}
                    onChange={() => setExportMode(m)}
                  />
                  <span>
                    {m === "both"
                      ? "Sanctioned + unsuppressed leaks"
                      : m === "sanctioned"
                        ? "Sanctioned matches only"
                        : "Unsuppressed leaks only"}
                  </span>
                </label>
              ))}
              <label className="mt-2 flex items-center gap-2 border-t border-hairline pt-2 text-xs">
                <input
                  type="checkbox"
                  checked={useSnapshots}
                  onChange={(e) => setUseSnapshots(e.target.checked)}
                />
                <span>Include saved snapshots ({snapshots.length})</span>
              </label>
            </fieldset>

            {/* Routes */}
            <fieldset className="rounded-md border border-hairline p-2">
              <legend className="px-1 text-[11px] uppercase tracking-wide text-muted-foreground">
                Routes ({routeFilter.size === 0 ? "all" : routeFilter.size})
              </legend>
              <div className="mb-1 flex gap-2 text-[11px]">
                <button
                  type="button"
                  className="underline decoration-dotted"
                  onClick={() => setRouteFilter(new Set(availableRoutes))}
                >
                  select all
                </button>
                <button
                  type="button"
                  className="underline decoration-dotted"
                  onClick={() => setRouteFilter(new Set())}
                >
                  clear
                </button>
              </div>
              <div className="max-h-32 overflow-auto">
                {availableRoutes.length === 0 && (
                  <p className="text-[11px] text-muted-foreground">
                    Run a probe or enable snapshots to populate.
                  </p>
                )}
                {availableRoutes.map((r) => (
                  <label key={r} className="flex items-center gap-2 py-0.5 text-xs">
                    <input
                      type="checkbox"
                      checked={routeFilter.has(r)}
                      onChange={() => toggleInSet(routeFilter, r, setRouteFilter)}
                    />
                    <code className="truncate">{r}</code>
                  </label>
                ))}
              </div>
            </fieldset>

            {/* Kinds */}
            <fieldset className="rounded-md border border-hairline p-2">
              <legend className="px-1 text-[11px] uppercase tracking-wide text-muted-foreground">
                Kinds ({kindFilter.size === 0 ? "all" : kindFilter.size})
              </legend>
              <div className="mb-1 flex gap-2 text-[11px]">
                <button
                  type="button"
                  className="underline decoration-dotted"
                  onClick={() => setKindFilter(new Set(availableKinds))}
                >
                  select all
                </button>
                <button
                  type="button"
                  className="underline decoration-dotted"
                  onClick={() => setKindFilter(new Set())}
                >
                  clear
                </button>
              </div>
              {availableKinds.length === 0 && (
                <p className="text-[11px] text-muted-foreground">
                  Run a probe or enable snapshots to populate.
                </p>
              )}
              {availableKinds.map((k) => (
                <label key={k} className="flex items-center gap-2 py-0.5 text-xs">
                  <input
                    type="checkbox"
                    checked={kindFilter.has(k)}
                    onChange={() => toggleInSet(kindFilter, k, setKindFilter)}
                  />
                  <code>{k}</code>
                </label>
              ))}
            </fieldset>
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">
            Filters apply to the Export JSON / CSV buttons above. Empty route or
            kind selections mean "all".
          </p>
        </div>
        {result && (
          <pre className="mt-3 max-h-72 overflow-auto rounded-md bg-muted/40 p-3 text-xs">
            {result}
          </pre>
        )}

        {highlight && (
          <p className="mt-2 flex items-center gap-3 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <span className="inline-block h-2 w-4 rounded-sm outline outline-2 outline-dashed" style={{ outlineColor: "rgb(16 185 129)" }} />
              allowlisted
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="inline-block h-2 w-4 rounded-sm outline outline-2 outline-dashed" style={{ outlineColor: "rgb(244 63 94)" }} />
              no matching rule
            </span>
          </p>
        )}
        <p className="mt-2 text-[11px] text-muted-foreground">
          Runs <code>document.querySelectorAll</code> against the currently
          rendered admin page. Enable <em>Highlight matches</em> to outline
          every element on the page (emerald = allowlisted, rose = no
          matching rule). Open another route in a new tab to probe its DOM.
        </p>
      </section>

      <SelectorTesterPanel
        rules={mergedRules}
        onJumpToRule={(ruleId) => {
          navigate({
            search: (prev: Record<string, unknown>) => ({ ...prev, ruleId: ruleId || undefined }),
            replace: false,
          });
          setDiffFilterRuleId(ruleId);
          requestAnimationFrame(() => {
            const el = document.querySelector<HTMLElement>('[data-diff-filters]');
            el?.scrollIntoView({ behavior: "smooth", block: "start" });
          });
          toast.success(`Filtered diff to rule "${ruleId}"`);
        }}
        onSaveAsSnapshot={(sel, knd) => {
          runProbe({ selector: sel, kind: knd });
          toast.success("Saved tester run as snapshot");
        }}
      />

      <section data-allowlist-admin-ui className="mb-8 rounded-xl border border-hairline p-4">

        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            Coverage snapshots ({snapshots.length})
          </h2>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] text-muted-foreground">
              {syncing
                ? "Syncing…"
                : syncError
                  ? `Sync error: ${syncError}`
                  : lastSyncedAt
                    ? `Synced ${new Date(lastSyncedAt).toLocaleTimeString()}`
                    : "Local only"}
            </span>
            <button
              type="button"
              onClick={() => void syncSnapshots()}
              disabled={syncing}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40"
              title="Push local snapshots to the backend and pull remote ones"
            >
              Sync now
            </button>
            <button
              type="button"
              onClick={() => {
                if (!currentSnapshot) return;
                const id = currentSnapshot.id;
                deleteSnapshot(id);
                void deleteRemote({ data: { id } }).catch((e) =>
                  setSyncError(e?.message ?? "Remote delete failed"),
                );
              }}
              disabled={!currentSnapshot}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40"
              title="Delete the most recent snapshot (local + remote)"
            >
              Delete latest
            </button>
            <button
              type="button"
              onClick={() => {
                if (confirm("Clear all saved probe snapshots (local + remote)?")) {
                  clearSnapshots();
                  void clearRemote().catch((e) =>
                    setSyncError(e?.message ?? "Remote clear failed"),
                  );
                }
              }}
              disabled={snapshots.length === 0}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40"
            >
              Clear all
            </button>
          </div>
        </div>

        {!currentSnapshot ? (
          <p className="text-xs text-muted-foreground">
            Run a probe to capture your first snapshot. Snapshots are stored
            locally (last {20}) and can be diffed against any earlier run.
          </p>
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-md border border-hairline p-3 text-xs">
                <div className="mb-1 text-[10px] uppercase tracking-widest text-muted-foreground">
                  Current (today)
                </div>
                <div className="font-mono text-sm">{currentSnapshot.selector}</div>
                <div className="text-muted-foreground">
                  {currentSnapshot.kind} · {currentSnapshot.total} matches ·{" "}
                  {new Date(currentSnapshot.ranAt).toLocaleString()}
                </div>
                <div className="text-muted-foreground">on {currentSnapshot.pathname}</div>
              </div>
              <div className="rounded-md border border-hairline p-3 text-xs">
                <div className="mb-1 flex items-center justify-between gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <span>Compare against</span>
                </div>
                <select
                  className="w-full rounded-md border border-hairline bg-background px-2 py-1 font-mono text-sm"
                  value={compareId}
                  onChange={(e) => setCompareId(e.target.value)}
                >
                  <option value="">
                    Auto (previous run with same selector/kind)
                  </option>
                  {snapshots
                    .filter((s) => s.id !== currentSnapshot.id)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {new Date(s.ranAt).toLocaleString()} · {s.selector} · {s.kind} ·{" "}
                        {s.total}
                      </option>
                    ))}
                </select>
                <div className="mt-1 text-muted-foreground">
                  {previousSnapshot
                    ? `Baseline: ${previousSnapshot.total} matches at ${new Date(previousSnapshot.ranAt).toLocaleString()}`
                    : "No prior snapshot — everything shows as added."}
                </div>
              </div>
            </div>

            {snapshots.length > 0 && (
              <div className="mt-4 rounded-md border border-hairline">
                <div className="flex items-center justify-between border-b border-hairline px-3 py-2 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <span>Stored snapshots ({snapshots.length})</span>
                  <span>Re-run reuses selector + kind and re-diffs against the snapshot</span>
                </div>
                <ul className="divide-y divide-hairline text-xs">
                  {snapshots.slice(0, 10).map((s) => {
                    const isCurrent = currentSnapshot?.id === s.id;
                    return (
                      <li key={s.id} className="flex flex-wrap items-center gap-2 px-3 py-2">
                        <div className="min-w-0 flex-1">
                          <div className="truncate font-mono">{s.selector}</div>
                          <div className="text-muted-foreground">
                            {s.kind} · {s.total} matches · {new Date(s.ranAt).toLocaleString()} · {s.pathname}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setCompareId(s.id);
                            runProbe({ selector: s.selector, kind: s.kind });
                            toast.success(`Re-running ${s.selector} (${s.kind}) vs snapshot`);
                          }}
                          disabled={isCurrent}
                          className="rounded-md border border-hairline px-2 py-1 hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
                          title={
                            isCurrent
                              ? "This is the latest snapshot"
                              : `Re-run ${s.selector} (${s.kind}) and diff against this snapshot`
                          }
                        >
                          Re-run
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (!currentSnapshot || isCurrent) return;
                            if (
                              !confirm(
                                `Promote the latest run (${currentSnapshot.total} matches at ${new Date(
                                  currentSnapshot.ranAt,
                                ).toLocaleString()}) as the new baseline for this snapshot?\n\nThe stored baseline rows will be replaced. This cannot be undone.`,
                              )
                            )
                              return;
                            const updated = updateSnapshot(s.id, {
                              rows: currentSnapshot.rows,
                              total: currentSnapshot.total,
                              ranAt: currentSnapshot.ranAt,
                              pathname: currentSnapshot.pathname,
                            });
                            if (!updated) {
                              toast.error("Snapshot not found");
                              return;
                            }
                            void upsertRemote({
                              data: {
                                id: updated.id,
                                ranAt: updated.ranAt,
                                pathname: updated.pathname,
                                selector: updated.selector,
                                kind: updated.kind,
                                total: updated.total,
                                rows: updated.rows,
                              },
                            }).catch((e) =>
                              setSyncError(e?.message ?? "Remote baseline update failed"),
                            );
                            toast.success("Baseline updated");
                          }}
                          disabled={isCurrent || !currentSnapshot}
                          className="rounded-md border border-hairline px-2 py-1 hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
                          title={
                            isCurrent
                              ? "This is the latest snapshot"
                              : "Replace this snapshot's rows with the latest run so future diffs use it as the new baseline"
                          }
                        >
                          Set as baseline
                        </button>
                        <button
                          type="button"
                          onClick={() => exportSnapshotDiff(s, "json")}
                          disabled={isCurrent || !currentSnapshot}
                          className="rounded-md border border-hairline px-2 py-1 hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
                          title="Download diff (current vs this snapshot) as JSON"
                        >
                          Export JSON
                        </button>
                        <button
                          type="button"
                          onClick={() => exportSnapshotDiff(s, "csv")}
                          disabled={isCurrent || !currentSnapshot}
                          className="rounded-md border border-hairline px-2 py-1 hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
                          title="Download diff (current vs this snapshot) as CSV"
                        >
                          Export CSV
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            {diff && (diff.added > 0 || diff.changed > 0) && (
              <div
                role="alert"
                className="mt-4 flex flex-wrap items-center gap-3 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-800 dark:text-amber-200"
              >
                <span aria-hidden className="text-base leading-none">⚠</span>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold">
                    Today's run has {diff.added > 0 ? `${diff.added} newly added` : ""}
                    {diff.added > 0 && diff.changed > 0 ? " and " : ""}
                    {diff.changed > 0 ? `${diff.changed} rule-changed` : ""} match
                    {diff.added + diff.changed === 1 ? "" : "es"}.
                  </div>
                  <div className="opacity-80">
                    Review before shipping — new leaks or rule regressions can bypass motion policy.
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {diff.added > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        navigate({
                          search: (prev: Record<string, unknown>) => ({ ...prev, jump: "added", sig: undefined }),
                          replace: true,
                        });
                        jumpToDiffRow("added");
                      }}
                      className="rounded-md border border-amber-500/50 bg-background/60 px-2 py-1 font-medium hover:bg-background"
                      title="Deep-link and scroll to the first newly added row"
                    >
                      Jump to added ({diff.added})
                    </button>
                  )}
                  {diff.changed > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        navigate({
                          search: (prev: Record<string, unknown>) => ({ ...prev, jump: "changed", sig: undefined }),
                          replace: true,
                        });
                        jumpToDiffRow("changed");
                      }}
                      className="rounded-md border border-amber-500/50 bg-background/60 px-2 py-1 font-medium hover:bg-background"
                      title="Deep-link and scroll to the first rule-changed row"
                    >
                      Jump to rule-changed ({diff.changed})
                    </button>
                  )}
                </div>
              </div>
            )}

            {diff && (
              <>
                <div data-diff-filters className="mt-4 flex flex-wrap items-end gap-3 rounded-md border border-hairline bg-muted/30 p-2 text-xs">
                  <div className="flex flex-col gap-1">
                    <label htmlFor="diff-filter-rule" className="text-muted-foreground">
                      Filter by rule id
                    </label>
                    <input
                      id="diff-filter-rule"
                      type="text"
                      value={diffFilterRuleId}
                      onChange={(e) => setDiffFilterRuleId(e.target.value)}
                      placeholder="substring, e.g. motion.card"
                      className="w-56 rounded-md border border-hairline bg-background px-2 py-1"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label htmlFor="diff-filter-status" className="text-muted-foreground">
                      Status
                    </label>
                    <select
                      id="diff-filter-status"
                      value={diffFilterStatus}
                      onChange={(e) =>
                        setDiffFilterStatus(e.target.value as "all" | "sanctioned" | "leak")
                      }
                      className="rounded-md border border-hairline bg-background px-2 py-1"
                    >
                      <option value="all">All (sanctioned + leak)</option>
                      <option value="sanctioned">Sanctioned (has rule id)</option>
                      <option value="leak">Leak (no rule id)</option>
                    </select>
                  </div>
                  <div className="ml-auto flex items-center gap-2">
                    <span className="text-muted-foreground">
                      Export scope: <span className="font-medium text-foreground">{filteredDiffChanged.length}</span> of {diff.added + diff.removed + diff.changed} changed row
                      {diff.added + diff.removed + diff.changed === 1 ? "" : "s"}
                      {" · "}
                      <span className="font-medium text-foreground">{filteredDiffAll.length}</span> of {diff.entries.length} full
                    </span>
                    {(diffFilterRuleId || diffFilterStatus !== "all") && (
                      <button
                        type="button"
                        onClick={() => {
                          setDiffFilterRuleId("");
                          setDiffFilterStatus("all");
                        }}
                        className="rounded-md border border-hairline px-2 py-1 hover:bg-muted"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>





                <div className="mt-4 flex flex-wrap gap-2 text-xs">
                  <span className="rounded-md border border-hairline bg-emerald-500/10 px-2 py-1 text-emerald-600 dark:text-emerald-400">
                    +{diff.added} added
                  </span>
                  <span className="rounded-md border border-hairline bg-rose-500/10 px-2 py-1 text-rose-600 dark:text-rose-400">
                    −{diff.removed} removed
                  </span>
                  <span className="rounded-md border border-hairline bg-amber-500/10 px-2 py-1 text-amber-700 dark:text-amber-400">
                    ~{diff.changed} rule changed
                  </span>
                  <span className="rounded-md border border-hairline px-2 py-1 text-muted-foreground">
                    ={diff.unchanged} unchanged
                  </span>
                  <div className="ml-auto flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (!diff || !currentSnapshot) return;
                        const changed = filteredDiffChanged;

                        const payload = {
                          schemaVersion: 1,
                          exportKind: "motion-coverage-diff",
                          exportedAt: new Date().toISOString(),
                          generator: "admin.motion-allowlist",
                          baseline: previousSnapshot
                            ? {
                                id: previousSnapshot.id,
                                ranAt: previousSnapshot.ranAt,
                                pathname: previousSnapshot.pathname,
                                selector: previousSnapshot.selector,
                                kind: previousSnapshot.kind,
                                total: previousSnapshot.total,
                              }
                            : null,
                          current: {
                            id: currentSnapshot.id,
                            ranAt: currentSnapshot.ranAt,
                            pathname: currentSnapshot.pathname,
                            selector: currentSnapshot.selector,
                            kind: currentSnapshot.kind,
                            total: currentSnapshot.total,
                          },
                          summary: {
                            added: diff.added,
                            removed: diff.removed,
                            changed: diff.changed,
                            unchanged: diff.unchanged,
                            exportedRows: changed.length,
                          },
                          filters: {
                            ruleId: diffFilterRuleId || null,
                            status: diffFilterStatus,
                          },

                          entries: changed.map((e) => ({
                            status: e.status,
                            signature: e.signature,
                            before: e.before ?? null,
                            after: e.after ?? null,
                          })),
                        };
                        const blob = new Blob([JSON.stringify(payload, null, 2)], {
                          type: "application/json",
                        });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `motion-coverage-diff-v1-${payload.exportedAt.replace(/[:.]/g, "-")}.json`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        URL.revokeObjectURL(url);
                        toast.success(`Exported diff (${changed.length} rows)`);
                      }}
                      disabled={!diff || filteredDiffChanged.length === 0}
                      className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Download filtered added/removed/rule-changed entries as JSON"

                    >
                      Export diff JSON
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!diff || !currentSnapshot) return;
                        const changed = filteredDiffChanged;
                        const exportedAt = new Date().toISOString();
                        const esc = (v: unknown) => {
                          const s = v == null ? "" : String(v);
                          return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
                        };
                        const header = [
                          "schemaVersion",
                          "exportedAt",
                          "status",
                          "signature",
                          "kind",
                          "tag",
                          "id",
                          "classes",
                          "beforeRuleId",
                          "afterRuleId",
                          "beforeSnapshotId",
                          "currentSnapshotId",
                          "currentPathname",
                        ];
                        const meta = [
                          `# schemaVersion=1`,
                          `# exportKind=motion-coverage-diff`,
                          `# exportedAt=${exportedAt}`,
                          `# baselineId=${previousSnapshot?.id ?? ""}`,
                          `# currentId=${currentSnapshot.id}`,
                          `# selector=${currentSnapshot.selector}`,
                          `# kind=${currentSnapshot.kind}`,
                          `# filterRuleId=${diffFilterRuleId}`,
                          `# filterStatus=${diffFilterStatus}`,

                        ].join("\n");
                        const rows = changed.map((e) => {
                          const ref = e.after ?? e.before;
                          return [
                            1,
                            exportedAt,
                            e.status,
                            e.signature,
                            ref?.kind ?? currentSnapshot.kind,
                            ref?.tag ?? "",
                            ref?.id ?? "",
                            ref?.classes ?? "",
                            e.before?.ruleId ?? "",
                            e.after?.ruleId ?? "",
                            previousSnapshot?.id ?? "",
                            currentSnapshot.id,
                            currentSnapshot.pathname,
                          ]
                            .map(esc)
                            .join(",");
                        });
                        const csv = [meta, header.join(","), ...rows].join("\n") + "\n";
                        const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `motion-coverage-diff-v1-${exportedAt.replace(/[:.]/g, "-")}.csv`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        URL.revokeObjectURL(url);
                        toast.success(`Exported diff (${changed.length} rows)`);
                      }}
                      disabled={!diff || filteredDiffChanged.length === 0}
                      className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Download filtered added/removed/rule-changed entries as CSV"

                    >
                      Export diff CSV
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!diff || !currentSnapshot) return;
                        const rowsAll = filteredDiffAll;
                        const payload = {
                          schemaVersion: 1,
                          exportKind: "motion-coverage-diff-full",
                          exportedAt: new Date().toISOString(),
                          generator: "admin.motion-allowlist",
                          baseline: previousSnapshot
                            ? {
                                id: previousSnapshot.id,
                                ranAt: previousSnapshot.ranAt,
                                pathname: previousSnapshot.pathname,
                                selector: previousSnapshot.selector,
                                kind: previousSnapshot.kind,
                                total: previousSnapshot.total,
                              }
                            : null,
                          current: {
                            id: currentSnapshot.id,
                            ranAt: currentSnapshot.ranAt,
                            pathname: currentSnapshot.pathname,
                            selector: currentSnapshot.selector,
                            kind: currentSnapshot.kind,
                            total: currentSnapshot.total,
                          },
                          summary: {
                            added: diff.added,
                            removed: diff.removed,
                            changed: diff.changed,
                            unchanged: diff.unchanged,
                            exportedRows: rowsAll.length,
                          },
                          filters: {
                            ruleId: diffFilterRuleId || null,
                            status: diffFilterStatus,
                            includeUnchanged: true,
                          },
                          entries: rowsAll.map((e) => ({
                            status: e.status,
                            signature: e.signature,
                            before: e.before ?? null,
                            after: e.after ?? null,
                          })),
                        };
                        const blob = new Blob([JSON.stringify(payload, null, 2)], {
                          type: "application/json",
                        });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `motion-coverage-diff-full-v1-${payload.exportedAt.replace(/[:.]/g, "-")}.json`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        URL.revokeObjectURL(url);
                        toast.success(`Exported full diff (${rowsAll.length} rows)`);
                      }}
                      disabled={!diff || filteredDiffAll.length === 0}
                      className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Download all entries incl. unchanged as JSON"
                    >
                      Export full JSON
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!diff || !currentSnapshot) return;
                        const rowsAll = filteredDiffAll;
                        const exportedAt = new Date().toISOString();
                        const esc = (v: unknown) => {
                          const s = v == null ? "" : String(v);
                          return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
                        };
                        const header = [
                          "schemaVersion",
                          "exportedAt",
                          "status",
                          "signature",
                          "kind",
                          "tag",
                          "id",
                          "classes",
                          "beforeRuleId",
                          "afterRuleId",
                          "beforeSnapshotId",
                          "currentSnapshotId",
                          "currentPathname",
                        ];
                        const meta = [
                          `# schemaVersion=1`,
                          `# exportKind=motion-coverage-diff-full`,
                          `# exportedAt=${exportedAt}`,
                          `# baselineId=${previousSnapshot?.id ?? ""}`,
                          `# currentId=${currentSnapshot.id}`,
                          `# selector=${currentSnapshot.selector}`,
                          `# kind=${currentSnapshot.kind}`,
                          `# filterRuleId=${diffFilterRuleId}`,
                          `# filterStatus=${diffFilterStatus}`,
                          `# includeUnchanged=true`,
                        ].join("\n");
                        const rows = rowsAll.map((e) => {
                          const ref = e.after ?? e.before;
                          return [
                            1,
                            exportedAt,
                            e.status,
                            e.signature,
                            ref?.kind ?? currentSnapshot.kind,
                            ref?.tag ?? "",
                            ref?.id ?? "",
                            ref?.classes ?? "",
                            e.before?.ruleId ?? "",
                            e.after?.ruleId ?? "",
                            previousSnapshot?.id ?? "",
                            currentSnapshot.id,
                            currentSnapshot.pathname,
                          ]
                            .map(esc)
                            .join(",");
                        });
                        const csv = [meta, header.join(","), ...rows].join("\n") + "\n";
                        const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `motion-coverage-diff-full-v1-${exportedAt.replace(/[:.]/g, "-")}.csv`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        URL.revokeObjectURL(url);
                        toast.success(`Exported full diff (${rowsAll.length} rows)`);
                      }}
                      disabled={!diff || filteredDiffAll.length === 0}
                      className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Download all entries incl. unchanged as CSV"
                    >
                      Export full CSV
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!diff || !currentSnapshot) return;
                        const XLSX = await import("xlsx");
                        const exportedAt = new Date().toISOString();
                        const buildSheet = (rows: DiffSummary["entries"]) => {
                          const aoa: (string | number)[][] = [[
                            "status",
                            "signature",
                            "kind",
                            "tag",
                            "id",
                            "classes",
                            "beforeRuleId",
                            "afterRuleId",
                            "beforeSnapshotId",
                            "currentSnapshotId",
                            "currentPathname",
                          ]];
                          for (const e of rows) {
                            const ref = e.after ?? e.before;
                            aoa.push([
                              e.status,
                              e.signature,
                              ref?.kind ?? currentSnapshot.kind,
                              ref?.tag ?? "",
                              ref?.id ?? "",
                              ref?.classes ?? "",
                              e.before?.ruleId ?? "",
                              e.after?.ruleId ?? "",
                              previousSnapshot?.id ?? "",
                              currentSnapshot.id,
                              currentSnapshot.pathname,
                            ]);
                          }
                          const ws = XLSX.utils.aoa_to_sheet(aoa);
                          ws["!cols"] = [
                            { wch: 10 }, { wch: 32 }, { wch: 10 }, { wch: 8 },
                            { wch: 18 }, { wch: 24 }, { wch: 18 }, { wch: 18 },
                            { wch: 22 }, { wch: 22 }, { wch: 28 },
                          ];
                          ws["!autofilter"] = {
                            ref: XLSX.utils.encode_range({
                              s: { r: 0, c: 0 },
                              e: { r: Math.max(0, aoa.length - 1), c: 10 },
                            }),
                          };
                          return ws;
                        };
                        const summaryAoa: (string | number)[][] = [
                          ["Motion coverage diff"],
                          [],
                          ["schemaVersion", 1],
                          ["exportKind", "motion-coverage-diff-xlsx"],
                          ["exportedAt", exportedAt],
                          ["baselineId", previousSnapshot?.id ?? ""],
                          ["baselineRanAt", previousSnapshot?.ranAt ?? ""],
                          ["currentId", currentSnapshot.id],
                          ["currentRanAt", currentSnapshot.ranAt],
                          ["pathname", currentSnapshot.pathname],
                          ["selector", currentSnapshot.selector],
                          ["kind", currentSnapshot.kind],
                          [],
                          ["Counts"],
                          ["added", diff.added],
                          ["removed", diff.removed],
                          ["changed", diff.changed],
                          ["unchanged", diff.unchanged],
                          [],
                          ["Filters"],
                          ["ruleId", diffFilterRuleId || ""],
                          ["status", diffFilterStatus],
                          ["changedRowsExported", filteredDiffChanged.length],
                          ["fullRowsExported", filteredDiffAll.length],
                        ];
                        const summary = XLSX.utils.aoa_to_sheet(summaryAoa);
                        summary["!cols"] = [{ wch: 22 }, { wch: 48 }];
                        const wb = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(wb, summary, "Summary");
                        XLSX.utils.book_append_sheet(wb, buildSheet(filteredDiffChanged), "Diff (changed)");
                        XLSX.utils.book_append_sheet(wb, buildSheet(filteredDiffAll), "Full (incl. unchanged)");
                        const out = XLSX.write(wb, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
                        const blob = new Blob([out], {
                          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `motion-coverage-diff-v1-${exportedAt.replace(/[:.]/g, "-")}.xlsx`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        URL.revokeObjectURL(url);
                        toast.success(
                          `Exported XLSX (${filteredDiffChanged.length} changed / ${filteredDiffAll.length} full)`,
                        );
                      }}
                      disabled={!diff || (filteredDiffChanged.length === 0 && filteredDiffAll.length === 0)}
                      className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Download diff as a multi-sheet XLSX workbook (Summary / Changed / Full)"
                    >
                      Export diff XLSX
                    </button>
                    <DiffXlsxExportDialog
                      diff={diff}
                      currentSnapshot={currentSnapshot}
                      previousSnapshot={previousSnapshot}
                      changedRows={filteredDiffChanged}
                      fullRows={filteredDiffAll}
                      previewRows={filteredDiffChanged}
                      diffFilterRuleId={diffFilterRuleId}
                      diffFilterStatus={diffFilterStatus}
                    />
                  </div>
                </div>


                {/* Export preview — shows the exact rows that will be written */}
                {diff && (
                  <ExportPreview
                    changedRows={filteredDiffChanged}
                    fullRows={filteredDiffAll}
                  />
                )}




                <div id="motion-diff-table" className="mt-3 max-h-80 overflow-auto rounded-md border border-hairline">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-muted/60 text-left">
                      <tr>
                        <th className="px-2 py-1 font-medium">Status</th>
                        <th className="px-2 py-1 font-medium">Element</th>
                        <th className="px-2 py-1 font-medium">Before</th>
                        <th className="px-2 py-1 font-medium">After</th>
                        <th className="px-2 py-1 font-medium w-16">Link</th>
                      </tr>
                    </thead>
                    <tbody>
                      {diff.entries
                        .filter((e) => e.status !== "unchanged")
                        .slice(0, 500)
                        .map((e) => {
                          const badge =
                            e.status === "added"
                              ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                              : e.status === "removed"
                                ? "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                                : "bg-amber-500/10 text-amber-700 dark:text-amber-400";
                          const rowId = `diff-row-${e.signature.replace(/[^a-z0-9_-]/gi, "_")}`;
                          const isFocused = routeSearch.sig === e.signature;
                          return (
                            <tr
                              key={e.signature}
                              id={rowId}
                              tabIndex={-1}
                              data-diff-status={e.status}
                              data-diff-signature={e.signature}
                              className={`border-t border-hairline align-top transition-shadow outline-none focus-visible:ring-2 focus-visible:ring-amber-500/70 ${
                                isFocused ? "bg-amber-500/10 ring-1 ring-amber-500/60" : ""
                              }`}
                            >

                              <td className="px-2 py-1">
                                <span className={`rounded px-1.5 py-0.5 font-mono ${badge}`}>
                                  {e.status}
                                </span>
                              </td>
                              <td className="px-2 py-1 font-mono break-all">{e.signature}</td>
                              <td className="px-2 py-1 font-mono text-muted-foreground">
                                {e.before?.ruleId ?? (e.before ? "(no match)" : "—")}
                              </td>
                              <td className="px-2 py-1 font-mono">
                                {e.after?.ruleId ?? (e.after ? "(no match)" : "—")}
                              </td>
                              <td className="px-2 py-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    navigate({
                                      search: (prev: Record<string, unknown>) => ({
                                        ...prev,
                                        sig: e.signature,
                                        jump: undefined,
                                      }),
                                      replace: true,
                                    });
                                    const params = new URLSearchParams();
                                    params.set("sig", e.signature);
                                    const rid = diffFilterRuleId.trim();
                                    if (rid) params.set("ruleId", rid);
                                    if (diffFilterStatus !== "all") params.set("status", diffFilterStatus);
                                    const url = `${window.location.origin}${window.location.pathname}?${params.toString()}`;
                                    navigator.clipboard?.writeText(url).catch(() => {});
                                    const bits: string[] = [];
                                    if (rid) bits.push(`rule "${rid}"`);
                                    if (diffFilterStatus !== "all") bits.push(diffFilterStatus);
                                    toast.success(
                                      bits.length
                                        ? `Deep link copied — preserves filters (${bits.join(", ")})`
                                        : "Deep link copied — opens focused on this row",
                                    );
                                  }}
                                  className="rounded border border-hairline px-1.5 py-0.5 text-[10px] hover:bg-muted"
                                  title="Copy a shareable URL that opens the diff table focused on this match row"
                                >
                                  🔗 Share
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      {diff.entries.every((e) => e.status === "unchanged") && (
                        <tr>
                          <td colSpan={5} className="px-2 py-3 text-center text-muted-foreground">
                            No differences vs. the baseline snapshot.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </>
        )}
      </section>



      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
          Rules ({scrollAllowlist.length})
        </h2>
        {(["scroll-snap", "scroll-behavior-smooth"] as ScrollAllowlistKind[]).map(
          (kind) => (
            <div key={kind} className="mb-4">
              <h3 className="mb-2 text-xs font-mono text-muted-foreground">
                {kind}
              </h3>
              <ul className="divide-y divide-hairline overflow-hidden rounded-xl border border-hairline">
                {(rulesByKind[kind] ?? []).map((r) => (
                  <li key={r.id} className="grid gap-1 px-4 py-3 text-sm">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded bg-emerald-500/10 px-1.5 py-px font-mono text-[11px] text-emerald-600 dark:text-emerald-400">
                        {r.id}
                      </span>
                      <code className="rounded bg-muted/50 px-1.5 py-px text-[11px]">
                        {r.selector}
                      </code>
                      {r.routes?.map((p) => (
                        <span
                          key={p}
                          className="rounded bg-muted px-1.5 py-px text-[10px] uppercase tracking-widest"
                        >
                          {p}
                        </span>
                      ))}
                      {r.requireHtmlAttr && (
                        <span className="rounded bg-amber-500/10 px-1.5 py-px text-[10px] text-amber-600 dark:text-amber-400">
                          when {r.requireHtmlAttr.name}
                          {r.requireHtmlAttr.value
                            ? `="${r.requireHtmlAttr.value}"`
                            : ""}
                        </span>
                      )}
                    </div>
                    <p className="text-muted-foreground">{r.reason}</p>
                  </li>
                ))}
                {(rulesByKind[kind] ?? []).length === 0 && (
                  <li className="px-4 py-3 text-sm text-muted-foreground">
                    No rules of this kind.
                  </li>
                )}
              </ul>
            </div>
          )
        )}
      </section>

      <section className="mt-8">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
            Candidate rules ({candidates.length})
          </h2>
          {candidates.length > 0 && (
            <button
              type="button"
              onClick={() => clearCandidates()}
              className="text-xs text-muted-foreground hover:text-foreground underline decoration-dotted"
            >
              Clear all
            </button>
          )}
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Auto-collected from repeated CSS scroll leaks in the runtime MotionDebugIndicator.
          Review each proposal; if genuinely user-driven, copy the snippet into{" "}
          <code>src/config/motion-scroll-allowlist.ts</code> and re-run{" "}
          <code>bun run gen:motion-allowlist</code>.
        </p>
        {candidates.length === 0 ? (
          <p className="rounded-xl border border-dashed border-hairline px-4 py-6 text-center text-sm text-muted-foreground">
            No candidates yet. Enable <code>?motionDebug=1</code> under reduced motion and browse
            the app — repeated CSS leaks will be grouped here.
          </p>
        ) : (
          <ul className="grid gap-3">
            {candidates
              .slice()
              .sort((a, b) => b.count - a.count)
              .map((c) => {
                const snippet = `{
  id: "${c.id}",
  kind: "${c.kind}",
  selector: ${JSON.stringify(c.selector)},
  reason: ${JSON.stringify(c.reason)},
},`;
                return (
                  <li key={c.id} className="rounded-xl border border-hairline p-4 text-sm">
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      <span className="rounded bg-amber-500/10 px-1.5 py-px font-mono text-[11px] text-amber-600 dark:text-amber-400">
                        {c.id}
                      </span>
                      <code className="rounded bg-muted/50 px-1.5 py-px text-[11px]">
                        {c.selector}
                      </code>
                      <span className="rounded bg-muted px-1.5 py-px text-[10px] uppercase tracking-widest text-muted-foreground">
                        {c.kind}
                      </span>
                      <span className="text-xs text-muted-foreground">×{c.count}</span>
                      <button
                        type="button"
                        onClick={() => removeCandidate(c.id)}
                        className="ml-auto text-xs text-muted-foreground hover:text-foreground underline decoration-dotted"
                      >
                        Dismiss
                      </button>
                    </div>
                    <p className="text-muted-foreground">{c.reason}</p>
                    {c.routes.length > 0 && (
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        seen on: {c.routes.join(", ")}
                      </p>
                    )}
                    <pre className="mt-2 overflow-auto rounded-md bg-muted/40 p-2 text-[11px]">
                      {snippet}
                    </pre>
                    <button
                      type="button"
                      onClick={() => navigator.clipboard?.writeText(snippet)}
                      className="mt-1 text-[11px] text-muted-foreground hover:text-foreground underline decoration-dotted"
                    >
                      Copy snippet
                    </button>
                  </li>
                );
              })}
          </ul>
        )}
      </section>
    </main>

  );
}

function MetaCell({
  label,
  value,
  mono = false,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="rounded-md border border-hairline bg-background/40 p-2">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div
        className={`mt-0.5 break-all ${mono ? "font-mono" : ""}`}
        title={value}
      >
        {value}
      </div>
    </div>
  );
}



// ---------------------------------------------------------------------------
// SelectorTesterPanel
// Read-only tester: parses a CSS selector, counts DOM matches, maps to a
// shipped rule, and previews the first 20 matched elements with rich
// identifiers. Never mutates the DOM unless the user explicitly opts into
// "Save as snapshot" (which delegates back to the parent's live probe).
// ---------------------------------------------------------------------------
function downloadBlobFile(name: string, mime: string, body: string) {
  const blob = new Blob([body], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function SelectorTesterPanel({
  rules = scrollAllowlist,
  onJumpToRule,
  onSaveAsSnapshot,
}: {
  rules?: ScrollAllowlistRule[];
  onJumpToRule?: (ruleId: string) => void;
  onSaveAsSnapshot?: (selector: string, kind: ScrollAllowlistKind) => void;
} = {}) {
  const [selector, setSelector] = useState<string>("");
  const [kind, setKind] = useState<ScrollAllowlistKind>("scroll-snap");
  const [tick, setTick] = useState(0);

  // Parse the browser's DOMException from querySelector to extract the exact
  // offending token when possible. Browsers phrase it either as:
  //   "'<token>' is not a valid selector."
  // or:
  //   "Failed to execute 'querySelector' on 'DocumentFragment': '<token>' ..."
  // We surface both a machine-readable reason and (when we can locate it) the
  // offending substring so the input can highlight it inline.
  const validation = useMemo<{
    error: string | null;
    reason: string | null;
    badToken: string | null;
  }>(() => {
    const t = selector.trim();
    if (!t) return { error: null, reason: null, badToken: null };
    try {
      document.createDocumentFragment().querySelector(t);
      return { error: null, reason: null, badToken: null };
    } catch (e) {
      const msg = (e as Error).message || "Invalid CSS selector syntax.";
      const m = msg.match(/'([^']+)'\s+is not a valid selector/);
      const token = m?.[1] ?? null;
      // Best-effort human reason: strip the noisy "Failed to execute" prefix.
      const reason = msg.replace(/^Failed to execute[^:]+:\s*/i, "").trim();
      return { error: msg, reason, badToken: token && t.includes(token) ? token : null };
    }
  }, [selector]);

  const validationError = validation.error;

  const result = useMemo(() => {
    const t = selector.trim();
    if (!t || validationError) return null;
    let matches: HTMLElement[] = [];
    try {
      matches = Array.from(document.querySelectorAll<HTMLElement>(t));
    } catch {
      return null;
    }
    const rule =
      rules.find((r) => r.kind === kind && r.selector === t) ?? null;
    return { matches, rule };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selector, kind, validationError, tick, rules]);

  const preview = useMemo(() => {
    if (!result) return [];
    return result.matches.slice(0, 20).map((el, i) => ({
      index: i,
      tag: el.tagName.toLowerCase(),
      id: el.id || "",
      classes: (el.className && typeof el.className === "string" ? el.className : "")
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 4)
        .join(" "),
      dataTestid: el.getAttribute("data-testid") || "",
      ariaLabel: el.getAttribute("aria-label") || "",
    }));
  }, [result]);

  const trimmed = selector.trim();
  const total = result?.matches.length ?? 0;

  function exportPreview(format: "json" | "csv") {
    if (!preview.length) return;
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const meta = {
      schemaVersion: 1,
      exportKind: "motion-selector-tester-preview",
      exportedAt: new Date().toISOString(),
      selector: trimmed,
      kind,
      totalMatches: total,
      previewCount: preview.length,
      shippedRuleId: result?.rule?.id ?? null,
    };
    if (format === "json") {
      downloadBlobFile(
        `motion-tester-preview_${stamp}.json`,
        "application/json",
        JSON.stringify({ ...meta, rows: preview }, null, 2),
      );
    } else {
      const header = [
        `# motion-selector-tester-preview`,
        `# selector=${trimmed}`,
        `# kind=${kind}`,
        `# totalMatches=${total}`,
        `# previewCount=${preview.length}`,
        `# shippedRuleId=${result?.rule?.id ?? ""}`,
      ].join("\n");
      const cols: Array<keyof (typeof preview)[number]> = [
        "index",
        "tag",
        "id",
        "classes",
        "dataTestid",
        "ariaLabel",
      ];
      const body = [cols.join(",")]
        .concat(
          preview.map((r) =>
            cols
              .map((c) => `"${String(r[c] ?? "").replace(/"/g, '""')}"`)
              .join(","),
          ),
        )
        .join("\n");
      downloadBlobFile(`motion-tester-preview_${stamp}.csv`, "text/csv", header + "\n" + body);
    }
    toast.success(`Exported ${preview.length} preview row(s)`);
  }

  // Split the selector around the offending token so we can highlight it.
  const highlighted = useMemo(() => {
    const token = validation.badToken;
    if (!token || !selector) return null;
    const idx = selector.indexOf(token);
    if (idx < 0) return null;
    return {
      before: selector.slice(0, idx),
      bad: selector.slice(idx, idx + token.length),
      after: selector.slice(idx + token.length),
    };
  }, [selector, validation.badToken]);

  return (
    <section data-allowlist-admin-ui className="mb-8 rounded-xl border border-hairline p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
          Selector tester
        </h2>
        <span className="text-[11px] text-muted-foreground">
          Read-only · no highlights, no snapshots (unless you save)
        </span>
      </div>

      <div className="flex flex-wrap items-end gap-2">
        <label className="flex flex-1 min-w-[280px] flex-col gap-1 text-xs">
          <span className="text-muted-foreground">Selector</span>
          <input
            className={`rounded-md border bg-background px-3 py-2 font-mono text-sm ${
              validationError ? "border-rose-500 focus:outline-rose-500" : "border-hairline"
            }`}
            value={selector}
            onChange={(e) => setSelector(e.target.value)}
            placeholder=".marquee, [data-carousel], #hero .snap-x > *"
            aria-invalid={validationError ? true : undefined}
            aria-describedby={validationError ? "tester-selector-error" : undefined}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs">
          <span className="text-muted-foreground">Kind</span>
          <select
            className="rounded-md border border-hairline bg-background px-3 py-2 text-sm"
            value={kind}
            onChange={(e) => setKind(e.target.value as ScrollAllowlistKind)}
          >
            <option value="scroll-snap">scroll-snap</option>
            <option value="scroll-behavior-smooth">scroll-behavior:smooth</option>
          </select>
        </label>
        <button
          type="button"
          onClick={() => setTick((n) => n + 1)}
          disabled={!!validationError || !trimmed}
          className="rounded-md border border-hairline px-3 py-2 text-sm hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
          title="Recount matches against the current DOM"
        >
          Recount
        </button>
        <button
          type="button"
          onClick={() => {
            setSelector("");
            setTick(0);
          }}
          disabled={!selector}
          className="rounded-md border border-hairline px-3 py-2 text-sm hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
        >
          Clear
        </button>
      </div>

      {validationError && (
        <div
          id="tester-selector-error"
          role="alert"
          className="mt-3 space-y-2 rounded-md border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-700 dark:text-rose-300"
        >
          <div>
            <strong>Malformed selector</strong> — {validation.reason ?? validationError}
          </div>
          {highlighted && (
            <div className="rounded bg-background/60 px-2 py-1 font-mono text-[11px]">
              <span>{highlighted.before}</span>
              <mark className="rounded bg-rose-500/30 px-0.5 text-rose-900 dark:text-rose-100">
                {highlighted.bad}
              </mark>
              <span>{highlighted.after}</span>
              <div className="mt-1 text-[10px] text-rose-600/80 dark:text-rose-300/80">
                Offending token: <code>{highlighted.bad}</code>
              </div>
            </div>
          )}
          <div>
            Expected a valid CSS selector, e.g. <code>[data-carousel]</code>,{" "}
            <code>.snap-x &gt; *</code>, <code>#hero .marquee</code>.
          </div>
        </div>
      )}

      {!validationError && trimmed && result && (
        <div className="mt-3 space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span
              className={`inline-flex items-center rounded-md border px-2 py-1 text-xs font-medium ${
                total > 0
                  ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
                  : "border-hairline bg-muted text-muted-foreground"
              }`}
            >
              {total} match{total === 1 ? "" : "es"}
            </span>
            {result.rule ? (
              <span className="inline-flex items-center gap-2 rounded-md border border-emerald-500/40 bg-emerald-500/10 px-2 py-1 text-xs text-emerald-700 dark:text-emerald-300">
                allowlisted rule: <code>{result.rule.id}</code>
                {onJumpToRule && (
                  <button
                    type="button"
                    onClick={() => onJumpToRule(result.rule!.id)}
                    className="rounded border border-emerald-500/40 bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-medium hover:bg-emerald-500/30"
                    title={`Filter the diff table to rule "${result.rule.id}" and scroll to it`}
                  >
                    Jump to rule →
                  </button>
                )}
              </span>
            ) : (
              <span className="inline-flex items-center rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-xs text-amber-700 dark:text-amber-300">
                no matching rule for kind <code className="ml-1">{kind}</code>
              </span>
            )}
            {onSaveAsSnapshot && (
              <button
                type="button"
                onClick={() => onSaveAsSnapshot(trimmed, kind)}
                className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted"
                title="Run this selector+kind through the live probe and store the result as a new coverage snapshot"
              >
                Save as snapshot
              </button>
            )}
            <button
              type="button"
              onClick={() => exportPreview("json")}
              disabled={!preview.length}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
              title="Download the first 20 preview rows as JSON"
            >
              Export preview JSON
            </button>
            <button
              type="button"
              onClick={() => exportPreview("csv")}
              disabled={!preview.length}
              className="rounded-md border border-hairline px-2 py-1 text-xs hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40"
              title="Download the first 20 preview rows as CSV"
            >
              Export preview CSV
            </button>
          </div>

          {preview.length > 0 && (
            <div className="overflow-hidden rounded-md border border-hairline">
              <table className="w-full border-collapse text-xs">
                <thead className="bg-muted/50 text-muted-foreground">
                  <tr>
                    <th className="px-2 py-1 text-left font-medium">#</th>
                    <th className="px-2 py-1 text-left font-medium">tag</th>
                    <th className="px-2 py-1 text-left font-medium">id</th>
                    <th className="px-2 py-1 text-left font-medium">classes</th>
                    <th className="px-2 py-1 text-left font-medium">data-testid</th>
                    <th className="px-2 py-1 text-left font-medium">aria-label</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.map((r) => (
                    <tr key={r.index} className="border-t border-hairline">
                      <td className="px-2 py-1 font-mono">{r.index}</td>
                      <td className="px-2 py-1 font-mono">{r.tag}</td>
                      <td className="px-2 py-1 font-mono">{r.id || "—"}</td>
                      <td className="px-2 py-1 font-mono">{r.classes || "—"}</td>
                      <td className="px-2 py-1 font-mono">{r.dataTestid || "—"}</td>
                      <td className="px-2 py-1 font-mono">{r.ariaLabel || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {total > preview.length && (
                <div className="border-t border-hairline bg-muted/30 px-2 py-1 text-[11px] text-muted-foreground">
                  Showing first {preview.length} of {total}. Click Recount after
                  navigating or updating the DOM.
                </div>
              )}
            </div>
          )}
        </div>
      )}

      <p className="mt-3 text-[11px] text-muted-foreground">
        Same validation as the live probe: syntax is parsed via{" "}
        <code>createDocumentFragment().querySelector</code>, matches counted via{" "}
        <code>document.querySelectorAll</code> on the currently rendered page.
        Open another admin route in a new tab to test selectors against that
        DOM.
      </p>
    </section>
  );
}

// ── Export preview ─────────────────────────────────────────────────────
// Renders the exact rows that will end up in the diff CSV/JSON before the
// user hits download. Supports switching between the changed-only scope
// (what "Export diff" writes) and the full scope (what "Export full" writes,
// which additionally includes unchanged entries), plus a search box.
function ExportPreview({
  changedRows,
  fullRows,
}: {
  changedRows: DiffSummary["entries"];
  fullRows: DiffSummary["entries"];
}) {
  const [scope, setScope] = useState<"changed" | "full">("changed");
  const [q, setQ] = useState("");
  const source = scope === "changed" ? changedRows : fullRows;
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return source;
    return source.filter((e) => {
      const ref = e.after ?? e.before;
      const hay = [
        e.status,
        e.signature,
        ref?.tag,
        ref?.id,
        ref?.classes,
        e.before?.ruleId,
        e.after?.ruleId,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return hay.includes(needle);
    });
  }, [source, q]);
  const counts = useMemo(() => {
    const c = { added: 0, removed: 0, changed: 0, unchanged: 0 };
    for (const e of filtered) c[e.status] += 1;
    return c;
  }, [filtered]);
  const badgeFor = (s: string) =>
    s === "added"
      ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
      : s === "removed"
        ? "bg-rose-500/10 text-rose-600 dark:text-rose-400"
        : s === "changed"
          ? "bg-amber-500/10 text-amber-700 dark:text-amber-400"
          : "bg-muted text-muted-foreground";

  return (
    <div className="mt-3 rounded-md border border-hairline">
      <div className="flex flex-wrap items-center gap-2 border-b border-hairline px-2 py-1.5">
        <span className="text-xs font-medium">Export preview</span>
        <div className="inline-flex overflow-hidden rounded-md border border-hairline text-[11px]">
          <button
            type="button"
            onClick={() => setScope("changed")}
            className={`px-2 py-0.5 ${scope === "changed" ? "bg-muted" : "hover:bg-muted/60"}`}
            aria-pressed={scope === "changed"}
          >
            Changed only ({changedRows.length})
          </button>
          <button
            type="button"
            onClick={() => setScope("full")}
            className={`border-l border-hairline px-2 py-0.5 ${scope === "full" ? "bg-muted" : "hover:bg-muted/60"}`}
            aria-pressed={scope === "full"}
          >
            Full incl. unchanged ({fullRows.length})
          </button>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Filter preview…"
          className="ml-auto h-6 w-40 rounded-md border border-hairline bg-transparent px-2 text-[11px] outline-none focus:border-foreground/40"
        />
        <span className="text-[11px] text-muted-foreground">
          {filtered.length} row{filtered.length === 1 ? "" : "s"} · +{counts.added} −{counts.removed} ~{counts.changed}
          {scope === "full" ? ` · =${counts.unchanged}` : ""}
        </span>
      </div>
      {filtered.length === 0 ? (
        <div className="px-2 py-3 text-[11px] text-muted-foreground">
          Nothing to preview. Adjust filters or switch scope.
        </div>
      ) : (
        <div className="max-h-64 overflow-auto">
          <table className="w-full text-[11px]">
            <thead className="sticky top-0 bg-muted/60 text-left">
              <tr>
                <th className="px-2 py-1 font-medium">Status</th>
                <th className="px-2 py-1 font-medium">Element</th>
                <th className="px-2 py-1 font-medium">Before rule</th>
                <th className="px-2 py-1 font-medium">After rule</th>
              </tr>
            </thead>
            <tbody>
              {filtered.slice(0, 300).map((e, i) => {
                const ref = e.after ?? e.before;
                const el = [ref?.tag, ref?.id ? `#${ref.id}` : "", ref?.classes ? `.${String(ref.classes).split(/\s+/).join(".")}` : ""]
                  .filter(Boolean)
                  .join("");
                return (
                  <tr key={`${e.signature}-${i}`} className="border-t border-hairline/60">
                    <td className="px-2 py-1 align-top">
                      <span className={`inline-block rounded px-1.5 py-0.5 ${badgeFor(e.status)}`}>{e.status}</span>
                    </td>
                    <td className="px-2 py-1 font-mono text-[10px] break-all">{el || e.signature}</td>
                    <td className="px-2 py-1 font-mono text-[10px] break-all">{e.before?.ruleId ?? "—"}</td>
                    <td className="px-2 py-1 font-mono text-[10px] break-all">{e.after?.ruleId ?? "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length > 300 && (
            <div className="px-2 py-1 text-[10px] text-muted-foreground">
              Showing first 300 of {filtered.length}. The export includes all rows.
            </div>
          )}
        </div>
      )}
    </div>
  );
}


