import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bookmark, Eye, Heart, Download, Users, Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/audience")({
  head: () => ({ meta: [{ title: "Audience — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: AudiencePage,
});

type Row = {
  id: string;
  name: string;
  slug: string;
  views: number;
  interested: number;
  bookmarks: number;
  followers: number;
};

function AudiencePage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [total, setTotal] = useState({ views: 0, interested: 0, bookmarks: 0, followers: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => { void load(); }, []);

  async function load() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const { data: listings } = await supabase
      .from("saas_listings")
      .select("id, name, slug, views, interested_count")
      .eq("owner_id", user.id);
    const ids = (listings ?? []).map((l: any) => l.id);
    let bookmarksByListing: Record<string, number> = {};
    if (ids.length) {
      const { data: bm } = await supabase.from("bookmarks").select("listing_id").in("listing_id", ids);
      (bm ?? []).forEach((b: any) => { bookmarksByListing[b.listing_id] = (bookmarksByListing[b.listing_id] ?? 0) + 1; });
    }
    const { count: followers } = await supabase
      .from("follows").select("*", { count: "exact", head: true }).eq("following_id", user.id);

    const out: Row[] = (listings ?? []).map((l: any) => ({
      id: l.id, name: l.name, slug: l.slug,
      views: l.views ?? 0,
      interested: l.interested_count ?? 0,
      bookmarks: bookmarksByListing[l.id] ?? 0,
      followers: 0,
    }));
    setRows(out);
    setTotal({
      views: out.reduce((s, r) => s + r.views, 0),
      interested: out.reduce((s, r) => s + r.interested, 0),
      bookmarks: out.reduce((s, r) => s + r.bookmarks, 0),
      followers: followers ?? 0,
    });
    setLoading(false);
  }

  function exportCsv() {
    const header = "listing,slug,views,interested,bookmarks\n";
    const body = rows.map((r) => `"${r.name}",${r.slug},${r.views},${r.interested},${r.bookmarks}`).join("\n");
    const blob = new Blob([header + body], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "audience.csv"; a.click();
    URL.revokeObjectURL(url);
    toast.success("Exported");
  }

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
            <BackButton />
            <DashHero
              signature="analytics"
              eyebrow="Marketing desk"
              title="Audience"
              description="Everyone paying attention to your SaaS — viewers, bookmarkers, interested founders, and your followers."
            />

            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground mt-6"><Loader2 className="h-4 w-4 animate-spin" /> Loading…</div>
            ) : (
              <>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
                  <Stat icon={Eye} label="Total views" value={total.views} />
                  <Stat icon={Heart} label="Interested" value={total.interested} />
                  <Stat icon={Bookmark} label="Bookmarks" value={total.bookmarks} />
                  <Stat icon={Users} label="Followers" value={total.followers} />
                </div>

                <div className="flex items-center justify-between mt-8 mb-3">
                  <h2 className="text-xl font-display italic">Per-listing breakdown</h2>
                  <Button size="sm" variant="outline" onClick={exportCsv} disabled={!rows.length}><Download className="h-4 w-4 mr-1" /> Export CSV</Button>
                </div>

                {rows.length === 0 ? (
                  <Card className="p-6 text-sm text-muted-foreground">No listings yet.</Card>
                ) : (
                  <div className="space-y-2">
                    {rows.map((r) => (
                      <Card key={r.id} className="p-4 flex flex-wrap items-center gap-4 justify-between">
                        <div className="min-w-0">
                          <div className="font-medium truncate">{r.name}</div>
                          <div className="text-xs text-muted-foreground">/{r.slug}</div>
                        </div>
                        <div className="flex gap-3 flex-wrap">
                          <Badge variant="secondary"><Eye className="h-3 w-3 mr-1" /> {r.views}</Badge>
                          <Badge variant="secondary"><Heart className="h-3 w-3 mr-1" /> {r.interested}</Badge>
                          <Badge variant="secondary"><Bookmark className="h-3 w-3 mr-1" /> {r.bookmarks}</Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}

                <Card className="mt-8 p-5">
                  <div className="text-sm font-medium mb-2">Turn attention into proposals</div>
                  <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                    <li>DM bookmarkers a personal note — bookmarks are the highest-intent signal.</li>
                    <li>Post a listing update every 2 weeks; each update pings followers via notifications.</li>
                    <li>Export CSV before a big push so you can compare deltas after your campaign.</li>
                  </ul>
                </Card>
              </>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: any; label: string; value: number }) {
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wider"><Icon className="h-3.5 w-3.5" /> {label}</div>
      <div className="text-2xl font-display italic mt-1">{value.toLocaleString()}</div>
    </Card>
  );
}
