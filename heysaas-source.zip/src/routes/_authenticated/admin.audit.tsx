import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatDistanceToNow } from "date-fns";
import { ScrollText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/audit")({
  head: () => ({ meta: [{ title: "Audit Log — Admin" }, { name: "robots", content: "noindex" }] }),
  component: AuditLog,
});

type Row = {
  id: string;
  admin_id: string;
  action: string;
  target_type: string | null;
  target_id: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
  admin?: { username: string | null; display_name: string | null } | null;
};

function AuditLog() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("admin_actions")
        .select("id,admin_id,action,target_type,target_id,metadata,created_at")
        .order("created_at", { ascending: false })
        .limit(200);
      const list = (data as Row[]) || [];
      const ids = Array.from(new Set(list.map((r) => r.admin_id)));
      if (ids.length) {
        const { data: profs } = await supabase
          .from("profiles")
          .select("id,username,display_name")
          .in("id", ids);
        const map = new Map((profs || []).map((p) => [p.id, p]));
        list.forEach((r) => {
          const p = map.get(r.admin_id);
          if (p) r.admin = { username: p.username, display_name: p.display_name };
        });
      }
      setRows(list);
      setLoading(false);
    })();
  }, []);

  const filtered = filter
    ? rows.filter((r) =>
        [r.action, r.target_type, r.target_id, r.admin?.username, r.admin?.display_name]
          .filter(Boolean)
          .some((v) => String(v).toLowerCase().includes(filter.toLowerCase())),
      )
    : rows;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-display tracking-tight">Audit log</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Every admin action, in chronological order. Last 200 events.
          </p>
        </div>
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter by action, admin, target…"
          className="w-full sm:w-72 rounded-full border border-hairline bg-background px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      {loading ? (
        <div className="rounded-2xl border border-hairline p-12 text-center text-sm text-muted-foreground">
          Loading…
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-hairline p-12 text-center">
          <ScrollText className="h-8 w-8 mx-auto text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">No admin actions recorded yet.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-hairline overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-secondary/40 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">When</th>
                <th className="text-left px-4 py-3">Admin</th>
                <th className="text-left px-4 py-3">Action</th>
                <th className="text-left px-4 py-3">Target</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.id} className="border-t border-hairline">
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">
                    {formatDistanceToNow(new Date(r.created_at), { addSuffix: true })}
                  </td>
                  <td className="px-4 py-3">
                    {r.admin?.display_name || r.admin?.username || (
                      <span className="text-muted-foreground">{r.admin_id.slice(0, 8)}…</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <code className="rounded bg-secondary px-2 py-0.5 text-xs">{r.action}</code>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {r.target_type ? (
                      <span>
                        {r.target_type}
                        {r.target_id ? <span className="opacity-60"> · {r.target_id.slice(0, 8)}…</span> : null}
                      </span>
                    ) : (
                      "—"
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
