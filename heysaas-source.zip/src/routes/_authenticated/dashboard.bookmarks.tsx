import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ListingCard, type ListingCardData } from "@/components/site/ListingCard";
import { Loader2, Bookmark, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { DashboardSidebar } from "@/components/site/DashboardSidebar";
import { BackButton } from "@/components/site/BackButton";
import { DashHero } from "@/components/site/DashHero";
import { DashRibbon } from "@/components/site/DashRibbon";
import { DashBodyBlock } from "@/components/site/DashBodyBlock";


export const Route = createFileRoute("/_authenticated/dashboard/bookmarks")({
  head: () => ({ meta: [{ title: "Bookmarks — Hey SaaS" }, { name: "robots", content: "noindex" }] }),
  component: Bookmarks,
});

type Row = ListingCardData & { _saved?: string };

function Bookmarks() {
  const [items, setItems] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"recent" | "views" | "interested" | "name">("recent");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from("bookmarks")
        .select(`created_at, listing:saas_listings ( id, slug, name, tagline, logo_url, cover_url, status, mrr_range, views, interested_count, tag_slugs )`)
        .eq("user_id", user.id)
        .not("listing_id", "is", null)
        .order("created_at", { ascending: false });
      const listings = (data ?? [])
        .map((r: any) => r.listing && ({ ...r.listing, _saved: r.created_at }))
        .filter(Boolean) as Row[];
      setItems(listings);
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const arr = query
      ? items.filter((l) =>
          l.name?.toLowerCase().includes(query) ||
          l.tagline?.toLowerCase().includes(query) ||
          (l.tag_slugs ?? []).some((t: string) => t.toLowerCase().includes(query))
        )
      : items.slice();
    switch (sort) {
      case "views": arr.sort((a, b) => (b.views ?? 0) - (a.views ?? 0)); break;
      case "interested": arr.sort((a, b) => (b.interested_count ?? 0) - (a.interested_count ?? 0)); break;
      case "name": arr.sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "")); break;
      default: arr.sort((a, b) => (b._saved ?? "").localeCompare(a._saved ?? ""));
    }
    return arr;
  }, [items, q, sort]);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex gap-10">
          <DashboardSidebar />
          <div className="flex-1 min-w-0">
      <BackButton />

      <DashHero
              signature="bookmarks"
        eyebrow={items.length > 0 ? `${items.length} saved` : "Your library"}
        title="Bookmarks"
        description="SaaS you want to come back to — every listing you saved, ready to review."
        actions={items.length > 0 ? (
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search bookmarks…" className="pl-9 rounded-full" />
            </div>
            <Select value={sort} onValueChange={(v: any) => setSort(v)}>
              <SelectTrigger className="w-40 rounded-full"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Recently saved</SelectItem>
                <SelectItem value="views">Most viewed</SelectItem>
                <SelectItem value="interested">Most interested</SelectItem>
                <SelectItem value="name">Name A–Z</SelectItem>
              </SelectContent>
            </Select>
          </div>
        ) : undefined}
      />
      <DashRibbon variant="bookmarks" />
      <DashBodyBlock variant="bookmarks" />
      <div className="mt-8">
        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : items.length === 0 ? (
          <div className="hs-empty">
            <div className="hs-empty-icon"><Bookmark className="h-6 w-6" /></div>
            <p className="mt-5 font-display text-3xl">No bookmarks yet.</p>
            <p className="mt-2 text-sm text-muted-foreground">Save listings to review them later — one tap on any card.</p>
            <Link to="/explore"><Button className="mt-6 rounded-full bg-gradient-to-r from-violet to-violet-glow text-white hover:opacity-90 border-0 shadow-[0_10px_30px_-10px_var(--violet)]">Explore SaaS</Button></Link>
          </div>
        ) : filtered.length === 0 ? (
          <div className="hs-empty">
            <p className="font-display text-2xl">No matches for "{q}".</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
            {filtered.map((l) => <ListingCard key={l.id} listing={l} />)}
          </div>
        )}
      </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

