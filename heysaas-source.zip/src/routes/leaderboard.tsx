import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useSignedImage } from "@/hooks/useSignedImage";
import { Badge } from "@/components/ui/badge";
import { Trophy, Sparkles, TrendingUp, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/leaderboard")({
  head: () =>
    buildHead({
      path: "/leaderboard",
      title: "Leaderboard — Top swappers on Hey SaaS",
      description:
        "The founders with the most completed swaps. No fake numbers.",
    }),
  component: Leaderboard,
});

type Founder = {
  id: string;
  username: string;
  display_name: string | null;
  avatar_url: string | null;
  verified: boolean;
  swap_score: number;
};

type TrendingListing = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  logo_url: string | null;
  views: number;
  interested_count: number;
};

function Leaderboard() {
  const [founders, setFounders] = useState<Founder[]>([]);
  const [trending, setTrending] = useState<TrendingListing[]>([]);

  useEffect(() => {
    (async () => {
      // Count completed swaps per user (both sides).
      const { data: completed } = await supabase
        .from("swap_requests")
        .select("initiator_id, recipient_id")
        .eq("status", "completed");
      const counts = new Map<string, number>();
      for (const row of completed ?? []) {
        counts.set(row.initiator_id, (counts.get(row.initiator_id) ?? 0) + 1);
        counts.set(row.recipient_id, (counts.get(row.recipient_id) ?? 0) + 1);
      }
      const ids = [...counts.keys()];
      let profiles: any[] = [];
      if (ids.length > 0) {
        const { data } = await supabase
          .from("profiles")
          .select("id, username, display_name, avatar_url, verified")
          .in("id", ids);
        profiles = data ?? [];
      }
      const ranked: Founder[] = profiles
        .map((p) => ({ ...p, swap_score: counts.get(p.id) ?? 0 }))
        .sort((a, b) => b.swap_score - a.swap_score)
        .slice(0, 20);
      setFounders(ranked);

      const { data: t } = await supabase
        .from("saas_listings")
        .select("id, slug, name, tagline, logo_url, views, interested_count")
        .eq("status", "live")
        .order("interested_count", { ascending: false })
        .limit(10);
      setTrending((t ?? []) as TrendingListing[]);
    })();
  }, []);

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-2xl">
          <p className="text-sm text-muted-foreground inline-flex items-center gap-2"><Trophy className="h-4 w-4 text-violet" />Leaderboard</p>
          <h1 className="mt-2 font-display text-4xl md:text-5xl">Top swappers</h1>
          <p className="mt-3 text-muted-foreground">Founders ranked by completed swaps. The higher up, the more trust they've earned in the trade.</p>
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-[1fr,340px]">
          <div>
            <h2 className="font-display text-2xl">All-time swappers</h2>
            <ol className="mt-6 space-y-2">
              {founders.length === 0 && <li className="text-sm text-muted-foreground">Rankings will appear as founders complete swaps.</li>}
              {founders.map((f, i) => (
                <FounderRow key={f.id} rank={i + 1} founder={f} />
              ))}
            </ol>
          </div>
          <aside>
            <h2 className="font-display text-2xl inline-flex items-center gap-2"><TrendingUp className="h-5 w-5" />Trending now</h2>
            <div className="mt-6 space-y-2">
              {trending.length === 0 && <div className="text-sm text-muted-foreground">Nothing trending yet.</div>}
              {trending.map((t, i) => (
                <Link key={t.id} to="/saas/$slug" params={{ slug: t.slug }} className="flex items-center gap-3 rounded-xl border border-hairline bg-surface p-3 hover:border-foreground/30">
                  <span className="text-xs text-muted-foreground w-4 text-right">{i + 1}</span>
                  <TrendingLogo path={t.logo_url} letter={t.name.slice(0, 1)} />
                  <div className="min-w-0 flex-1">
                    <div className="font-medium truncate">{t.name}</div>
                    {t.tagline && <div className="text-xs text-muted-foreground line-clamp-1">{t.tagline}</div>}
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground"><Sparkles className="h-3 w-3" />{t.interested_count}</span>
                </Link>
              ))}
            </div>
          </aside>
        </div>
      </main>
      <Footer />
    </div>
  );
}

function FounderRow({ rank, founder }: { rank: number; founder: Founder }) {
  const url = useSignedImage("avatars", founder.avatar_url);
  const rankAccent = rank <= 3 ? ["text-amber-400", "text-slate-300", "text-orange-400"][rank - 1] : "text-muted-foreground";
  return (
    <li>
      <Link to="/@{$username}" params={{ username: founder.username }} className="flex items-center gap-4 rounded-2xl border border-hairline bg-surface p-4 hover:border-foreground/30">
        <div className={`font-display text-2xl w-8 text-center ${rankAccent}`}>{rank}</div>
        <Avatar className="h-10 w-10">
          {url && <AvatarImage src={url} />}
          <AvatarFallback>{(founder.display_name || founder.username).slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 font-medium">
            {founder.display_name || founder.username}
            {founder.verified && <CheckCircle2 className="h-3.5 w-3.5 text-violet" />}
          </div>
          <div className="text-xs text-muted-foreground">@{founder.username}</div>
        </div>
        <Badge variant="outline" className="rounded-full">{founder.swap_score} swaps</Badge>
      </Link>
    </li>
  );
}

function TrendingLogo({ path, letter }: { path: string | null; letter: string }) {
  const url = useSignedImage("logos", path);
  return (
    <div className="h-8 w-8 shrink-0 overflow-hidden rounded-lg border border-hairline bg-background">
      {url ? <img src={url} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center text-xs">{letter}</div>}
    </div>
  );
}
