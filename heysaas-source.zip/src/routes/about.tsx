import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () =>
    buildHead({
      path: "/about",
      title: "About — HeySaaS",
      description:
        "HeySaaS is a marketplace where founders swap SaaS products directly. Built for indie hackers, by indie hackers.",
    }),
  component: About,
});

function About() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />
          <div className="absolute inset-0 hero-grid pointer-events-none" />
          <div className="relative mx-auto max-w-4xl px-6 sm:px-10 pt-20 pb-8 md:pt-28">
            <div className="inline-flex items-center gap-2 rounded-full border border-violet/30 bg-violet/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.22em] text-violet-glow">
              About
            </div>
            <h1 className="mt-6 font-display text-5xl md:text-7xl leading-[0.95] text-balance">
              Swap your SaaS. <span className="italic text-violet-glow">Not your money.</span>
            </h1>
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-6 sm:px-10 pb-24">
          <div className="mt-10 space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              Thousands of indie founders run SaaS products they no longer want to run. Some are thriving but no longer aligned with what they care about. Others are stuck, but full of potential in someone else's hands.
            </p>
            <p>
              Cash acquisition marketplaces don't serve them well. Pricing is fuzzy, buyers scarce, and brokers slow. Meanwhile, another founder — somewhere — has the opposite problem.
            </p>
            <p>
              HeySaaS exists so those two founders can find each other and trade, directly. No cash between them. No brokers. No lawyers on retainer. Just a match, a handshake, and a $19 safety fee to keep everyone honest.
            </p>
          </div>

          <blockquote className="relative mt-14 rounded-3xl border border-hairline bg-surface p-10 md:p-14">
            <div aria-hidden className="absolute -top-16 -left-16 h-56 w-56 rounded-full hs-aurora pointer-events-none" />
            <p className="relative font-display text-3xl md:text-5xl leading-[1.05] italic text-foreground">
              &ldquo;The best acquisition for your SaaS might not be an acquirer. It might be another founder.&rdquo;
            </p>
          </blockquote>

          <div className="mt-14 flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <Link to="/list" className="inline-flex items-center gap-2 rounded-xl bg-violet px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors" style={{ boxShadow: "var(--shadow-glow)" }}>
              List your SaaS <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/how-it-works" className="inline-flex items-center gap-2 rounded-xl border border-hairline bg-surface/60 px-6 py-3 text-sm text-foreground hover:bg-surface transition-colors">
              Read how it works
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
