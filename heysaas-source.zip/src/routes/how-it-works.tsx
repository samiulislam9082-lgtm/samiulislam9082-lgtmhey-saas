import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { ArrowRight } from "lucide-react";

const steps = [
  { n: "01", t: "List your SaaS",         d: "Unlimited free listings. Add product details, revenue, tech stack, and what you're looking for in return." },
  { n: "02", t: "Get discovered",         d: "Founders browse the directory the way you browse Product Hunt. Bookmarks and 'Interested' clicks tell you who's serious." },
  { n: "03", t: "Send a proposal",        d: "Pick one of your listings to offer. Attach a note. The other founder gets notified instantly." },
  { n: "04", t: "Negotiate privately",    d: "A dedicated thread opens per proposal. Chat, share screenshots, agree on scope — all off-broker." },
  { n: "05", t: "Both sides confirm",     d: "When you're ready, both click Confirm. That's when — and only when — the $19 safety fee gets charged to each side." },
  { n: "06", t: "Unlock the Swap Room",   d: "Verified contact info + a handover checklist (domain, code, customers, Stripe, email). Execute the transfer off-platform." },
  { n: "07", t: "Mark complete",          d: "Both listings flip to Swapped. Reputation history public on your profile. That's it — no cash ever changed hands between you two." },
];

export const Route = createFileRoute("/how-it-works")({
  head: () =>
    buildHead({
      path: "/how-it-works",
      title: "How it works — HeySaaS",
      description:
        "Step-by-step guide to swapping your SaaS on HeySaaS. Free listings, $19 safety fee only when both sides agree.",
      ogType: "article",
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "HowTo",
            name: "How to swap your SaaS on HeySaaS",
            description:
              "Seven steps to swap SaaS products directly with another founder — no cash between users.",
            totalTime: "PT30M",
            step: steps.map((s, i) => ({
              "@type": "HowToStep",
              position: i + 1,
              name: s.t,
              text: s.d,
            })),
          }),
        },
      ],
    }),
  component: HowItWorks,
});

function HowItWorks() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />
          <div className="absolute inset-0 hero-grid pointer-events-none" />
          <div className="relative mx-auto max-w-5xl px-6 sm:px-10 pt-20 pb-8 md:pt-28">
            <div className="inline-flex items-center gap-2 rounded-full border border-violet/30 bg-violet/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.22em] text-violet-glow">
              How it works
            </div>
            <h1 className="mt-6 font-display text-5xl md:text-7xl leading-[0.95] text-balance">
              From <span className="italic text-violet-glow">&ldquo;I have this&rdquo;</span> to <span className="italic text-violet-glow">&ldquo;I own that.&rdquo;</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
              Seven steps. No money moves between founders. Ever.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-4xl px-6 sm:px-10 pb-24">
          <ol className="relative mt-6 space-y-4">
            <div aria-hidden className="pointer-events-none absolute left-6 md:left-10 top-4 bottom-4 w-px bg-gradient-to-b from-transparent via-hairline to-transparent" />
            {steps.map((s) => (
              <li key={s.n} className="relative pl-16 md:pl-24">
                <div className="absolute left-0 top-4 grid h-12 w-12 md:h-14 md:w-14 place-items-center rounded-2xl border border-violet/30 bg-violet/10 backdrop-blur">
                  <span className="font-display text-lg md:text-xl text-violet-glow">{s.n}</span>
                </div>
                <div className="rounded-2xl border border-hairline bg-surface p-6 md:p-8 transition-colors hover:border-violet/40">
                  <h2 className="font-display text-2xl md:text-3xl">{s.t}</h2>
                  <p className="mt-3 text-muted-foreground leading-relaxed">{s.d}</p>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-14 rounded-3xl border border-hairline bg-surface p-8 md:p-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="font-display text-2xl md:text-3xl">Ready to try it?</div>
              <p className="text-muted-foreground mt-1 text-sm">Free to list. Free to browse. Only $19 when you swap.</p>
            </div>
            <Link to="/list" className="inline-flex items-center gap-2 rounded-xl bg-violet px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-violet-glow transition-colors" style={{ boxShadow: "var(--shadow-glow)" }}>
              List your SaaS <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
