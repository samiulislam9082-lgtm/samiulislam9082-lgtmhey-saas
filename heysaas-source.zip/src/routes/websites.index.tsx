import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { wsListPublicListings } from "@/lib/websites.functions";
import { supabase } from "@/integrations/supabase/client";
import { ArrowRight, Globe, Search, Repeat, FileSignature, Handshake } from "lucide-react";
import { CountUp, Sparkline, VerifiedSeal } from "@/components/websites/ws-ui";

export const Route = createFileRoute("/websites/")({
  head: () =>
    buildHead({
      path: "/websites",
      title: "WebSwap — Buy, sell & swap websites",
      description:
        "The founder-first marketplace to buy, sell, and swap live websites with verified revenue and traffic.",
    }),
  component: WebSwapHome,
});

function WebSwapHome() {
  const list = useServerFn(wsListPublicListings);
  const { data: featured, isLoading } = useQuery({
    queryKey: ["ws", "featured"],
    queryFn: () => list({ data: { limit: 6, offset: 0 } }),
  });

  const { data: stats } = useQuery({
    queryKey: ["ws", "platform-stats"],
    queryFn: async () => {
      const [liveListings, verifiedListings] = await Promise.all([
        supabase.from("ws_listings").select("id", { count: "exact", head: true }).eq("status", "live"),
        supabase
          .from("ws_listings")
          .select("id", { count: "exact", head: true })
          .eq("status", "live")
          .eq("ownership_verified", true),
      ]);
      return { live: liveListings.count ?? 0, verified: verifiedListings.count ?? 0 };
    },
  });

  const navigate = useNavigate();
  const hasStats = (stats?.live ?? 0) > 0;

  return (
    <>
      {/* ============ EDITORIAL HERO ============ */}
      <section className="relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 sm:pt-24 pb-20">
          <div className="grid lg:grid-cols-12 gap-10 lg:gap-12 items-end">
            <div className="lg:col-span-8 ws-reveal">
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-[#2dd4bf] uppercase tracking-[0.28em] font-semibold">
                  Vol. 01 · Digital Real Estate Exchange
                </span>
                <span className="h-px flex-1 bg-[#1a4a6e]/60 max-w-24" />
              </div>
              <h1 className="ws-serif mt-6 text-white text-5xl sm:text-6xl lg:text-[7.5rem] leading-[0.95] font-normal">
                Acquire the{" "}
                <span className="italic text-[#e2b464]">next</span> generation of web properties.
              </h1>
            </div>
            <div className="lg:col-span-4 ws-reveal ws-reveal-2 border-l border-[#1a4a6e] pl-8 pb-2">
              <VerifiedSeal label="Every listing DNS-verified" />
              <p className="mt-4 text-[15px] leading-relaxed text-[#c7d5e6]/80 max-w-sm">
                A curated marketplace for high-yield SaaS, content hubs, and digital storefronts. Sellers prove
                ownership before their listing goes live — you deal with the real founder, not a middleman.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button className="ws-btn-primary" onClick={() => navigate({ to: "/websites/browse" })}>
                  Browse marketplace
                </button>
                <button className="ws-btn-ghost" onClick={() => navigate({ to: "/websites/dashboard/listings/new" })}>
                  List a site
                </button>
              </div>
            </div>
          </div>

          {/* Data ribbon */}
          {hasStats && (
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-px bg-[#1a4a6e]/40 border border-[#1a4a6e]/40">
              <RibbonStat label="Live listings" value={stats!.live} />
              <RibbonStat label="Verified owners" value={stats!.verified} />
              <RibbonStat label="Avg. review time" value={48} suffix="h" />
              <RibbonStat label="Payout escrow" value={100} suffix="%" gold />
            </div>
          )}
        </div>
      </section>

      {/* ============ FEATURED EDITORIAL GRID ============ */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-24">
        <div className="flex items-end justify-between mb-10 pb-4 border-b border-[#1a4a6e]/50">
          <div>
            <div className="text-[10px] uppercase tracking-[0.28em] text-[#2dd4bf] font-semibold">Live now</div>
            <h2 className="ws-serif mt-1 text-white text-4xl sm:text-5xl">Recently listed</h2>
          </div>
          <Link to="/websites/browse" className="hidden sm:inline-flex items-center gap-1.5 text-xs uppercase tracking-widest text-[#c7d5e6] hover:text-[#2dd4bf]">
            View all <ArrowRight className="h-3 w-3" />
          </Link>
        </div>

        {isLoading ? (
          <div className="grid gap-8 md:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => <MagazineSkeleton key={i} />)}
          </div>
        ) : !featured || featured.length === 0 ? (
          <div className="border border-dashed border-[#1a4a6e]/60 p-16 text-center">
            <Search className="h-8 w-8 text-[#2dd4bf]/60 mx-auto" />
            <p className="ws-serif mt-4 text-2xl text-white">No verified listings — yet.</p>
            <p className="mt-2 text-sm text-[#7d94ad] max-w-md mx-auto">
              Be the first to list. Publishing is free during early access.
            </p>
            <button className="ws-btn-primary mt-6" onClick={() => navigate({ to: "/websites/dashboard/listings/new" })}>
              List your website
            </button>
          </div>
        ) : (
          <div className="grid gap-8 md:grid-cols-3">
            {featured.map((l, i) => (
              <MagazineCard key={l.id} l={l} offset={i === 1} delay={i} />
            ))}
          </div>
        )}
      </section>

      {/* ============ HOW IT WORKS ============ */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-24">
        <div className="grid lg:grid-cols-12 gap-10 items-end mb-10">
          <div className="lg:col-span-6">
            <div className="text-[10px] uppercase tracking-[0.28em] text-[#2dd4bf] font-semibold">How it works</div>
            <h2 className="ws-serif mt-2 text-white text-4xl sm:text-5xl">Three ways to move a website.</h2>
          </div>
          <div className="lg:col-span-6 text-[#c7d5e6]/70 text-sm leading-relaxed lg:pl-16">
            Every path is transparent. Sellers surface real numbers, buyers verify domain ownership, and offers are
            structured with a full audit trail.
          </div>
        </div>
        <div className="grid gap-px bg-[#1a4a6e]/40 border border-[#1a4a6e]/40 md:grid-cols-3">
          {[
            { icon: FileSignature, kicker: "Sell", title: "List with a real price", body: "Set an asking price, share screenshots, and disclose revenue & traffic upfront." },
            { icon: Repeat,        kicker: "Swap", title: "Trade site for site",   body: "Prefer a direct exchange? Add cash top-ups if the values differ." },
            { icon: Handshake,     kicker: "Deal", title: "Message & make offers", body: "Chat inside WebSwap. Send offers with one click — counter, accept, or reject inline." },
          ].map((s, i) => (
            <div key={s.title} className="bg-[#04101a] p-8">
              <div className="flex items-baseline justify-between mb-6">
                <span className="text-[10px] uppercase tracking-[0.22em] text-[#2dd4bf] font-semibold">{s.kicker}</span>
                <span className="ws-serif italic text-3xl text-[#1a4a6e] ws-num">0{i + 1}</span>
              </div>
              <s.icon className="h-6 w-6 text-[#e2b464]" strokeWidth={1.5} />
              <h3 className="ws-serif mt-5 text-2xl text-white">{s.title}</h3>
              <p className="mt-2 text-sm text-[#c7d5e6]/70 leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

function RibbonStat({ label, value, suffix, gold }: { label: string; value: number; suffix?: string; gold?: boolean }) {
  return (
    <div className="bg-[#04101a] px-6 py-6">
      <div className="text-[10px] uppercase tracking-[0.22em] text-[#7d94ad] font-semibold">{label}</div>
      <div className={`ws-serif mt-1 text-4xl ${gold ? "text-[#e2b464]" : "text-white"}`}>
        <CountUp value={value} suffix={suffix} />
      </div>
    </div>
  );
}

function MagazineSkeleton() {
  return (
    <div className="animate-pulse space-y-4">
      <div className="aspect-[4/5] bg-[#0c2340]" />
      <div className="h-6 bg-[#0c2340] w-2/3" />
      <div className="h-3 bg-[#0c2340] w-1/2" />
    </div>
  );
}

function MagazineCard({
  l,
  offset,
  delay,
}: {
  l: {
    id: string;
    title: string;
    domain: string;
    listing_type: "for_sale" | "open_to_swap" | "open_to_both";
    asking_price_usd: number | null;
    monthly_revenue_usd: number | null;
    monthly_traffic: number | null;
    niche: string | null;
    screenshots: string[];
    ownership_verified?: boolean;
  };
  offset?: boolean;
  delay?: number;
}) {
  const typeLabel = { for_sale: "For sale", open_to_swap: "Open to swap", open_to_both: "Sale or swap" }[l.listing_type];
  const price = l.asking_price_usd != null ? `$${Number(l.asking_price_usd).toLocaleString()}` : "—";
  const stat = l.monthly_revenue_usd != null
    ? `$${Number(l.monthly_revenue_usd).toLocaleString()} MRR`
    : l.monthly_traffic != null
    ? `${Number(l.monthly_traffic).toLocaleString()} monthly visits`
    : (l.niche ?? "—");

  return (
    <Link
      to="/websites/$id"
      params={{ id: l.id }}
      className={`ws-hover-lift ws-reveal ws-reveal-${(delay ?? 0) + 1} group block space-y-4 ${offset ? "md:mt-14" : ""}`}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-[#0c2340] border border-[#1a4a6e]/60">
        {l.screenshots?.[0] ? (
          <img
            src={l.screenshots[0]}
            alt={l.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-[#1a4a6e]">
            <Globe className="h-14 w-14" strokeWidth={1} />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#04101a] via-transparent to-transparent" />
        {l.ownership_verified !== false && (
          <div className="absolute top-3 right-3"><VerifiedSeal label="Verified" /></div>
        )}
        <div className="absolute bottom-3 left-3 text-[10px] uppercase tracking-[0.22em] text-[#2dd4bf] font-semibold bg-[#04101a]/70 px-2 py-1 backdrop-blur-sm">
          {typeLabel}
        </div>
      </div>
      <div>
        <h3 className="ws-serif text-2xl italic text-white group-hover:text-[#2dd4bf] transition-colors">
          {l.title}
        </h3>
        <p className="mt-0.5 text-[11px] uppercase tracking-widest text-[#7d94ad]">{l.domain}</p>
      </div>
      <div className="flex items-center justify-between border-t border-[#1a4a6e]/60 pt-3">
        <div className="flex items-center gap-2 text-xs text-[#2dd4bf]">
          <span>{stat}</span>
          {l.monthly_revenue_usd != null && <Sparkline className="text-[#2dd4bf]" />}
        </div>
        <span className="ws-num text-sm font-semibold text-[#e2b464]">{price}</span>
      </div>
    </Link>
  );
}
