import { createFileRoute, useNavigate, useSearch, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { toast } from "sonner";
import { Loader2, Mail } from "lucide-react";

const searchSchema = z.object({
  redirect: z.string().optional(),
  mode: z.enum(["signin", "signup", "forgot"]).optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Sign in — Hey SaaS" },
      { name: "description", content: "Sign in or create your Hey SaaS founder account." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function friendlyOAuthError(raw: string | undefined | null): string {
  const m = (raw ?? "").toLowerCase();
  if (!m) return "Google sign-in failed. Please try again.";
  if (m.includes("popup") && m.includes("clos")) return "The Google sign-in window was closed before finishing. Try again.";
  if (m.includes("popup") && m.includes("block")) return "Your browser blocked the sign-in popup. Allow popups for this site and try again.";
  if (m.includes("network") || m.includes("failed to fetch")) return "Network error reaching Google. Check your connection and retry.";
  if (m.includes("access_denied") || m.includes("denied")) return "You cancelled the Google consent screen. Try again to continue.";
  if (m.includes("unsupported provider") || m.includes("provider is not enabled")) return "Google sign-in isn't enabled for this app yet. Contact support.";
  if (m.includes("redirect") && m.includes("uri")) return "Google rejected the redirect URL for this app. Contact support.";
  if (m.includes("state") || m.includes("csrf")) return "Sign-in session expired. Please try again.";
  return raw ?? "Google sign-in failed. Please try again.";
}



function AuthPage() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/auth" });
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">(search.mode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [oauthError, setOauthError] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: (search.redirect as any) ?? "/dashboard" });
      else setChecking(false);
    });
    // Catch the session that lands after the OAuth popup completes.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) {
        navigate({ to: (search.redirect as any) ?? "/dashboard" });
      }
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate, search.redirect]);

  const onGoogle = async () => {
    if (googleLoading) return; // hard lock against double-click / double-tap
    setGoogleLoading(true);
    setOauthError(null);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      const err = (result as any)?.error as Error | undefined;
      if (err) {
        const msg = friendlyOAuthError(err.message);
        setOauthError(msg);
        toast.error(msg);
        setGoogleLoading(false);
        return;
      }
      if ((result as any)?.redirected) {
        // Full-page redirect flow — leave the lock on until the browser navigates away.
        return;
      }
      // Popup (web_message) flow — session should be set by the helper.
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        toast.success("Signed in.");
        navigate({ to: (search.redirect as any) ?? "/dashboard" });
      } else {
        // Popup was closed or blocked without a session — release the lock.
        setOauthError("The Google sign-in window was closed before finishing. Try again.");
        setGoogleLoading(false);
      }
    } catch (err: any) {
      const msg = friendlyOAuthError(err?.message);
      setOauthError(msg);
      toast.error(msg);
      setGoogleLoading(false);
    }
  };



  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { display_name: displayName || email.split("@")[0] },
          },
        });
        if (error) throw error;
        toast.success("Welcome — let's set up your profile.");
        navigate({ to: "/onboarding" });
      } else if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Signed in.");
        navigate({ to: (search.redirect as any) ?? "/dashboard" });
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("Reset link sent — check your email.");
        setMode("signin");
      }
    } catch (err: any) {
      toast.error(err?.message ?? "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="min-h-dvh flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const heading =
    mode === "signup" ? "Join Hey SaaS" : mode === "forgot" ? "Reset password" : "Welcome back";
  const sub =
    mode === "signup"
      ? "Create an account to list your SaaS and swap with other founders."
      : mode === "forgot"
      ? "We'll email you a link to set a new password."
      : "Sign in to your founder account.";

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 w-full px-4 py-8 sm:px-6 sm:py-12 lg:py-16">
        <div className="mx-auto w-full max-w-md lg:max-w-5xl">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,420px)] lg:items-center lg:gap-14">
            {/* Brand panel — compact on phones, full column on desktop */}
            <section className="min-w-0 text-center lg:text-left">
              <span className="inline-flex items-center gap-2 rounded-full border border-hairline px-3 py-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                Founder access
              </span>
              <h1 className="mt-4 font-display text-3xl leading-tight sm:text-4xl lg:text-5xl">
                {heading}
              </h1>
              <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground sm:text-[15px] lg:mx-0">
                {sub}
              </p>
              <ul className="mt-6 hidden gap-3 text-sm text-muted-foreground lg:grid">
                <li className="flex items-start gap-3">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Swap your SaaS with vetted founders — no cash sale required.
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  Messaging, offers and transfers tracked in one desk.
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  A one-time $19 safety fee keeps both sides accountable.
                </li>
              </ul>
            </section>

            {/* Form card — identical features on every breakpoint */}
            <section className="min-w-0">
              <div className="rounded-3xl border border-hairline bg-surface p-5 sm:p-8 lg:p-9">
                {mode !== "forgot" && (
                  <>
                    {oauthError && (
                      <div
                        role="alert"
                        className="mb-5 rounded-xl border border-red-500/30 bg-red-500/5 px-4 py-3 text-sm text-red-300"
                      >
                        {oauthError}
                      </div>
                    )}
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full rounded-full h-12 text-[15px]"
                      onClick={onGoogle}
                      disabled={loading || googleLoading}
                      aria-busy={googleLoading}
                    >
                      {googleLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Opening Google…
                        </>
                      ) : (
                        <>
                          <svg className="h-4 w-4 mr-2 shrink-0" viewBox="0 0 24 24" aria-hidden>
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"/>
                          </svg>
                          Continue with Google
                        </>
                      )}
                    </Button>

                    <div className="my-6 flex items-center gap-4">
                      <div className="h-px flex-1 bg-hairline" />
                      <span className="text-xs uppercase tracking-widest text-muted-foreground">or</span>
                      <div className="h-px flex-1 bg-hairline" />
                    </div>
                  </>
                )}

                <form onSubmit={onSubmit} className="space-y-4">
                  {mode === "signup" && (
                    <div className="space-y-2">
                      <Label htmlFor="displayName">Display name</Label>
                      <Input
                        id="displayName"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder="Alex Founder"
                        autoComplete="name"
                        className="h-12 rounded-xl text-base"
                      />
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      inputMode="email"
                      autoComplete="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="h-12 rounded-xl text-base"
                    />
                  </div>
                  {mode !== "forgot" && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-3">
                        <Label htmlFor="password">Password</Label>
                        {mode === "signin" && (
                          <button
                            type="button"
                            onClick={() => setMode("forgot")}
                            className="shrink-0 text-xs text-muted-foreground hover:text-foreground"
                          >
                            Forgot?
                          </button>
                        )}
                      </div>
                      <Input
                        id="password"
                        type="password"
                        required
                        minLength={8}
                        autoComplete={mode === "signup" ? "new-password" : "current-password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="At least 8 characters"
                        className="h-12 rounded-xl text-base"
                      />
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full h-12 rounded-full bg-foreground text-background hover:opacity-90"
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : mode === "signup" ? (
                      "Create account"
                    ) : mode === "forgot" ? (
                      <>
                        <Mail className="h-4 w-4 mr-2" />
                        Send reset link
                      </>
                    ) : (
                      "Sign in"
                    )}
                  </Button>
                </form>

                <div className="mt-6 text-center text-sm text-muted-foreground">
                  {mode === "signin" && (
                    <>
                      New here?{" "}
                      <button onClick={() => setMode("signup")} className="text-foreground hover:underline">
                        Create an account
                      </button>
                    </>
                  )}
                  {mode === "signup" && (
                    <>
                      Already have an account?{" "}
                      <button onClick={() => setMode("signin")} className="text-foreground hover:underline">
                        Sign in
                      </button>
                    </>
                  )}
                  {mode === "forgot" && (
                    <button onClick={() => setMode("signin")} className="text-foreground hover:underline">
                      Back to sign in
                    </button>
                  )}
                </div>
              </div>

              <p className="mt-6 text-center text-xs text-muted-foreground">
                By continuing, you agree to our{" "}
                <Link to="/legal/terms" className="hover:text-foreground">Terms</Link> and{" "}
                <Link to="/legal/privacy" className="hover:text-foreground">Privacy Policy</Link>.
              </p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

