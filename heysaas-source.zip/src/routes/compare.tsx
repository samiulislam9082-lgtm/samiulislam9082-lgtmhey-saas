import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getCompareListings } from "@/lib/compare.functions";
import { useSignedImage } from "@/hooks/useSignedImage";
import { Check, Minus, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/compare")({
  validateSearch: (raw: Record<string, unknown>) => ({
    ids: typeof raw.ids === "string" ? raw.ids : "",
  }),
  head: () =>
    buildHead({
      path: "/compare",
      title: "Compare SaaS side by side — HeySaaS",
      description:
        "Evaluate multiple SaaS listings side by side before you propose a swap.",
    }),
  component: ComparePage,
});

type Row = Awaited<ReturnType<typeof getCompareListings>>[number];

function LogoCell({ path, name }: { path: string | null; name: string }) {
  const url = useSignedImage("logos", path);
  return (
    <div className="flex items-center gap-3">
      <div className="h-10 w-10 rounded-lg overflow-hidden border border-hairline bg-background shrink-0">
        {url ? <img src={url} alt="" className="h-full w-full object-cover" /> : (
          <div className="h-full w-full flex items-center justify-center text-sm text-muted-foreground">{name.slice(0, 1)}</div>
        )}
      </div>
      <div className="min-w-0">
        <div className="font-display text-base truncate">{name}</div>
      </div>
    </div>
  );
}

function CoverCell({ path }: { path: string | null }) {
  const url = useSignedImage("covers", path);
  return (
    <div className="aspect-[16/10] w-full overflow-hidden rounded-lg border border-hairline bg-gradient-to-br from-violet/20 via-surface to-background">
      {url && <img src={url} alt="" className="h-full w-full object-cover" />}
    </div>
  );
}

function Cell({ children }: { children: React.ReactNode }) {
  return <td className="px-4 py-3 align-top border-t border-hairline text-sm">{children || <Minus className="h-4 w-4 text-muted-foreground/40" />}</td>;
}

function ComparePage() {
  const { ids } = useSearch({ from: "/compare" }) as { ids: string };
  const slugs = ids.split(",").map((s: string) => s.trim()).filter(Boolean).slice(0, 4);
  const fetchCompare = useServerFn(getCompareListings);

  const { data, isLoading } = useQuery({
    queryKey: ["compare", slugs.join(",")],
    queryFn: () => fetchCompare({ data: { slugs: slugs as [string, string, ...string[]] } }),
    enabled: slugs.length >= 2,
  });

  const rows: Row[] = (data ?? []).sort((a, b) => slugs.indexOf(a.slug) - slugs.indexOf(b.slug));

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <Link to="/explore" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to explore
        </Link>
        <h1 className="mt-4 font-display text-4xl md:text-5xl">Side-by-side compare</h1>
        <p className="mt-2 text-muted-foreground">Weigh up to 4 listings before you propose a swap.</p>

        {slugs.length < 2 ? (
          <div className="mt-16 rounded-2xl border border-hairline bg-surface p-10 text-center">
            <p className="font-display text-2xl">Pick at least two listings.</p>
            <p className="mt-2 text-muted-foreground">Add listings to the compare tray from the explore page.</p>
            <Button asChild className="mt-6"><Link to="/explore">Go to explore</Link></Button>
          </div>
        ) : isLoading ? (
          <div className="mt-16 text-center text-muted-foreground">Loading comparison…</div>
        ) : rows.length === 0 ? (
          <div className="mt-16 text-center text-muted-foreground">No live listings match those slugs.</div>
        ) : (
          <div className="mt-10 overflow-x-auto">
            <table className="w-full min-w-[720px] border border-hairline rounded-2xl overflow-hidden bg-surface">
              <thead>
                <tr>
                  <th className="w-48 px-4 py-3 text-left text-xs uppercase tracking-wider text-muted-foreground bg-background/60">Attribute</th>
                  {rows.map((r) => (
                    <th key={r.id} className="px-4 py-3 text-left bg-background/60 min-w-[220px]">
                      <div className="space-y-3">
                        <CoverCell path={r.cover_url} />
                        <LogoCell path={r.logo_url} name={r.name} />
                        <div className="flex gap-2">
                          <Button asChild size="sm" variant="outline" className="rounded-full">
                            <Link to="/saas/$slug" params={{ slug: r.slug }}>Open</Link>
                          </Button>
                        </div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Tagline</td>
                  {rows.map((r) => <Cell key={r.id}>{r.tagline}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">MRR</td>
                  {rows.map((r) => <Cell key={r.id}>{r.mrr_range && <Badge variant="outline" className="rounded-full">{r.mrr_range}</Badge>}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">ARR</td>
                  {rows.map((r) => <Cell key={r.id}>{r.arr_range}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Users</td>
                  {rows.map((r) => <Cell key={r.id}>{r.user_count_range}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Pricing</td>
                  {rows.map((r) => <Cell key={r.id}>{r.pricing_model}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Country</td>
                  {rows.map((r) => <Cell key={r.id}>{r.country}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Launched</td>
                  {rows.map((r) => <Cell key={r.id}>{r.launch_year}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Tech stack</td>
                  {rows.map((r) => (
                    <Cell key={r.id}>
                      <div className="flex flex-wrap gap-1">
                        {(r.tech_stack ?? []).map((t) => <Badge key={t} variant="outline" className="rounded-full text-xs">{t}</Badge>)}
                      </div>
                    </Cell>
                  ))}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Tags</td>
                  {rows.map((r) => (
                    <Cell key={r.id}>
                      <div className="flex flex-wrap gap-1">
                        {(r.tag_slugs ?? []).map((t) => <Badge key={t} variant="outline" className="rounded-full text-xs">#{t}</Badge>)}
                      </div>
                    </Cell>
                  ))}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Views</td>
                  {rows.map((r) => <Cell key={r.id}>{r.views}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Interested</td>
                  {rows.map((r) => <Cell key={r.id}>{r.interested_count}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Website</td>
                  {rows.map((r) => (
                    <Cell key={r.id}>
                      {r.website_url ? <a className="text-violet underline underline-offset-2" href={r.website_url} target="_blank" rel="noreferrer">Visit ↗</a> : null}
                    </Cell>
                  ))}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Why swap</td>
                  {rows.map((r) => <Cell key={r.id}>{r.reason_for_swap}</Cell>)}
                </tr>
                <tr><td className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-t border-hairline">Looking for</td>
                  {rows.map((r) => <Cell key={r.id}>{r.looking_for}</Cell>)}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

// keep Check imported for future use
void Check;
