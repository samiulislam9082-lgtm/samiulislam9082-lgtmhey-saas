import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/useSession";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { ListingCard, type ListingCardData } from "@/components/site/ListingCard";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Search, Loader2, SlidersHorizontal, X, Info, GitCompare, Bookmark, Bell, BellOff, Trash2, ChevronDown, Settings2, Pencil, Share2, Link2, History, RotateCcw, Copy, Check,
} from "lucide-react";
import {
  MRR_BUCKETS, POPULAR_TECH, COUNTRIES, SORTS, PRICING_MODELS, LOOKING_FOR,
  type MarketplaceFilters, EMPTY_FILTERS, explainMatch,
} from "@/lib/marketplace-filters";
import {
  createSavedSearch, listSavedSearches, deleteSavedSearch, toggleSavedSearchNotify, updateSavedSearch,
} from "@/lib/saved-searches.functions";
import { listPresetVersions, restorePresetVersion, setPresetShareSlug } from "@/lib/preset-versions.functions";
import { getExplorePrefs, saveExplorePrefs } from "@/lib/explore-prefs.functions";
import { z } from "zod";

const PAGE_SIZE = 24;

type Category = { id: string; name: string; slug: string };

export const Route = createFileRoute("/explore")({
  validateSearch: (s: Record<string, unknown>) => z.object({ share: z.string().optional() }).parse(s),
  head: () =>
    buildHead({
      path: "/explore",
      title: "Explore SaaS open to swap — HeySaaS",
      description:
        "Browse indie SaaS founders open to trading access. Filter by MRR, tech stack, and country.",
    }),
  component: Explore,
});

type CardWithReasons = ListingCardData & {
  mrr_range: string | null;
  tech_stack: string[] | null;
  country: string | null;
  featured?: boolean;
};

function Explore() {
  const { user } = useSession();
  const navigate = useNavigate();
  const { share } = Route.useSearch();
  const [filters, setFilters] = useState<MarketplaceFilters>(EMPTY_FILTERS);
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<CardWithReasons[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // Compare tray
  const [compareSlugs, setCompareSlugs] = useState<string[]>([]);
  const toggleCompare = (slug: string) => {
    setCompareSlugs((prev) =>
      prev.includes(slug) ? prev.filter((s) => s !== slug) : prev.length >= 4 ? prev : [...prev, slug],
    );
  };

  // Saved searches
  const fetchSaved = useServerFn(listSavedSearches);
  const saveSearch = useServerFn(createSavedSearch);
  const deleteSearch = useServerFn(deleteSavedSearch);
  const toggleNotify = useServerFn(toggleSavedSearchNotify);
  const updateSearch = useServerFn(updateSavedSearch);
  const listVersions = useServerFn(listPresetVersions);
  const restoreVersion = useServerFn(restorePresetVersion);
  const setShareSlug = useServerFn(setPresetShareSlug);
  const loadPrefs = useServerFn(getExplorePrefs);
  const savePrefs = useServerFn(saveExplorePrefs);
  const [saved, setSaved] = useState<any[]>([]);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [emailNotify, setEmailNotify] = useState(true);
  const [manageOpen, setManageOpen] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [historyPreset, setHistoryPreset] = useState<any | null>(null);
  const [versions, setVersions] = useState<any[]>([]);
  const [versionsLoading, setVersionsLoading] = useState(false);
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  const refreshSaved = async () => {
    if (!user) return;
    try {
      const rows = await fetchSaved();
      setSaved(rows);
    } catch {
      /* ignore */
    }
  };

  useEffect(() => { refreshSaved(); }, [user?.id]);

  // Persist filters on the user's profile so they follow across devices.
  const hydratedRef = useRef(false);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!user?.id || hydratedRef.current) return;
    (async () => {
      // 1) If a share slug is present, prefer that.
      if (share) {
        const { data } = await supabase
          .from("saved_searches")
          .select("q, category_id, mrr_ranges, tech_stack, countries, pricing_models, looking_for, sort")
          .eq("share_slug", share)
          .maybeSingle();
        if (data) {
          setFilters({
            q: (data as any).q ?? "",
            categoryId: (data as any).category_id ?? null,
            mrr: (data as any).mrr_ranges ?? [],
            tech: (data as any).tech_stack ?? [],
            countries: (data as any).countries ?? [],
            pricingModels: (data as any).pricing_models ?? [],
            lookingFor: (data as any).looking_for ?? [],
            sort: (data as any).sort ?? "trending",
          });
          toast.success("Shared search applied");
          hydratedRef.current = true;
          return;
        }
      }
      // 2) Otherwise load cloud prefs.
      try {
        const prefs = await loadPrefs();
        setFilters({ ...EMPTY_FILTERS, ...(prefs as any) });
      } catch { /* ignore */ }
      hydratedRef.current = true;
    })();
  }, [user?.id, share]);

  // Debounced save of filters to profile.
  useEffect(() => {
    if (!user?.id || !hydratedRef.current) return;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      savePrefs({ data: filters as any }).catch(() => {});
    }, 800);
    return () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current); };
  }, [user?.id, filters]);

  useEffect(() => {
    supabase.from("categories").select("id, name, slug").order("sort_order").then(({ data }) => {
      setCategories((data ?? []) as Category[]);
    });
  }, []);

  const filterKey = useMemo(
    () => JSON.stringify(filters),
    [filters],
  );

  useEffect(() => {
    setItems([]); setPage(0); setHasMore(true);
  }, [filterKey, user?.id]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      let query = supabase
        .from("saas_listings")
        .select("id, slug, name, tagline, logo_url, cover_url, status, mrr_range, views, interested_count, tag_slugs, tech_stack, country, featured")
        .eq("status", "live");

      if (filters.categoryId) query = query.eq("category_id", filters.categoryId);
      // Never show the signed-in founder their own listings in the feed.
      if (user?.id) query = query.neq("owner_id", user.id);
      if (filters.q.trim()) {
        const term = filters.q.trim().replace(/[%,()]/g, " ").trim();
        if (term) {
          query = query.or(
            [`name.ilike.%${term}%`, `tagline.ilike.%${term}%`, `description.ilike.%${term}%`].join(","),
          );
        }
      }

      if (filters.mrr.length) query = query.in("mrr_range", filters.mrr);
      if (filters.tech.length) query = query.overlaps("tech_stack", filters.tech);
      if (filters.countries.length) query = query.in("country", filters.countries);
      if (filters.pricingModels.length) query = query.in("pricing_model", filters.pricingModels as any);
      if (filters.lookingFor.length) {
        const ors = filters.lookingFor.map((k) => `looking_for.ilike.%${k}%`).join(",");
        query = query.or(ors);
      }

      if (filters.sort === "new") query = query.order("created_at", { ascending: false, nullsFirst: false });
      else if (filters.sort === "popular") query = query.order("interested_count", { ascending: false });
      else if (filters.sort === "activity") query = query.order("updated_at", { ascending: false, nullsFirst: false });
      else if (filters.sort === "mrr") query = query.order("interested_count", { ascending: false }); // fallback secondary; client re-ranks by bucket below
      else if (filters.sort === "match") query = query.order("interested_count", { ascending: false }); // fallback secondary; client re-ranks by match below
      else query = query.order("views", { ascending: false });

      query = query.range(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE - 1);
      const { data, error } = await query;
      if (cancelled) return;
      if (error) { console.error(error); setLoading(false); return; }

      let rows = (data ?? []) as CardWithReasons[];

      if (page === 0 && rows.length > 0) {
        const now = new Date().toISOString();
        const ids = rows.map((r) => r.id);
        const { data: promos } = await supabase
          .from("promotions")
          .select("listing_id")
          .lte("starts_at", now)
          .gte("ends_at", now)
          .in("listing_id", ids);
        const promoted = new Set((promos ?? []).map((p: any) => p.listing_id));
        if (promoted.size > 0) {
          rows = rows.map((r) => ({ ...r, promoted: promoted.has(r.id) }));
        }
      }

      // Client-side re-ranking for sorts Postgres can't easily express.
      if (filters.sort === "mrr") {
        const rank = (b: string | null) => (b ? MRR_BUCKETS.indexOf(b as any) : -1);
        rows = [...rows].sort((a, b) => rank(b.mrr_range) - rank(a.mrr_range));
      } else if (filters.sort === "match") {
        const score = (r: CardWithReasons) => {
          let s = 0;
          if (filters.tech.length && r.tech_stack?.length) {
            s += r.tech_stack.filter((t) => filters.tech.includes(t)).length * 10;
          }
          if (filters.countries.length && r.country && filters.countries.includes(r.country)) s += 8;
          if (filters.mrr.length && r.mrr_range && filters.mrr.includes(r.mrr_range)) s += 6;
          s += Math.log10((r.interested_count ?? 0) + 1) * 2;
          s += Math.log10((r.views ?? 0) + 1);
          return s;
        };
        rows = [...rows].sort((a, b) => score(b) - score(a));
      }

      // Always keep promoted on top.
      rows.sort((a, b) => Number(!!(b as any).promoted) - Number(!!(a as any).promoted));

      setItems((prev) => (page === 0 ? rows : [...prev, ...rows]));
      setHasMore(rows.length === PAGE_SIZE);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [page, filterKey, filters, user?.id]);

  useEffect(() => {
    if (!sentinelRef.current) return;
    const el = sentinelRef.current;
    const io = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !loading && hasMore) setPage((p) => p + 1);
    }, { rootMargin: "600px" });
    io.observe(el);
    return () => io.disconnect();
  }, [loading, hasMore]);

  const activeFilterCount =
    (filters.mrr.length ? 1 : 0) +
    (filters.tech.length ? 1 : 0) +
    (filters.countries.length ? 1 : 0) +
    (filters.pricingModels.length ? 1 : 0) +
    (filters.lookingFor.length ? 1 : 0) +
    (filters.categoryId ? 1 : 0);

  const handleSaveSearch = async () => {
    if (!user) { navigate({ to: "/auth", search: { redirect: "/explore" } as any }); return; }
    if (!saveName.trim()) { toast.error("Give this search a name."); return; }
    try {
      await saveSearch({
        data: {
          name: saveName.trim(),
          q: filters.q || null,
          category_id: filters.categoryId,
          mrr_ranges: filters.mrr,
          tech_stack: filters.tech,
          countries: filters.countries,
          pricing_models: filters.pricingModels,
          looking_for: filters.lookingFor,
          sort: filters.sort,
          email_notify: emailNotify,
        },
      });
      toast.success("Search saved. We'll email you when new matches appear.");
      setSaveOpen(false);
      setSaveName("");
      await refreshSaved();
    } catch (e: any) {
      toast.error(e?.message ?? "Couldn't save.");
    }
  };

  const applySaved = (s: any) => {
    setFilters({
      q: s.q ?? "",
      categoryId: s.category_id ?? null,
      mrr: s.mrr_ranges ?? [],
      tech: s.tech_stack ?? [],
      countries: s.countries ?? [],
      pricingModels: s.pricing_models ?? [],
      lookingFor: s.looking_for ?? [],
      sort: s.sort ?? "trending",
    });
  };

  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-12 pb-40">
        <div className="max-w-2xl">
          <p className="text-sm text-muted-foreground">Discovery</p>
          <h1 className="mt-1 font-display text-4xl md:text-5xl">Explore SaaS open to swap</h1>
          <p className="mt-3 text-muted-foreground">Every founder here has said yes to trading access. Filter by MRR, tech stack, and country.</p>
        </div>

        {/* Saved searches strip */}
        {user && saved.length > 0 && (
          <div className="mt-6 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground mr-1">Saved:</span>
            {saved.map((s) => (
              <div key={s.id} className="group inline-flex items-center gap-1 rounded-full border border-hairline bg-surface px-3 py-1 text-xs">
                <button onClick={() => applySaved(s)} className="hover:text-violet">{s.name}</button>
                <button
                  aria-label={s.email_notify ? "Disable email" : "Enable email"}
                  onClick={async () => {
                    await toggleNotify({ data: { id: s.id, email_notify: !s.email_notify } });
                    await refreshSaved();
                  }}
                  className="text-muted-foreground hover:text-foreground"
                  title={s.email_notify ? "Email notifications on" : "Email notifications off"}
                >
                  {s.email_notify ? <Bell className="h-3 w-3" /> : <BellOff className="h-3 w-3" />}
                </button>
                <button
                  aria-label="Delete saved search"
                  onClick={async () => {
                    await deleteSearch({ data: { id: s.id } });
                    await refreshSaved();
                  }}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))}
            <button
              onClick={() => setManageOpen(true)}
              className="inline-flex items-center gap-1 rounded-full border border-hairline bg-surface px-3 py-1 text-xs text-muted-foreground hover:text-foreground"
            >
              <Settings2 className="h-3 w-3" /> Manage
            </button>
          </div>
        )}

        {/* Manage presets dialog */}
        <Dialog open={manageOpen} onOpenChange={(o) => { setManageOpen(o); if (!o) setRenamingId(null); }}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Saved searches</DialogTitle></DialogHeader>
            {saved.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">No saved searches yet.</p>
            ) : (
              <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                {saved.map((s) => {
                  const sortLabel = SORTS.find((x) => x.id === s.sort)?.label ?? s.sort;
                  const chipCount = (s.mrr_ranges?.length ?? 0) + (s.tech_stack?.length ?? 0) + (s.countries?.length ?? 0) + (s.pricing_models?.length ?? 0) + (s.looking_for?.length ?? 0);
                  return (
                    <div key={s.id} className="rounded-lg border border-hairline p-3">
                      {renamingId === s.id ? (
                        <div className="flex items-center gap-2">
                          <Input
                            value={renameValue}
                            onChange={(e) => setRenameValue(e.target.value)}
                            className="h-8 text-sm"
                            autoFocus
                            onKeyDown={(e) => { if (e.key === "Enter") { (async () => {
                              const name = renameValue.trim();
                              if (!name) return;
                              try {
                                await updateSearch({ data: { id: s.id, name } });
                                toast.success("Renamed");
                                setRenamingId(null);
                                await refreshSaved();
                              } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                            })(); } if (e.key === "Escape") setRenamingId(null); }}
                          />
                          <Button size="sm" onClick={async () => {
                            const name = renameValue.trim();
                            if (!name) return;
                            try {
                              await updateSearch({ data: { id: s.id, name } });
                              toast.success("Renamed");
                              setRenamingId(null);
                              await refreshSaved();
                            } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                          }}>Save</Button>
                          <Button size="sm" variant="ghost" onClick={() => setRenamingId(null)}>Cancel</Button>
                        </div>
                      ) : (
                        <div className="flex items-start gap-3">
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-medium truncate">{s.name}</div>
                            <div className="text-[11px] text-muted-foreground mt-0.5">
                              Sort: {sortLabel} · {chipCount} filter{chipCount === 1 ? "" : "s"} · {s.email_notify ? "email on" : "email off"}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <Button size="sm" variant="ghost" className="h-8 px-2" onClick={() => { applySaved(s); setManageOpen(false); toast.success("Applied"); }}>Apply</Button>
                            <Button size="sm" variant="ghost" className="h-8 px-2" onClick={async () => {
                              try {
                                await updateSearch({ data: {
                                  id: s.id,
                                  q: filters.q || null,
                                  category_id: filters.categoryId,
                                  mrr_ranges: filters.mrr,
                                  tech_stack: filters.tech,
                                  countries: filters.countries,
                                  pricing_models: filters.pricingModels,
                                  looking_for: filters.lookingFor,
                                  sort: filters.sort,
                                } });
                                toast.success("Updated with current filters");
                                await refreshSaved();
                              } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                            }}>Update</Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={async () => {
                              try {
                                let slug = s.share_slug as string | null;
                                if (!slug) {
                                  const res = await setShareSlug({ data: { id: s.id, enabled: true } });
                                  slug = res.share_slug ?? null;
                                  await refreshSaved();
                                }
                                if (slug) {
                                  const url = `${window.location.origin}/s/${slug}`;
                                  try { await navigator.clipboard.writeText(url); } catch { /* ignore */ }
                                  setCopiedSlug(slug);
                                  setTimeout(() => setCopiedSlug((c) => (c === slug ? null : c)), 2000);
                                  toast.success("Share link copied", { description: url });
                                }
                              } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                            }} aria-label={s.share_slug ? "Copy share link" : "Enable sharing"} title={s.share_slug ? "Copy share link" : "Enable sharing"}>
                              {copiedSlug && copiedSlug === s.share_slug ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : (s.share_slug ? <Link2 className="h-3.5 w-3.5" /> : <Share2 className="h-3.5 w-3.5" />)}
                            </Button>
                            {s.share_slug && (
                              <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive" onClick={async () => {
                                try {
                                  await setShareSlug({ data: { id: s.id, enabled: false } });
                                  toast.success("Sharing disabled");
                                  await refreshSaved();
                                } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                              }} aria-label="Disable sharing" title="Disable sharing">
                                <X className="h-3.5 w-3.5" />
                              </Button>
                            )}
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={async () => {
                              setHistoryPreset(s);
                              setVersionsLoading(true);
                              try {
                                const rows = await listVersions({ data: { saved_search_id: s.id } });
                                setVersions(rows as any[]);
                              } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                              finally { setVersionsLoading(false); }
                            }} aria-label="View history" title="View history">
                              <History className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => { setRenamingId(s.id); setRenameValue(s.name); }} aria-label="Rename">
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            {s.share_slug && (
                              <a
                                href={`/s/${s.share_slug}`}
                                target="_blank"
                                rel="noreferrer"
                                className="hidden md:inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground px-2"
                                title="Open shared link"
                              >
                                /s/{s.share_slug}
                              </a>
                            )}
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive" onClick={async () => {
                              try {
                                await deleteSearch({ data: { id: s.id } });
                                toast.success("Deleted");
                                await refreshSaved();
                              } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                            }} aria-label="Delete">
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setManageOpen(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Version history dialog */}
        <Dialog open={!!historyPreset} onOpenChange={(o) => { if (!o) { setHistoryPreset(null); setVersions([]); } }}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>History — {historyPreset?.name}</DialogTitle>
            </DialogHeader>
            {versionsLoading ? (
              <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : versions.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">No prior versions yet. Edits to this preset will show up here.</p>
            ) : (
              <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                {versions.map((v) => {
                  const snap = v.snapshot ?? {};
                  const chips = [
                    ...(snap.mrr_ranges ?? []).map((x: string) => `MRR ${x}`),
                    ...(snap.tech_stack ?? []),
                    ...(snap.countries ?? []),
                    ...(snap.pricing_models ?? []),
                    ...(snap.looking_for ?? []),
                  ];
                  return (
                    <div key={v.id} className="rounded-lg border border-hairline p-3">
                      <div className="flex items-start gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-[10px]">v{v.version_number}</Badge>
                            <span className="text-sm font-medium truncate">{snap.name ?? historyPreset?.name}</span>
                          </div>
                          <div className="text-[11px] text-muted-foreground mt-0.5">
                            {new Date(v.created_at).toLocaleString()} · sort: {snap.sort ?? "trending"} · {chips.length} filter{chips.length === 1 ? "" : "s"}
                          </div>
                          {snap.q && <div className="text-xs text-muted-foreground mt-1 truncate">"{snap.q}"</div>}
                          {chips.length > 0 && (
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              {chips.slice(0, 8).map((c: string) => (
                                <span key={c} className="text-[10px] rounded-full border border-hairline px-2 py-0.5 text-muted-foreground">{c}</span>
                              ))}
                              {chips.length > 8 && <span className="text-[10px] text-muted-foreground">+{chips.length - 8}</span>}
                            </div>
                          )}
                        </div>
                        <Button size="sm" variant="ghost" className="h-8 gap-1 shrink-0" onClick={async () => {
                          try {
                            await restoreVersion({ data: { version_id: v.id } });
                            toast.success(`Restored v${v.version_number}`);
                            await refreshSaved();
                            const rows = await listVersions({ data: { saved_search_id: historyPreset.id } });
                            setVersions(rows as any[]);
                          } catch (err: any) { toast.error(err?.message ?? "Failed"); }
                        }}>
                          <RotateCcw className="h-3.5 w-3.5" /> Restore
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setHistoryPreset(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <div className="mt-8 flex flex-col gap-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input value={filters.q} onChange={(e) => setFilters({ ...filters, q: e.target.value })} placeholder="Search by name…" className="pl-10 h-11 rounded-full" />
              {filters.q && (
                <button aria-label="Clear" onClick={() => setFilters({ ...filters, q: "" })} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {SORTS.map((s) => (
                <Button
                  key={s.id}
                  variant={filters.sort === s.id ? "default" : "outline"}
                  onClick={() => setFilters({ ...filters, sort: s.id })}
                  className={`rounded-full ${filters.sort === s.id ? "bg-foreground text-background hover:opacity-90" : ""}`}
                >
                  {s.label}
                </Button>
              ))}
              <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="rounded-full gap-2">
                    <Bookmark className="h-4 w-4" /> Save search
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Save this search</DialogTitle></DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" value={saveName} onChange={(e) => setSaveName(e.target.value)} placeholder="AI B2B SaaS in Europe" />
                    </div>
                    <div className="flex items-center justify-between rounded-lg border border-hairline p-3">
                      <div>
                        <div className="text-sm font-medium">Email me when new listings match</div>
                        <div className="text-xs text-muted-foreground">Daily digest, unsubscribe anytime.</div>
                      </div>
                      <Switch checked={emailNotify} onCheckedChange={setEmailNotify} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setSaveOpen(false)}>Cancel</Button>
                    <Button onClick={handleSaveSearch}>Save search</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Filter chips row */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground mr-1"><SlidersHorizontal className="h-3.5 w-3.5" /> Filters</span>

            {/* Category */}
            <FilterPopover label="Category" activeCount={filters.categoryId ? 1 : 0}>
              <div className="max-h-64 overflow-y-auto space-y-1">
                <button
                  onClick={() => setFilters({ ...filters, categoryId: null })}
                  className={`w-full text-left px-2 py-1.5 rounded text-sm ${filters.categoryId === null ? "bg-foreground text-background" : "hover:bg-muted"}`}
                >
                  All categories
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setFilters({ ...filters, categoryId: c.id })}
                    className={`w-full text-left px-2 py-1.5 rounded text-sm ${filters.categoryId === c.id ? "bg-foreground text-background" : "hover:bg-muted"}`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </FilterPopover>

            {/* MRR */}
            <FilterPopover label="MRR" activeCount={filters.mrr.length}>
              <div className="grid grid-cols-2 gap-1.5 w-64">
                {MRR_BUCKETS.map((m) => {
                  const active = filters.mrr.includes(m);
                  return (
                    <button
                      key={m}
                      onClick={() =>
                        setFilters({
                          ...filters,
                          mrr: active ? filters.mrr.filter((x) => x !== m) : [...filters.mrr, m],
                        })
                      }
                      className={`px-2.5 py-1.5 rounded-full text-xs border ${active ? "bg-foreground text-background border-foreground" : "border-hairline hover:border-foreground/40"}`}
                    >
                      {m}
                    </button>
                  );
                })}
              </div>
            </FilterPopover>

            {/* Tech */}
            <FilterPopover label="Tech stack" activeCount={filters.tech.length}>
              <div className="w-72">
                <div className="flex flex-wrap gap-1.5 max-h-64 overflow-y-auto">
                  {POPULAR_TECH.map((t) => {
                    const active = filters.tech.includes(t);
                    return (
                      <button
                        key={t}
                        onClick={() =>
                          setFilters({
                            ...filters,
                            tech: active ? filters.tech.filter((x) => x !== t) : [...filters.tech, t],
                          })
                        }
                        className={`px-2.5 py-1 rounded-full text-xs border ${active ? "bg-foreground text-background border-foreground" : "border-hairline hover:border-foreground/40"}`}
                      >
                        {t}
                      </button>
                    );
                  })}
                </div>
              </div>
            </FilterPopover>

            {/* Country */}
            <FilterPopover label="Country" activeCount={filters.countries.length}>
              <div className="w-64 max-h-64 overflow-y-auto space-y-1">
                {COUNTRIES.map((c) => {
                  const active = filters.countries.includes(c);
                  return (
                    <button
                      key={c}
                      onClick={() =>
                        setFilters({
                          ...filters,
                          countries: active ? filters.countries.filter((x) => x !== c) : [...filters.countries, c],
                        })
                      }
                      className={`w-full text-left px-2 py-1.5 rounded text-sm ${active ? "bg-foreground text-background" : "hover:bg-muted"}`}
                    >
                      {c}
                    </button>
                  );
                })}
              </div>
            </FilterPopover>

            {/* Pricing model */}
            <FilterPopover label="Pricing" activeCount={filters.pricingModels.length}>
              <div className="w-56 max-h-64 overflow-y-auto space-y-1">
                {PRICING_MODELS.map((p) => {
                  const active = filters.pricingModels.includes(p.id);
                  return (
                    <button
                      key={p.id}
                      onClick={() =>
                        setFilters({
                          ...filters,
                          pricingModels: active ? filters.pricingModels.filter((x) => x !== p.id) : [...filters.pricingModels, p.id],
                        })
                      }
                      className={`w-full text-left px-2 py-1.5 rounded text-sm ${active ? "bg-foreground text-background" : "hover:bg-muted"}`}
                    >
                      {p.label}
                    </button>
                  );
                })}
              </div>
            </FilterPopover>

            {/* Looking for (swap type) */}
            <FilterPopover label="Looking for" activeCount={filters.lookingFor.length}>
              <div className="w-64 max-h-64 overflow-y-auto space-y-1">
                <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-muted-foreground">What the founder wants in a swap</div>
                {LOOKING_FOR.map((l) => {
                  const active = filters.lookingFor.includes(l.id);
                  return (
                    <button
                      key={l.id}
                      onClick={() =>
                        setFilters({
                          ...filters,
                          lookingFor: active ? filters.lookingFor.filter((x) => x !== l.id) : [...filters.lookingFor, l.id],
                        })
                      }
                      className={`w-full text-left px-2 py-1.5 rounded text-sm ${active ? "bg-foreground text-background" : "hover:bg-muted"}`}
                    >
                      {l.label}
                    </button>
                  );
                })}
              </div>
            </FilterPopover>

            {activeFilterCount > 0 && (
              <Button variant="ghost" size="sm" className="rounded-full text-xs" onClick={() => setFilters(EMPTY_FILTERS)}>
                Clear all
              </Button>
            )}
          </div>

          {/* Active filter pills */}
          {(filters.mrr.length > 0 || filters.tech.length > 0 || filters.countries.length > 0 || filters.pricingModels.length > 0 || filters.lookingFor.length > 0) && (
            <div className="flex flex-wrap gap-1.5">
              {filters.mrr.map((m) => (
                <ActivePill key={"mrr-" + m} label={`MRR ${m}`} onRemove={() => setFilters({ ...filters, mrr: filters.mrr.filter((x) => x !== m) })} />
              ))}
              {filters.tech.map((t) => (
                <ActivePill key={"tech-" + t} label={t} onRemove={() => setFilters({ ...filters, tech: filters.tech.filter((x) => x !== t) })} />
              ))}
              {filters.countries.map((c) => (
                <ActivePill key={"c-" + c} label={c} onRemove={() => setFilters({ ...filters, countries: filters.countries.filter((x) => x !== c) })} />
              ))}
              {filters.pricingModels.map((p) => {
                const label = PRICING_MODELS.find((x) => x.id === p)?.label ?? p;
                return <ActivePill key={"pm-" + p} label={label} onRemove={() => setFilters({ ...filters, pricingModels: filters.pricingModels.filter((x) => x !== p) })} />;
              })}
              {filters.lookingFor.map((l) => {
                const label = LOOKING_FOR.find((x) => x.id === l)?.label ?? l;
                return <ActivePill key={"lf-" + l} label={label} onRemove={() => setFilters({ ...filters, lookingFor: filters.lookingFor.filter((x) => x !== l) })} />;
              })}
            </div>
          )}
        </div>


        {/* Grid */}
        {items.length === 0 && !loading ? (
          <div className="mt-24 text-center">
            <p className="font-display text-2xl">Nothing here yet.</p>
            <p className="mt-2 text-muted-foreground">Try clearing filters, or be the first to list.</p>
          </div>
        ) : (
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {items.map((l) => (
              <ListingCardWithMeta
                key={l.id}
                listing={l}
                filters={filters}
                inCompare={compareSlugs.includes(l.slug)}
                onToggleCompare={() => toggleCompare(l.slug)}
              />
            ))}
          </div>
        )}

        {loading && (
          <div className="mt-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        )}
        <div ref={sentinelRef} className="h-10" />
      </main>

      {/* Compare tray */}
      {compareSlugs.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-hairline bg-surface/95 backdrop-blur">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 min-w-0">
              <GitCompare className="h-4 w-4 text-violet shrink-0" />
              <span className="text-sm font-medium shrink-0">Compare {compareSlugs.length}/4:</span>
              <div className="flex flex-wrap gap-1.5 min-w-0">
                {compareSlugs.map((s) => (
                  <Badge key={s} variant="outline" className="rounded-full">
                    {s}
                    <button className="ml-1 hover:text-destructive" onClick={() => toggleCompare(s)}><X className="h-3 w-3" /></button>
                  </Badge>
                ))}
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="ghost" size="sm" onClick={() => setCompareSlugs([])}>Clear</Button>
              <Button
                size="sm"
                disabled={compareSlugs.length < 2}
                onClick={() => navigate({ to: "/compare", search: { ids: compareSlugs.join(",") } as any })}
              >
                Compare →
              </Button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

function FilterPopover({
  label, activeCount, children,
}: { label: string; activeCount: number; children: React.ReactNode }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="rounded-full h-8 gap-1.5">
          {label}
          {activeCount > 0 && <Badge className="h-4 min-w-4 px-1 rounded-full bg-violet text-primary-foreground text-[10px]">{activeCount}</Badge>}
          <ChevronDown className="h-3 w-3" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="p-3">{children}</PopoverContent>
    </Popover>
  );
}

function ActivePill({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <Badge variant="outline" className="rounded-full pl-2.5 pr-1 py-0.5 gap-1">
      {label}
      <button onClick={onRemove} aria-label="Remove" className="ml-0.5 rounded-full p-0.5 hover:bg-muted">
        <X className="h-3 w-3" />
      </button>
    </Badge>
  );
}

function ListingCardWithMeta({
  listing, filters, inCompare, onToggleCompare,
}: {
  listing: CardWithReasons;
  filters: MarketplaceFilters;
  inCompare: boolean;
  onToggleCompare: () => void;
}) {
  const reasons = explainMatch(listing, filters);
  return (
    <div className="relative">
      <ListingCard listing={listing} />
      <div className="absolute top-3 right-3 flex gap-1.5">
        <Popover>
          <PopoverTrigger asChild>
            <button
              aria-label="Why am I seeing this?"
              className="h-7 w-7 rounded-full bg-background/80 backdrop-blur border border-hairline flex items-center justify-center text-muted-foreground hover:text-foreground"
              onClick={(e) => e.preventDefault()}
            >
              <Info className="h-3.5 w-3.5" />
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-72 text-xs">
            <p className="font-medium mb-1.5">Why you're seeing this</p>
            <ul className="space-y-1 text-muted-foreground list-disc pl-4">
              {reasons.map((r, i) => <li key={i}>{r}</li>)}
            </ul>
          </PopoverContent>
        </Popover>
        <button
          aria-label={inCompare ? "Remove from compare" : "Add to compare"}
          onClick={(e) => { e.preventDefault(); onToggleCompare(); }}
          className={`h-7 px-2 rounded-full backdrop-blur border text-[11px] flex items-center gap-1 ${
            inCompare
              ? "bg-violet text-primary-foreground border-violet"
              : "bg-background/80 border-hairline text-muted-foreground hover:text-foreground"
          }`}
        >
          <GitCompare className="h-3 w-3" />
          {inCompare ? "Added" : "Compare"}
        </button>
      </div>
    </div>
  );
}

void Link;
