import { createFileRoute, redirect } from "@tanstack/react-router";

/** Convenience alias: /u/<username> → /@<username> */
export const Route = createFileRoute("/u/$username")({
  beforeLoad: ({ params }) => {
    throw redirect({ to: "/@{$username}", params: { username: params.username } });
  },
});
