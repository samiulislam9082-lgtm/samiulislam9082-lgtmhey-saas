import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useSignedImage } from "@/hooks/useSignedImage";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { buildHead } from "@/lib/seo-head";
import { Search, CheckCircle2, Users, ArrowUpRight, Loader2 } from "lucide-react";

export const Route = createFileRoute("/founders")({
  head: () =>
    buildHead({
      path: "/founders",
      title: "Founders directory — Browse SaaS founders on Hey SaaS",
      description:
        "Search founders by username and open any public profile to see their SaaS listings, swaps closed and links.",
    }),
  component: FoundersDirectory,
});

type FounderRow = {
  id: string;
  username: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  verified: boolean;
  created_at: string;
};

function FoundersDirectory() {
  const [rows, setRows] = useState<FounderRow[] | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, username, display_name, bio, avatar_url, verified, created_at")
        .not("username", "is", null)
        .order("verified", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(200);
      setRows((data ?? []) as FounderRow[]);
    })();
  }, []);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase().replace(/^@/, "");
    if (!rows) return null;
    if (!needle) return rows;
    return rows.filter(
      (r) =>
        r.username?.toLowerCase().includes(needle) ||
        (r.display_name ?? "").toLowerCase().includes(needle),
    );
  }, [rows, q]);

  const exact = useMemo(() => {
    const needle = q.trim().toLowerCase().replace(/^@/, "");
    if (!needle || !rows) return null;
    return rows.find((r) => r.username?.toLowerCase() === needle) ?? null;
  }, [rows, q]);

  return (
    <div className="min-h-dvh flex flex-col bg-background">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="max-w-2xl">
          <p className="text-sm text-muted-foreground inline-flex items-center gap-2">
            <Users className="h-4 w-4 text-violet" />
            Founders
          </p>
          <h1 className="mt-2 font-display text-4xl md:text-5xl">Find a founder by username</h1>
          <p className="mt-3 text-muted-foreground">
            Type a username to jump straight to a public profile, or browse everyone building on Hey SaaS.
          </p>
        </div>

        <form
          className="mt-8 relative max-w-xl"
          onSubmit={(e) => {
            e.preventDefault();
          }}
        >
          <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search @username or name…"
            aria-label="Search founders by username"
            className="h-12 rounded-full pl-11 pr-4 bg-surface/60 border-hairline"
          />
        </form>

        {exact && (
          <Link
            to="/@{$username}"
            params={{ username: exact.username }}
            className="mt-4 inline-flex items-center gap-2 rounded-full border border-violet/40 bg-violet/10 px-4 py-2 text-sm text-foreground hover:bg-violet/20 transition-colors"
          >
            Open @{exact.username}
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        )}

        {filtered === null ? (
          <div className="mt-16 flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading founders…
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-16 rounded-2xl border border-hairline bg-surface p-10 text-center text-muted-foreground">
            No founder matches “{q}”.
          </div>
        ) : (
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((f) => (
              <FounderCard key={f.id} founder={f} />
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

function FounderCard({ founder }: { founder: FounderRow }) {
  const url = useSignedImage("avatars", founder.avatar_url);
  const name = founder.display_name || founder.username;
  return (
    <Link
      to="/@{$username}"
      params={{ username: founder.username }}
      className="group rounded-2xl border border-hairline bg-surface p-5 transition-colors hover:border-violet/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet/60"
    >
      <div className="flex items-center gap-3">
        <Avatar className="h-12 w-12">
          {url && <AvatarImage src={url} alt={founder.username} />}
          <AvatarFallback>{name.slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 font-medium truncate">
            <span className="truncate">{name}</span>
            {founder.verified && <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-violet" />}
          </div>
          <div className="text-xs text-muted-foreground truncate">@{founder.username}</div>
        </div>
      </div>
      {founder.bio && (
        <p className="mt-4 text-sm text-muted-foreground line-clamp-2">{founder.bio}</p>
      )}
      <div className="mt-4 flex items-center justify-between">
        <Badge variant="outline" className="rounded-full text-[11px]">
          Since {new Date(founder.created_at).getFullYear()}
        </Badge>
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground group-hover:text-foreground transition-colors">
          View profile <ArrowUpRight className="h-3 w-3" />
        </span>
      </div>
    </Link>
  );
}
