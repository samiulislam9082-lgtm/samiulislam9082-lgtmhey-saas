import { createFileRoute } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo-head";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/legal/terms")({
  head: () =>
    buildHead({
      path: "/legal/terms",
      title: "Terms of Service — Hey SaaS",
      description:
        "The terms that govern using Hey SaaS to list, discover, and swap SaaS products.",
    }),
  component: Terms,
});

function Terms() {
  return (
    <div className="min-h-dvh flex flex-col">
      <Header />
      <main id="main" className="flex-1 mx-auto w-full max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="font-display text-5xl mb-2">Terms of Service</h1>
        <p className="text-sm text-muted-foreground mb-10">Last updated: {new Date().toLocaleDateString()}</p>
        <article className="prose prose-invert max-w-none space-y-6 text-muted-foreground">
          <section>
            <h2 className="text-foreground font-display text-2xl">1. What Hey SaaS is</h2>
            <p>Hey SaaS is a marketplace where founders swap access to their SaaS products with other founders. We never facilitate cash payments between users. The only money we handle is the non-refundable $19 safety fee per side per swap.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">2. Eligibility</h2>
            <p>You must be 18+ and legally able to enter contracts. Accounts are for humans; no bots, no resellers, no bulk-listing farms.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">3. Your listings</h2>
            <p>You retain all rights to your product. You grant us a license to display your listing content on Hey SaaS and its promotional surfaces. You warrant that you own or control the SaaS you list, and that your listing is truthful.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">4. Swaps are peer-to-peer</h2>
            <p>Once both parties pay the safety fee, you exchange access directly. Hey SaaS is not a party to the swap and does not guarantee the value, quality, uptime, or continuity of any listed product.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">5. Safety fee</h2>
            <p>See the <a href="/legal/safety-fee-policy" className="text-primary">Safety Fee Policy</a>. Fees are non-refundable except in cases of proven fraud, as determined by Hey SaaS admins at their sole discretion.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">6. Prohibited content</h2>
            <p>No illegal, adult, hateful, deceptive, or infringing content. No selling seats/accounts. No cash on the side. Violations = removal + ban.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">7. Termination</h2>
            <p>We can suspend or delete accounts at our discretion. You can delete your account at any time from Settings.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">8. Disclaimers</h2>
            <p>Hey SaaS is provided "as is" with no warranties. To the maximum extent permitted by law, our total liability is capped at the sum of safety fees you paid us in the trailing 12 months.</p>
          </section>
          <section>
            <h2 className="text-foreground font-display text-2xl">9. Contact</h2>
            <p>Questions? hello@heysaas.co</p>
          </section>
        </article>
      </main>
      <Footer />
    </div>
  );
}
