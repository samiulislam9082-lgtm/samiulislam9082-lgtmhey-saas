export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_actions: {
        Row: {
          action: string
          admin_id: string
          created_at: string
          id: string
          metadata: Json
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          admin_id: string
          created_at?: string
          id?: string
          metadata?: Json
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          admin_id?: string
          created_at?: string
          id?: string
          metadata?: Json
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: []
      }
      bookmarks: {
        Row: {
          created_at: string
          founder_id: string | null
          id: string
          listing_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          founder_id?: string | null
          id?: string
          listing_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          founder_id?: string | null
          id?: string
          listing_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookmarks_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "saas_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          name: string
          slug: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name: string
          slug: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name?: string
          slug?: string
          sort_order?: number
        }
        Relationships: []
      }
      follows: {
        Row: {
          created_at: string
          follower_id: string
          following_id: string
          id: string
        }
        Insert: {
          created_at?: string
          follower_id: string
          following_id: string
          id?: string
        }
        Update: {
          created_at?: string
          follower_id?: string
          following_id?: string
          id?: string
        }
        Relationships: []
      }
      interests: {
        Row: {
          created_at: string
          id: string
          listing_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          listing_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          listing_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "interests_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "saas_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      message_action_audit: {
        Row: {
          action: string
          created_at: string
          details: Json
          id: string
          thread_ids: string[]
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json
          id?: string
          thread_ids?: string[]
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json
          id?: string
          thread_ids?: string[]
          user_id?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          attachments: Json
          body: string
          created_at: string
          id: string
          seen_at: string | null
          sender_id: string
          thread_id: string
        }
        Insert: {
          attachments?: Json
          body: string
          created_at?: string
          id?: string
          seen_at?: string | null
          sender_id: string
          thread_id: string
        }
        Update: {
          attachments?: Json
          body?: string
          created_at?: string
          id?: string
          seen_at?: string | null
          sender_id?: string
          thread_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      motion_probe_snapshots: {
        Row: {
          created_at: string
          device_label: string | null
          id: string
          kind: string
          pathname: string
          ran_at: string
          rows: Json
          selector: string
          total: number
          user_id: string
        }
        Insert: {
          created_at?: string
          device_label?: string | null
          id: string
          kind: string
          pathname: string
          ran_at: string
          rows?: Json
          selector: string
          total: number
          user_id: string
        }
        Update: {
          created_at?: string
          device_label?: string | null
          id?: string
          kind?: string
          pathname?: string
          ran_at?: string
          rows?: Json
          selector?: string
          total?: number
          user_id?: string
        }
        Relationships: []
      }
      newsletter_subscribers: {
        Row: {
          confirmed_at: string | null
          created_at: string
          email: string
          id: string
          source: string | null
          unsubscribed_at: string | null
        }
        Insert: {
          confirmed_at?: string | null
          created_at?: string
          email: string
          id?: string
          source?: string | null
          unsubscribed_at?: string | null
        }
        Update: {
          confirmed_at?: string | null
          created_at?: string
          email?: string
          id?: string
          source?: string | null
          unsubscribed_at?: string | null
        }
        Relationships: []
      }
      notification_preferences: {
        Row: {
          created_at: string
          email_prefs: Json
          inapp_prefs: Json
          quiet_hours_enabled: boolean
          quiet_hours_end: number
          quiet_hours_start: number
          timezone: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email_prefs?: Json
          inapp_prefs?: Json
          quiet_hours_enabled?: boolean
          quiet_hours_end?: number
          quiet_hours_start?: number
          timezone?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email_prefs?: Json
          inapp_prefs?: Json
          quiet_hours_enabled?: boolean
          quiet_hours_end?: number
          quiet_hours_start?: number
          timezone?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          link: string | null
          metadata: Json
          read_at: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          metadata?: Json
          read_at?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          metadata?: Json
          read_at?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount_cents: number
          created_at: string
          currency: string
          id: string
          paid_at: string | null
          refunded_at: string | null
          status: string
          stripe_charge_id: string | null
          stripe_checkout_session_id: string | null
          stripe_payment_intent_id: string | null
          swap_request_id: string
          user_id: string
        }
        Insert: {
          amount_cents?: number
          created_at?: string
          currency?: string
          id?: string
          paid_at?: string | null
          refunded_at?: string | null
          status?: string
          stripe_charge_id?: string | null
          stripe_checkout_session_id?: string | null
          stripe_payment_intent_id?: string | null
          swap_request_id: string
          user_id: string
        }
        Update: {
          amount_cents?: number
          created_at?: string
          currency?: string
          id?: string
          paid_at?: string | null
          refunded_at?: string | null
          status?: string
          stripe_charge_id?: string | null
          stripe_checkout_session_id?: string | null
          stripe_payment_intent_id?: string | null
          swap_request_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_swap_request_id_fkey"
            columns: ["swap_request_id"]
            isOneToOne: false
            referencedRelation: "swap_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_config: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      posts: {
        Row: {
          author_id: string | null
          body_md: string
          cover_url: string | null
          created_at: string
          excerpt: string | null
          id: string
          published_at: string | null
          slug: string
          title: string
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          body_md: string
          cover_url?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          published_at?: string | null
          slug: string
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          body_md?: string
          cover_url?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          published_at?: string | null
          slug?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          country: string | null
          cover_url: string | null
          created_at: string
          display_name: string | null
          explore_preferences: Json
          github_handle: string | null
          id: string
          linkedin_handle: string | null
          location: string | null
          motion_preference: string
          twitter_handle: string | null
          updated_at: string
          username: string | null
          verified: boolean
          website_url: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          country?: string | null
          cover_url?: string | null
          created_at?: string
          display_name?: string | null
          explore_preferences?: Json
          github_handle?: string | null
          id: string
          linkedin_handle?: string | null
          location?: string | null
          motion_preference?: string
          twitter_handle?: string | null
          updated_at?: string
          username?: string | null
          verified?: boolean
          website_url?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          country?: string | null
          cover_url?: string | null
          created_at?: string
          display_name?: string | null
          explore_preferences?: Json
          github_handle?: string | null
          id?: string
          linkedin_handle?: string | null
          location?: string | null
          motion_preference?: string
          twitter_handle?: string | null
          updated_at?: string
          username?: string | null
          verified?: boolean
          website_url?: string | null
        }
        Relationships: []
      }
      promotions: {
        Row: {
          created_at: string
          ends_at: string
          id: string
          listing_id: string
          slot: string
          starts_at: string
        }
        Insert: {
          created_at?: string
          ends_at: string
          id?: string
          listing_id: string
          slot: string
          starts_at: string
        }
        Update: {
          created_at?: string
          ends_at?: string
          id?: string
          listing_id?: string
          slot?: string
          starts_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "promotions_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "saas_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      rate_limits: {
        Row: {
          bucket: string
          count: number
          id: string
          ip_hash: string | null
          user_id: string | null
          window_start: string
        }
        Insert: {
          bucket: string
          count?: number
          id?: string
          ip_hash?: string | null
          user_id?: string | null
          window_start?: string
        }
        Update: {
          bucket?: string
          count?: number
          id?: string
          ip_hash?: string | null
          user_id?: string | null
          window_start?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          details: string | null
          id: string
          reason: string
          reporter_id: string
          status: string
          target_id: string
          target_type: string
        }
        Insert: {
          created_at?: string
          details?: string | null
          id?: string
          reason: string
          reporter_id: string
          status?: string
          target_id: string
          target_type: string
        }
        Update: {
          created_at?: string
          details?: string | null
          id?: string
          reason?: string
          reporter_id?: string
          status?: string
          target_id?: string
          target_type?: string
        }
        Relationships: []
      }
      saas_listings: {
        Row: {
          arr_range: string | null
          category_id: string | null
          country: string | null
          cover_url: string | null
          created_at: string
          demo_video_url: string | null
          description: string | null
          featured: boolean
          id: string
          interested_count: number
          launch_year: number | null
          logo_url: string | null
          looking_for: string | null
          mrr_range: string | null
          name: string
          owner_id: string
          pricing_model: Database["public"]["Enums"]["pricing_model"] | null
          reason_for_swap: string | null
          screenshots: Json
          search_tsv: unknown
          slug: string
          status: Database["public"]["Enums"]["listing_status"]
          status_expires_at: string | null
          status_note: string | null
          tag_slugs: string[]
          tagline: string | null
          tech_stack: string[]
          updated_at: string
          user_count_range: string | null
          views: number
          website_url: string | null
        }
        Insert: {
          arr_range?: string | null
          category_id?: string | null
          country?: string | null
          cover_url?: string | null
          created_at?: string
          demo_video_url?: string | null
          description?: string | null
          featured?: boolean
          id?: string
          interested_count?: number
          launch_year?: number | null
          logo_url?: string | null
          looking_for?: string | null
          mrr_range?: string | null
          name: string
          owner_id: string
          pricing_model?: Database["public"]["Enums"]["pricing_model"] | null
          reason_for_swap?: string | null
          screenshots?: Json
          search_tsv?: unknown
          slug: string
          status?: Database["public"]["Enums"]["listing_status"]
          status_expires_at?: string | null
          status_note?: string | null
          tag_slugs?: string[]
          tagline?: string | null
          tech_stack?: string[]
          updated_at?: string
          user_count_range?: string | null
          views?: number
          website_url?: string | null
        }
        Update: {
          arr_range?: string | null
          category_id?: string | null
          country?: string | null
          cover_url?: string | null
          created_at?: string
          demo_video_url?: string | null
          description?: string | null
          featured?: boolean
          id?: string
          interested_count?: number
          launch_year?: number | null
          logo_url?: string | null
          looking_for?: string | null
          mrr_range?: string | null
          name?: string
          owner_id?: string
          pricing_model?: Database["public"]["Enums"]["pricing_model"] | null
          reason_for_swap?: string | null
          screenshots?: Json
          search_tsv?: unknown
          slug?: string
          status?: Database["public"]["Enums"]["listing_status"]
          status_expires_at?: string | null
          status_note?: string | null
          tag_slugs?: string[]
          tagline?: string | null
          tech_stack?: string[]
          updated_at?: string
          user_count_range?: string | null
          views?: number
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "saas_listings_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_search_versions: {
        Row: {
          created_at: string
          id: string
          saved_search_id: string
          snapshot: Json
          user_id: string
          version_number: number
        }
        Insert: {
          created_at?: string
          id?: string
          saved_search_id: string
          snapshot: Json
          user_id: string
          version_number: number
        }
        Update: {
          created_at?: string
          id?: string
          saved_search_id?: string
          snapshot?: Json
          user_id?: string
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "saved_search_versions_saved_search_id_fkey"
            columns: ["saved_search_id"]
            isOneToOne: false
            referencedRelation: "saved_searches"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_searches: {
        Row: {
          category_id: string | null
          countries: string[]
          created_at: string
          email_notify: boolean
          id: string
          last_notified_at: string | null
          looking_for: string[]
          mrr_ranges: string[]
          name: string
          pricing_models: string[]
          q: string | null
          share_slug: string | null
          sort: string
          tech_stack: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          category_id?: string | null
          countries?: string[]
          created_at?: string
          email_notify?: boolean
          id?: string
          last_notified_at?: string | null
          looking_for?: string[]
          mrr_ranges?: string[]
          name: string
          pricing_models?: string[]
          q?: string | null
          share_slug?: string | null
          sort?: string
          tech_stack?: string[]
          updated_at?: string
          user_id: string
        }
        Update: {
          category_id?: string | null
          countries?: string[]
          created_at?: string
          email_notify?: boolean
          id?: string
          last_notified_at?: string | null
          looking_for?: string[]
          mrr_ranges?: string[]
          name?: string
          pricing_models?: string[]
          q?: string | null
          share_slug?: string | null
          sort?: string
          tech_stack?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "saved_searches_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      security_audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          id: string
          new_data: Json | null
          old_data: Json | null
          row_id: string | null
          table_name: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          id?: string
          new_data?: Json | null
          old_data?: Json | null
          row_id?: string | null
          table_name: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          id?: string
          new_data?: Json | null
          old_data?: Json | null
          row_id?: string | null
          table_name?: string
        }
        Relationships: []
      }
      stripe_events: {
        Row: {
          event_type: string
          id: string
          received_at: string
          stripe_event_id: string
        }
        Insert: {
          event_type: string
          id?: string
          received_at?: string
          stripe_event_id: string
        }
        Update: {
          event_type?: string
          id?: string
          received_at?: string
          stripe_event_id?: string
        }
        Relationships: []
      }
      support_alerts: {
        Row: {
          acknowledged_at: string | null
          acknowledged_by: string | null
          count: number
          created_at: string
          id: string
          kind: string
          meta: Json
          threshold: number
          window_minutes: number
        }
        Insert: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          count: number
          created_at?: string
          id?: string
          kind: string
          meta?: Json
          threshold: number
          window_minutes: number
        }
        Update: {
          acknowledged_at?: string | null
          acknowledged_by?: string | null
          count?: number
          created_at?: string
          id?: string
          kind?: string
          meta?: Json
          threshold?: number
          window_minutes?: number
        }
        Relationships: []
      }
      support_chat_events: {
        Row: {
          created_at: string
          error_code: string | null
          event_type: string
          id: string
          message: string | null
          meta: Json
          session_id: string
          status: number | null
          topic: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          error_code?: string | null
          event_type: string
          id?: string
          message?: string | null
          meta?: Json
          session_id: string
          status?: number | null
          topic?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          error_code?: string | null
          event_type?: string
          id?: string
          message?: string | null
          meta?: Json
          session_id?: string
          status?: number | null
          topic?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      support_conversations: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      support_message_feedback: {
        Row: {
          comment: string | null
          conversation_id: string | null
          created_at: string
          escalated_ticket_id: string | null
          id: string
          is_report: boolean
          message_excerpt: string | null
          message_index: number
          rating: string
          reason: string | null
          report_explanation: string | null
          resolved_at: string | null
          resolved_by: string | null
          session_id: string
          topic: string | null
          user_id: string | null
          user_question: string | null
        }
        Insert: {
          comment?: string | null
          conversation_id?: string | null
          created_at?: string
          escalated_ticket_id?: string | null
          id?: string
          is_report?: boolean
          message_excerpt?: string | null
          message_index: number
          rating: string
          reason?: string | null
          report_explanation?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          session_id: string
          topic?: string | null
          user_id?: string | null
          user_question?: string | null
        }
        Update: {
          comment?: string | null
          conversation_id?: string | null
          created_at?: string
          escalated_ticket_id?: string | null
          id?: string
          is_report?: boolean
          message_excerpt?: string | null
          message_index?: number
          rating?: string
          reason?: string | null
          report_explanation?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          session_id?: string
          topic?: string | null
          user_id?: string | null
          user_question?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "support_message_feedback_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "support_conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "support_message_feedback_escalated_ticket_id_fkey"
            columns: ["escalated_ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      support_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "support_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      support_ticket_events: {
        Row: {
          actor_id: string | null
          created_at: string
          event_type: string
          from_status: string | null
          id: string
          meta: Json
          note: string | null
          ticket_id: string
          to_status: string | null
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          event_type: string
          from_status?: string | null
          id?: string
          meta?: Json
          note?: string | null
          ticket_id: string
          to_status?: string | null
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          event_type?: string
          from_status?: string | null
          id?: string
          meta?: Json
          note?: string | null
          ticket_id?: string
          to_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "support_ticket_events_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      support_tickets: {
        Row: {
          attachment_mime: string | null
          attachment_name: string | null
          attachment_path: string | null
          attachment_size: number | null
          created_at: string
          email: string
          id: string
          message: string
          name: string
          priority: string
          source: string
          status: string
          subject: string
          transcript: Json
          updated_at: string
          user_id: string | null
        }
        Insert: {
          attachment_mime?: string | null
          attachment_name?: string | null
          attachment_path?: string | null
          attachment_size?: number | null
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          priority?: string
          source?: string
          status?: string
          subject: string
          transcript?: Json
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          attachment_mime?: string | null
          attachment_name?: string | null
          attachment_path?: string | null
          attachment_size?: number | null
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          priority?: string
          source?: string
          status?: string
          subject?: string
          transcript?: Json
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      support_topic_rules: {
        Row: {
          active: boolean
          created_at: string
          id: string
          pattern: string
          priority: number
          topic_slug: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          pattern: string
          priority?: number
          topic_slug: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          pattern?: string
          priority?: number
          topic_slug?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_topic_rules_topic_slug_fkey"
            columns: ["topic_slug"]
            isOneToOne: false
            referencedRelation: "support_topics"
            referencedColumns: ["slug"]
          },
        ]
      }
      support_topics: {
        Row: {
          active: boolean
          created_at: string
          description: string | null
          eta_hours: number | null
          id: string
          label: string
          slug: string
          sort_order: number
          suggested_flow: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string | null
          eta_hours?: number | null
          id?: string
          label: string
          slug: string
          sort_order?: number
          suggested_flow?: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string | null
          eta_hours?: number | null
          id?: string
          label?: string
          slug?: string
          sort_order?: number
          suggested_flow?: string
          updated_at?: string
        }
        Relationships: []
      }
      support_webhook_deliveries: {
        Row: {
          alert_id: string | null
          attempt_count: number
          channel: string
          created_at: string
          dead_lettered_at: string | null
          error: string | null
          failure_reason: string | null
          http_status: number | null
          id: string
          kind: string
          last_attempt_at: string | null
          max_attempts: number
          meta: Json | null
          next_attempt_at: string | null
          payload: Json | null
          status: string
          target: string | null
          ticket_id: string | null
        }
        Insert: {
          alert_id?: string | null
          attempt_count?: number
          channel: string
          created_at?: string
          dead_lettered_at?: string | null
          error?: string | null
          failure_reason?: string | null
          http_status?: number | null
          id?: string
          kind: string
          last_attempt_at?: string | null
          max_attempts?: number
          meta?: Json | null
          next_attempt_at?: string | null
          payload?: Json | null
          status: string
          target?: string | null
          ticket_id?: string | null
        }
        Update: {
          alert_id?: string | null
          attempt_count?: number
          channel?: string
          created_at?: string
          dead_lettered_at?: string | null
          error?: string | null
          failure_reason?: string | null
          http_status?: number | null
          id?: string
          kind?: string
          last_attempt_at?: string | null
          max_attempts?: number
          meta?: Json | null
          next_attempt_at?: string | null
          payload?: Json | null
          status?: string
          target?: string | null
          ticket_id?: string | null
        }
        Relationships: []
      }
      swap_requests: {
        Row: {
          completed_at: string | null
          counter_of_id: string | null
          created_at: string
          fee_deadline_at: string | null
          id: string
          initiator_confirmed_at: string | null
          initiator_id: string
          initiator_listing_id: string
          note: string | null
          recipient_confirmed_at: string | null
          recipient_id: string
          recipient_listing_id: string
          status: Database["public"]["Enums"]["swap_status"]
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          counter_of_id?: string | null
          created_at?: string
          fee_deadline_at?: string | null
          id?: string
          initiator_confirmed_at?: string | null
          initiator_id: string
          initiator_listing_id: string
          note?: string | null
          recipient_confirmed_at?: string | null
          recipient_id: string
          recipient_listing_id: string
          status?: Database["public"]["Enums"]["swap_status"]
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          counter_of_id?: string | null
          created_at?: string
          fee_deadline_at?: string | null
          id?: string
          initiator_confirmed_at?: string | null
          initiator_id?: string
          initiator_listing_id?: string
          note?: string | null
          recipient_confirmed_at?: string | null
          recipient_id?: string
          recipient_listing_id?: string
          status?: Database["public"]["Enums"]["swap_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "swap_requests_counter_of_id_fkey"
            columns: ["counter_of_id"]
            isOneToOne: false
            referencedRelation: "swap_requests"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "swap_requests_initiator_listing_id_fkey"
            columns: ["initiator_listing_id"]
            isOneToOne: false
            referencedRelation: "saas_listings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "swap_requests_recipient_listing_id_fkey"
            columns: ["recipient_listing_id"]
            isOneToOne: false
            referencedRelation: "saas_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      tags: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      thread_states: {
        Row: {
          archived: boolean
          created_at: string
          marked_unread_at: string | null
          muted: boolean
          thread_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          archived?: boolean
          created_at?: string
          marked_unread_at?: string | null
          muted?: boolean
          thread_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          archived?: boolean
          created_at?: string
          marked_unread_at?: string | null
          muted?: boolean
          thread_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thread_states_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "threads"
            referencedColumns: ["id"]
          },
        ]
      }
      threads: {
        Row: {
          archived_by: Json
          created_at: string
          id: string
          last_message_at: string | null
          swap_request_id: string | null
          user_a: string
          user_b: string
        }
        Insert: {
          archived_by?: Json
          created_at?: string
          id?: string
          last_message_at?: string | null
          swap_request_id?: string | null
          user_a: string
          user_b: string
        }
        Update: {
          archived_by?: Json
          created_at?: string
          id?: string
          last_message_at?: string | null
          swap_request_id?: string | null
          user_a?: string
          user_b?: string
        }
        Relationships: [
          {
            foreignKeyName: "threads_swap_request_id_fkey"
            columns: ["swap_request_id"]
            isOneToOne: true
            referencedRelation: "swap_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      user_blocks: {
        Row: {
          blocked_id: string
          blocker_id: string
          created_at: string
          id: string
        }
        Insert: {
          blocked_id: string
          blocker_id: string
          created_at?: string
          id?: string
        }
        Update: {
          blocked_id?: string
          blocker_id?: string
          created_at?: string
          id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      ws_dns_verifications: {
        Row: {
          attempts: number
          created_at: string
          domain: string
          expires_at: string
          id: string
          last_checked_at: string | null
          listing_id: string
          seller_id: string
          status: Database["public"]["Enums"]["ws_dns_status"]
          txt_token: string
          updated_at: string
          verified_at: string | null
        }
        Insert: {
          attempts?: number
          created_at?: string
          domain: string
          expires_at?: string
          id?: string
          last_checked_at?: string | null
          listing_id: string
          seller_id: string
          status?: Database["public"]["Enums"]["ws_dns_status"]
          txt_token: string
          updated_at?: string
          verified_at?: string | null
        }
        Update: {
          attempts?: number
          created_at?: string
          domain?: string
          expires_at?: string
          id?: string
          last_checked_at?: string | null
          listing_id?: string
          seller_id?: string
          status?: Database["public"]["Enums"]["ws_dns_status"]
          txt_token?: string
          updated_at?: string
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ws_dns_verifications_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "ws_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_link_previews: {
        Row: {
          description: string | null
          fetched_at: string
          image_url: string | null
          site_name: string | null
          title: string | null
          url: string
        }
        Insert: {
          description?: string | null
          fetched_at?: string
          image_url?: string | null
          site_name?: string | null
          title?: string | null
          url: string
        }
        Update: {
          description?: string | null
          fetched_at?: string
          image_url?: string | null
          site_name?: string | null
          title?: string | null
          url?: string
        }
        Relationships: []
      }
      ws_listings: {
        Row: {
          ai_generated_draft: boolean
          asking_price_usd: number | null
          category_slug: string | null
          created_at: string
          currency: string
          description: string | null
          domain: string
          estimated_value_high: number | null
          estimated_value_low: number | null
          featured: boolean
          id: string
          included_assets: Json
          listing_type: Database["public"]["Enums"]["ws_listing_type"]
          monthly_revenue_usd: number | null
          monthly_traffic: number | null
          niche: string | null
          ownership_verified: boolean
          promoted_until: string | null
          published_at: string | null
          reason_for_selling: string | null
          screenshots: string[]
          search_tsv: unknown
          seller_id: string
          site_age_months: number | null
          status: Database["public"]["Enums"]["ws_listing_status"]
          tech_stack: string[]
          title: string
          updated_at: string
          verified_at: string | null
          verified_revenue_usd: number | null
          verified_sources: Json
          verified_traffic: number | null
          views_count: number
          website_url: string
        }
        Insert: {
          ai_generated_draft?: boolean
          asking_price_usd?: number | null
          category_slug?: string | null
          created_at?: string
          currency?: string
          description?: string | null
          domain: string
          estimated_value_high?: number | null
          estimated_value_low?: number | null
          featured?: boolean
          id?: string
          included_assets?: Json
          listing_type?: Database["public"]["Enums"]["ws_listing_type"]
          monthly_revenue_usd?: number | null
          monthly_traffic?: number | null
          niche?: string | null
          ownership_verified?: boolean
          promoted_until?: string | null
          published_at?: string | null
          reason_for_selling?: string | null
          screenshots?: string[]
          search_tsv?: unknown
          seller_id: string
          site_age_months?: number | null
          status?: Database["public"]["Enums"]["ws_listing_status"]
          tech_stack?: string[]
          title: string
          updated_at?: string
          verified_at?: string | null
          verified_revenue_usd?: number | null
          verified_sources?: Json
          verified_traffic?: number | null
          views_count?: number
          website_url: string
        }
        Update: {
          ai_generated_draft?: boolean
          asking_price_usd?: number | null
          category_slug?: string | null
          created_at?: string
          currency?: string
          description?: string | null
          domain?: string
          estimated_value_high?: number | null
          estimated_value_low?: number | null
          featured?: boolean
          id?: string
          included_assets?: Json
          listing_type?: Database["public"]["Enums"]["ws_listing_type"]
          monthly_revenue_usd?: number | null
          monthly_traffic?: number | null
          niche?: string | null
          ownership_verified?: boolean
          promoted_until?: string | null
          published_at?: string | null
          reason_for_selling?: string | null
          screenshots?: string[]
          search_tsv?: unknown
          seller_id?: string
          site_age_months?: number | null
          status?: Database["public"]["Enums"]["ws_listing_status"]
          tech_stack?: string[]
          title?: string
          updated_at?: string
          verified_at?: string | null
          verified_revenue_usd?: number | null
          verified_sources?: Json
          verified_traffic?: number | null
          views_count?: number
          website_url?: string
        }
        Relationships: []
      }
      ws_message_attachments: {
        Row: {
          created_at: string
          height: number | null
          id: string
          kind: string
          message_id: string
          mime: string
          size: number
          storage_path: string
          thread_id: string
          uploader_id: string
          width: number | null
        }
        Insert: {
          created_at?: string
          height?: number | null
          id?: string
          kind?: string
          message_id: string
          mime: string
          size: number
          storage_path: string
          thread_id: string
          uploader_id: string
          width?: number | null
        }
        Update: {
          created_at?: string
          height?: number | null
          id?: string
          kind?: string
          message_id?: string
          mime?: string
          size?: number
          storage_path?: string
          thread_id?: string
          uploader_id?: string
          width?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "ws_message_attachments_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "ws_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ws_message_attachments_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "ws_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_message_reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          message_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          id?: string
          message_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          message_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ws_message_reactions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "ws_messages"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_messages: {
        Row: {
          attachments: Json
          body: string
          client_flags: Json
          created_at: string
          deleted_at: string | null
          edited_at: string | null
          id: string
          kind: string
          read_at: string | null
          reply_to_id: string | null
          sender_id: string
          thread_id: string
        }
        Insert: {
          attachments?: Json
          body: string
          client_flags?: Json
          created_at?: string
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          kind?: string
          read_at?: string | null
          reply_to_id?: string | null
          sender_id: string
          thread_id: string
        }
        Update: {
          attachments?: Json
          body?: string
          client_flags?: Json
          created_at?: string
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          kind?: string
          read_at?: string | null
          reply_to_id?: string | null
          sender_id?: string
          thread_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ws_messages_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "ws_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ws_messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "ws_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_offers: {
        Row: {
          amount_usd: number | null
          buyer_id: string
          cash_component_usd: number | null
          created_at: string
          expires_at: string | null
          id: string
          listing_id: string
          message: string | null
          offer_type: Database["public"]["Enums"]["ws_offer_type"]
          parent_offer_id: string | null
          responded_at: string | null
          seller_id: string
          status: Database["public"]["Enums"]["ws_offer_status"]
          swap_listing_id: string | null
          thread_id: string | null
          updated_at: string
        }
        Insert: {
          amount_usd?: number | null
          buyer_id: string
          cash_component_usd?: number | null
          created_at?: string
          expires_at?: string | null
          id?: string
          listing_id: string
          message?: string | null
          offer_type?: Database["public"]["Enums"]["ws_offer_type"]
          parent_offer_id?: string | null
          responded_at?: string | null
          seller_id: string
          status?: Database["public"]["Enums"]["ws_offer_status"]
          swap_listing_id?: string | null
          thread_id?: string | null
          updated_at?: string
        }
        Update: {
          amount_usd?: number | null
          buyer_id?: string
          cash_component_usd?: number | null
          created_at?: string
          expires_at?: string | null
          id?: string
          listing_id?: string
          message?: string | null
          offer_type?: Database["public"]["Enums"]["ws_offer_type"]
          parent_offer_id?: string | null
          responded_at?: string | null
          seller_id?: string
          status?: Database["public"]["Enums"]["ws_offer_status"]
          swap_listing_id?: string | null
          thread_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ws_offers_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "ws_listings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ws_offers_parent_offer_id_fkey"
            columns: ["parent_offer_id"]
            isOneToOne: false
            referencedRelation: "ws_offers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ws_offers_swap_listing_id_fkey"
            columns: ["swap_listing_id"]
            isOneToOne: false
            referencedRelation: "ws_listings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ws_offers_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "ws_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_profile_extensions: {
        Row: {
          created_at: string
          stripe_account_id: string | null
          updated_at: string
          user_id: string
          verified_seller: boolean
        }
        Insert: {
          created_at?: string
          stripe_account_id?: string | null
          updated_at?: string
          user_id: string
          verified_seller?: boolean
        }
        Update: {
          created_at?: string
          stripe_account_id?: string | null
          updated_at?: string
          user_id?: string
          verified_seller?: boolean
        }
        Relationships: []
      }
      ws_rate_limits: {
        Row: {
          bucket: string
          count: number
          id: string
          user_id: string
          window_start: string
        }
        Insert: {
          bucket: string
          count?: number
          id?: string
          user_id: string
          window_start?: string
        }
        Update: {
          bucket?: string
          count?: number
          id?: string
          user_id?: string
          window_start?: string
        }
        Relationships: []
      }
      ws_saved_searches: {
        Row: {
          created_at: string
          filters: Json
          id: string
          last_notified_at: string | null
          name: string
          notify_email: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          filters?: Json
          id?: string
          last_notified_at?: string | null
          name: string
          notify_email?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          filters?: Json
          id?: string
          last_notified_at?: string | null
          name?: string
          notify_email?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ws_thread_reports: {
        Row: {
          created_at: string
          details: string | null
          id: string
          message_id: string | null
          reason: string
          reported_user_id: string | null
          reporter_id: string
          status: string
          thread_id: string
        }
        Insert: {
          created_at?: string
          details?: string | null
          id?: string
          message_id?: string | null
          reason: string
          reported_user_id?: string | null
          reporter_id: string
          status?: string
          thread_id: string
        }
        Update: {
          created_at?: string
          details?: string | null
          id?: string
          message_id?: string | null
          reason?: string
          reported_user_id?: string | null
          reporter_id?: string
          status?: string
          thread_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ws_thread_reports_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "ws_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ws_thread_reports_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "ws_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_threads: {
        Row: {
          buyer_id: string
          buyer_last_read_at: string | null
          buyer_muted: boolean
          created_at: string
          id: string
          last_message_at: string | null
          listing_id: string
          seller_id: string
          seller_last_read_at: string | null
          seller_muted: boolean
          updated_at: string
        }
        Insert: {
          buyer_id: string
          buyer_last_read_at?: string | null
          buyer_muted?: boolean
          created_at?: string
          id?: string
          last_message_at?: string | null
          listing_id: string
          seller_id: string
          seller_last_read_at?: string | null
          seller_muted?: boolean
          updated_at?: string
        }
        Update: {
          buyer_id?: string
          buyer_last_read_at?: string | null
          buyer_muted?: boolean
          created_at?: string
          id?: string
          last_message_at?: string | null
          listing_id?: string
          seller_id?: string
          seller_last_read_at?: string | null
          seller_muted?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ws_threads_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "ws_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      ws_watchlists: {
        Row: {
          created_at: string
          listing_id: string
          notify: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          listing_id: string
          notify?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          listing_id?: string
          notify?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ws_watchlists_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "ws_listings"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_support_error_threshold: { Args: never; Returns: undefined }
      completed_swaps_count: { Args: never; Returns: number }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_username_available: {
        Args: { _user_id?: string; _username: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      listing_status:
        | "draft"
        | "live"
        | "not_open"
        | "access_paused"
        | "access_extended"
        | "swapped"
        | "archived"
      pricing_model:
        | "free"
        | "freemium"
        | "subscription"
        | "one_time"
        | "usage_based"
        | "other"
      swap_status:
        | "pending"
        | "accepted"
        | "declined"
        | "countered"
        | "matched_fee_pending"
        | "fee_paid_one_side"
        | "confirmed"
        | "completed"
        | "expired"
        | "disputed"
        | "cancelled"
      ws_dns_status: "pending" | "verified" | "failed" | "expired"
      ws_listing_status:
        | "draft"
        | "pending_verification"
        | "live"
        | "paused"
        | "sold"
        | "removed"
      ws_listing_type: "for_sale" | "open_to_swap" | "open_to_both"
      ws_offer_status:
        | "pending"
        | "accepted"
        | "rejected"
        | "countered"
        | "withdrawn"
        | "expired"
      ws_offer_type: "cash" | "swap" | "cash_plus_swap"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      listing_status: [
        "draft",
        "live",
        "not_open",
        "access_paused",
        "access_extended",
        "swapped",
        "archived",
      ],
      pricing_model: [
        "free",
        "freemium",
        "subscription",
        "one_time",
        "usage_based",
        "other",
      ],
      swap_status: [
        "pending",
        "accepted",
        "declined",
        "countered",
        "matched_fee_pending",
        "fee_paid_one_side",
        "confirmed",
        "completed",
        "expired",
        "disputed",
        "cancelled",
      ],
      ws_dns_status: ["pending", "verified", "failed", "expired"],
      ws_listing_status: [
        "draft",
        "pending_verification",
        "live",
        "paused",
        "sold",
        "removed",
      ],
      ws_listing_type: ["for_sale", "open_to_swap", "open_to_both"],
      ws_offer_status: [
        "pending",
        "accepted",
        "rejected",
        "countered",
        "withdrawn",
        "expired",
      ],
      ws_offer_type: ["cash", "swap", "cash_plus_swap"],
    },
  },
} as const
