import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Bucket = "avatars" | "covers" | "logos" | "screenshots" | "attachments";

/**
 * Resolves a stored image reference to a displayable URL.
 * - Absolute URL (http/https) → returned as-is.
 * - Otherwise treated as a storage path in the given bucket and signed for 1h.
 */
export function useSignedImage(bucket: Bucket, ref: string | null | undefined) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!ref) {
      setUrl(null);
      return;
    }
    if (ref.startsWith("http://") || ref.startsWith("https://")) {
      setUrl(ref);
      return;
    }
    (async () => {
      const { data, error } = await supabase.storage
        .from(bucket)
        .createSignedUrl(ref, 60 * 60);
      if (!cancelled && !error) setUrl(data?.signedUrl ?? null);
    })();
    return () => {
      cancelled = true;
    };
  }, [bucket, ref]);

  return url;
}
