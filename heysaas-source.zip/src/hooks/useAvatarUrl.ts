import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Resolves a stored avatar reference to a displayable URL.
 * - If it's already an absolute URL (http/https), returns it as-is (OAuth providers).
 * - Otherwise treats it as a storage path in the `avatars` bucket and signs it.
 */
export function useAvatarUrl(ref: string | null | undefined) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!ref) {
      setUrl(null);
      return;
    }
    if (ref.startsWith("http://") || ref.startsWith("https://")) {
      setUrl(ref);
      return;
    }
    (async () => {
      const { data, error } = await supabase.storage
        .from("avatars")
        .createSignedUrl(ref, 60 * 60);
      if (!cancelled && !error) setUrl(data?.signedUrl ?? null);
    })();
    return () => {
      cancelled = true;
    };
  }, [ref]);

  return url;
}
