import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export function useUnreadCounts() {
  const [counts, setCounts] = useState({ notifications: 0, messages: 0 });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user || cancelled) return;

      const [{ count: n }, { count: m }] = await Promise.all([
        supabase.from("notifications").select("*", { count: "exact", head: true }).eq("user_id", user.id).is("read_at", null),
        supabase.from("messages").select("*, threads!inner(user_a,user_b)", { count: "exact", head: true }).is("seen_at", null).neq("sender_id", user.id),
      ]);

      if (!cancelled) setCounts({ notifications: n ?? 0, messages: m ?? 0 });
    }
    load();

    const ch = supabase
      .channel("unread-counts")
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, load)
      .subscribe();

    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, []);

  return counts;
}
