/**
 * Single source of truth for numeric / currency formatting across the app.
 * Every KPI ribbon and sparkline label must go through these helpers.
 */

export type FinancialFormat = "currency" | "compact" | "number" | "percent";

const currency0 = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});
const currencyCompact = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  notation: "compact",
  compactDisplay: "short",
  maximumFractionDigits: 1,
});
const numberCompact = new Intl.NumberFormat("en-US", {
  notation: "compact",
  compactDisplay: "short",
  maximumFractionDigits: 1,
});
const numberFull = new Intl.NumberFormat("en-US");
const percentFmt = new Intl.NumberFormat("en-US", {
  style: "percent",
  maximumFractionDigits: 1,
});

/** Compact threshold — below this we show full digits (readable at a glance). */
const COMPACT_THRESHOLD = 10_000;

export function formatFinancial(
  value: number | null | undefined,
  format: FinancialFormat = "number",
  opts?: { currency?: string }
): string {
  if (value == null || Number.isNaN(value)) return "—";
  const abs = Math.abs(value);
  switch (format) {
    case "currency": {
      const cur = opts?.currency ?? "USD";
      if (cur !== "USD") {
        return new Intl.NumberFormat("en-US", {
          style: "currency",
          currency: cur,
          notation: abs >= COMPACT_THRESHOLD ? "compact" : "standard",
          maximumFractionDigits: abs >= COMPACT_THRESHOLD ? 1 : 0,
        }).format(value);
      }
      return abs >= COMPACT_THRESHOLD ? currencyCompact.format(value) : currency0.format(value);
    }
    case "compact":
      return abs >= COMPACT_THRESHOLD ? numberCompact.format(value) : numberFull.format(value);
    case "percent":
      return percentFmt.format(value);
    case "number":
    default:
      return numberFull.format(value);
  }
}

export type DeltaDirection = "up" | "down" | "flat";

export function deltaFrom(
  value: number | null | undefined
): { direction: DeltaDirection; value: number } | null {
  if (value == null || Number.isNaN(value)) return null;
  if (value > 0) return { direction: "up", value };
  if (value < 0) return { direction: "down", value };
  return { direction: "flat", value: 0 };
}
