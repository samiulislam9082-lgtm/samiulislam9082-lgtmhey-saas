import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listPresetVersions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ saved_search_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("saved_search_versions")
      .select("id, version_number, snapshot, created_at")
      .eq("saved_search_id", data.saved_search_id)
      .eq("user_id", context.userId)
      .order("version_number", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const restorePresetVersion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ version_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: v, error } = await context.supabase
      .from("saved_search_versions")
      .select("saved_search_id, snapshot, user_id")
      .eq("id", data.version_id)
      .single();
    if (error || !v) throw new Error(error?.message ?? "Not found");
    if (v.user_id !== context.userId) throw new Error("Forbidden");
    const s: any = v.snapshot;
    const { error: upErr, data: row } = await context.supabase
      .from("saved_searches")
      .update({
        name: s.name,
        q: s.q ?? null,
        category_id: s.category_id ?? null,
        mrr_ranges: s.mrr_ranges ?? [],
        tech_stack: s.tech_stack ?? [],
        countries: s.countries ?? [],
        pricing_models: s.pricing_models ?? [],
        looking_for: s.looking_for ?? [],
        sort: s.sort ?? "trending",
        email_notify: s.email_notify ?? true,
      } as any)
      .eq("id", v.saved_search_id)
      .eq("user_id", context.userId)
      .select()
      .single();
    if (upErr) throw new Error(upErr.message);
    return row;
  });

function makeSlug() {
  const alphabet = "abcdefghijkmnpqrstuvwxyz23456789";
  let s = "";
  const bytes = new Uint8Array(10);
  crypto.getRandomValues(bytes);
  for (const b of bytes) s += alphabet[b % alphabet.length];
  return s;
}

export const setPresetShareSlug = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), enabled: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    if (!data.enabled) {
      const { error } = await context.supabase
        .from("saved_searches")
        .update({ share_slug: null } as any)
        .eq("id", data.id)
        .eq("user_id", context.userId);
      if (error) throw new Error(error.message);
      return { share_slug: null as string | null };
    }
    // Try a few times to avoid unique collisions.
    for (let attempt = 0; attempt < 5; attempt++) {
      const slug = makeSlug();
      const { data: row, error } = await context.supabase
        .from("saved_searches")
        .update({ share_slug: slug } as any)
        .eq("id", data.id)
        .eq("user_id", context.userId)
        .select("share_slug")
        .single();
      if (!error && row) return { share_slug: (row as any).share_slug as string };
      if (error && !/duplicate|unique/i.test(error.message)) throw new Error(error.message);
    }
    throw new Error("Could not allocate share slug");
  });
