import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const FiltersSchema = z.object({
  name: z.string().min(1).max(80),
  q: z.string().max(200).optional().nullable(),
  category_id: z.string().uuid().optional().nullable(),
  mrr_ranges: z.array(z.string()).max(10).default([]),
  tech_stack: z.array(z.string()).max(20).default([]),
  countries: z.array(z.string()).max(20).default([]),
  pricing_models: z.array(z.string()).max(10).default([]),
  looking_for: z.array(z.string()).max(20).default([]),
  sort: z.string().max(20).default("trending"),
  email_notify: z.boolean().default(true),
});

export const listSavedSearches = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("saved_searches")
      .select("*")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createSavedSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => FiltersSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { error, data: row } = await context.supabase
      .from("saved_searches")
      .insert({
        user_id: context.userId,
        name: data.name,
        q: data.q ?? null,
        category_id: data.category_id ?? null,
        mrr_ranges: data.mrr_ranges,
        tech_stack: data.tech_stack,
        countries: data.countries,
        pricing_models: data.pricing_models,
        looking_for: data.looking_for,
        sort: data.sort,
        email_notify: data.email_notify,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteSavedSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("saved_searches")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const UpdateSchema = FiltersSchema.partial().extend({ id: z.string().uuid() });

export const updateSavedSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => UpdateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { id, ...rest } = data;
    const patch: Record<string, unknown> = {};
    if (rest.name !== undefined) patch.name = rest.name;
    if (rest.q !== undefined) patch.q = rest.q;
    if (rest.category_id !== undefined) patch.category_id = rest.category_id;
    if (rest.mrr_ranges !== undefined) patch.mrr_ranges = rest.mrr_ranges;
    if (rest.tech_stack !== undefined) patch.tech_stack = rest.tech_stack;
    if (rest.countries !== undefined) patch.countries = rest.countries;
    if (rest.pricing_models !== undefined) patch.pricing_models = rest.pricing_models;
    if (rest.looking_for !== undefined) patch.looking_for = rest.looking_for;
    if (rest.sort !== undefined) patch.sort = rest.sort;
    if (rest.email_notify !== undefined) patch.email_notify = rest.email_notify;
    const { error, data: row } = await context.supabase
      .from("saved_searches")
      .update(patch as any)
      .eq("id", id)
      .eq("user_id", context.userId)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const toggleSavedSearchNotify = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), email_notify: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("saved_searches")
      .update({ email_notify: data.email_notify })
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
