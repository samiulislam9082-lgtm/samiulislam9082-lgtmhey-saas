import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ThreadInput = z.object({ thread_id: z.string().uuid() });

async function assertParticipant(supabase: any, userId: string, threadId: string) {
  const { data } = await supabase.from("threads").select("user_a, user_b").eq("id", threadId).maybeSingle();
  if (!data) throw new Error("Thread not found");
  if (data.user_a !== userId && data.user_b !== userId) throw new Error("Not a participant");
}

export const setThreadMuted = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ThreadInput.extend({ muted: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertParticipant(supabase, userId, data.thread_id);
    await supabase
      .from("thread_states")
      .upsert({ user_id: userId, thread_id: data.thread_id, muted: data.muted }, { onConflict: "user_id,thread_id" });
    return { ok: true };
  });

export const setThreadArchived = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ThreadInput.extend({ archived: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertParticipant(supabase, userId, data.thread_id);
    await supabase
      .from("thread_states")
      .upsert({ user_id: userId, thread_id: data.thread_id, archived: data.archived }, { onConflict: "user_id,thread_id" });
    return { ok: true };
  });

export const markThreadUnread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ThreadInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertParticipant(supabase, userId, data.thread_id);
    // Reset seen_at on the most recent message from the other party so it appears unread.
    const { data: last } = await supabase
      .from("messages")
      .select("id, sender_id")
      .eq("thread_id", data.thread_id)
      .neq("sender_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (last) {
      await supabase.from("messages").update({ seen_at: null }).eq("id", last.id);
    }
    await supabase
      .from("thread_states")
      .upsert({ user_id: userId, thread_id: data.thread_id, marked_unread_at: new Date().toISOString() }, { onConflict: "user_id,thread_id" });
    return { ok: true };
  });

export const listThreadStates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data } = await supabase
      .from("thread_states")
      .select("thread_id, muted, archived, marked_unread_at")
      .eq("user_id", userId);
    return data ?? [];
  });
