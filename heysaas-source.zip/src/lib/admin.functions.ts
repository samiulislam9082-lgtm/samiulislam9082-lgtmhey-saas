import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(supabase: any, userId: string) {
  const { data } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (!data) throw new Error("Forbidden");
}

export const resolveReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), status: z.enum(["resolved", "dismissed"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("reports").update({ status: data.status }).eq("id", data.id);
    await supabaseAdmin.from("admin_actions").insert({
      admin_id: context.userId,
      action: `report_${data.status}`,
      target_type: "report",
      target_id: data.id,
    });
    return { ok: true };
  });

export const verifyFounder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ user_id: z.string().uuid(), verified: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("profiles").update({ verified: data.verified }).eq("id", data.user_id);
    await supabaseAdmin.from("admin_actions").insert({
      admin_id: context.userId,
      action: data.verified ? "verify_founder" : "unverify_founder",
      target_type: "profile",
      target_id: data.user_id,
    });
    return { ok: true };
  });

export const moderateListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ listing_id: z.string().uuid(), action: z.enum(["archive", "restore"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const status = data.action === "archive" ? "archived" : "live";
    await supabaseAdmin.from("saas_listings").update({ status }).eq("id", data.listing_id);
    await supabaseAdmin.from("admin_actions").insert({
      admin_id: context.userId,
      action: `listing_${data.action}`,
      target_type: "listing",
      target_id: data.listing_id,
    });
    return { ok: true };
  });

export const resolveDispute = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({
      swap_id: z.string().uuid(),
      resolution: z.enum(["refund_both", "refund_initiator", "refund_recipient", "no_refund"]),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("swap_requests").update({ status: "cancelled" }).eq("id", data.swap_id);
    await supabaseAdmin.from("admin_actions").insert({
      admin_id: context.userId,
      action: `dispute_${data.resolution}`,
      target_type: "swap",
      target_id: data.swap_id,
      metadata: { resolution: data.resolution },
    });
    return { ok: true };
  });
