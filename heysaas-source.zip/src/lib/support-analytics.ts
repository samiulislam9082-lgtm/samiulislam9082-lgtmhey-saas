import { supabase } from "@/integrations/supabase/client";

const SESSION_KEY = "heysaas.support.session";

export function getSupportSessionId(): string {
  if (typeof window === "undefined") return "server";
  let id = sessionStorage.getItem(SESSION_KEY);
  if (!id) {
    id = (crypto.randomUUID?.() ?? `s_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`);
    sessionStorage.setItem(SESSION_KEY, id);
  }
  return id;
}

export type SupportEventType =
  | "chat_opened"
  | "chat_closed"
  | "quick_reply_clicked"
  | "faq_opened"
  | "faq_ask_ai"
  | "message_sent"
  | "message_replied"
  | "chat_error"
  | "escalation_started"
  | "ticket_submitted"
  | "follow_up_requested"
  | "intake_submitted"
  | "intake_skipped"
  | "feedback_submitted";

export type SupportEventInput = {
  event_type: SupportEventType;
  topic?: string | null;
  message?: string | null;
  error_code?: string | null;
  status?: number | null;
  meta?: Record<string, unknown>;
};

/** Classify a raw user question into a coarse analytics topic. */
export function classifyTopic(text: string | undefined | null): string {
  if (!text) return "other";
  const t = text.toLowerCase();
  if (/(refund|charge back|money back)/.test(t)) return "refunds";
  if (/(safety fee|\$19|19\s*dollar|19\$)/.test(t)) return "safety_fee";
  if (/(swap|trade|exchange)/.test(t)) return "swaps";
  if (/(list|listing|wizard|publish|create)/.test(t)) return "listing";
  if (/(verify|verification|dns|kyc|identity|linkedin)/.test(t)) return "verification";
  if (/(pay|payment|stripe|invoice|receipt|billing)/.test(t)) return "payments";
  if (/(message|inbox|thread|chat)/.test(t)) return "messaging";
  if (/(delete|remove|close account|gdpr|export)/.test(t)) return "account";
  if (/(websites?|webswap|domain|traffic)/.test(t)) return "webswap";
  if (/(price|pricing|cost|fee)/.test(t)) return "pricing";
  if (/(bug|error|broken|not working|issue)/.test(t)) return "bug_report";
  return "other";
}

export async function logSupportEvent(input: SupportEventInput): Promise<void> {
  try {
    const session_id = getSupportSessionId();
    const { data } = await supabase.auth.getUser();
    await supabase.from("support_chat_events").insert({
      session_id,
      user_id: data.user?.id ?? null,
      event_type: input.event_type,
      topic: input.topic ?? null,
      message: input.message ? input.message.slice(0, 500) : null,
      error_code: input.error_code ?? null,
      status: input.status ?? null,
      meta: (input.meta ?? {}) as never,
    });
  } catch {
    // Analytics must never break the UX.
  }
}
