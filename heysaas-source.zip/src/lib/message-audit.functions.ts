import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ActionEnum = z.enum(["mute", "unmute", "mark_unread", "mark_read"]);

export const logMessageAction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({
      action: ActionEnum,
      thread_ids: z.array(z.string().uuid()).min(1).max(200),
      details: z.record(z.string(), z.any()).optional(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("message_action_audit")
      .insert({
        user_id: context.userId,
        action: data.action,
        thread_ids: data.thread_ids,
        details: data.details ?? {},
      } as any);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listMessageAudit = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("message_action_audit")
      .select("id, action, thread_ids, details, created_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const clearMessageAudit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase
      .from("message_action_audit")
      .delete()
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
