import { useEffect, useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

const CHANNEL = "presence:online-users";
const STORAGE_KEY = "hs:presence-visible";

export function getPresenceVisible(): boolean {
  if (typeof window === "undefined") return true;
  const v = window.localStorage.getItem(STORAGE_KEY);
  return v === null ? true : v === "1";
}

export function setPresenceVisible(v: boolean) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, v ? "1" : "0");
  window.dispatchEvent(new CustomEvent("hs:presence-visible", { detail: v }));
}

/**
 * Tracks online users via a shared Supabase Realtime presence channel.
 * Returns a set of userIds currently online (respecting each user's visibility).
 */
export function usePresence(currentUserId: string | null) {
  const [online, setOnline] = useState<Set<string>>(new Set());
  const [visible, setVisible] = useState<boolean>(() => getPresenceVisible());
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  useEffect(() => {
    const handler = (e: Event) => setVisible((e as CustomEvent).detail as boolean);
    window.addEventListener("hs:presence-visible", handler);
    return () => window.removeEventListener("hs:presence-visible", handler);
  }, []);

  useEffect(() => {
    if (!currentUserId) return;
    const channel = supabase.channel(CHANNEL, {
      config: { presence: { key: currentUserId } },
    });
    channelRef.current = channel;

    const sync = () => {
      const state = channel.presenceState() as Record<string, Array<{ visible?: boolean }>>;
      const s = new Set<string>();
      for (const [uid, metas] of Object.entries(state)) {
        if (metas.some((m) => m.visible !== false)) s.add(uid);
      }
      setOnline(s);
    };

    channel
      .on("presence", { event: "sync" }, sync)
      .on("presence", { event: "join" }, sync)
      .on("presence", { event: "leave" }, sync)
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await channel.track({ visible, at: Date.now() });
        }
      });

    return () => {
      channel.untrack();
      supabase.removeChannel(channel);
      channelRef.current = null;
    };
  }, [currentUserId]);

  // Retrack when visibility toggles
  useEffect(() => {
    const ch = channelRef.current;
    if (!ch) return;
    ch.track({ visible, at: Date.now() });
  }, [visible]);

  return { online, visible, setVisible: setPresenceVisible };
}
