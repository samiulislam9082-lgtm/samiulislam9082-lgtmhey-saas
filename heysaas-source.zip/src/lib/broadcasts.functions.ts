import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const BroadcastInput = z.object({
  listing_id: z.string().uuid(),
  audience: z.enum(["followers", "bookmarkers", "interested"]),
  title: z.string().trim().min(1).max(160),
  body: z.string().trim().max(2000).optional().nullable(),
  link: z.string().trim().max(500).optional().nullable(),
});

/**
 * Send a founder update to a real audience derived from the database.
 * Recipients are resolved server-side; the sender must own the listing.
 */
export const sendBroadcast = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => BroadcastInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: listing } = await supabase
      .from("saas_listings")
      .select("id, owner_id, name")
      .eq("id", data.listing_id)
      .maybeSingle();
    if (!listing || listing.owner_id !== userId) throw new Error("You don't own this listing");

    let userIds: string[] = [];
    if (data.audience === "followers") {
      const { data: rows } = await supabase.from("follows").select("follower_id").eq("following_id", userId);
      userIds = (rows ?? []).map((r: { follower_id: string }) => r.follower_id);
    } else if (data.audience === "bookmarkers") {
      const { data: rows } = await supabase.from("bookmarks").select("user_id").eq("listing_id", data.listing_id);
      userIds = (rows ?? []).map((r: { user_id: string }) => r.user_id);
    } else {
      const { data: rows } = await supabase.from("interests").select("user_id").eq("listing_id", data.listing_id);
      userIds = (rows ?? []).map((r: { user_id: string }) => r.user_id);
    }

    userIds = Array.from(new Set(userIds)).filter((id) => id && id !== userId);
    if (userIds.length === 0) return { sent: 0 };

    const { notify } = await import("@/lib/notify.server");
    await notify(
      userIds.map((uid) => ({
        user_id: uid,
        type: "founder_update",
        title: data.title,
        body: data.body?.trim() || null,
        link: data.link?.trim() || null,
        metadata: { listing_id: data.listing_id, from: userId, audience: data.audience },
      })),
    );
    return { sent: userIds.length };
  });
