// Canonical filter buckets shared by wizard, explore, saved searches, and compare.

export const MRR_BUCKETS = [
  "$0",
  "$1–$1k",
  "$1k–$5k",
  "$5k–$20k",
  "$20k–$50k",
  "$50k+",
] as const;
export type MrrBucket = (typeof MRR_BUCKETS)[number];

export const POPULAR_TECH = [
  "React", "Next.js", "TanStack", "Vue", "Svelte", "Angular",
  "Node.js", "TypeScript", "Python", "Go", "Rust", "Ruby",
  "Postgres", "MySQL", "MongoDB", "Redis",
  "Supabase", "Firebase", "AWS", "Vercel", "Cloudflare",
  "Stripe", "OpenAI", "Tailwind",
] as const;

export const COUNTRIES = [
  "United States", "Canada", "United Kingdom", "Germany", "France",
  "Netherlands", "Spain", "Italy", "Sweden", "Poland",
  "Bangladesh", "India", "Pakistan", "Singapore", "Australia",
  "Brazil", "Mexico", "Argentina", "Nigeria", "South Africa",
  "Japan", "South Korea", "China", "UAE", "Remote / Global",
] as const;

export const PRICING_MODELS = [
  { id: "free", label: "Free" },
  { id: "freemium", label: "Freemium" },
  { id: "subscription", label: "Subscription" },
  { id: "one_time", label: "One-time" },
  { id: "usage_based", label: "Usage-based" },
  { id: "other", label: "Other" },
] as const;

export const LOOKING_FOR = [
  { id: "growth", label: "Growth & marketing" },
  { id: "engineering", label: "Engineering help" },
  { id: "design", label: "Design & UX" },
  { id: "content", label: "Content & SEO" },
  { id: "sales", label: "Sales & outreach" },
  { id: "distribution", label: "Distribution / audience" },
  { id: "advisory", label: "Advisory / mentorship" },
] as const;

export const SORTS = [
  { id: "trending", label: "Trending" },
  { id: "new", label: "Newest" },
  { id: "popular", label: "Most interested" },
  { id: "match", label: "Best match" },
  { id: "activity", label: "Recent activity" },
  { id: "mrr", label: "Expected MRR" },
] as const;

export type MarketplaceFilters = {
  q: string;
  categoryId: string | null;
  mrr: string[];
  tech: string[];
  countries: string[];
  pricingModels: string[];
  lookingFor: string[];
  sort: string;
};

export const EMPTY_FILTERS: MarketplaceFilters = {
  q: "",
  categoryId: null,
  mrr: [],
  tech: [],
  countries: [],
  pricingModels: [],
  lookingFor: [],
  sort: "trending",
};

export function serializeFilters(f: MarketplaceFilters): Record<string, string | undefined> {
  return {
    q: f.q || undefined,
    cat: f.categoryId ?? undefined,
    mrr: f.mrr.length ? f.mrr.join(",") : undefined,
    tech: f.tech.length ? f.tech.join(",") : undefined,
    country: f.countries.length ? f.countries.join(",") : undefined,
    pm: f.pricingModels.length ? f.pricingModels.join(",") : undefined,
    lf: f.lookingFor.length ? f.lookingFor.join(",") : undefined,
    sort: f.sort !== "trending" ? f.sort : undefined,
  };
}

export function explainMatch(
  listing: {
    promoted?: boolean;
    featured?: boolean;
    mrr_range?: string | null;
    tech_stack?: string[] | null;
    country?: string | null;
    interested_count?: number;
    views?: number;
  },
  filters: MarketplaceFilters,
): string[] {
  const reasons: string[] = [];
  if (listing.promoted) reasons.push("Promoted — the founder paid to boost this listing for 7 days.");
  if (listing.featured) reasons.push("Editor's pick — hand-picked by HeySaaS.");
  if (filters.q && filters.q.trim()) reasons.push(`Name matches “${filters.q.trim()}”.`);
  if (filters.mrr.length && listing.mrr_range && filters.mrr.includes(listing.mrr_range))
    reasons.push(`MRR bucket matches: ${listing.mrr_range}.`);
  const techOverlap = (listing.tech_stack ?? []).filter((t) => filters.tech.includes(t));
  if (techOverlap.length) reasons.push(`Tech stack matches: ${techOverlap.join(", ")}.`);
  if (filters.countries.length && listing.country && filters.countries.includes(listing.country))
    reasons.push(`Country matches: ${listing.country}.`);
  if (!reasons.length) {
    if (filters.sort === "new") reasons.push("Sorted by newest first.");
    else if (filters.sort === "popular") reasons.push(`Ranked by interest (${listing.interested_count ?? 0} founders interested).`);
    else reasons.push(`Ranked by trending views (${listing.views ?? 0} views).`);
  }
  return reasons;
}
