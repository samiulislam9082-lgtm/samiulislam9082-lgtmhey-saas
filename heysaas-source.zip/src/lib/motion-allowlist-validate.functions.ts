/**
 * Server-side validation for motion scroll allowlist rules.
 *
 * The admin overlay UI can stage rules locally, but any path that persists
 * rules toward production (import → save overlay, future backend writes,
 * copy-ready TS snippet) must first pass this server function. Selectors
 * are parsed with `css-what`, which runs in Node and Cloudflare Workers, so
 * a malformed selector is rejected before it can reach a shared surface.
 *
 * Admin-only: gated by `requireSupabaseAuth` + `has_role(_, 'admin')`.
 */

import { createServerFn } from "@tanstack/react-start";
import { parse as parseSelector } from "css-what";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AllowlistValidationIssue = {
  index: number;
  id?: string;
  field?: string;
  message: string;
};

export type AllowlistValidationResult = {
  ok: boolean;
  issues: AllowlistValidationIssue[];
  ruleCount: number;
};

const VALID_KINDS = new Set(["scroll-behavior-smooth", "scroll-snap"]);

/**
 * Best-effort human-readable hint for common selector mistakes. Purely
 * additive — the parser's raw error is preserved before the hint so the
 * rule id stays exact and easy to grep.
 */
function selectorHint(sel: string, parserMsg: string): string | null {
  const s = sel;

  // Bracket / paren / brace balance
  const pairs: Array<[string, string, string]> = [
    ["[", "]", "attribute bracket `[...]`"],
    ["(", ")", "pseudo-class parenthesis `(...)`"],
    ["{", "}", "curly brace `{...}` (CSS blocks are not valid inside a selector)"],
  ];
  for (const [open, close, label] of pairs) {
    const o = (s.match(new RegExp(`\\${open}`, "g")) || []).length;
    const c = (s.match(new RegExp(`\\${close}`, "g")) || []).length;
    if (o > c) return `unclosed ${label} — add a matching \`${close}\`.`;
    if (c > o) return `stray \`${close}\` — remove it or add a matching \`${open}\`.`;
  }

  // Quote balance (single & double), ignoring escapes
  const dq = (s.match(/(?<!\\)"/g) || []).length;
  const sq = (s.match(/(?<!\\)'/g) || []).length;
  if (dq % 2 === 1)
    return 'unbalanced `"` — attribute values with spaces or special characters need matching double quotes, e.g. `[data-x="my value"]`.';
  if (sq % 2 === 1)
    return "unbalanced `'` — attribute values with spaces or special characters need matching single quotes, e.g. `[data-x='my value']`.";

  // Attribute values that look like they need quoting
  const attr = s.match(/\[[^\]]*=[^\]]*\]/);
  if (attr) {
    const inside = attr[0].slice(1, -1);
    const eq = inside.indexOf("=");
    const val = inside.slice(eq + 1).trim();
    const unquoted = !/^["'].*["']$/.test(val);
    if (unquoted && /[\s:/#().]/.test(val)) {
      return `attribute value \`${val}\` looks unquoted — wrap it in quotes, e.g. \`[attr="${val}"]\`.`;
    }
  }

  // Unsupported / non-standard combinators
  if (/(^|[^|])\|\|([^|]|$)/.test(s))
    return "column combinator `||` is not supported — use a descendant (space) or child (`>`) combinator instead.";
  if (/\/[a-zA-Z][a-zA-Z0-9-]*\//.test(s))
    return "reference combinator `/foo/` was removed from the spec — rewrite without it.";
  if (/&/.test(s))
    return "nesting selector `&` only works inside CSS rules, not as a standalone match — remove it or expand the parent selector.";
  if (/>>>/.test(s))
    return "shadow-piercing combinator `>>>` is not supported — target elements inside their own selector context.";
  if (/\s\/deep\/\s/.test(s))
    return "`/deep/` combinator is deprecated and not supported — remove it.";

  // Trailing combinator
  if (/[>+~,]\s*$/.test(s))
    return "selector ends with a combinator — add a target after `>`, `+`, `~`, or `,`.";
  if (/^\s*[>+~,]/.test(s))
    return "selector starts with a combinator — add a subject before `>`, `+`, `~`, or `,`.";

  // Empty group in a comma list
  if (/,\s*,/.test(s) || /,\s*$/.test(s))
    return "empty selector in comma list — remove the trailing/duplicate `,`.";

  // Double colon typo for known pseudo-classes
  if (/::(hover|focus|active|checked|disabled|not|is|where)/.test(s))
    return "used `::` for a pseudo-class — pseudo-classes take a single `:` (e.g. `:hover`), only pseudo-elements use `::`.";

  // Hint at parser messages we can prettify
  if (/unmatched/i.test(parserMsg))
    return `${parserMsg} — check that every \`[\`, \`(\`, and quote has a matching close.`;

  return null;
}

function validateSelectorServer(sel: string): string | null {
  const trimmed = sel.trim();
  if (!trimmed) return "selector is empty";
  try {
    const parsed = parseSelector(trimmed);
    if (!parsed.length || parsed.every((group) => group.length === 0)) {
      return "selector parsed to nothing";
    }
    // Even when the parser accepts it, warn on unsupported/legacy syntax.
    const hint = selectorHint(trimmed, "");
    if (hint) return `${hint}`;
    return null;
  } catch (e) {
    const raw = (e as Error).message || "invalid CSS selector";
    const hint = selectorHint(trimmed, raw);
    return hint ? `${raw} — hint: ${hint}` : raw;
  }
}


function validatePayload(
  raw: unknown,
): AllowlistValidationResult {
  const issues: AllowlistValidationIssue[] = [];
  if (!Array.isArray(raw)) {
    return {
      ok: false,
      ruleCount: 0,
      issues: [{ index: -1, message: "Expected an array of rules." }],
    };
  }
  const seen = new Set<string>();
  raw.forEach((entry, i) => {
    if (!entry || typeof entry !== "object") {
      issues.push({ index: i, message: "Rule must be an object." });
      return;
    }
    const r = entry as Record<string, unknown>;
    const id = typeof r.id === "string" ? r.id.trim() : "";
    if (!id) {
      issues.push({ index: i, field: "id", message: "Missing string `id`." });
      return;
    }
    if (seen.has(id)) {
      issues.push({ index: i, id, field: "id", message: `Duplicate id: ${id}.` });
      return;
    }
    seen.add(id);

    const kind = r.kind;
    if (typeof kind !== "string" || !VALID_KINDS.has(kind)) {
      issues.push({
        index: i,
        id,
        field: "kind",
        message: `Invalid \`kind\` — expected one of ${Array.from(VALID_KINDS).join(", ")}.`,
      });
    }

    const selector = typeof r.selector === "string" ? r.selector : "";
    if (!selector) {
      issues.push({
        index: i,
        id,
        field: "selector",
        message: "Missing string `selector`.",
      });
    } else {
      const err = validateSelectorServer(selector);
      if (err) {
        issues.push({
          index: i,
          id,
          field: "selector",
          message: `Malformed selector — ${err}`,
        });
      }
    }

    const reason = typeof r.reason === "string" ? r.reason.trim() : "";
    if (!reason) {
      issues.push({
        index: i,
        id,
        field: "reason",
        message: "Missing string `reason`.",
      });
    }

    if (r.routes !== undefined && r.routes !== null) {
      if (
        !Array.isArray(r.routes) ||
        !r.routes.every((x) => typeof x === "string")
      ) {
        issues.push({
          index: i,
          id,
          field: "routes",
          message: "`routes` must be an array of strings if present.",
        });
      }
    }

    if (r.requireHtmlAttr !== undefined && r.requireHtmlAttr !== null) {
      const a = r.requireHtmlAttr;
      if (!a || typeof a !== "object") {
        issues.push({
          index: i,
          id,
          field: "requireHtmlAttr",
          message: "`requireHtmlAttr` must be an object.",
        });
      } else {
        const name = (a as Record<string, unknown>).name;
        const value = (a as Record<string, unknown>).value;
        if (typeof name !== "string" || !name) {
          issues.push({
            index: i,
            id,
            field: "requireHtmlAttr.name",
            message: "`requireHtmlAttr.name` must be a non-empty string.",
          });
        }
        if (value !== undefined && typeof value !== "string") {
          issues.push({
            index: i,
            id,
            field: "requireHtmlAttr.value",
            message: "`requireHtmlAttr.value` must be a string if present.",
          });
        }
      }
    }
  });

  return { ok: issues.length === 0, issues, ruleCount: raw.length };
}

export const validateAllowlistRules = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { rules: unknown }) => input)
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleErr } = await context.supabase.rpc(
      "has_role",
      { _user_id: context.userId, _role: "admin" },
    );
    if (roleErr || !isAdmin) {
      throw new Error("Forbidden: admin role required");
    }
    return validatePayload(data.rules);
  });
