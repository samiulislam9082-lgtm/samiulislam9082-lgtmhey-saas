/**
 * Scroll helpers that respect the user's motion preference.
 * All app code should use `smoothScrollIntoView` / `smoothScrollTo` instead
 * of calling native APIs with `behavior: "smooth"` directly.
 */
import { motionPreferenceIsReduced } from "./motion";
import { reportMotionSuppression } from "./motion-debug";
import { markSanctionedScroll } from "@/components/site/MotionDebugIndicator";

export function smoothScrollIntoView(el: Element | null | undefined, opts?: ScrollIntoViewOptions) {
  if (!el) return;
  const reduced = motionPreferenceIsReduced();
  const behavior: ScrollBehavior = reduced ? "auto" : "smooth";
  if (reduced) reportMotionSuppression("scroll.smoothScrollIntoView");
  markSanctionedScroll(() => el.scrollIntoView({ block: "start", ...opts, behavior }));
}

export function smoothScrollTo(x: number, y: number) {
  const reduced = motionPreferenceIsReduced();
  const behavior: ScrollBehavior = reduced ? "auto" : "smooth";
  if (reduced) reportMotionSuppression("scroll.smoothScrollTo", { detail: `${x},${y}` });
  markSanctionedScroll(() => window.scrollTo({ left: x, top: y, behavior }));
}

