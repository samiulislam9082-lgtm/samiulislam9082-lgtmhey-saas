// Client-side helpers for routing support chats based on topic + urgency.

export type Urgency = "low" | "normal" | "high" | "urgent";
export type Flow = "chat" | "ticket";

const ETA_HOURS_BY_URGENCY: Record<Urgency, number> = {
  urgent: 2,
  high: 6,
  normal: 24,
  low: 48,
};

// Topics that should prefer human ticket right away.
const TICKET_TOPICS = new Set([
  "refunds",
  "verification",
  "account",
  "bug_report",
]);

export function suggestedFlow(topic: string | null | undefined, urgency: Urgency): Flow {
  if (urgency === "urgent" || urgency === "high") return "ticket";
  if (topic && TICKET_TOPICS.has(topic)) return "ticket";
  return "chat";
}

export function estimatedResponse(topic: string | null | undefined, urgency: Urgency): string {
  const flow = suggestedFlow(topic, urgency);
  if (flow === "chat") return "AI reply in seconds";
  const h = ETA_HOURS_BY_URGENCY[urgency];
  return h <= 2 ? "Human reply within 2 hours" : `Human reply within ${h}h`;
}

export function urgencyLabel(u: Urgency): string {
  return { low: "Whenever", normal: "Normal", high: "Blocking me", urgent: "Urgent" }[u];
}
