import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const FEE_CENTS = 1900;

const CreateCheckoutInput = z.object({
  swap_id: z.string().uuid(),
});

/**
 * Creates a Stripe checkout session for the $19 safety fee.
 * If STRIPE_SECRET_KEY is not configured, falls back to dev mode:
 * marks the payment as paid immediately and advances the swap state.
 * This lets the flow be tested end-to-end before Stripe is wired up.
 */
export const createFeeCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => CreateCheckoutInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: swap, error } = await supabase
      .from("swap_requests")
      .select("id, initiator_id, recipient_id, status")
      .eq("id", data.swap_id)
      .maybeSingle();
    if (error || !swap) throw new Error("Swap not found");
    if (swap.initiator_id !== userId && swap.recipient_id !== userId)
      throw new Error("Not a participant");
    if (!["matched_fee_pending", "fee_paid_one_side"].includes(swap.status))
      throw new Error("Fee not payable in this state");

    // Existing paid payment?
    const { data: existing } = await supabase
      .from("payments")
      .select("id, status")
      .eq("swap_request_id", data.swap_id)
      .eq("user_id", userId)
      .maybeSingle();
    if (existing?.status === "paid") throw new Error("You've already paid the fee");

    const stripeKey = process.env.STRIPE_SECRET_KEY;
    const origin = process.env.PUBLIC_URL || "http://localhost:8080";

    if (stripeKey) {
      const { default: Stripe } = await import("stripe");
      const stripe = new Stripe(stripeKey, { apiVersion: "2024-11-20.acacia" as never });
      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: { name: "Hey SaaS — Swap safety fee" },
              unit_amount: FEE_CENTS,
            },
            quantity: 1,
          },
        ],
        client_reference_id: swap.id,
        metadata: { swap_id: swap.id, user_id: userId },
        success_url: `${origin}/dashboard/swaps/${swap.id}?paid=1`,
        cancel_url: `${origin}/dashboard/swaps/${swap.id}?cancelled=1`,
      });

      await supabase.from("payments").upsert(
        {
          swap_request_id: swap.id,
          user_id: userId,
          amount_cents: FEE_CENTS,
          currency: "usd",
          status: "pending",
          stripe_checkout_session_id: session.id,
        },
        { onConflict: "swap_request_id,user_id" },
      );

      return { url: session.url as string, mode: "stripe" as const };
    }

    // Dev fallback — instant mark as paid
    await supabase.from("payments").upsert(
      {
        swap_request_id: swap.id,
        user_id: userId,
        amount_cents: FEE_CENTS,
        currency: "usd",
        status: "paid",
        paid_at: new Date().toISOString(),
      },
      { onConflict: "swap_request_id,user_id" },
    );

    // Advance swap state
    await advanceSwapAfterPayment(supabase, swap.id, userId, swap);

    return { url: `/dashboard/swaps/${swap.id}?paid=1`, mode: "dev" as const };
  });

async function advanceSwapAfterPayment(
  supabase: any,
  swapId: string,
  payerId: string,
  swap: { initiator_id: string; recipient_id: string; status: string },
) {
  const { data: paidRows } = await supabase
    .from("payments")
    .select("user_id")
    .eq("swap_request_id", swapId)
    .eq("status", "paid");
  const paidUsers = new Set((paidRows || []).map((r: any) => r.user_id));
  paidUsers.add(payerId);

  const bothPaid = paidUsers.has(swap.initiator_id) && paidUsers.has(swap.recipient_id);
  const newStatus = bothPaid ? "confirmed" : "fee_paid_one_side";
  await supabase.from("swap_requests").update({ status: newStatus }).eq("id", swapId);

  const otherId = payerId === swap.initiator_id ? swap.recipient_id : swap.initiator_id;
  await (await import("@/lib/notify.server")).notify({
    user_id: otherId,
    type: bothPaid ? "swap_confirmed" : "fee_paid_by_partner",
    title: bothPaid ? "Swap confirmed — start exchanging!" : "Your swap partner paid the fee",
    body: bothPaid ? "Both sides paid. The Swap Room is now unlocked." : "Pay your side to unlock the Swap Room.",
    link: `/dashboard/swaps/${swapId}`,
  });
}

const ConfirmInput = z.object({ swap_id: z.string().uuid() });

/**
 * Participant confirms the swap is complete. When both confirm, swap is
 * marked as swapped and both listings flip to swapped status.
 */
export const confirmSwap = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ConfirmInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: swap, error } = await supabase
      .from("swap_requests")
      .select("id, initiator_id, recipient_id, status, initiator_confirmed_at, recipient_confirmed_at, initiator_listing_id, recipient_listing_id")
      .eq("id", data.swap_id)
      .maybeSingle();
    if (error || !swap) throw new Error("Swap not found");
    if (swap.status !== "confirmed") throw new Error("Swap not yet confirmed by both sides");

    const isInitiator = swap.initiator_id === userId;
    const isRecipient = swap.recipient_id === userId;
    if (!isInitiator && !isRecipient) throw new Error("Not a participant");

    const now = new Date().toISOString();
    const patch: {
      initiator_confirmed_at?: string;
      recipient_confirmed_at?: string;
      status?: "completed";
      completed_at?: string;
    } = {};
    if (isInitiator && !swap.initiator_confirmed_at) patch.initiator_confirmed_at = now;
    if (isRecipient && !swap.recipient_confirmed_at) patch.recipient_confirmed_at = now;
    if (Object.keys(patch).length === 0) return { ok: true, already: true };

    const bothConfirmed =
      (patch.initiator_confirmed_at || swap.initiator_confirmed_at) &&
      (patch.recipient_confirmed_at || swap.recipient_confirmed_at);

    if (bothConfirmed) {
      patch.status = "completed";
      patch.completed_at = now;
    }


    await supabase.from("swap_requests").update(patch).eq("id", swap.id);

    if (bothConfirmed) {
      await supabase.from("saas_listings").update({ status: "swapped" }).in("id", [swap.initiator_listing_id, swap.recipient_listing_id]);
      await (await import("@/lib/notify.server")).notify([
        { user_id: swap.initiator_id, type: "swap_completed", title: "Swap complete 🎉", body: "You've completed a swap on Hey SaaS.", link: `/dashboard/swaps/${swap.id}` },
        { user_id: swap.recipient_id, type: "swap_completed", title: "Swap complete 🎉", body: "You've completed a swap on Hey SaaS.", link: `/dashboard/swaps/${swap.id}` },
      ]);
    } else {
      const otherId = isInitiator ? swap.recipient_id : swap.initiator_id;
      await (await import("@/lib/notify.server")).notify({
        user_id: otherId,
        type: "swap_partner_confirmed",
        title: "Your partner confirmed the swap",
        body: "Confirm from your side to complete the swap.",
        link: `/dashboard/swaps/${swap.id}`,
      });
    }

    return { ok: true, completed: bothConfirmed };
  });

const DisputeInput = z.object({
  swap_id: z.string().uuid(),
  reason: z.string().min(10).max(2000),
});

export const disputeSwap = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => DisputeInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: swap } = await supabase
      .from("swap_requests")
      .select("id, initiator_id, recipient_id, status")
      .eq("id", data.swap_id)
      .maybeSingle();
    if (!swap) throw new Error("Swap not found");
    if (swap.initiator_id !== userId && swap.recipient_id !== userId)
      throw new Error("Not a participant");

    await supabase.from("swap_requests").update({ status: "disputed" }).eq("id", swap.id);
    await supabase.from("reports").insert({
      reporter_id: userId,
      target_type: "swap",
      target_id: swap.id,
      reason: "dispute",
      details: data.reason,
    });
    return { ok: true };
  });
