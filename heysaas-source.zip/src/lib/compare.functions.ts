import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const CompareSchema = z.object({
  slugs: z.array(z.string().min(1).max(120)).min(2).max(4),
});

function serverClient() {
  const url = process.env.SUPABASE_URL!;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const getCompareListings = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => CompareSchema.parse(input))
  .handler(async ({ data }) => {
    const supabase = serverClient();
    const { data: rows, error } = await supabase
      .from("saas_listings")
      .select(
        "id, slug, name, tagline, logo_url, cover_url, website_url, mrr_range, arr_range, user_count_range, pricing_model, tech_stack, tag_slugs, country, launch_year, views, interested_count, category_id, reason_for_swap, looking_for",
      )
      .in("slug", data.slugs)
      .eq("status", "live");
    if (error) throw new Error(error.message);
    return rows ?? [];
  });
