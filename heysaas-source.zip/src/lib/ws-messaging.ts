// Client-safe helpers shared by WebSwap messaging UI.

export const REACTION_EMOJIS = ["👍", "❤️", "😂", "😮", "😢", "🎉", "✅"] as const;

export const QUICK_REPLIES: Array<{ label: string; seed: string }> = [
  { label: "Ask for financial proof", seed: "politely ask the seller to share verified revenue and traffic screenshots (Stripe / analytics)." },
  { label: "Request a call", seed: "propose a 15-minute intro call this week to discuss the deal." },
  { label: "Counter offer", seed: "acknowledge their price but suggest a lower counter with a brief rationale." },
  { label: "Politely decline", seed: "thank them but politely decline for now and leave the door open." },
  { label: "Ask about migration", seed: "ask how they plan to transfer ownership (domain, hosting, code, customer list)." },
];

export function extractUrls(text: string): string[] {
  const re = /\bhttps?:\/\/[^\s)]+/gi;
  const found = text.match(re) ?? [];
  return Array.from(new Set(found)).slice(0, 3);
}

export function formatDayLabel(iso: string): string {
  const d = new Date(iso);
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  if (same(d, today)) return "Today";
  if (same(d, y)) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });
}

export function shortTime(iso: string): string {
  return new Date(iso).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

export function bytesLabel(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

// Groups consecutive messages by day for the day-divider render.
export function groupByDay<T extends { created_at: string }>(msgs: T[]): Array<{ label: string; items: T[] }> {
  const out: Array<{ label: string; items: T[] }> = [];
  let cur = "";
  for (const m of msgs) {
    const label = formatDayLabel(m.created_at);
    if (label !== cur) {
      out.push({ label, items: [] });
      cur = label;
    }
    out[out.length - 1].items.push(m);
  }
  return out;
}
