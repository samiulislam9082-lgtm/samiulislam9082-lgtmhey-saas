/**
 * Candidate allowlist rule proposals.
 *
 * The MotionDebugIndicator groups repeated leak events by a stable
 * "signature" derived from the target element description (tag + id +
 * first classes / data-* attributes) and the leak kind. When a signature
 * repeats above a threshold, we surface it as a candidate the developer
 * can promote into `src/config/motion-scroll-allowlist.ts`.
 *
 * Candidates are stored in `localStorage` under a single key so the
 * admin page (`/dashboard/admin/motion-allowlist`) can render, edit, and
 * clear them out-of-band from the runtime panel.
 */
import type { MotionSuppressionEvent } from "./motion-debug";
import type { ScrollAllowlistKind } from "@/config/motion-scroll-allowlist";

const STORAGE_KEY = "heysaas.motion.candidates";
const CHANNEL = "motioncandidateschange";

export type CandidateRule = {
  id: string;                       // stable hash-like id derived from selector+kind
  selector: string;                 // proposed CSS selector
  kind: ScrollAllowlistKind;
  reason: string;                   // human-editable reason (pre-filled)
  count: number;                    // number of leak events collapsed into this candidate
  firstSeen: number;
  lastSeen: number;
  routes: string[];                 // routes where seen (deduped, capped at 8)
  sampleDetails: string[];          // up to 5 sample "detail" strings
};

function safeParse(): CandidateRule[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage?.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persist(list: CandidateRule[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage?.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch { /* ignore quota */ }
  window.dispatchEvent(new CustomEvent(CHANNEL));
}

export function getCandidates(): CandidateRule[] {
  return safeParse();
}

export function clearCandidates() {
  persist([]);
}

export function removeCandidate(id: string) {
  persist(safeParse().filter((c) => c.id !== id));
}

export function subscribeCandidates(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const h = () => cb();
  window.addEventListener(CHANNEL, h);
  window.addEventListener("storage", h);
  return () => {
    window.removeEventListener(CHANNEL, h);
    window.removeEventListener("storage", h);
  };
}

/**
 * Parse a leak `detail` like `on <div#hero.foo.bar>` or `mandatory on <ul>`
 * into a best-effort CSS selector. Falls back to the raw tag name.
 */
export function selectorFromDetail(detail: string | undefined): string | null {
  if (!detail) return null;
  const m = detail.match(/<([a-zA-Z][\w-]*)([^>]*)>/);
  if (!m) return null;
  const tag = m[1].toLowerCase();
  const rest = m[2] ?? "";
  const idMatch = rest.match(/#([\w-]+)/);
  const classMatch = rest.match(/\.([\w.-]+)/);
  if (idMatch) return `${tag}#${idMatch[1]}`;
  if (classMatch) {
    const cls = classMatch[1].split(".").filter(Boolean).slice(0, 2).map((c) => `.${c}`).join("");
    return `${tag}${cls}`;
  }
  return tag;
}

function kindFromSource(source: string): ScrollAllowlistKind | null {
  if (source.includes("scroll-snap")) return "scroll-snap";
  if (source.includes("scroll-behavior")) return "scroll-behavior-smooth";
  return null;
}

function hash(input: string): string {
  let h = 5381;
  for (let i = 0; i < input.length; i++) h = ((h << 5) + h + input.charCodeAt(i)) | 0;
  return "c" + (h >>> 0).toString(36);
}

/**
 * Fold a leak event into the candidate list. Only CSS-scroll leaks are
 * eligible — raw JS calls (`Element.scrollTo` etc.) are code bugs, not
 * candidates for the sanctioned CSS allowlist.
 */
export function recordLeakForCandidate(evt: MotionSuppressionEvent): CandidateRule | null {
  if (evt.kind !== "leak") return null;
  const kind = kindFromSource(evt.source);
  if (!kind) return null;
  const selector = selectorFromDetail(evt.detail);
  if (!selector) return null;

  const id = hash(`${kind}::${selector}`);
  const now = Date.now();
  const list = safeParse();
  const existing = list.find((c) => c.id === id);
  if (existing) {
    existing.count += 1;
    existing.lastSeen = now;
    if (evt.route && !existing.routes.includes(evt.route)) {
      existing.routes = [...existing.routes, evt.route].slice(-8);
    }
    if (evt.detail && !existing.sampleDetails.includes(evt.detail)) {
      existing.sampleDetails = [...existing.sampleDetails, evt.detail].slice(-5);
    }
    persist(list);
    return existing;
  }
  const created: CandidateRule = {
    id,
    selector,
    kind,
    reason:
      kind === "scroll-snap"
        ? "Repeated snap container — confirm it is user-driven (carousel/gallery) before sanctioning."
        : "Repeated smooth-scroll surface — confirm it is behind a user gesture before sanctioning.",
    count: 1,
    firstSeen: now,
    lastSeen: now,
    routes: evt.route ? [evt.route] : [],
    sampleDetails: evt.detail ? [evt.detail] : [],
  };
  persist([...list, created]);
  return created;
}
