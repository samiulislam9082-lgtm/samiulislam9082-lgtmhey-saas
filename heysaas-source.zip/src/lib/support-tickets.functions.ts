import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Get a short-lived signed URL for a ticket attachment.
// Only the ticket owner or an admin can fetch one.
export const getTicketAttachmentUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ ticket_id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: ticket, error } = await supabase
      .from("support_tickets")
      .select("id, user_id, attachment_path, attachment_name, attachment_mime")
      .eq("id", data.ticket_id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!ticket) throw new Error("Ticket not found");
    if (!ticket.attachment_path) return { url: null as string | null, name: null, mime: null };

    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin && ticket.user_id !== userId) throw new Error("Forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error: signErr } = await supabaseAdmin.storage
      .from("support-attachments")
      .createSignedUrl(ticket.attachment_path, 60 * 10);
    if (signErr) throw new Error(signErr.message);
    return { url: signed.signedUrl, name: ticket.attachment_name, mime: ticket.attachment_mime };
  });

// Simple rate limit for new tickets: max 3 per user per hour.
export const checkTicketRateLimit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count, error } = await supabase
      .from("support_tickets")
      .select("id", { count: "exact", head: true })
      .eq("user_id", userId)
      .gte("created_at", since);
    if (error) throw new Error(error.message);
    return { count: count ?? 0, remaining: Math.max(0, 3 - (count ?? 0)), limit: 3 };
  });

// Update ticket status (admins only) with an optional note.
export const updateTicketStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        ticket_id: z.string().uuid(),
        status: z.enum(["new", "open", "pending", "resolved"]),
        note: z.string().max(2000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Forbidden");
    const { error } = await supabase
      .from("support_tickets")
      .update({ status: data.status })
      .eq("id", data.ticket_id);
    if (error) throw new Error(error.message);
    if (data.note && data.note.trim()) {
      await supabase.from("support_ticket_events").insert({
        ticket_id: data.ticket_id,
        actor_id: userId,
        event_type: "note",
        note: data.note.trim(),
      });
    }
    return { ok: true };
  });
