/**
 * Named export presets for the motion-diff XLSX exporter.
 *
 * A preset captures the operator's saved choices: which columns to include,
 * which scope (changed / full / preview), single- or multi-sheet layout, and
 * an optional filename prefix. Persisted to localStorage so the same
 * operator on the same browser gets a consistent workflow next visit.
 */

const STORAGE_KEY = "motion.xlsx-export-presets.v1";

export const ALL_XLSX_COLUMNS = [
  "status",
  "signature",
  "kind",
  "tag",
  "id",
  "classes",
  "beforeRuleId",
  "afterRuleId",
  "beforeSnapshotId",
  "currentSnapshotId",
  "currentPathname",
] as const;

export type XlsxColumn = (typeof ALL_XLSX_COLUMNS)[number];
export type XlsxScope = "changed" | "full" | "preview";
export type XlsxSheetMode = "single" | "multi";

export type XlsxExportPreset = {
  id: string;
  name: string;
  columns: XlsxColumn[];
  scope: XlsxScope;
  sheetMode: XlsxSheetMode;
  filenamePrefix?: string;
  createdAt: string;
  updatedAt: string;
};

export const DEFAULT_XLSX_PRESET: Omit<
  XlsxExportPreset,
  "id" | "name" | "createdAt" | "updatedAt"
> = {
  columns: [...ALL_XLSX_COLUMNS],
  scope: "changed",
  sheetMode: "multi",
  filenamePrefix: "motion-coverage-diff-v1",
};

function isBrowser() {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

export function listXlsxPresets(): XlsxExportPreset[] {
  if (!isBrowser()) return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (p): p is XlsxExportPreset =>
        p && typeof p.id === "string" && typeof p.name === "string",
    );
  } catch {
    return [];
  }
}

function persist(list: XlsxExportPreset[]) {
  if (!isBrowser()) return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

export function saveXlsxPreset(
  input: Omit<XlsxExportPreset, "id" | "createdAt" | "updatedAt"> & {
    id?: string;
  },
): XlsxExportPreset {
  const list = listXlsxPresets();
  const now = new Date().toISOString();
  const existingIdx = input.id
    ? list.findIndex((p) => p.id === input.id)
    : list.findIndex((p) => p.name.toLowerCase() === input.name.toLowerCase());

  if (existingIdx >= 0) {
    const merged: XlsxExportPreset = {
      ...list[existingIdx],
      ...input,
      id: list[existingIdx].id,
      createdAt: list[existingIdx].createdAt,
      updatedAt: now,
    };
    list[existingIdx] = merged;
    persist(list);
    return merged;
  }

  const preset: XlsxExportPreset = {
    ...input,
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `preset_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    createdAt: now,
    updatedAt: now,
  };
  list.push(preset);
  persist(list);
  return preset;
}

export function deleteXlsxPreset(id: string) {
  persist(listXlsxPresets().filter((p) => p.id !== id));
}

export function isValidColumn(v: string): v is XlsxColumn {
  return (ALL_XLSX_COLUMNS as readonly string[]).includes(v);
}

/**
 * Last-used XLSX exporter selections, persisted so the operator's next visit
 * starts from the same column picker / scope / sheet mode / filename prefix
 * without having to re-pick or re-load a named preset.
 */
const LAST_USED_KEY = "motion.xlsx-export-last-used.v1";

export type XlsxLastUsed = {
  columns: XlsxColumn[];
  scope: XlsxScope;
  sheetMode: XlsxSheetMode;
  filenamePrefix?: string;
  activePresetId?: string | null;
  presetName?: string;
};

export function loadXlsxLastUsed(): XlsxLastUsed | null {
  if (!isBrowser()) return null;
  try {
    const raw = localStorage.getItem(LAST_USED_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    const cols = Array.isArray(parsed.columns)
      ? (parsed.columns as unknown[]).filter(
          (c): c is XlsxColumn => typeof c === "string" && isValidColumn(c),
        )
      : [];
    const scope: XlsxScope =
      parsed.scope === "full" || parsed.scope === "preview"
        ? parsed.scope
        : "changed";
    const sheetMode: XlsxSheetMode =
      parsed.sheetMode === "single" ? "single" : "multi";
    return {
      columns: cols.length ? cols : [...DEFAULT_XLSX_PRESET.columns],
      scope,
      sheetMode,
      filenamePrefix:
        typeof parsed.filenamePrefix === "string"
          ? parsed.filenamePrefix
          : undefined,
      activePresetId:
        typeof parsed.activePresetId === "string"
          ? parsed.activePresetId
          : null,
      presetName:
        typeof parsed.presetName === "string" ? parsed.presetName : "",
    };
  } catch {
    return null;
  }
}

export function saveXlsxLastUsed(state: XlsxLastUsed) {
  if (!isBrowser()) return;
  try {
    localStorage.setItem(LAST_USED_KEY, JSON.stringify(state));
  } catch {
    /* ignore quota errors */
  }
}

