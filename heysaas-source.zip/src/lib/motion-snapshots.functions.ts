import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const RowSchema = z.object({
  index: z.number(),
  tag: z.string(),
  id: z.string(),
  classes: z.string(),
  ruleId: z.string().nullable(),
  selector: z.string(),
  kind: z.string(),
});

const SnapshotSchema = z.object({
  id: z.string().min(1).max(200),
  ranAt: z.string().min(1),
  pathname: z.string().max(500),
  selector: z.string().max(2000),
  kind: z.string().max(100),
  total: z.number().int().nonnegative(),
  rows: z.array(RowSchema).max(5000),
  deviceLabel: z.string().max(200).optional().nullable(),
});

async function assertAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", {
    _user_id: userId,
    _role: "admin",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden");
}

export const listRemoteSnapshots = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { data, error } = await context.supabase
      .from("motion_probe_snapshots")
      .select("id, ran_at, pathname, selector, kind, total, rows, device_label, user_id")
      .order("ran_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return (data ?? []).map((r: any) => ({
      id: r.id,
      ranAt: r.ran_at,
      pathname: r.pathname,
      selector: r.selector,
      kind: r.kind,
      total: r.total,
      rows: r.rows ?? [],
      deviceLabel: r.device_label ?? null,
      ownerId: r.user_id,
    }));
  });

export const upsertRemoteSnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SnapshotSchema.parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { error } = await context.supabase
      .from("motion_probe_snapshots")
      .upsert(
        {
          id: data.id,
          user_id: context.userId,
          ran_at: data.ranAt,
          pathname: data.pathname,
          selector: data.selector,
          kind: data.kind,
          total: data.total,
          rows: data.rows,
          device_label: data.deviceLabel ?? null,
        },
        { onConflict: "user_id,id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteRemoteSnapshot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().min(1) }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { error } = await context.supabase
      .from("motion_probe_snapshots")
      .delete()
      .eq("user_id", context.userId)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const clearRemoteSnapshots = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { error } = await context.supabase
      .from("motion_probe_snapshots")
      .delete()
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
