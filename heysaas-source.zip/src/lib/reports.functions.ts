import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ReportInput = z.object({
  target_type: z.enum(["listing", "profile", "message", "swap"]),
  target_id: z.string().uuid(),
  reason: z.string().min(2).max(80),
  details: z.string().max(2000).optional().nullable(),
});

export const createReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ReportInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { checkRateLimit } = await import("./rate-limit.server");
    const rl = await checkRateLimit({ bucket: "report", userId, limit: 10, windowSeconds: 3600 });
    if (!rl.ok) throw new Error(`Too many reports. Try again in ${rl.retryAfter}s.`);
    const { error } = await supabase.from("reports").insert({
      reporter_id: userId,
      target_type: data.target_type,
      target_id: data.target_id,
      reason: data.reason,
      details: data.details ?? null,
    });
    if (error) throw error;
    return { ok: true };
  });

export const blockUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ user_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    if (data.user_id === userId) throw new Error("Cannot block yourself");
    const { error } = await supabase
      .from("user_blocks")
      .upsert({ blocker_id: userId, blocked_id: data.user_id }, { onConflict: "blocker_id,blocked_id" });
    if (error) throw error;
    return { ok: true };
  });

export const unblockUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ user_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await supabase.from("user_blocks").delete().eq("blocker_id", userId).eq("blocked_id", data.user_id);
    return { ok: true };
  });

export const subscribeNewsletter = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ email: z.string().email(), source: z.string().max(64).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { checkRateLimit } = await import("./rate-limit.server");
    const emailKey = data.email.toLowerCase();
    const rl = await checkRateLimit({ bucket: "newsletter", ipHash: emailKey, limit: 3, windowSeconds: 3600 });
    if (!rl.ok) throw new Error("Too many attempts. Please try later.");
    const { error } = await supabaseAdmin
      .from("newsletter_subscribers")
      .upsert({ email: emailKey, source: data.source ?? "site" }, { onConflict: "email" });
    if (error) throw error;
    return { ok: true };
  });
