import type { ScrollAllowlistKind } from "@/config/motion-scroll-allowlist";

export type ProbeRow = {
  index: number;
  tag: string;
  id: string;
  classes: string;
  ruleId: string | null;
  selector: string;
  kind: ScrollAllowlistKind;
};

export type ProbeSnapshot = {
  id: string;
  ranAt: string;
  pathname: string;
  selector: string;
  kind: ScrollAllowlistKind;
  total: number;
  rows: ProbeRow[];
};

const KEY = "motion.probe.snapshots.v1";
const MAX = 20;

function read(): ProbeSnapshot[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as ProbeSnapshot[]) : [];
  } catch {
    return [];
  }
}

function write(list: ProbeSnapshot[]) {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
    window.dispatchEvent(new CustomEvent("motion-probe-snapshots-changed"));
  } catch {
    // ignore quota / private-mode failures
  }
}

export function listSnapshots(): ProbeSnapshot[] {
  return read().sort((a, b) => (a.ranAt < b.ranAt ? 1 : -1));
}

export function saveSnapshot(input: Omit<ProbeSnapshot, "id">): ProbeSnapshot {
  const snap: ProbeSnapshot = { id: input.ranAt, ...input };
  const next = [snap, ...read().filter((s) => s.id !== snap.id)];
  write(next);
  return snap;
}

export function deleteSnapshot(id: string) {
  write(read().filter((s) => s.id !== id));
}

/**
 * Merge a partial patch into a stored snapshot (keeps `id` stable) and
 * republish to subscribers. Used to promote a re-run's rows as the new
 * baseline for an existing snapshot slot.
 */
export function updateSnapshot(id: string, patch: Partial<Omit<ProbeSnapshot, "id">>): ProbeSnapshot | null {
  const list = read();
  const idx = list.findIndex((s) => s.id === id);
  if (idx === -1) return null;
  const next: ProbeSnapshot = { ...list[idx], ...patch, id };
  const out = [...list];
  out[idx] = next;
  write(out);
  return next;
}

export function clearSnapshots() {
  write([]);
}

export function subscribeSnapshots(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const fn = () => cb();
  window.addEventListener("motion-probe-snapshots-changed", fn);
  window.addEventListener("storage", fn);
  return () => {
    window.removeEventListener("motion-probe-snapshots-changed", fn);
    window.removeEventListener("storage", fn);
  };
}

export function signatureOf(row: ProbeRow): string {
  const cls = row.classes ? "." + row.classes.split(/\s+/).filter(Boolean).join(".") : "";
  const id = row.id ? "#" + row.id : "";
  // Include index so duplicate anonymous elements stay distinct.
  return `${row.tag}${id}${cls}@${row.index}`;
}

export type DiffEntry = {
  signature: string;
  status: "added" | "removed" | "changed" | "unchanged";
  before?: ProbeRow;
  after?: ProbeRow;
};

export type DiffSummary = {
  added: number;
  removed: number;
  changed: number;
  unchanged: number;
  entries: DiffEntry[];
};

export function diffSnapshots(prev: ProbeSnapshot | null, next: ProbeSnapshot): DiffSummary {
  const prevMap = new Map<string, ProbeRow>();
  const nextMap = new Map<string, ProbeRow>();
  for (const r of prev?.rows ?? []) prevMap.set(signatureOf(r), r);
  for (const r of next.rows) nextMap.set(signatureOf(r), r);

  const entries: DiffEntry[] = [];
  const seen = new Set<string>();

  for (const [sig, after] of nextMap) {
    seen.add(sig);
    const before = prevMap.get(sig);
    if (!before) entries.push({ signature: sig, status: "added", after });
    else if (before.ruleId !== after.ruleId)
      entries.push({ signature: sig, status: "changed", before, after });
    else entries.push({ signature: sig, status: "unchanged", before, after });
  }
  for (const [sig, before] of prevMap) {
    if (seen.has(sig)) continue;
    entries.push({ signature: sig, status: "removed", before });
  }

  const summary: DiffSummary = {
    added: 0,
    removed: 0,
    changed: 0,
    unchanged: 0,
    entries: entries.sort((a, b) => {
      const rank = { added: 0, removed: 1, changed: 2, unchanged: 3 } as const;
      if (rank[a.status] !== rank[b.status]) return rank[a.status] - rank[b.status];
      return a.signature.localeCompare(b.signature);
    }),
  };
  for (const e of entries) summary[e.status] += 1;
  return summary;
}
