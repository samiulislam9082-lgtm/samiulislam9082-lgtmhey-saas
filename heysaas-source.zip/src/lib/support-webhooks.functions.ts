import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin } from "@/lib/admin-guard.server";

// Unified webhook notifier for Slack + Microsoft Teams with durable
// background retry. Every attempt is persisted as a row in
// `support_webhook_deliveries`; failed rows are retried by
// /api/public/hooks/retry-webhooks on an exponential backoff.

type Priority = "urgent" | "high" | "normal" | "low";

type TicketPayload = {
  ticketId: string;
  subject: string;
  name: string;
  email: string;
  priority: Priority | string;
  source: string;
  message: string;
  transcript?: string | null;
  hasAttachment?: boolean;
};

type AlertPayload = {
  kind: "error_spike" | string;
  count: number;
  threshold: number;
  windowMinutes: number;
  topBreakdown?: { code: string; count: number }[];
};

type TestPayload = { channel?: "slack" | "teams" | "both" };

const EMOJI: Record<string, string> = {
  urgent: "🚨", high: "⚠️", normal: "📩", low: "📥",
};

// Backoff in seconds after each failed attempt. Attempt 1 fails → wait 60s
// before attempt 2; attempt 6 fails → give up.
const BACKOFF_SECONDS = [60, 300, 900, 3600, 14400, 43200];
const MAX_ATTEMPTS = BACKOFF_SECONDS.length;

function nextBackoff(nextAttemptNumber: number): number {
  const idx = Math.min(nextAttemptNumber - 1, BACKOFF_SECONDS.length - 1);
  return BACKOFF_SECONDS[Math.max(0, idx)];
}

function truncate(s: string, n: number) {
  if (!s) return "";
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}

// --- Slack (Block Kit) ---
function slackTicketBody(p: TicketPayload) {
  const emoji = EMOJI[p.priority] ?? "📩";
  const tail = p.transcript
    ? truncate(p.transcript.split("\n").slice(-12).join("\n"), 1500) : null;
  const blocks: unknown[] = [
    { type: "header", text: { type: "plain_text", text: truncate(`${emoji} ${p.subject}`, 140) } },
    { type: "section", fields: [
      { type: "mrkdwn", text: `*Priority:*\n${p.priority}` },
      { type: "mrkdwn", text: `*Source:*\n${p.source}` },
      { type: "mrkdwn", text: `*From:*\n${truncate(p.name, 60)} <${p.email}>` },
      { type: "mrkdwn", text: `*Attachment:*\n${p.hasAttachment ? "yes" : "no"}` },
    ] },
    { type: "section", text: { type: "mrkdwn", text: `*Message:*\n${truncate(p.message, 1200)}` } },
  ];
  if (tail) blocks.push({ type: "section", text: { type: "mrkdwn", text: `*Recent transcript:*\n\`\`\`${tail}\`\`\`` } });
  blocks.push({ type: "context", elements: [{ type: "mrkdwn", text: `Ticket \`${p.ticketId}\`` }] });
  return { text: `${emoji} New support ticket · ${String(p.priority).toUpperCase()}`, blocks };
}

function slackAlertBody(a: AlertPayload) {
  const lines = (a.topBreakdown ?? []).map(b => `• *${b.code}* — ${b.count}`).join("\n") || "_no breakdown_";
  return {
    text: `🚨 Support error spike (${a.count} in ${a.windowMinutes}m)`,
    blocks: [
      { type: "header", text: { type: "plain_text", text: `🚨 Support error spike` } },
      { type: "section", fields: [
        { type: "mrkdwn", text: `*Count:*\n${a.count}` },
        { type: "mrkdwn", text: `*Threshold:*\n${a.threshold}` },
        { type: "mrkdwn", text: `*Window:*\n${a.windowMinutes} min` },
        { type: "mrkdwn", text: `*Kind:*\n${a.kind}` },
      ] },
      { type: "section", text: { type: "mrkdwn", text: `*Top errors:*\n${lines}` } },
    ],
  };
}

// --- Teams (MessageCard) ---
function teamsMessageCard(title: string, themeColor: string, facts: { name: string; value: string }[], text?: string) {
  return {
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    themeColor,
    summary: title,
    title,
    sections: [{ facts, text: text ? truncate(text, 3000) : undefined, markdown: true }],
  };
}

function teamsTicketBody(p: TicketPayload) {
  const color = p.priority === "urgent" ? "E53935" : p.priority === "high" ? "FB8C00" : "5E35B1";
  return teamsMessageCard(
    `${EMOJI[p.priority] ?? "📩"} ${truncate(p.subject, 140)}`,
    color,
    [
      { name: "Priority", value: String(p.priority) },
      { name: "Source", value: p.source },
      { name: "From", value: `${truncate(p.name, 60)} <${p.email}>` },
      { name: "Attachment", value: p.hasAttachment ? "yes" : "no" },
      { name: "Ticket", value: p.ticketId },
    ],
    `**Message:**\n\n${truncate(p.message, 1500)}${p.transcript ? `\n\n**Recent transcript:**\n\n\`\`\`\n${truncate(p.transcript.split("\n").slice(-12).join("\n"), 1200)}\n\`\`\`` : ""}`,
  );
}

function teamsAlertBody(a: AlertPayload) {
  const lines = (a.topBreakdown ?? []).map(b => `- **${b.code}** — ${b.count}`).join("\n") || "_no breakdown_";
  return teamsMessageCard(
    `🚨 Support error spike`,
    "E53935",
    [
      { name: "Count", value: String(a.count) },
      { name: "Threshold", value: String(a.threshold) },
      { name: "Window", value: `${a.windowMinutes} min` },
      { name: "Kind", value: a.kind },
    ],
    `**Top errors:**\n\n${lines}`,
  );
}

export function buildBody(
  channel: "slack" | "teams",
  kind: "ticket" | "alert" | "test",
  payload: TicketPayload | AlertPayload | { text: string },
): unknown {
  if (channel === "slack") {
    if (kind === "ticket") return slackTicketBody(payload as TicketPayload);
    if (kind === "alert") return slackAlertBody(payload as AlertPayload);
    return { text: (payload as { text: string }).text };
  }
  if (kind === "ticket") return teamsTicketBody(payload as TicketPayload);
  if (kind === "alert") return teamsAlertBody(payload as AlertPayload);
  return teamsMessageCard("Support webhook test", "5E35B1", [{ name: "Status", value: "OK" }], (payload as { text: string }).text);
}

type PostResult = { sent: boolean; status?: number; body?: string; error?: string; responseHeaders?: Record<string, string>; durationMs?: number };

async function post(url: string, body: unknown, timeoutMs = 8000): Promise<PostResult> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  const started = Date.now();
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    const responseHeaders: Record<string, string> = {};
    res.headers.forEach((v, k) => { responseHeaders[k] = v; });
    const durationMs = Date.now() - started;
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return { sent: false, status: res.status, body: text.slice(0, 1000), responseHeaders, durationMs };
    }
    // Some webhook targets return a small body on success (e.g. "ok"); capture briefly for the timeline.
    const okText = await res.text().catch(() => "");
    return { sent: true, status: res.status, body: okText.slice(0, 500), responseHeaders, durationMs };
  } catch (e) {
    return { sent: false, error: e instanceof Error ? e.message : String(e), durationMs: Date.now() - started };
  } finally {
    clearTimeout(t);
  }
}


type Channel = "slack" | "teams";
type Kind = "ticket" | "alert" | "test";

async function insertPending(opts: {
  channel: Channel;
  kind: Kind;
  target: string;
  payload: unknown;
  ticket_id?: string | null;
  alert_id?: string | null;
  meta?: Record<string, unknown>;
}): Promise<string | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("support_webhook_deliveries")
    .insert({
      channel: opts.channel,
      kind: opts.kind,
      status: "pending",
      target: opts.target,
      payload: opts.payload as never,
      ticket_id: opts.ticket_id ?? null,
      alert_id: opts.alert_id ?? null,
      meta: (opts.meta ?? {}) as never,
      max_attempts: MAX_ATTEMPTS,
      next_attempt_at: new Date().toISOString(),
    })
    .select("id")
    .single();
  if (error) {
    console.error("[support-webhooks] insertPending failed", error);
    return null;
  }
  return data.id;
}

async function logNotConfigured(channel: Channel, kind: Kind, meta: Record<string, unknown>) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("support_webhook_deliveries").insert({
      channel, kind, status: "not_configured",
      meta: meta as never, attempt_count: 0, max_attempts: 0,
    });
  } catch (e) {
    console.error("[support-webhooks] logNotConfigured failed", e);
  }
}

/** Attempt one delivery for a row and update its status/next_attempt_at. */
export async function attemptDelivery(rowId: string): Promise<PostResult & { finalStatus: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: row, error } = await supabaseAdmin
    .from("support_webhook_deliveries")
    .select("id, channel, kind, target, payload, attempt_count, max_attempts, meta")
    .eq("id", rowId)
    .single();
  if (error || !row) {
    return { sent: false, error: error?.message ?? "row_missing", finalStatus: "failed" };
  }
  const target = row.target as string | null;
  const payload = row.payload;
  if (!target || !payload) {
    await supabaseAdmin.from("support_webhook_deliveries").update({
      status: "failed", error: "missing target/payload", last_attempt_at: new Date().toISOString(),
    }).eq("id", rowId);
    return { sent: false, error: "missing target/payload", finalStatus: "failed" };
  }

  const attemptNumber = (row.attempt_count ?? 0) + 1;
  const result = await post(target, payload);
  const now = new Date();
  const maxAttempts = row.max_attempts ?? MAX_ATTEMPTS;

  // Append this attempt to a rolling meta.attempts[] timeline (capped to last 20).
  const priorMeta = (row.meta && typeof row.meta === "object" ? row.meta : {}) as Record<string, unknown>;
  const priorAttempts = Array.isArray(priorMeta.attempts) ? (priorMeta.attempts as unknown[]) : [];
  const attemptEntry = {
    n: attemptNumber,
    at: now.toISOString(),
    outcome: result.sent ? "sent" : (attemptNumber >= maxAttempts ? "dead_letter" : "retrying"),
    http_status: result.status ?? null,
    duration_ms: result.durationMs ?? null,
    error: result.error ?? null,
    response_body: result.body ?? null,
    response_headers: result.responseHeaders ?? null,
  };
  const nextAttempts = [...priorAttempts, attemptEntry].slice(-20);
  const nextMeta = { ...priorMeta, attempts: nextAttempts, request_headers: { "Content-Type": "application/json" } };

  if (result.sent) {
    await supabaseAdmin.from("support_webhook_deliveries").update({
      status: "sent",
      attempt_count: attemptNumber,
      last_attempt_at: now.toISOString(),
      next_attempt_at: null,
      http_status: result.status ?? null,
      error: null,
      meta: nextMeta as never,
    }).eq("id", rowId);
    return { ...result, finalStatus: "sent" };
  }

  const exhausted = attemptNumber >= maxAttempts;
  const nextAt = exhausted ? null : new Date(now.getTime() + nextBackoff(attemptNumber + 1) * 1000).toISOString();
  const failureReason = exhausted ? classifyFailure(result) : null;
  await supabaseAdmin.from("support_webhook_deliveries").update({
    status: exhausted ? "dead_letter" : "retrying",
    attempt_count: attemptNumber,
    last_attempt_at: now.toISOString(),
    next_attempt_at: nextAt,
    http_status: result.status ?? null,
    error: result.error ?? result.body ?? null,
    dead_lettered_at: exhausted ? now.toISOString() : null,
    failure_reason: failureReason,
    meta: nextMeta as never,
  }).eq("id", rowId);

  if (exhausted) {
    await notifyAdminsDeadLetter({
      deliveryId: rowId,
      channel: row.channel as Channel,
      kind: row.kind as Kind,
      failureReason: failureReason ?? "unknown",
      httpStatus: result.status ?? null,
      error: result.error ?? result.body ?? null,
      attempts: attemptNumber,
    });
  }
  return { ...result, finalStatus: exhausted ? "dead_letter" : "retrying" };
}


async function notifyAdminsDeadLetter(info: {
  deliveryId: string;
  channel: Channel;
  kind: Kind;
  failureReason: string;
  httpStatus: number | null;
  error: string | null;
  attempts: number;
}) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: admins } = await supabaseAdmin
      .from("user_roles")
      .select("user_id")
      .eq("role", "admin");
    if (!admins || admins.length === 0) return;

    const prettyReason = info.failureReason.replace(/_/g, " ");
    const rows = admins.map((a) => ({
      user_id: a.user_id,
      type: "webhook_dead_letter",
      title: `Webhook dead-lettered: ${info.channel} ${info.kind}`,
      body: `Gave up after ${info.attempts} attempts — ${prettyReason}${info.httpStatus ? ` (HTTP ${info.httpStatus})` : ""}. ${info.error ? info.error.slice(0, 160) : ""}`.trim(),
      link: "/dashboard/admin/support-webhooks",
      metadata: {
        delivery_id: info.deliveryId,
        channel: info.channel,
        kind: info.kind,
        failure_reason: info.failureReason,
        http_status: info.httpStatus,
        attempts: info.attempts,
      } as never,
    }));
    await supabaseAdmin.from("notifications").insert(rows as never);
  } catch (e) {
    console.error("[support-webhooks] notifyAdminsDeadLetter failed", e);
  }
}

function classifyFailure(r: PostResult): string {
  if (r.status && r.status >= 400 && r.status < 500) return `client_error_${r.status}`;
  if (r.status && r.status >= 500 && r.status < 600) return `server_error_${r.status}`;
  if (r.error && /abort|timeout/i.test(r.error)) return "timeout";
  if (r.error) return "network_error";
  return "unknown";
}

/**
 * Queue deliveries and fire the first attempt in the background. Returns as
 * soon as rows are enqueued so the caller (e.g. ticket submission) never
 * blocks on Slack/Teams latency.
 */
async function enqueue(kind: Kind, payload: TicketPayload | AlertPayload | { text: string }, target: "slack" | "teams" | "both" = "both") {
  const slackUrl = process.env.SLACK_TICKET_WEBHOOK_URL;
  const teamsUrl = process.env.TEAMS_TICKET_WEBHOOK_URL;
  const ticket_id = kind === "ticket" ? (payload as TicketPayload).ticketId : null;
  const alert_id = null;
  const meta: Record<string, unknown> =
    kind === "ticket"
      ? { priority: (payload as TicketPayload).priority, subject: (payload as TicketPayload).subject, source: (payload as TicketPayload).source }
      : kind === "alert"
      ? { count: (payload as AlertPayload).count, threshold: (payload as AlertPayload).threshold, window_minutes: (payload as AlertPayload).windowMinutes }
      : { channel: target };

  const queued: { channel: Channel; id: string }[] = [];

  if (target === "both" || target === "slack") {
    if (slackUrl) {
      const id = await insertPending({ channel: "slack", kind, target: slackUrl, payload: buildBody("slack", kind, payload), ticket_id, alert_id, meta });
      if (id) queued.push({ channel: "slack", id });
    } else {
      await logNotConfigured("slack", kind, meta);
    }
  }
  if (target === "both" || target === "teams") {
    if (teamsUrl) {
      const id = await insertPending({ channel: "teams", kind, target: teamsUrl, payload: buildBody("teams", kind, payload), ticket_id, alert_id, meta });
      if (id) queued.push({ channel: "teams", id });
    } else {
      await logNotConfigured("teams", kind, meta);
    }
  }

  // Fire the first attempt(s) in the background. Errors are swallowed;
  // the /api/public/hooks/retry-webhooks cron will pick up failures.
  for (const q of queued) {
    void attemptDelivery(q.id).catch((e) => console.error("[support-webhooks] first-attempt error", e));
  }
  return { queued: queued.length };
}

// Public: the support chat is available to signed-out visitors, so this one
// stays unauthenticated — but the payload is strictly validated and length
// capped so it can't be used to spam arbitrary content into admin channels.
const ticketSchema = z.object({
  ticketId: z.string().max(64),
  subject: z.string().min(1).max(200),
  name: z.string().max(120),
  email: z.string().email().max(200),
  priority: z.enum(["urgent", "high", "normal", "low"]).catch("normal"),
  source: z.string().max(60),
  message: z.string().max(4000),
  transcript: z.string().max(8000).nullish(),
  hasAttachment: z.boolean().optional(),
});

export const notifyTicket = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => ticketSchema.parse(d) as TicketPayload)
  .handler(async ({ data }) => enqueue("ticket", data, "both"));

export const notifyAlert = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      kind: z.string().max(60),
      count: z.number().int().nonnegative(),
      threshold: z.number().int().nonnegative(),
      windowMinutes: z.number().int().positive(),
      topBreakdown: z.array(z.object({ code: z.string().max(80), count: z.number() })).max(20).optional(),
    }).parse(d) as AlertPayload,
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    return enqueue("alert", data, "both");
  });

export const sendTestWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ channel: z.enum(["slack", "teams", "both"]).optional() }).parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const text = `✅ Test alert from HeySaaS · ${new Date().toISOString()}`;
    const channel = data?.channel ?? "both";
    return enqueue("test", { text }, channel);
  });

/** Run one cycle of retries. Called by the scheduled route. */
export async function runRetryCycle(limit = 25): Promise<{ processed: number; sent: number; retrying: number; failed: number }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: due, error } = await supabaseAdmin
    .from("support_webhook_deliveries")
    .select("id")
    .in("status", ["pending", "retrying"])
    .lte("next_attempt_at", new Date().toISOString())
    .order("next_attempt_at", { ascending: true })
    .limit(limit);
  if (error) throw new Error(error.message);
  const rows = due ?? [];
  let sent = 0, retrying = 0, failed = 0;
  for (const r of rows) {
    const res = await attemptDelivery(r.id);
    if (res.finalStatus === "sent") sent++;
    else if (res.finalStatus === "retrying") retrying++;
    else failed++; // includes "dead_letter"
  }
  return { processed: rows.length, sent, retrying, failed };
}

/** Manual retry from the admin UI. */
export const retryWebhookDelivery = createServerFn({ method: "POST" })
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Reset next_attempt_at to now and clear dead-letter fields so admins
    // can force a retry past the cap.
    await supabaseAdmin.from("support_webhook_deliveries").update({
      status: "retrying",
      next_attempt_at: new Date().toISOString(),
      dead_lettered_at: null,
      failure_reason: null,
    }).eq("id", data.id);
    return attemptDelivery(data.id);
  });
