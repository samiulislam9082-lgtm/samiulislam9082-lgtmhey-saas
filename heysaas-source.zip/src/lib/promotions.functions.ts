import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const PROMO_CENTS = 4900; // $49 for 7-day featured slot
const PROMO_DAYS = 7;

const Input = z.object({ listing_id: z.string().uuid() });

/**
 * Creates a Stripe Checkout session to promote a listing for 7 days.
 * Falls back to dev-mode (instant activation) if STRIPE_SECRET_KEY is missing.
 */
export const promoteListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: listing, error } = await supabase
      .from("saas_listings")
      .select("id, owner_id, status, name")
      .eq("id", data.listing_id)
      .maybeSingle();
    if (error || !listing) throw new Error("Listing not found");
    if (listing.owner_id !== userId) throw new Error("You don't own this listing");
    if (listing.status !== "live") throw new Error("Only live listings can be promoted");

    const stripeKey = process.env.STRIPE_SECRET_KEY;
    const origin = process.env.PUBLIC_URL || "http://localhost:8080";

    const starts = new Date();
    const ends = new Date(Date.now() + PROMO_DAYS * 864e5);

    if (stripeKey) {
      const { default: Stripe } = await import("stripe");
      const stripe = new Stripe(stripeKey, { apiVersion: "2024-11-20.acacia" as never });
      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        line_items: [{
          price_data: {
            currency: "usd",
            product_data: { name: `Promote ${listing.name} — 7-day featured slot` },
            unit_amount: PROMO_CENTS,
          },
          quantity: 1,
        }],
        metadata: { kind: "promotion", listing_id: listing.id, user_id: userId },
        success_url: `${origin}/dashboard/listings?promoted=1`,
        cancel_url: `${origin}/dashboard/listings?cancelled=1`,
      });
      return { url: session.url as string, mode: "stripe" as const };
    }

    // Dev fallback — activate immediately
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("promotions").insert({
      listing_id: listing.id,
      slot: "featured",
      starts_at: starts.toISOString(),
      ends_at: ends.toISOString(),
    });
    return { url: `/dashboard/listings?promoted=1`, mode: "dev" as const };
  });
