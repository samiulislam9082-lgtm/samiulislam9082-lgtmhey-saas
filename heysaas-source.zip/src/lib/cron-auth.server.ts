/**
 * Shared auth guard for scheduled / machine-called endpoints under
 * `/api/public/*`. These routes bypass site auth, so every one of them must
 * verify a shared secret before doing any work.
 *
 * The secret is compared in constant time to avoid leaking it byte-by-byte
 * through response timing.
 */
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/**
 * Returns a 401/503 `Response` when the caller is not authorised, or `null`
 * when the request may proceed.
 *
 * Accepts the secret either as `Authorization: Bearer <secret>` or as the
 * `x-cron-secret` header (pg_cron / external schedulers).
 */
export function requireCronSecret(request: Request): Response | null {
  const expected = process.env['CRON_SECRET'];
  if (!expected) {
    // Fail closed: an unset secret must never mean "open to everyone".
    return new Response("Cron secret not configured", { status: 503 });
  }
  const header = request.headers.get("x-cron-secret") ?? "";
  const bearer = (request.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  const provided = header || bearer;
  if (!provided || !timingSafeEqual(provided, expected)) {
    return new Response("Unauthorized", { status: 401 });
  }
  return null;
}
