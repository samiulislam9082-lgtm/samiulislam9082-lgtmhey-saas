/**
 * Runtime motion-debug indicator.
 *
 * Enable by:
 *   - `?motionDebug=1` (persists to localStorage), or
 *   - `window.__motionDebug(true)` in devtools.
 * Disable with `?motionDebug=0` or `window.__motionDebug(false)`.
 *
 * Enable "strict" mode with `?motionDebug=strict` (or
 * `window.__motionDebugStrict(true)`). When strict mode is on and any
 * leak is reported, `window.__motionDebugFailures` is populated and
 * `motiondebugleak` events fire on `window` so automated harnesses
 * (Playwright, CI) can treat leaks as hard test failures.
 */

const STORAGE_KEY = "heysaas.motion.debug";
const STRICT_KEY = "heysaas.motion.debug.strict";
const MAX_EVENTS = 200;

export type MotionSuppressionKind = "suppressed" | "leak";

export type MotionSuppressionEvent = {
  id: number;
  ts: number;
  source: string;
  kind: MotionSuppressionKind;
  detail?: string;
  /** Stack trace of the caller (leaks and suppressions alike). */
  stack?: string;
  /** First user-code frame parsed out of the stack, e.g. `src/foo.tsx:42:7`. */
  callsite?: string;
  /** Route info at the moment of the event (`/path?query`). */
  route?: string;
  /** Actionable hint for leaks: which sanctioned helper to use. */
  hint?: string;
  /** Allowlist rule id — set when a sanctioned CSS pattern matched. */
  ruleId?: string;
  /** Allowlist rule reason — shown in the debug panel for suppressed events. */
  ruleReason?: string;
};

type Listener = (e: MotionSuppressionEvent) => void;
const listeners = new Set<Listener>();
const buffer: MotionSuppressionEvent[] = [];
let seq = 0;

export function isMotionDebugEnabled(): boolean {
  if (typeof window === "undefined") return false;
  try { return window.localStorage?.getItem(STORAGE_KEY) === "1"; } catch { return false; }
}

export function isMotionDebugStrict(): boolean {
  if (typeof window === "undefined") return false;
  try { return window.localStorage?.getItem(STRICT_KEY) === "1"; } catch { return false; }
}

export function setMotionDebugEnabled(on: boolean) {
  if (typeof window === "undefined") return;
  try {
    if (on) window.localStorage?.setItem(STORAGE_KEY, "1");
    else window.localStorage?.removeItem(STORAGE_KEY);
  } catch { /* ignore */ }
  window.dispatchEvent(new CustomEvent("motiondebugtoggle", { detail: on }));
}

export function setMotionDebugStrict(on: boolean) {
  if (typeof window === "undefined") return;
  try {
    if (on) window.localStorage?.setItem(STRICT_KEY, "1");
    else window.localStorage?.removeItem(STRICT_KEY);
  } catch { /* ignore */ }
}

export function getBufferedEvents(): MotionSuppressionEvent[] {
  return buffer.slice();
}

export function clearBufferedEvents() {
  buffer.length = 0;
}

function parseCallsite(stack: string | undefined): string | undefined {
  if (!stack) return undefined;
  const lines = stack.split("\n").map((l) => l.trim());
  for (const l of lines) {
    // skip our own frames
    if (/motion-debug|MotionDebugIndicator|scroll\.ts/.test(l)) continue;
    const m = l.match(/\(?(https?:[^)\s]+|\/[^)\s]+):(\d+):(\d+)\)?/);
    if (m) return `${m[1]}:${m[2]}:${m[3]}`;
  }
  return lines[2];
}

function hintForSource(source: string, kind: MotionSuppressionKind): string | undefined {
  if (kind !== "leak") return undefined;
  if (source.includes("scrollIntoView")) {
    return "Wrap with markSanctionedScroll() or use smoothScrollIntoView() from @/lib/scroll.";
  }
  if (source.includes("scrollTo") || source.includes("scroll")) {
    return "Use smoothScrollTo() from @/lib/scroll (respects reduced motion).";
  }
  return "Route this animation through a sanctioned helper that gates on motionPreferenceIsReduced().";
}

export function reportMotionSuppression(
  source: string,
  meta?: {
    detail?: string;
    kind?: MotionSuppressionKind;
    stack?: string;
    ruleId?: string;
    ruleReason?: string;
  }
) {
  if (typeof window === "undefined") return;
  if (!isMotionDebugEnabled()) return;
  const kind = meta?.kind ?? "suppressed";
  const stack = meta?.stack ?? new Error().stack;
  const route = typeof location !== "undefined" ? location.pathname + location.search : undefined;
  const evt: MotionSuppressionEvent = {
    id: ++seq,
    ts: Date.now(),
    source,
    kind,
    detail: meta?.detail,
    stack,
    callsite: parseCallsite(stack),
    route,
    hint: hintForSource(source, kind),
    ruleId: meta?.ruleId,
    ruleReason: meta?.ruleReason,
  };
  buffer.push(evt);
  if (buffer.length > MAX_EVENTS) buffer.splice(0, buffer.length - MAX_EVENTS);
  for (const l of listeners) { try { l(evt); } catch { /* noop */ } }

  if (kind === "leak" && isMotionDebugStrict()) {
    const w = window as unknown as { __motionDebugFailures?: MotionSuppressionEvent[] };
    (w.__motionDebugFailures ||= []).push(evt);
    window.dispatchEvent(new CustomEvent("motiondebugleak", { detail: evt }));
  }
}

export function subscribeMotionSuppression(l: Listener): () => void {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function syncMotionDebugFromUrl() {
  if (typeof window === "undefined") return;
  const params = new URLSearchParams(window.location.search);
  const q = params.get("motionDebug");
  if (q === "1" || q === "strict") setMotionDebugEnabled(true);
  else if (q === "0") setMotionDebugEnabled(false);
  if (q === "strict") setMotionDebugStrict(true);
  else if (q === "0") setMotionDebugStrict(false);
}

if (typeof window !== "undefined") {
  const w = window as unknown as {
    __motionDebug?: (on: boolean) => void;
    __motionDebugStrict?: (on: boolean) => void;
    __motionDebugEvents?: () => MotionSuppressionEvent[];
    __motionDebugFailures?: MotionSuppressionEvent[];
  };
  w.__motionDebug = setMotionDebugEnabled;
  w.__motionDebugStrict = setMotionDebugStrict;
  w.__motionDebugEvents = getBufferedEvents;
  w.__motionDebugFailures = [];
}
