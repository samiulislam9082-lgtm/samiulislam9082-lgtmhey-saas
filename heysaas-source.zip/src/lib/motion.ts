/**
 * Motion preference resolver.
 * Precedence: explicit user setting (localStorage) > OS media query.
 *
 * Cross-session persistence:
 *   - Anonymous: localStorage under `heysaas.motion`.
 *   - Authenticated: mirrored to `profiles.motion_preference` so the same
 *     setting follows the user to any device / browser / private session.
 *
 * The resolved value is mirrored to the <html> element as
 * `data-motion="reduced"|"full"` so CSS can key off a single selector
 * regardless of the source. An inline script in `__root.tsx` applies the
 * localStorage value before hydration to avoid FOUC.
 */
import { useEffect, useState } from "react";

export type MotionPreference = "system" | "reduced" | "full";
const STORAGE_KEY = "heysaas.motion";

export function readStoredPreference(): MotionPreference {
  if (typeof window === "undefined") return "system";
  const v = window.localStorage?.getItem(STORAGE_KEY) as MotionPreference | null;
  return v === "reduced" || v === "full" || v === "system" ? v : "system";
}

export function osPrefersReduced(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
}

/** True when *effective* motion is reduced (setting or OS). */
export function motionPreferenceIsReduced(): boolean {
  const pref = readStoredPreference();
  if (pref === "reduced") return true;
  if (pref === "full") return false;
  return osPrefersReduced();
}

export function applyMotionPreference(pref: MotionPreference = readStoredPreference()) {
  if (typeof document === "undefined") return;
  const reduced = pref === "reduced" || (pref === "system" && osPrefersReduced());
  document.documentElement.dataset.motion = reduced ? "reduced" : "full";
}

/**
 * Write the preference locally, apply it, and (best-effort) push it to the
 * authenticated user's profile so it restores on other devices/sessions.
 * Also broadcasts a `motionpreferencechange` event so other tabs / listeners
 * (e.g. the Settings hook) can react.
 */
export function setMotionPreference(pref: MotionPreference, opts: { persistRemote?: boolean } = {}) {
  const persistRemote = opts.persistRemote ?? true;
  if (typeof window !== "undefined") {
    try {
      window.localStorage?.setItem(STORAGE_KEY, pref);
    } catch {
      /* storage disabled */
    }
    window.dispatchEvent(new CustomEvent("motionpreferencechange", { detail: pref }));
  }
  applyMotionPreference(pref);

  if (persistRemote && typeof window !== "undefined") {
    // Fire-and-forget; only writes if a session exists (server fn requires auth).
    void (async () => {
      try {
        const { supabase } = await import("@/integrations/supabase/client");
        const { data } = await supabase.auth.getSession();
        if (!data.session) return;
        const { saveMotionPref } = await import("@/lib/motion-prefs.functions");
        await saveMotionPref({ data: pref });
      } catch {
        /* offline / not signed in — local value still persists */
      }
    })();
  }
}

/**
 * Pull the remote preference for the signed-in user and reconcile with
 * localStorage. Remote wins on conflict so a value set on another device
 * restores here.
 */
export async function hydrateMotionFromServer(): Promise<void> {
  if (typeof window === "undefined") return;
  try {
    const { supabase } = await import("@/integrations/supabase/client");
    const { data } = await supabase.auth.getSession();
    if (!data.session) return;
    const { getMotionPref } = await import("@/lib/motion-prefs.functions");
    const remote = (await getMotionPref()) as MotionPreference;
    const local = readStoredPreference();
    if (remote !== local) {
      setMotionPreference(remote, { persistRemote: false });
    } else {
      applyMotionPreference(remote);
    }
  } catch {
    /* ignore — local preference remains in effect */
  }
}

/** React hook returning [preference, resolvedReduced, setter]. */
export function useMotionPreference(): [MotionPreference, boolean, (p: MotionPreference) => void] {
  const [pref, setPref] = useState<MotionPreference>("system");
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const initial = readStoredPreference();
    setPref(initial);
    applyMotionPreference(initial);
    setReduced(motionPreferenceIsReduced());

    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    const onOs = () => {
      applyMotionPreference();
      setReduced(motionPreferenceIsReduced());
    };
    mq?.addEventListener?.("change", onOs);

    // Listen for changes made elsewhere (other tabs, MotionSync, other components).
    const onLocal = () => {
      setPref(readStoredPreference());
      setReduced(motionPreferenceIsReduced());
    };
    window.addEventListener("motionpreferencechange", onLocal as EventListener);
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) onLocal();
    };
    window.addEventListener("storage", onStorage);

    return () => {
      mq?.removeEventListener?.("change", onOs);
      window.removeEventListener("motionpreferencechange", onLocal as EventListener);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  const update = (p: MotionPreference) => {
    setPref(p);
    setMotionPreference(p);
    setReduced(motionPreferenceIsReduced());
  };
  return [pref, reduced, update];
}
