import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const CreateSwapInput = z.object({
  initiator_listing_id: z.string().uuid(),
  recipient_listing_id: z.string().uuid(),
  note: z.string().max(2000).optional().nullable(),
});

/**
 * Create a swap proposal between two live listings. Validates both listings
 * are live, ownership rules, and prevents duplicates.
 */
export const createSwapProposal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => CreateSwapInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const [initiatorRes, recipientRes] = await Promise.all([
      supabase
        .from("saas_listings")
        .select("id, owner_id, status, name")
        .eq("id", data.initiator_listing_id)
        .maybeSingle(),
      supabase
        .from("saas_listings")
        .select("id, owner_id, status, name")
        .eq("id", data.recipient_listing_id)
        .maybeSingle(),
    ]);

    const initiator = initiatorRes.data;
    const recipient = recipientRes.data;
    if (!initiator || !recipient) throw new Error("Listing not found");
    if (initiator.owner_id !== userId) throw new Error("You must own the initiator listing");
    if (recipient.owner_id === userId) throw new Error("You cannot swap with yourself");
    if (initiator.status !== "live") throw new Error("Your listing must be live");
    if (recipient.status !== "live") throw new Error("That listing is not open to swap");

    // Prevent duplicate pending proposals between the same pair
    const { data: existing } = await supabase
      .from("swap_requests")
      .select("id")
      .eq("initiator_listing_id", data.initiator_listing_id)
      .eq("recipient_listing_id", data.recipient_listing_id)
      .in("status", ["pending", "accepted", "countered", "matched_fee_pending", "fee_paid_one_side", "confirmed"])
      .maybeSingle();
    if (existing) throw new Error("A proposal already exists between these listings");

    const { data: inserted, error } = await supabase
      .from("swap_requests")
      .insert({
        initiator_id: userId,
        recipient_id: recipient.owner_id,
        initiator_listing_id: initiator.id,
        recipient_listing_id: recipient.id,
        note: data.note ?? null,
        status: "pending",
      })
      .select("id")
      .single();
    if (error) throw error;

    // Create thread
    const [uA, uB] = [userId, recipient.owner_id].sort();
    await supabase.from("threads").insert({
      user_a: uA,
      user_b: uB,
      swap_request_id: inserted.id,
    });

    // Notify recipient
    await (await import("@/lib/notify.server")).notify({
      user_id: recipient.owner_id,
      type: "proposal_received",
      title: `New swap proposal for ${recipient.name}`,
      body: `${initiator.name} wants to swap with you.`,
      link: `/dashboard/swaps`,
    });

    return { id: inserted.id };
  });

const RespondInput = z.object({
  swap_id: z.string().uuid(),
  action: z.enum(["accept", "decline", "cancel"]),
});

export const respondToSwap = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => RespondInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: swap, error } = await supabase
      .from("swap_requests")
      .select("id, initiator_id, recipient_id, status")
      .eq("id", data.swap_id)
      .maybeSingle();
    if (error || !swap) throw new Error("Proposal not found");

    if (data.action === "accept") {
      if (swap.recipient_id !== userId) throw new Error("Only the recipient can accept");
      if (swap.status !== "pending") throw new Error("Proposal is not pending");
      const { error: uErr } = await supabase
        .from("swap_requests")
        .update({ status: "matched_fee_pending", fee_deadline_at: new Date(Date.now() + 7 * 864e5).toISOString() })
        .eq("id", swap.id);
      if (uErr) throw uErr;
      await (await import("@/lib/notify.server")).notify({
        user_id: swap.initiator_id,
        type: "proposal_accepted",
        title: "Your swap proposal was accepted",
        body: "Time to pay the $19 safety fee. You have 7 days.",
        link: `/dashboard/swaps`,
      });
    } else if (data.action === "decline") {
      if (swap.recipient_id !== userId) throw new Error("Only the recipient can decline");
      if (swap.status !== "pending") throw new Error("Proposal is not pending");
      const { error: uErr } = await supabase.from("swap_requests").update({ status: "declined" }).eq("id", swap.id);
      if (uErr) throw uErr;
      await (await import("@/lib/notify.server")).notify({
        user_id: swap.initiator_id,
        type: "proposal_declined",
        title: "Your swap proposal was declined",
        link: `/dashboard/swaps`,
      });
    } else if (data.action === "cancel") {
      if (swap.initiator_id !== userId) throw new Error("Only the initiator can cancel");
      if (!["pending", "matched_fee_pending"].includes(swap.status)) throw new Error("Cannot cancel now");
      const { error: uErr } = await supabase.from("swap_requests").update({ status: "cancelled" }).eq("id", swap.id);
      if (uErr) throw uErr;
    }

    return { ok: true };
  });
