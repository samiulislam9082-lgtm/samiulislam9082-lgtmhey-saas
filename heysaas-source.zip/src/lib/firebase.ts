// Firebase client init (browser only).
// Note: the web `apiKey` is a public identifier per Firebase docs — restrict
// it in Google Cloud Console (HTTP referrers) rather than treating it as a secret.
import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import { getAnalytics, isSupported, logEvent, type Analytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string,
  authDomain: "english-buddy-vl6fk5.firebaseapp.com",
  projectId: "english-buddy-vl6fk5",
  storageBucket: "english-buddy-vl6fk5.firebasestorage.app",
  messagingSenderId: "845839387230",
  appId: "1:845839387230:web:97fc4c604228b1b7c002cf",
};

let cachedApp: FirebaseApp | null = null;
let analyticsPromise: Promise<Analytics | null> | null = null;

export function getFirebaseApp(): FirebaseApp | null {
  if (typeof window === "undefined") return null;
  if (!firebaseConfig.apiKey) {
    console.warn("[firebase] VITE_FIREBASE_API_KEY missing — Firebase disabled.");
    return null;
  }
  if (cachedApp) return cachedApp;
  cachedApp = getApps().length ? getApp() : initializeApp(firebaseConfig);
  return cachedApp;
}

export function getFirebaseAnalytics(): Promise<Analytics | null> {
  if (typeof window === "undefined") return Promise.resolve(null);
  if (analyticsPromise) return analyticsPromise;
  analyticsPromise = (async () => {
    try {
      const app = getFirebaseApp();
      if (!app) return null;
      if (!(await isSupported())) return null;
      return getAnalytics(app);
    } catch (err) {
      console.warn("[firebase] analytics init failed", err);
      return null;
    }
  })();
  return analyticsPromise;
}

export async function trackEvent(name: string, params?: Record<string, unknown>) {
  const analytics = await getFirebaseAnalytics();
  if (!analytics) return;
  logEvent(analytics, name as string, params as Record<string, unknown>);
}
