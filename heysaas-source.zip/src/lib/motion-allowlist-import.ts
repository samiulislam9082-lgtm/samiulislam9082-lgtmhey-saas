/**
 * Import + diff for motion scroll allowlist JSON uploads.
 *
 * The source of truth is the TS config (`src/config/motion-scroll-allowlist.ts`).
 * Imported rules live in a browser-side overlay (localStorage) so admins can
 * preview and stage changes before the config author copies the resulting
 * snippet into the TS file. Nothing here mutates the shipped config.
 */

import {
  scrollAllowlist,
  type ScrollAllowlistKind,
  type ScrollAllowlistRule,
} from "@/config/motion-scroll-allowlist";

const STORAGE_KEY = "motion-allowlist:import-overlay:v1";
const VALID_KINDS: ScrollAllowlistKind[] = [
  "scroll-behavior-smooth",
  "scroll-snap",
];

export type ImportIssue = { index: number; id?: string; message: string };
export type ImportParseResult = {
  rules: ScrollAllowlistRule[];
  issues: ImportIssue[];
};

function validateSelectorSyntax(sel: string): string | null {
  if (typeof document === "undefined") return null;
  try {
    document.createDocumentFragment().querySelector(sel);
    return null;
  } catch (e) {
    return (e as Error).message || "invalid CSS selector";
  }
}

export function parseAllowlistJson(text: string): ImportParseResult {
  const issues: ImportIssue[] = [];
  const rules: ScrollAllowlistRule[] = [];
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch (e) {
    return {
      rules: [],
      issues: [{ index: -1, message: `Invalid JSON: ${(e as Error).message}` }],
    };
  }
  // Accept either an array of rules or an object with a `rules` array (matches
  // the shape emitted by the CI freezer at /motion-scroll-allowlist.json).
  const arr = Array.isArray(data)
    ? data
    : Array.isArray((data as { rules?: unknown })?.rules)
      ? (data as { rules: unknown[] }).rules
      : null;
  if (!arr) {
    return {
      rules: [],
      issues: [
        {
          index: -1,
          message:
            'Expected a JSON array of rules or an object like { "rules": [...] }.',
        },
      ],
    };
  }
  const seen = new Set<string>();
  arr.forEach((raw, i) => {
    if (!raw || typeof raw !== "object") {
      issues.push({ index: i, message: "Rule must be an object." });
      return;
    }
    const r = raw as Record<string, unknown>;
    const id = typeof r.id === "string" ? r.id.trim() : "";
    const kind = r.kind as ScrollAllowlistKind;
    const selector = typeof r.selector === "string" ? r.selector : "";
    const reason = typeof r.reason === "string" ? r.reason : "";
    if (!id) {
      issues.push({ index: i, message: "Missing string `id`." });
      return;
    }
    if (seen.has(id)) {
      issues.push({ index: i, id, message: `Duplicate id in file: ${id}.` });
      return;
    }
    seen.add(id);
    if (!VALID_KINDS.includes(kind)) {
      issues.push({
        index: i,
        id,
        message: `Invalid \`kind\` — expected one of ${VALID_KINDS.join(", ")}.`,
      });
      return;
    }
    if (!selector) {
      issues.push({ index: i, id, message: "Missing string `selector`." });
      return;
    }
    const selErr = validateSelectorSyntax(selector);
    if (selErr) {
      issues.push({
        index: i,
        id,
        message: `Malformed selector — ${selErr}`,
      });
      return;
    }
    if (!reason) {
      issues.push({ index: i, id, message: "Missing string `reason`." });
      return;
    }
    const rule: ScrollAllowlistRule = { id, kind, selector, reason };
    if (Array.isArray(r.routes) && r.routes.every((x) => typeof x === "string")) {
      rule.routes = r.routes as string[];
    } else if (r.routes !== undefined && r.routes !== null) {
      issues.push({
        index: i,
        id,
        message: "`routes` must be an array of strings if present.",
      });
      return;
    }
    if (r.requireHtmlAttr && typeof r.requireHtmlAttr === "object") {
      const a = r.requireHtmlAttr as Record<string, unknown>;
      if (typeof a.name !== "string") {
        issues.push({
          index: i,
          id,
          message: "`requireHtmlAttr.name` must be a string.",
        });
        return;
      }
      rule.requireHtmlAttr = {
        name: a.name,
        value: typeof a.value === "string" ? a.value : undefined,
      };
    }
    rules.push(rule);
  });
  return { rules, issues };
}

/**
 * Attempt a one-click auto-fix for a parse issue against the raw JSON text.
 * Returns the patched text + a short human description of what changed,
 * or null when the issue is not automatically fixable. The caller re-parses
 * the returned text to refresh the issue list & diff.
 */
export type AutoFixResult = { text: string; description: string } | null;
export function attemptAutoFix(text: string, issue: ImportIssue): AutoFixResult {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return null;
  }
  const arr = Array.isArray(data)
    ? (data as unknown[])
    : Array.isArray((data as { rules?: unknown })?.rules)
      ? ((data as { rules: unknown[] }).rules)
      : null;
  if (!arr || issue.index < 0 || issue.index >= arr.length) return null;
  const raw = arr[issue.index];
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const msg = issue.message.toLowerCase();
  let description = "";

  // Trim id whitespace or fill from index when the id key exists but blank.
  if (msg.includes("missing string `id`") || msg.includes("duplicate id")) {
    if (typeof r.id === "string" && r.id.trim() !== r.id) {
      r.id = r.id.trim();
      description = "Trimmed whitespace in id";
    } else if (msg.includes("duplicate id")) {
      const base = typeof r.id === "string" && r.id ? r.id : `rule-${issue.index}`;
      const ids = new Set(
        arr
          .map((x) => (x && typeof x === "object" ? (x as Record<string, unknown>).id : null))
          .filter((x): x is string => typeof x === "string"),
      );
      let suffix = 2;
      let next = `${base}-${suffix}`;
      while (ids.has(next)) next = `${base}-${++suffix}`;
      r.id = next;
      description = `Renamed duplicate id → ${next}`;
    } else {
      r.id = `rule-${issue.index}`;
      description = `Set id → rule-${issue.index}`;
    }
  } else if (msg.includes("invalid `kind`")) {
    const guess =
      typeof r.selector === "string" && /snap/i.test(r.selector)
        ? "scroll-snap"
        : "scroll-behavior-smooth";
    r.kind = guess;
    description = `Set kind → ${guess}`;
  } else if (msg.includes("missing string `reason`")) {
    r.reason = "TODO: describe why this rule is sanctioned";
    description = "Inserted placeholder reason";
  } else if (msg.includes("`routes` must be an array")) {
    delete r.routes;
    description = "Removed invalid routes field";
  } else if (msg.includes("`requirehtmlattr.name` must be a string")) {
    delete r.requireHtmlAttr;
    description = "Removed invalid requireHtmlAttr";
  } else if (msg.includes("missing string `selector`")) {
    // Not safely fixable — a selector must come from the author.
    return null;
  } else if (msg.startsWith("malformed selector") || msg.includes("malformed selector")) {
    // Not safely fixable — selectors are user intent.
    return null;
  } else {
    return null;
  }

  const patched = Array.isArray(data)
    ? arr
    : { ...(data as object), rules: arr };
  return { text: JSON.stringify(patched, null, 2), description };
}

export type ImportDiff = {
  added: ScrollAllowlistRule[];
  updated: Array<{ before: ScrollAllowlistRule; after: ScrollAllowlistRule; changed: string[] }>;
  unchanged: ScrollAllowlistRule[];
};

function ruleFieldsChanged(
  a: ScrollAllowlistRule,
  b: ScrollAllowlistRule,
): string[] {
  const fields: (keyof ScrollAllowlistRule)[] = [
    "kind",
    "selector",
    "reason",
    "routes",
    "requireHtmlAttr",
  ];
  const changed: string[] = [];
  for (const f of fields) {
    if (JSON.stringify(a[f] ?? null) !== JSON.stringify(b[f] ?? null)) {
      changed.push(f);
    }
  }
  return changed;
}

export function diffAgainstConfig(incoming: ScrollAllowlistRule[]): ImportDiff {
  const byId = new Map(scrollAllowlist.map((r) => [r.id, r]));
  const added: ScrollAllowlistRule[] = [];
  const updated: ImportDiff["updated"] = [];
  const unchanged: ScrollAllowlistRule[] = [];
  for (const r of incoming) {
    const existing = byId.get(r.id);
    if (!existing) {
      added.push(r);
      continue;
    }
    const changed = ruleFieldsChanged(existing, r);
    if (changed.length === 0) unchanged.push(r);
    else updated.push({ before: existing, after: r, changed });
  }
  return { added, updated, unchanged };
}

export function getSavedOverlay(): ScrollAllowlistRule[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? (arr as ScrollAllowlistRule[]) : [];
  } catch {
    return [];
  }
}

export function saveOverlay(rules: ScrollAllowlistRule[]): void {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rules));
}

export function clearOverlay(): void {
  if (typeof localStorage === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
}

// ── Overlay rollback history ────────────────────────────────────────
// Each mutation of the overlay (Save to overlay, Clear overlay, Revert)
// pushes a snapshot here so the user can roll back to any prior state.

const HISTORY_KEY = "motion-allowlist:overlay-history:v1";
const HISTORY_LIMIT = 30;

export type OverlayHistoryEntry = {
  id: string;
  savedAt: string; // ISO
  ruleCount: number;
  rules: ScrollAllowlistRule[];
  note: string;
};

export function listOverlayHistory(): OverlayHistoryEntry[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? (arr as OverlayHistoryEntry[]) : [];
  } catch {
    return [];
  }
}

function writeHistory(entries: OverlayHistoryEntry[]): void {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(
    HISTORY_KEY,
    JSON.stringify(entries.slice(0, HISTORY_LIMIT)),
  );
}

export function pushOverlayHistory(
  rules: ScrollAllowlistRule[],
  note: string,
): OverlayHistoryEntry {
  const entry: OverlayHistoryEntry = {
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `hist-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    savedAt: new Date().toISOString(),
    ruleCount: rules.length,
    rules: rules.map((r) => ({ ...r })),
    note,
  };
  const next = [entry, ...listOverlayHistory()];
  writeHistory(next);
  return entry;
}

export function deleteOverlayHistoryEntry(id: string): void {
  writeHistory(listOverlayHistory().filter((e) => e.id !== id));
}

export function clearOverlayHistory(): void {
  if (typeof localStorage === "undefined") return;
  localStorage.removeItem(HISTORY_KEY);
}


/** Render the merged (config + overlay) set as a TS snippet for the config file. */
export function toTsSnippet(rules: ScrollAllowlistRule[]): string {
  const body = rules
    .map((r) => {
      const parts: string[] = [
        `    id: ${JSON.stringify(r.id)},`,
        `    kind: ${JSON.stringify(r.kind)},`,
        `    selector: ${JSON.stringify(r.selector)},`,
        `    reason: ${JSON.stringify(r.reason)},`,
      ];
      if (r.routes) parts.push(`    routes: ${JSON.stringify(r.routes)},`);
      if (r.requireHtmlAttr)
        parts.push(`    requireHtmlAttr: ${JSON.stringify(r.requireHtmlAttr)},`);
      return `  {\n${parts.join("\n")}\n  },`;
    })
    .join("\n");
  return `export const scrollAllowlist: ScrollAllowlistRule[] = [\n${body}\n];\n`;
}
