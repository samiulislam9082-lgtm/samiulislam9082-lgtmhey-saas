import { useCallback, useEffect, useState } from "react";

export type MessagePrefs = {
  /** Send typing indicators to the other person */
  typingIndicator: boolean;
  /** Enter sends the message (off = Enter makes a new line) */
  enterToSend: boolean;
  /** Play a soft chime when a new message arrives */
  soundOnMessage: boolean;
  /** Show the message preview text in the conversation list */
  showPreviews: boolean;
  /** Compact list + bubbles */
  compact: boolean;
};

export const DEFAULT_MESSAGE_PREFS: MessagePrefs = {
  typingIndicator: true,
  enterToSend: true,
  soundOnMessage: true,
  showPreviews: true,
  compact: false,
};

const KEY = "hs:message-prefs";
const EVENT = "hs:message-prefs-change";

export function getMessagePrefs(): MessagePrefs {
  if (typeof window === "undefined") return DEFAULT_MESSAGE_PREFS;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_MESSAGE_PREFS;
    return { ...DEFAULT_MESSAGE_PREFS, ...(JSON.parse(raw) as Partial<MessagePrefs>) };
  } catch {
    return DEFAULT_MESSAGE_PREFS;
  }
}

export function useMessagePrefs() {
  const [prefs, setPrefs] = useState<MessagePrefs>(DEFAULT_MESSAGE_PREFS);

  // read after hydration to avoid SSR mismatch
  useEffect(() => {
    setPrefs(getMessagePrefs());
    const handler = (e: Event) => setPrefs((e as CustomEvent).detail as MessagePrefs);
    window.addEventListener(EVENT, handler);
    return () => window.removeEventListener(EVENT, handler);
  }, []);

  const setPref = useCallback(<K extends keyof MessagePrefs>(key: K, value: MessagePrefs[K]) => {
    const next = { ...getMessagePrefs(), [key]: value };
    window.localStorage.setItem(KEY, JSON.stringify(next));
    window.dispatchEvent(new CustomEvent(EVENT, { detail: next }));
    setPrefs(next);
  }, []);

  const resetPrefs = useCallback(() => {
    window.localStorage.removeItem(KEY);
    window.dispatchEvent(new CustomEvent(EVENT, { detail: DEFAULT_MESSAGE_PREFS }));
    setPrefs(DEFAULT_MESSAGE_PREFS);
  }, []);

  return { prefs, setPref, resetPrefs };
}

/** Soft two-tone chime, no asset needed. */
export function playMessageChime() {
  if (typeof window === "undefined") return;
  try {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [880, 1174.7].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, now + i * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.06, now + i * 0.09 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.09 + 0.28);
      osc.connect(gain).connect(ctx.destination);
      osc.start(now + i * 0.09);
      osc.stop(now + i * 0.09 + 0.3);
    });
    setTimeout(() => ctx.close().catch(() => {}), 900);
  } catch { /* noop */ }
}
