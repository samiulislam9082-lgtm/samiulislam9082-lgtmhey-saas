/**
 * Shared admin guard for server functions.
 * Uses the *caller-scoped* Supabase client (never the admin client) so the
 * role check is subject to RLS and can't be spoofed by the caller.
 */
export async function assertAdmin(
  // Caller-scoped client from `requireSupabaseAuth` middleware context.
  supabase: { rpc: (fn: never, args: never) => Promise<{ data: unknown }> } | any,
  userId: string,
) {
  const { data } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (!data) throw new Error("Forbidden");
}
