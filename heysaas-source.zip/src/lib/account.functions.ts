import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// GDPR: export everything the authenticated user owns as JSON.
export const exportMyData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [profile, listings, swapsA, swapsB, messages, bookmarks, follows, interests, notifications, payments, reports] =
      await Promise.all([
        supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
        supabase.from("saas_listings").select("*").eq("owner_id", userId),
        supabase.from("swap_requests").select("*").eq("initiator_id", userId),
        supabase.from("swap_requests").select("*").eq("recipient_id", userId),
        supabase.from("messages").select("*").eq("sender_id", userId),
        supabase.from("bookmarks").select("*").eq("user_id", userId),
        supabase.from("follows").select("*").eq("follower_id", userId),
        supabase.from("interests").select("*").eq("user_id", userId),
        supabase.from("notifications").select("*").eq("user_id", userId),
        supabase.from("payments").select("*").eq("user_id", userId),
        supabase.from("reports").select("*").eq("reporter_id", userId),
      ]);
    const result = {
      exported_at: new Date().toISOString(),
      user_id: userId,
      profile: profile.data ?? null,
      listings: listings.data ?? [],
      swap_requests: [...(swapsA.data ?? []), ...(swapsB.data ?? [])],
      messages: messages.data ?? [],
      bookmarks: bookmarks.data ?? [],
      follows: follows.data ?? [],
      interests: interests.data ?? [],
      notifications: notifications.data ?? [],
      payments: payments.data ?? [],
      reports: reports.data ?? [],
    };
    return JSON.stringify(result);
  });

// GDPR: hard delete account. Uses admin client after verifying caller.
export const deleteMyAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Cascades will clean owned rows; explicitly nuke content that may not cascade.
    await supabaseAdmin.from("saas_listings").delete().eq("owner_id", userId);
    await supabaseAdmin.from("profiles").delete().eq("id", userId);
    const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (error) throw error;
    return { ok: true };
  });
