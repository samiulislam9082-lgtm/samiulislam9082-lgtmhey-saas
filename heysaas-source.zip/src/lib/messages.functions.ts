import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const AttachmentSchema = z.object({
  kind: z.enum(["image", "audio", "sticker"]),
  path: z.string().optional(),          // storage path for image/audio
  url: z.string().optional(),           // sticker: direct emoji/url
  mime: z.string().optional(),
  duration_ms: z.number().int().nonnegative().optional(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
  name: z.string().optional(),
});

const SendInput = z.object({
  thread_id: z.string().uuid(),
  body: z.string().max(4000).default(""),
  attachments: z.array(AttachmentSchema).max(10).default([]),
}).refine((v) => v.body.trim().length > 0 || v.attachments.length > 0, {
  message: "Message must have text or an attachment",
});

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SendInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: thread } = await supabase
      .from("threads")
      .select("id, user_a, user_b, swap_request_id")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    if (thread.user_a !== userId && thread.user_b !== userId) throw new Error("Not a participant");

    if (thread.swap_request_id) {
      const { data: swap } = await supabase
        .from("swap_requests")
        .select("status")
        .eq("id", thread.swap_request_id)
        .maybeSingle();
      if (!swap) throw new Error("Swap missing");
      const allowed = ["confirmed", "completed", "disputed"];
      if (!allowed.includes(swap.status)) throw new Error("Messaging unlocks after both parties pay the safety fee");
    }

    const { data: msg, error } = await supabase
      .from("messages")
      .insert({
        thread_id: data.thread_id,
        sender_id: userId,
        body: data.body,
        attachments: data.attachments,
      })
      .select("id, created_at")
      .single();
    if (error) throw error;

    await supabase.from("threads").update({ last_message_at: msg.created_at }).eq("id", data.thread_id);

    const otherId = thread.user_a === userId ? thread.user_b : thread.user_a;
    const preview = data.body.trim()
      ? data.body.slice(0, 120)
      : data.attachments[0]?.kind === "audio" ? "🎙️ Voice message"
      : data.attachments[0]?.kind === "image" ? "📷 Photo"
      : "✨ Sticker";
    await (await import("@/lib/notify.server")).notify({
      user_id: otherId,
      type: "new_message",
      title: "New message",
      body: preview,
      link: `/dashboard/messages?t=${data.thread_id}`,
    });
    return { id: msg.id };
  });

export const markThreadSeen = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ thread_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await supabase
      .from("messages")
      .update({ seen_at: new Date().toISOString() })
      .eq("thread_id", data.thread_id)
      .neq("sender_id", userId)
      .is("seen_at", null);
    return { ok: true };
  });
