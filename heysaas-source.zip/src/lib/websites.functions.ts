import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// ---------- helpers ----------
function extractDomain(url: string): string {
  try {
    const u = new URL(url.startsWith("http") ? url : `https://${url}`);
    return u.hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return url.replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].toLowerCase();
  }
}

function randomToken(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

// Rough valuation: revenue × 30 (SaaS-ish) with traffic + age adjustments.
function estimateValuation(revenue: number | null, traffic: number | null, ageMonths: number | null) {
  const r = Number(revenue) || 0;
  const t = Number(traffic) || 0;
  const a = Number(ageMonths) || 0;
  const base = r * 30;
  const trafficComp = t * 0.05; // very rough
  const ageMultiplier = a >= 24 ? 1.2 : a >= 12 ? 1.0 : 0.8;
  const mid = Math.max(0, (base + trafficComp) * ageMultiplier);
  const low = Math.round(mid * 0.7);
  const high = Math.round(mid * 1.4);
  return { low, high };
}

// ---------- schemas ----------
const listingCreateSchema = z.object({
  website_url: z.string().trim().min(3).max(500),
  title: z.string().trim().min(3).max(200),
  description: z.string().trim().max(5000).optional().nullable(),
  niche: z.string().trim().max(100).optional().nullable(),
  category_slug: z.string().trim().max(100).optional().nullable(),
  listing_type: z.enum(["for_sale", "open_to_swap", "open_to_both"]),
  asking_price_usd: z.number().nonnegative().nullable().optional(),
  monthly_revenue_usd: z.number().nonnegative().nullable().optional(),
  monthly_traffic: z.number().int().nonnegative().nullable().optional(),
  site_age_months: z.number().int().nonnegative().nullable().optional(),
  tech_stack: z.array(z.string().max(50)).max(20).default([]),
  reason_for_selling: z.string().trim().max(1000).optional().nullable(),
  included_assets: z
    .object({
      domain: z.boolean().optional(),
      code: z.boolean().optional(),
      socials: z.boolean().optional(),
      email_list: z.boolean().optional(),
    })
    .default({}),
  screenshots: z.array(z.string().max(500)).max(10).default([]),
});

// ---------- LIST (public — status='live' + verified only) ----------
export const wsListPublicListings = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) =>
    z
      .object({
        q: z.string().max(200).optional(),
        listing_type: z.enum(["for_sale", "open_to_swap", "open_to_both"]).optional(),
        price_min: z.number().optional(),
        price_max: z.number().optional(),
        revenue_min: z.number().optional(),
        traffic_min: z.number().optional(),
        tech: z.array(z.string()).optional(),
        niche: z.string().optional(),
        limit: z.number().int().min(1).max(50).default(24),
        offset: z.number().int().min(0).default(0),
      })
      .parse(raw ?? {})
  )
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
    const sb = createClient(process.env.SUPABASE_URL!, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });

    let q = sb
      .from("ws_listings")
      .select(
        "id, title, description, domain, website_url, niche, category_slug, listing_type, asking_price_usd, monthly_revenue_usd, monthly_traffic, site_age_months, tech_stack, screenshots, featured, promoted_until, estimated_value_low, estimated_value_high, published_at, views_count",
      )
      .eq("status", "live")
      .eq("ownership_verified", true);

    if (data.q) q = q.textSearch("search_tsv", data.q.replace(/[^\w\s]/g, " ").trim().split(/\s+/).filter(Boolean).join(" | ") || data.q);
    if (data.listing_type) q = q.eq("listing_type", data.listing_type);
    if (data.price_min != null) q = q.gte("asking_price_usd", data.price_min);
    if (data.price_max != null) q = q.lte("asking_price_usd", data.price_max);
    if (data.revenue_min != null) q = q.gte("monthly_revenue_usd", data.revenue_min);
    if (data.traffic_min != null) q = q.gte("monthly_traffic", data.traffic_min);
    if (data.niche) q = q.ilike("niche", `%${data.niche}%`);
    if (data.tech && data.tech.length) q = q.overlaps("tech_stack", data.tech);

    q = q
      .order("featured", { ascending: false })
      .order("promoted_until", { ascending: false, nullsFirst: false })
      .order("published_at", { ascending: false, nullsFirst: false })
      .range(data.offset, data.offset + data.limit - 1);

    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

// ---------- GET one (public) ----------
export const wsGetPublicListing = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
    const sb = createClient(process.env.SUPABASE_URL!, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { data: row, error } = await sb
      .from("ws_listings")
      .select("*")
      .eq("id", data.id)
      .eq("status", "live")
      .eq("ownership_verified", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) return null;

    // fetch seller profile
    const { data: profile } = await sb
      .from("profiles")
      .select("id, username, display_name, avatar_url, created_at")
      .eq("id", row.seller_id)
      .maybeSingle();

    // bump views (fire-and-forget via service role import if needed — we'll skip to avoid admin here)
    return { ...row, seller: profile };
  });

// ---------- MY LISTINGS ----------
export const wsListMyListings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("ws_listings")
      .select("id, title, domain, listing_type, asking_price_usd, status, ownership_verified, views_count, created_at, screenshots")
      .eq("seller_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const wsGetMyListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("ws_listings")
      .select(
        "id, seller_id, website_url, domain, title, description, niche, category_slug, listing_type, asking_price_usd, currency, monthly_revenue_usd, monthly_traffic, site_age_months, tech_stack, reason_for_selling, included_assets, screenshots, status, ownership_verified, ai_generated_draft, estimated_value_low, estimated_value_high, views_count, featured, promoted_until, published_at, created_at, updated_at"
      )
      .eq("id", data.id)
      .eq("seller_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });

// ---------- CREATE ----------
export const wsCreateListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => listingCreateSchema.parse(raw))
  .handler(async ({ data, context }) => {
    const domain = extractDomain(data.website_url);
    if (!domain || !domain.includes(".")) throw new Error("Invalid website URL");

    const val = estimateValuation(
      data.monthly_revenue_usd ?? null,
      data.monthly_traffic ?? null,
      data.site_age_months ?? null,
    );

    const { data: row, error } = await context.supabase
      .from("ws_listings")
      .insert({
        seller_id: context.userId,
        website_url: data.website_url,
        domain,
        title: data.title,
        description: data.description ?? null,
        niche: data.niche ?? null,
        category_slug: data.category_slug ?? null,
        listing_type: data.listing_type,
        asking_price_usd: data.asking_price_usd ?? null,
        monthly_revenue_usd: data.monthly_revenue_usd ?? null,
        monthly_traffic: data.monthly_traffic ?? null,
        site_age_months: data.site_age_months ?? null,
        tech_stack: data.tech_stack,
        reason_for_selling: data.reason_for_selling ?? null,
        included_assets: data.included_assets,
        screenshots: data.screenshots,
        status: "draft",
        estimated_value_low: val.low,
        estimated_value_high: val.high,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

// ---------- UPDATE ----------
export const wsUpdateListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z.object({ id: z.string().uuid(), patch: listingCreateSchema.partial() }).parse(raw)
  )
  .handler(async ({ data, context }) => {
    const p = data.patch;
    const patch: {
      website_url?: string;
      domain?: string;
      title?: string;
      description?: string | null;
      niche?: string | null;
      category_slug?: string | null;
      listing_type?: "for_sale" | "open_to_swap" | "open_to_both";
      asking_price_usd?: number | null;
      monthly_revenue_usd?: number | null;
      monthly_traffic?: number | null;
      site_age_months?: number | null;
      tech_stack?: string[];
      reason_for_selling?: string | null;
      included_assets?: Record<string, boolean>;
      screenshots?: string[];
      estimated_value_low?: number;
      estimated_value_high?: number;
    } = { ...p };
    if (p.website_url) patch.domain = extractDomain(p.website_url);
    if (p.monthly_revenue_usd != null || p.monthly_traffic != null || p.site_age_months != null) {
      const { data: current } = await context.supabase
        .from("ws_listings")
        .select("monthly_revenue_usd, monthly_traffic, site_age_months")
        .eq("id", data.id)
        .maybeSingle();
      const val = estimateValuation(
        p.monthly_revenue_usd ?? current?.monthly_revenue_usd ?? null,
        p.monthly_traffic ?? current?.monthly_traffic ?? null,
        p.site_age_months ?? current?.site_age_months ?? null,
      );
      patch.estimated_value_low = val.low;
      patch.estimated_value_high = val.high;
    }
    const { error } = await context.supabase
      .from("ws_listings")
      .update(patch)
      .eq("id", data.id)
      .eq("seller_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- PUBLISH / PAUSE ----------
export const wsSetListingStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum(["draft", "pending_verification", "live", "paused", "sold", "removed"]),
      })
      .parse(raw)
  )
  .handler(async ({ data, context }) => {
    // If publishing, verify ownership_verified = true
    if (data.status === "live") {
      const { data: row } = await context.supabase
        .from("ws_listings")
        .select("ownership_verified")
        .eq("id", data.id)
        .eq("seller_id", context.userId)
        .maybeSingle();
      if (!row) throw new Error("Listing not found");
      if (!row.ownership_verified) throw new Error("Verify domain ownership before publishing.");
    }
    const { error } = await context.supabase
      .from("ws_listings")
      .update({ status: data.status })
      .eq("id", data.id)
      .eq("seller_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const wsDeleteListing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("ws_listings")
      .delete()
      .eq("id", data.id)
      .eq("seller_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- DNS: create or get token ----------
export const wsGetOrCreateDnsVerification = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ listing_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: listing } = await context.supabase
      .from("ws_listings")
      .select("id, domain, ownership_verified")
      .eq("id", data.listing_id)
      .eq("seller_id", context.userId)
      .maybeSingle();
    if (!listing) throw new Error("Listing not found");

    const { data: existing } = await context.supabase
      .from("ws_dns_verifications")
      .select("*")
      .eq("listing_id", listing.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (existing && new Date(existing.expires_at).getTime() > Date.now() && existing.status !== "expired") {
      return existing;
    }

    const token = `webswap-verify=${randomToken()}`;
    const { data: created, error } = await context.supabase
      .from("ws_dns_verifications")
      .insert({
        listing_id: listing.id,
        seller_id: context.userId,
        domain: listing.domain,
        txt_token: token,
      })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return created;
  });

// ---------- DNS: verify ----------
export const wsVerifyDns = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ listing_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: v } = await context.supabase
      .from("ws_dns_verifications")
      .select("*")
      .eq("listing_id", data.listing_id)
      .eq("seller_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (!v) throw new Error("No verification token — create one first.");
    if (new Date(v.expires_at).getTime() < Date.now()) {
      await context.supabase.from("ws_dns_verifications").update({ status: "expired" }).eq("id", v.id);
      throw new Error("Verification token expired. Generate a new one.");
    }

    // Query Cloudflare DNS-over-HTTPS
    const res = await fetch(
      `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(v.domain)}&type=TXT`,
      { headers: { Accept: "application/dns-json" } }
    );
    let found = false;
    if (res.ok) {
      const json: { Answer?: Array<{ data: string }> } = await res.json();
      const answers = json.Answer ?? [];
      found = answers.some((a) => {
        const clean = (a.data ?? "").replace(/^"|"$/g, "").replace(/"\s+"/g, "");
        return clean.includes(v.txt_token);
      });
    }

    if (found) {
      await context.supabase
        .from("ws_dns_verifications")
        .update({ status: "verified", verified_at: new Date().toISOString(), attempts: v.attempts + 1, last_checked_at: new Date().toISOString() })
        .eq("id", v.id);
      await context.supabase
        .from("ws_listings")
        .update({ ownership_verified: true })
        .eq("id", data.listing_id);
      return { verified: true };
    } else {
      await context.supabase
        .from("ws_dns_verifications")
        .update({ attempts: v.attempts + 1, last_checked_at: new Date().toISOString() })
        .eq("id", v.id);
      return { verified: false };
    }
  });

// ---------- AI DRAFT GENERATOR ----------
export const wsAiGenerateDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ url: z.string().min(3).max(500) }).parse(raw))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI is not configured.");
    const domain = extractDomain(data.url);
    const target = data.url.startsWith("http") ? data.url : `https://${domain}`;

    // Fetch site (best-effort)
    let siteText = "";
    try {
      const r = await fetch(target, {
        headers: { "User-Agent": "Mozilla/5.0 WebSwap-Bot/1.0" },
        signal: AbortSignal.timeout(8000),
      });
      if (r.ok) {
        const html = await r.text();
        siteText = html
          .replace(/<script[\s\S]*?<\/script>/gi, " ")
          .replace(/<style[\s\S]*?<\/style>/gi, " ")
          .replace(/<[^>]+>/g, " ")
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 6000);
      }
    } catch {
      siteText = "";
    }

    const { createLovableAiGatewayProvider } = await import("./ai-gateway.server");
    const gateway = createLovableAiGatewayProvider(key);
    const { generateText, Output } = await import("ai");

    const { output } = await generateText({
      model: gateway("google/gemini-2.5-flash"),
      output: Output.object({
        schema: z.object({
          title: z.string().max(80),
          description: z.string().max(1200),
          business_overview: z.string().max(800),
          feature_summary: z.array(z.string().max(160)).max(6),
          suggested_niche: z.string().max(60),
          suggested_tech_stack: z.array(z.string().max(40)).max(8),
        }),
      }),
      messages: [
        {
          role: "system",
          content:
            "You draft marketplace listings for websites for sale/swap. Ground everything strictly in the provided site content. If information isn't available, keep the field short and generic — never fabricate revenue, traffic, or specifics not present in the source.",
        },
        {
          role: "user",
          content: `Domain: ${domain}\nURL: ${target}\n\nSite content (may be truncated):\n${siteText || "[no content fetched — write a short generic draft based on domain only]"}\n\nDraft a listing. Keep tone factual and neutral.`,
        },
      ],
    });

    return output;
  });

// ---------- MESSAGING / OFFERS ----------
export const wsCreateOrGetThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ listing_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    // fetch seller_id
    const { data: listing } = await context.supabase
      .from("ws_listings")
      .select("id, seller_id, status, ownership_verified")
      .eq("id", data.listing_id)
      .maybeSingle();
    if (!listing) throw new Error("Listing not found");
    if (listing.seller_id === context.userId) throw new Error("You cannot message your own listing.");
    if (listing.status !== "live" || !listing.ownership_verified) throw new Error("Listing is not open for inquiries.");

    const { data: existing } = await context.supabase
      .from("ws_threads")
      .select("*")
      .eq("listing_id", listing.id)
      .eq("buyer_id", context.userId)
      .maybeSingle();
    if (existing) return existing;

    const { data: created, error } = await context.supabase
      .from("ws_threads")
      .insert({ listing_id: listing.id, buyer_id: context.userId, seller_id: listing.seller_id })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return created;
  });

export const wsListThreads = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("ws_threads")
      .select("*, ws_listings!inner(id, title, domain, screenshots)")
      .or(`buyer_id.eq.${context.userId},seller_id.eq.${context.userId}`)
      .order("last_message_at", { ascending: false, nullsFirst: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const wsGetThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ thread_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: thread } = await context.supabase
      .from("ws_threads")
      .select("*, ws_listings!inner(id, title, domain, listing_type, asking_price_usd, seller_id, screenshots)")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    const [messagesRes, offersRes, buyer, seller] = await Promise.all([
      context.supabase
        .from("ws_messages")
        .select("*")
        .eq("thread_id", data.thread_id)
        .order("created_at", { ascending: true }),
      context.supabase
        .from("ws_offers")
        .select("*")
        .eq("thread_id", data.thread_id)
        .order("created_at", { ascending: true }),
      context.supabase.from("profiles").select("id, username, display_name, avatar_url").eq("id", thread.buyer_id).maybeSingle(),
      context.supabase.from("profiles").select("id, username, display_name, avatar_url").eq("id", thread.seller_id).maybeSingle(),
    ]);
    const msgIds = (messagesRes.data ?? []).map((m) => m.id);
    const [reactionsRes, attachmentsRes] = await Promise.all([
      msgIds.length
        ? context.supabase.from("ws_message_reactions").select("*").in("message_id", msgIds)
        : Promise.resolve({ data: [] }),
      msgIds.length
        ? context.supabase.from("ws_message_attachments").select("*").in("message_id", msgIds)
        : Promise.resolve({ data: [] }),
    ]);
    return {
      thread,
      messages: messagesRes.data ?? [],
      offers: offersRes.data ?? [],
      buyer: buyer.data,
      seller: seller.data,
      reactions: reactionsRes.data ?? [],
      attachments: attachmentsRes.data ?? [],
    };
  });

const OFF_PLATFORM_PATTERNS = [
  /\b(venmo|paypal|zelle|cashapp|wire\s*transfer|western\s*union|bitcoin|btc|eth|usdt|crypto)\b/i,
  /\b(whatsapp|telegram|wechat|signal|kakao|viber)\b/i,
  /\b(dm\s+me|move\s+off|contact\s+me\s+at|email\s+me\s+at)\b/i,
];
function detectSpam(body: string) {
  const reasons: string[] = [];
  const linkCount = (body.match(/https?:\/\/\S+/gi) ?? []).length;
  for (const re of OFF_PLATFORM_PATTERNS) if (re.test(body)) reasons.push("off-platform");
  if (linkCount > 3) reasons.push(`many-links:${linkCount}`);
  if (/(?:bit\.ly|tinyurl|t\.co|goo\.gl|is\.gd|ow\.ly)\//i.test(body)) reasons.push("shortener");
  return { spam_score: reasons.length, reasons, link_count: linkCount };
}
async function enforceRateLimit(admin: { from: (t: string) => { select: (s: string) => { eq: (a: string, b: string) => { eq: (a: string, b: string) => { maybeSingle: () => Promise<{ data: { id: string; count: number; window_start: string } | null }> } } }; insert: (row: unknown) => Promise<unknown>; update: (patch: unknown) => { eq: (a: string, b: string) => Promise<unknown> } } }, userId: string) {
  const now = new Date();
  const { data: row } = await admin
    .from("ws_rate_limits")
    .select("id, count, window_start")
    .eq("user_id", userId)
    .eq("bucket", "ws_message_10s")
    .maybeSingle();
  if (!row) {
    await admin.from("ws_rate_limits").insert({ user_id: userId, bucket: "ws_message_10s", count: 1, window_start: now.toISOString() });
    return;
  }
  if (now.getTime() - new Date(row.window_start).getTime() > 10_000) {
    await admin.from("ws_rate_limits").update({ count: 1, window_start: now.toISOString() }).eq("id", row.id);
    return;
  }
  if (row.count >= 10) throw new Error("You're sending messages too fast. Please slow down.");
  await admin.from("ws_rate_limits").update({ count: row.count + 1 }).eq("id", row.id);
}

export const wsSendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        thread_id: z.string().uuid(),
        body: z.string().trim().min(1).max(4000),
        reply_to_id: z.string().uuid().nullish(),
        attachments: z
          .array(
            z.object({
              storage_path: z.string().min(1),
              mime: z.string().min(1),
              size: z.number().int().nonnegative(),
              width: z.number().int().nullish(),
              height: z.number().int().nullish(),
              kind: z.enum(["image", "file"]).default("file"),
            })
          )
          .max(10)
          .optional(),
      })
      .parse(raw)
  )
  .handler(async ({ data, context }) => {
    const { data: thread } = await context.supabase
      .from("ws_threads")
      .select("id, buyer_id, seller_id")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    if (thread.buyer_id !== context.userId && thread.seller_id !== context.userId) throw new Error("Not a participant.");

    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await enforceRateLimit(supabaseAdmin as unknown as Parameters<typeof enforceRateLimit>[0], context.userId);
    } catch (e) {
      if (e instanceof Error && e.message.includes("too fast")) throw e;
    }

    const flags = detectSpam(data.body);
    const { data: inserted, error } = await context.supabase
      .from("ws_messages")
      .insert({
        thread_id: data.thread_id,
        sender_id: context.userId,
        body: data.body,
        reply_to_id: data.reply_to_id ?? null,
        client_flags: flags,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    if (data.attachments?.length) {
      const rows = data.attachments.map((a) => ({
        message_id: inserted.id,
        thread_id: data.thread_id,
        uploader_id: context.userId,
        storage_path: a.storage_path,
        mime: a.mime,
        size: a.size,
        width: a.width ?? null,
        height: a.height ?? null,
        kind: a.kind,
      }));
      await context.supabase.from("ws_message_attachments").insert(rows);
    }
    await context.supabase
      .from("ws_threads")
      .update({ last_message_at: new Date().toISOString() })
      .eq("id", data.thread_id);
    return { ok: true, id: inserted.id, flags };
  });

export const wsEditMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid(), body: z.string().trim().min(1).max(4000) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: msg } = await context.supabase
      .from("ws_messages")
      .select("id, sender_id, created_at, deleted_at")
      .eq("id", data.id)
      .maybeSingle();
    if (!msg) throw new Error("Message not found");
    if (msg.sender_id !== context.userId) throw new Error("Not your message");
    if (msg.deleted_at) throw new Error("Deleted messages can't be edited");
    if (Date.now() - new Date(msg.created_at).getTime() > 15 * 60_000) throw new Error("Edit window expired (15 min).");
    const { error } = await context.supabase
      .from("ws_messages")
      .update({ body: data.body, edited_at: new Date().toISOString() })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const wsDeleteMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: msg } = await context.supabase
      .from("ws_messages")
      .select("id, sender_id")
      .eq("id", data.id)
      .maybeSingle();
    if (!msg) throw new Error("Message not found");
    if (msg.sender_id !== context.userId) throw new Error("Not your message");
    const { error } = await context.supabase
      .from("ws_messages")
      .update({ deleted_at: new Date().toISOString(), body: "" })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const wsToggleReaction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ message_id: z.string().uuid(), emoji: z.string().min(1).max(16) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: existing } = await context.supabase
      .from("ws_message_reactions")
      .select("id")
      .eq("message_id", data.message_id)
      .eq("user_id", context.userId)
      .eq("emoji", data.emoji)
      .maybeSingle();
    if (existing) {
      await context.supabase.from("ws_message_reactions").delete().eq("id", existing.id);
      return { reacted: false };
    }
    const { error } = await context.supabase
      .from("ws_message_reactions")
      .insert({ message_id: data.message_id, user_id: context.userId, emoji: data.emoji });
    if (error) throw new Error(error.message);
    return { reacted: true };
  });

export const wsMarkThreadRead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ thread_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: thread } = await context.supabase
      .from("ws_threads")
      .select("id, buyer_id, seller_id")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    const now = new Date().toISOString();
    const patch =
      thread.buyer_id === context.userId
        ? { buyer_last_read_at: now }
        : thread.seller_id === context.userId
        ? { seller_last_read_at: now }
        : null;
    if (!patch) throw new Error("Not a participant.");
    await context.supabase.from("ws_threads").update(patch).eq("id", data.thread_id);
    return { ok: true };
  });

export const wsSetMute = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ thread_id: z.string().uuid(), muted: z.boolean() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: thread } = await context.supabase
      .from("ws_threads")
      .select("id, buyer_id, seller_id")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    const patch =
      thread.buyer_id === context.userId
        ? { buyer_muted: data.muted }
        : thread.seller_id === context.userId
        ? { seller_muted: data.muted }
        : null;
    if (!patch) throw new Error("Not a participant.");
    await context.supabase.from("ws_threads").update(patch).eq("id", data.thread_id);
    return { ok: true };
  });

export const wsReportThread = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        thread_id: z.string().uuid(),
        reported_user_id: z.string().uuid(),
        reason: z.string().min(2).max(80),
        details: z.string().max(1000).optional(),
        message_id: z.string().uuid().optional(),
      })
      .parse(raw)
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("ws_thread_reports").insert({
      thread_id: data.thread_id,
      reporter_id: context.userId,
      reported_user_id: data.reported_user_id,
      reason: data.reason,
      details: data.details ?? null,
      message_id: data.message_id ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const wsAttachmentSignedUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ path: z.string().min(1) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: signed, error } = await context.supabase.storage
      .from("ws-message-attachments")
      .createSignedUrl(data.path, 60 * 30);
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl };
  });

export const wsFetchLinkPreview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ url: z.string().url() }).parse(raw))
  .handler(async ({ data, context }) => {
    const url = data.url.slice(0, 500);
    const { data: cached } = await context.supabase.from("ws_link_previews").select("*").eq("url", url).maybeSingle();
    if (cached && Date.now() - new Date(cached.fetched_at).getTime() < 1000 * 60 * 60 * 24 * 7) return cached;
    let html = "";
    try {
      const r = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0 HeySaaS-LinkPreview/1.0" },
        signal: AbortSignal.timeout(6000),
      });
      if (r.ok) html = (await r.text()).slice(0, 200_000);
    } catch {
      /* ignore */
    }
    const pick = (re: RegExp) => html.match(re)?.[1]?.trim() ?? null;
    const preview = {
      url,
      title:
        pick(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i) ??
        pick(/<title>([^<]+)<\/title>/i),
      description:
        pick(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i) ??
        pick(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i),
      image_url: pick(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i),
      site_name: pick(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i),
      fetched_at: new Date().toISOString(),
    };
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.from("ws_link_previews").upsert(preview);
    } catch {
      /* best-effort cache */
    }
    return preview;
  });

export const wsSuggestReply = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ thread_id: z.string().uuid(), seed: z.string().max(200).optional() }).parse(raw))
  .handler(async ({ data, context }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI is not configured.");
    const { data: thread } = await context.supabase
      .from("ws_threads")
      .select("id, buyer_id, seller_id, ws_listings!inner(title, domain, asking_price_usd, listing_type, description)")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    if (thread.buyer_id !== context.userId && thread.seller_id !== context.userId) throw new Error("Not a participant.");
    const { data: messages } = await context.supabase
      .from("ws_messages")
      .select("sender_id, body, deleted_at")
      .eq("thread_id", data.thread_id)
      .is("deleted_at", null)
      .order("created_at", { ascending: false })
      .limit(20);
    const isBuyer = thread.buyer_id === context.userId;
    const listing = (thread as unknown as { ws_listings: { title: string; domain: string; asking_price_usd: number | null; listing_type: string; description: string | null } }).ws_listings;
    const transcript = (messages ?? [])
      .reverse()
      .map((m) => `${m.sender_id === context.userId ? "ME" : "THEM"}: ${m.body}`)
      .join("\n");

    const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You draft ONE short reply for a marketplace negotiation between a website ${isBuyer ? "buyer" : "seller"} and the other party. Stay grounded in the transcript and listing facts. Do NOT invent numbers. Keep it under 60 words, natural, professional. Return only the reply text.`,
          },
          {
            role: "user",
            content: `Listing: ${listing.title} (${listing.domain}), type=${listing.listing_type}, ask=${listing.asking_price_usd ?? "open"}\nDescription: ${(listing.description ?? "").slice(0, 400)}\n\nTranscript (oldest first):\n${transcript || "(no messages yet)"}\n\n${data.seed ? `The user wants to: ${data.seed}\n` : ""}Draft my reply:`,
          },
        ],
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!r.ok) throw new Error(`AI error ${r.status}`);
    const json = (await r.json()) as { choices?: Array<{ message?: { content?: string } }> };
    const draft = json.choices?.[0]?.message?.content?.trim() ?? "";
    return { draft };
  });

export const wsSearchMessages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ thread_id: z.string().uuid(), q: z.string().trim().min(1).max(120) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: rows } = await context.supabase
      .from("ws_messages")
      .select("id, body, sender_id, created_at")
      .eq("thread_id", data.thread_id)
      .is("deleted_at", null)
      .ilike("body", `%${data.q.replace(/[%_]/g, "")}%`)
      .order("created_at", { ascending: false })
      .limit(50);
    return rows ?? [];
  });

export const wsCreateOffer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        thread_id: z.string().uuid(),
        amount_usd: z.number().nonnegative(),
        message: z.string().max(1000).optional(),
      })
      .parse(raw)
  )
  .handler(async ({ data, context }) => {
    const { data: thread } = await context.supabase
      .from("ws_threads")
      .select("listing_id, buyer_id, seller_id")
      .eq("id", data.thread_id)
      .maybeSingle();
    if (!thread) throw new Error("Thread not found");
    if (thread.buyer_id !== context.userId) throw new Error("Only the buyer can send offers.");
    const { error } = await context.supabase.from("ws_offers").insert({
      thread_id: data.thread_id,
      listing_id: thread.listing_id,
      buyer_id: thread.buyer_id,
      seller_id: thread.seller_id,
      amount_usd: data.amount_usd,
      message: data.message ?? null,
      offer_type: "cash",
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const wsRespondOffer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) =>
    z
      .object({
        offer_id: z.string().uuid(),
        action: z.enum(["accept", "reject", "counter", "withdraw"]),
        counter_amount: z.number().nonnegative().optional(),
      })
      .parse(raw)
  )
  .handler(async ({ data, context }) => {
    const { data: offer } = await context.supabase
      .from("ws_offers")
      .select("*")
      .eq("id", data.offer_id)
      .maybeSingle();
    if (!offer) throw new Error("Offer not found");
    if (data.action === "withdraw" && offer.buyer_id !== context.userId) throw new Error("Only the buyer can withdraw.");
    if (["accept", "reject", "counter"].includes(data.action) && offer.seller_id !== context.userId) {
      throw new Error("Only the seller can respond.");
    }

    const now = new Date().toISOString();
    if (data.action === "counter") {
      if (data.counter_amount == null) throw new Error("Counter amount required.");
      await context.supabase
        .from("ws_offers")
        .update({ status: "countered", responded_at: now })
        .eq("id", offer.id);
      await context.supabase.from("ws_offers").insert({
        thread_id: offer.thread_id,
        listing_id: offer.listing_id,
        buyer_id: offer.buyer_id,
        seller_id: offer.seller_id,
        amount_usd: data.counter_amount,
        offer_type: "cash",
        parent_offer_id: offer.id,
      });
    } else {
      const statusMap = { accept: "accepted", reject: "rejected", withdraw: "withdrawn" } as const;
      await context.supabase
        .from("ws_offers")
        .update({ status: statusMap[data.action as "accept" | "reject" | "withdraw"], responded_at: now })
        .eq("id", offer.id);
    }
    return { ok: true };
  });

// ---------- WATCHLIST ----------
export const wsToggleWatchlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ listing_id: z.string().uuid() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { data: existing } = await context.supabase
      .from("ws_watchlists")
      .select("user_id")
      .eq("user_id", context.userId)
      .eq("listing_id", data.listing_id)
      .maybeSingle();
    if (existing) {
      await context.supabase
        .from("ws_watchlists")
        .delete()
        .eq("user_id", context.userId)
        .eq("listing_id", data.listing_id);
      return { watched: false };
    }
    await context.supabase.from("ws_watchlists").insert({ user_id: context.userId, listing_id: data.listing_id });
    return { watched: true };
  });

export const wsListWatchlist = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("ws_watchlists")
      .select("created_at, notify, ws_listings!inner(id, title, domain, listing_type, asking_price_usd, screenshots, status, ownership_verified)")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const wsBulkRemoveWatchlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ listing_ids: z.array(z.string().uuid()).min(1).max(100) }).parse(raw))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("ws_watchlists")
      .delete()
      .eq("user_id", context.userId)
      .in("listing_id", data.listing_ids);
    if (error) throw new Error(error.message);
    return { removed: data.listing_ids.length };
  });

export const wsSetWatchlistNotify = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => z.object({ listing_ids: z.array(z.string().uuid()).min(1).max(100), notify: z.boolean() }).parse(raw))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("ws_watchlists")
      .update({ notify: data.notify })
      .eq("user_id", context.userId)
      .in("listing_id", data.listing_ids);
    if (error) throw new Error(error.message);
    return { updated: data.listing_ids.length };
  });


// ---------- DASHBOARD STATS ----------
export const wsDashboardStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const [listings, offersReceived, offersSent, watchlist] = await Promise.all([
      context.supabase.from("ws_listings").select("id, views_count, status", { count: "exact" }).eq("seller_id", context.userId),
      context.supabase.from("ws_offers").select("id", { count: "exact", head: true }).eq("seller_id", context.userId),
      context.supabase.from("ws_offers").select("id", { count: "exact", head: true }).eq("buyer_id", context.userId),
      context.supabase.from("ws_watchlists").select("listing_id", { count: "exact", head: true }).eq("user_id", context.userId),
    ]);
    const totalViews = (listings.data ?? []).reduce((s, r) => s + (r.views_count ?? 0), 0);
    const liveCount = (listings.data ?? []).filter((r) => r.status === "live").length;
    return {
      listings_total: listings.count ?? 0,
      listings_live: liveCount,
      total_views: totalViews,
      offers_received: offersReceived.count ?? 0,
      offers_sent: offersSent.count ?? 0,
      watchlist_count: watchlist.count ?? 0,
    };
  });
