// Server-only rate limit helper. Uses fixed-window counters in public.rate_limits.
// Import lazily inside server function handlers.

export async function checkRateLimit(opts: {
  bucket: string;
  userId?: string | null;
  ipHash?: string | null;
  limit: number;
  windowSeconds: number;
}): Promise<{ ok: true } | { ok: false; retryAfter: number }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const now = new Date();
  const windowStart = new Date(Math.floor(now.getTime() / (opts.windowSeconds * 1000)) * opts.windowSeconds * 1000);

  const userId = opts.userId ?? null;
  const ipHash = opts.ipHash ?? null;
  if (!userId && !ipHash) return { ok: true };

  const key = userId
    ? { bucket: opts.bucket, user_id: userId, ip_hash: null as string | null, window_start: windowStart.toISOString() }
    : { bucket: opts.bucket, user_id: null as string | null, ip_hash: ipHash, window_start: windowStart.toISOString() };

  // Try to find current window
  let q = supabaseAdmin.from("rate_limits").select("id, count").eq("bucket", key.bucket).eq("window_start", key.window_start);
  q = userId ? q.eq("user_id", userId) : q.is("user_id", null).eq("ip_hash", ipHash!);
  const { data: existing } = await q.maybeSingle();

  if (!existing) {
    await supabaseAdmin.from("rate_limits").insert({ ...key, count: 1 });
    return { ok: true };
  }
  if (existing.count >= opts.limit) {
    const retryAfter = Math.max(1, Math.ceil((windowStart.getTime() + opts.windowSeconds * 1000 - now.getTime()) / 1000));
    return { ok: false, retryAfter };
  }
  await supabaseAdmin.from("rate_limits").update({ count: existing.count + 1 }).eq("id", existing.id);
  return { ok: true };
}
