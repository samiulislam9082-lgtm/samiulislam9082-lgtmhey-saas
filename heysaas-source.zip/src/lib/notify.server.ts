/**
 * Server-only notification writer.
 *
 * The `notifications` table intentionally has no INSERT policy, so a
 * user-scoped client can never create a notification for another user.
 * All cross-user notifications must go through here.
 */
export type NotificationRow = {
  user_id: string;
  type: string;
  title: string;
  body?: string | null;
  link?: string | null;
  metadata?: Record<string, unknown> | null;
};

export async function notify(rows: NotificationRow | NotificationRow[]) {
  const list = (Array.isArray(rows) ? rows : [rows]).filter((r) => r && r.user_id);
  if (list.length === 0) return { inserted: 0 };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { error } = await supabaseAdmin.from("notifications").insert(list as never);
  if (error) {
    console.error("[notify] failed to insert notifications", error);
    throw new Error(error.message);
  }
  return { inserted: list.length };
}
