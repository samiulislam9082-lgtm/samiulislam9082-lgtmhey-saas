/**
 * Shared head() helper — keeps canonical, og:url, description, and
 * twitter/OG alignment consistent across every public route.
 *
 * Usage:
 *   export const Route = createFileRoute("/about")({
 *     head: () => buildHead({
 *       path: "/about",
 *       title: "About — Hey SaaS",
 *       description: "Who we are and why we built Hey SaaS.",
 *       ogType: "website",          // optional, defaults to "website"
 *       image: "https://…/og.jpg",  // optional, leaf-only
 *     }),
 *     component: About,
 *   });
 *
 * Rules baked in (see `head-meta`, `tanstack-ssr-head`):
 *  - Canonical + og:url self-reference the same absolute route URL.
 *  - og:description mirrors <meta name=description> exactly.
 *  - twitter:title / twitter:description are omitted so Twitter falls
 *    back to og:*; only twitter:card is emitted.
 *  - og:image / twitter:image only when explicitly provided (leaf routes).
 *  - Never call from __root.tsx — canonical must live on leaves only.
 */

export const SITE_ORIGIN = "https://heysaas.lovable.app";

export type BuildHeadOptions = {
  /** Route path starting with "/" (e.g. "/about", "/posts/hello"). */
  path: string;
  title: string;
  description: string;
  /** Defaults to "website"; use "article", "product", etc. on leaves. */
  ogType?: string;
  /** Absolute https URL. Leaf routes only. */
  image?: string;
  /** Extra meta entries appended after the defaults. */
  extraMeta?: Array<Record<string, string>>;
  /** Extra links appended after the canonical. */
  extraLinks?: Array<Record<string, string>>;
  /** JSON-LD or other script tags. */
  scripts?: Array<Record<string, unknown>>;
  /** Set to true to emit robots noindex (e.g. not-found variants). */
  noindex?: boolean;
};

export type HeadReturn = {
  meta: Array<Record<string, string>>;
  links: Array<Record<string, string>>;
  scripts?: Array<Record<string, unknown>>;
};

function absoluteUrl(path: string): string {
  const normalized = path.startsWith("/") ? path : `/${path}`;
  return `${SITE_ORIGIN}${normalized === "/" ? "" : normalized}` || SITE_ORIGIN;
}

export function buildHead(opts: BuildHeadOptions): HeadReturn {
  const {
    path,
    title,
    description,
    ogType = "website",
    image,
    extraMeta = [],
    extraLinks = [],
    scripts,
    noindex,
  } = opts;

  const url = absoluteUrl(path);

  const meta: Array<Record<string, string>> = [
    { title },
    { name: "description", content: description },
    { property: "og:title", content: title },
    { property: "og:description", content: description },
    { property: "og:url", content: url },
    { property: "og:type", content: ogType },
    { name: "twitter:card", content: "summary_large_image" },
    // twitter:title / twitter:description intentionally omitted — Twitter
    // falls back to og:title / og:description automatically.
  ];

  if (image) {
    meta.push(
      { property: "og:image", content: image },
      { name: "twitter:image", content: image },
    );
  }

  if (noindex) {
    meta.push({ name: "robots", content: "noindex" });
  }

  meta.push(...extraMeta);

  const links: Array<Record<string, string>> = [
    { rel: "canonical", href: url },
    ...extraLinks,
  ];

  return scripts ? { meta, links, scripts } : { meta, links };
}
