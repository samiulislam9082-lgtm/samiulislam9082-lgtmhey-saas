import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const PrefsSchema = z.object({
  q: z.string().default(""),
  categoryId: z.string().uuid().nullable().default(null),
  mrr: z.array(z.string()).default([]),
  tech: z.array(z.string()).default([]),
  countries: z.array(z.string()).default([]),
  pricingModels: z.array(z.string()).default([]),
  lookingFor: z.array(z.string()).default([]),
  sort: z.string().default("trending"),
});

export type ExplorePrefs = z.infer<typeof PrefsSchema>;

export const getExplorePrefs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select("explore_preferences")
      .eq("id", context.userId)
      .single();
    if (error) throw new Error(error.message);
    const raw = (data as any)?.explore_preferences ?? {};
    const parsed = PrefsSchema.safeParse(raw);
    return parsed.success ? parsed.data : PrefsSchema.parse({});
  });

export const saveExplorePrefs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => PrefsSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({ explore_preferences: data } as any)
      .eq("id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
