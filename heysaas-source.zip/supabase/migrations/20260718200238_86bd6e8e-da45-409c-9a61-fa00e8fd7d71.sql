CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Unschedule if exists (idempotent)
DO $$
BEGIN
  PERFORM cron.unschedule('saved-search-daily-digest');
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

SELECT cron.schedule(
  'saved-search-daily-digest',
  '0 14 * * *',
  $$
  SELECT net.http_post(
    url := 'https://project--eb8e247b-0ae3-4a14-ae3c-bfec3d8e503e.lovable.app/api/public/saved-search-digest',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'apikey', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdoaGhscHF3eHB1dWR1ZXhqbG1tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQzMDg0NjYsImV4cCI6MjA5OTg4NDQ2Nn0.MgxvE1Zv13Atlx7vvvqQxZ2abPN1ZjjCyu0LaMjcyu4'
    ),
    body := '{}'::jsonb
  );
  $$
);