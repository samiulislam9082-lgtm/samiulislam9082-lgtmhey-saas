
-- 1) ws_messages: prevent non-senders from changing anything other than read_at
CREATE OR REPLACE FUNCTION public.ws_messages_guard_recipient_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.sender_id = auth.uid() THEN
    RETURN NEW;
  END IF;
  -- Non-sender: only read_at may change
  IF NEW.thread_id     IS DISTINCT FROM OLD.thread_id
  OR NEW.sender_id     IS DISTINCT FROM OLD.sender_id
  OR NEW.body          IS DISTINCT FROM OLD.body
  OR NEW.attachments   IS DISTINCT FROM OLD.attachments
  OR NEW.created_at    IS DISTINCT FROM OLD.created_at
  OR NEW.edited_at     IS DISTINCT FROM OLD.edited_at
  OR NEW.deleted_at    IS DISTINCT FROM OLD.deleted_at
  OR NEW.reply_to_id   IS DISTINCT FROM OLD.reply_to_id
  OR NEW.kind          IS DISTINCT FROM OLD.kind
  OR NEW.client_flags  IS DISTINCT FROM OLD.client_flags
  OR NEW.id            IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'Only the message read_at field can be updated by recipients';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ws_messages_guard_recipient_update ON public.ws_messages;
CREATE TRIGGER ws_messages_guard_recipient_update
BEFORE UPDATE ON public.ws_messages
FOR EACH ROW EXECUTE FUNCTION public.ws_messages_guard_recipient_update();

-- 2) ws_threads: prevent participants from reassigning ownership fields
CREATE OR REPLACE FUNCTION public.ws_threads_guard_participant_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.id          IS DISTINCT FROM OLD.id
  OR NEW.buyer_id    IS DISTINCT FROM OLD.buyer_id
  OR NEW.seller_id   IS DISTINCT FROM OLD.seller_id
  OR NEW.listing_id  IS DISTINCT FROM OLD.listing_id
  OR NEW.created_at  IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'Thread ownership fields cannot be modified';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ws_threads_guard_participant_update ON public.ws_threads;
CREATE TRIGGER ws_threads_guard_participant_update
BEFORE UPDATE ON public.ws_threads
FOR EACH ROW EXECUTE FUNCTION public.ws_threads_guard_participant_update();

-- Also add a WITH CHECK on the participants update policy to reinforce membership
DROP POLICY IF EXISTS "ws_threads participants update" ON public.ws_threads;
CREATE POLICY "ws_threads participants update"
ON public.ws_threads
FOR UPDATE
TO authenticated
USING ((auth.uid() = buyer_id) OR (auth.uid() = seller_id))
WITH CHECK ((auth.uid() = buyer_id) OR (auth.uid() = seller_id));
