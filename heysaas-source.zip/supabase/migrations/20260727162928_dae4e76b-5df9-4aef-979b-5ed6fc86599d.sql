CREATE POLICY "Participants create direct thread" ON public.threads
FOR INSERT TO authenticated
WITH CHECK (
  swap_request_id IS NULL
  AND (auth.uid() = user_a OR auth.uid() = user_b)
  AND user_a <> user_b
);