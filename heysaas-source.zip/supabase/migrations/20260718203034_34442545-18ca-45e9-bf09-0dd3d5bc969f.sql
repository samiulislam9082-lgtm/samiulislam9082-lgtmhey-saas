
-- Public read for ws-listing-screenshots (bucket kept private because workspace blocks public buckets;
-- public visibility is provided via storage.objects RLS instead)
CREATE POLICY "ws screenshots public read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'ws-listing-screenshots');

CREATE POLICY "ws screenshots owner insert"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'ws-listing-screenshots' AND owner = auth.uid());

CREATE POLICY "ws screenshots owner update"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'ws-listing-screenshots' AND owner = auth.uid());

CREATE POLICY "ws screenshots owner delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'ws-listing-screenshots' AND owner = auth.uid());
