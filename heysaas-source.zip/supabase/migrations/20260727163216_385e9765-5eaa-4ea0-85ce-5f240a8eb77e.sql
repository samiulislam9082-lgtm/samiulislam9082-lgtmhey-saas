
-- Thread participants can upload into message-media/{thread_id}/...
CREATE POLICY "Thread participants upload message media"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'message-media'
  AND auth.uid() = owner
  AND EXISTS (
    SELECT 1 FROM public.threads t
    WHERE t.id::text = (storage.foldername(name))[1]
      AND (t.user_a = auth.uid() OR t.user_b = auth.uid())
  )
);

-- Thread participants can read message-media/{thread_id}/...
CREATE POLICY "Thread participants read message media"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'message-media'
  AND EXISTS (
    SELECT 1 FROM public.threads t
    WHERE t.id::text = (storage.foldername(name))[1]
      AND (t.user_a = auth.uid() OR t.user_b = auth.uid() OR public.has_role(auth.uid(),'admin'))
  )
);

-- Owner can delete their own upload
CREATE POLICY "Owner deletes own message media"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'message-media' AND owner = auth.uid());
