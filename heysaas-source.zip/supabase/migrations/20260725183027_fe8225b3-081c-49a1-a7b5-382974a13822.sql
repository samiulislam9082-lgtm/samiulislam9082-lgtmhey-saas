REVOKE SELECT ON public.profiles FROM anon;
GRANT SELECT (
  id, username, display_name, avatar_url, bio, cover_url,
  website_url, twitter_handle, github_handle, linkedin_handle,
  verified, created_at, updated_at
) ON public.profiles TO anon;

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;