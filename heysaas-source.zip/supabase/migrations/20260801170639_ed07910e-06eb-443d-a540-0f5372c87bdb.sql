CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_normalized_uidx
  ON public.profiles ((lower(replace(replace(username, '_', ''), '.', ''))))
  WHERE username IS NOT NULL;

CREATE OR REPLACE FUNCTION public.is_username_available(_username text, _user_id uuid DEFAULT NULL)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE lower(replace(replace(p.username, '_', ''), '.', ''))
        = lower(replace(replace(_username, '_', ''), '.', ''))
      AND (_user_id IS NULL OR p.id <> _user_id)
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_username_available(text, uuid) TO authenticated;