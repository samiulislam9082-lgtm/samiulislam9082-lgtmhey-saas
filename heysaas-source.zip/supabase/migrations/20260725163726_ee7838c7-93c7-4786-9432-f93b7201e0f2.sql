-- 1) Fix OVEREXPOSED_RELATIONSHIP_DATA on follows
DROP POLICY IF EXISTS "Follows readable by authenticated" ON public.follows;
CREATE POLICY "Follows readable by involved users"
  ON public.follows FOR SELECT
  TO authenticated
  USING (auth.uid() = follower_id OR auth.uid() = following_id);

-- 2) Fix OVEREXPOSED_RELATIONSHIP_DATA on interests
DROP POLICY IF EXISTS "Authenticated views interests" ON public.interests;
CREATE POLICY "Interests readable by interested user or listing owner"
  ON public.interests FOR SELECT
  TO authenticated
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM public.saas_listings l
      WHERE l.id = interests.listing_id AND l.owner_id = auth.uid()
    )
  );

-- 3) Fix MISSING_OWNERSHIP_CHECK on support_message_feedback
DROP POLICY IF EXISTS "Anyone can submit feedback" ON public.support_message_feedback;
CREATE POLICY "Users submit own feedback"
  ON public.support_message_feedback FOR INSERT
  TO authenticated
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());

-- 4) Revoke EXECUTE on trigger-only SECURITY DEFINER functions from PUBLIC/authenticated/anon.
--    Triggers still fire (they run as the trigger owner), but the functions cannot be called via PostgREST.
DO $$
DECLARE
  fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'public.log_ticket_status_change()',
    'public.log_ticket_created()',
    'public.notify_admins_new_ticket()',
    'public.grant_super_admin_role()',
    'public.handle_new_user()',
    'public.saved_searches_snapshot_version()',
    'public.check_support_error_threshold()',
    'public.saas_listings_tsv_update()',
    'public.ws_listings_tsv_update()',
    'public.ws_listings_enforce_verified()',
    'public.update_updated_at_column()'
  ]
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, anon, authenticated', fn);
  END LOOP;
END $$;

-- Keep has_role and completed_swaps_count callable (used by RLS / UI counters)
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.completed_swaps_count() TO anon, authenticated;

-- 5) Security audit log
CREATE TABLE IF NOT EXISTS public.security_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  row_id uuid,
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.security_audit_log TO authenticated;
GRANT ALL ON public.security_audit_log TO service_role;

ALTER TABLE public.security_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read audit log"
  ON public.security_audit_log FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE OR REPLACE FUNCTION public.log_security_audit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  rid uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    rid := (row_to_json(OLD)->>'id')::uuid;
    INSERT INTO public.security_audit_log (actor_id, action, table_name, row_id, old_data)
    VALUES (auth.uid(), TG_OP, TG_TABLE_NAME, rid, to_jsonb(OLD));
    RETURN OLD;
  ELSE
    rid := (row_to_json(NEW)->>'id')::uuid;
    INSERT INTO public.security_audit_log (actor_id, action, table_name, row_id, old_data, new_data)
    VALUES (auth.uid(), TG_OP, TG_TABLE_NAME, rid,
            CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
            to_jsonb(NEW));
    RETURN NEW;
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.log_security_audit() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS trg_audit_saas_listings ON public.saas_listings;
CREATE TRIGGER trg_audit_saas_listings
  AFTER INSERT OR UPDATE OR DELETE ON public.saas_listings
  FOR EACH ROW EXECUTE FUNCTION public.log_security_audit();

DROP TRIGGER IF EXISTS trg_audit_ws_listings ON public.ws_listings;
CREATE TRIGGER trg_audit_ws_listings
  AFTER INSERT OR UPDATE OR DELETE ON public.ws_listings
  FOR EACH ROW EXECUTE FUNCTION public.log_security_audit();

DROP TRIGGER IF EXISTS trg_audit_user_roles ON public.user_roles;
CREATE TRIGGER trg_audit_user_roles
  AFTER INSERT OR UPDATE OR DELETE ON public.user_roles
  FOR EACH ROW EXECUTE FUNCTION public.log_security_audit();