
REVOKE EXECUTE ON FUNCTION public.grant_super_admin_role() FROM PUBLIC, anon, authenticated;
