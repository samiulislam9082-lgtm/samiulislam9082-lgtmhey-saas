
ALTER TABLE public.support_webhook_deliveries
  DROP CONSTRAINT IF EXISTS support_webhook_deliveries_status_check;

ALTER TABLE public.support_webhook_deliveries
  ADD CONSTRAINT support_webhook_deliveries_status_check
  CHECK (status = ANY (ARRAY['sent','failed','not_configured','pending','retrying','dead_letter']));

ALTER TABLE public.support_webhook_deliveries
  ADD COLUMN IF NOT EXISTS dead_lettered_at timestamptz,
  ADD COLUMN IF NOT EXISTS failure_reason text;

CREATE INDEX IF NOT EXISTS support_webhook_deliveries_dead_letter_idx
  ON public.support_webhook_deliveries (dead_lettered_at DESC)
  WHERE status = 'dead_letter';

-- Backfill: any historical 'failed' rows that hit the retry cap become dead-lettered.
UPDATE public.support_webhook_deliveries
   SET status = 'dead_letter',
       dead_lettered_at = COALESCE(last_attempt_at, created_at),
       failure_reason = CASE
         WHEN http_status BETWEEN 400 AND 499 THEN 'client_error_' || http_status::text
         WHEN http_status BETWEEN 500 AND 599 THEN 'server_error_' || http_status::text
         WHEN error ILIKE '%abort%' OR error ILIKE '%timeout%' THEN 'timeout'
         WHEN error IS NOT NULL THEN 'network_error'
         ELSE 'unknown'
       END
 WHERE status = 'failed'
   AND attempt_count IS NOT NULL
   AND max_attempts IS NOT NULL
   AND attempt_count >= max_attempts;
