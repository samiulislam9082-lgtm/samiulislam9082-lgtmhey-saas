
-- Notification preferences + quiet hours
CREATE TABLE public.notification_preferences (
  user_id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email_prefs JSONB NOT NULL DEFAULT '{"new_message":true,"swap_update":true,"offer":true,"payment":true,"system":true,"digest":true,"promo":false}'::jsonb,
  inapp_prefs JSONB NOT NULL DEFAULT '{"new_message":true,"swap_update":true,"offer":true,"payment":true,"system":true,"digest":true,"promo":true}'::jsonb,
  quiet_hours_enabled BOOLEAN NOT NULL DEFAULT false,
  quiet_hours_start SMALLINT NOT NULL DEFAULT 22,
  quiet_hours_end SMALLINT NOT NULL DEFAULT 8,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notification_preferences TO authenticated;
GRANT ALL ON public.notification_preferences TO service_role;
ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own notif prefs" ON public.notification_preferences FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_notif_prefs_updated BEFORE UPDATE ON public.notification_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Per-user thread state (mute, archive, mark-unread)
CREATE TABLE public.thread_states (
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  thread_id UUID NOT NULL REFERENCES public.threads ON DELETE CASCADE,
  muted BOOLEAN NOT NULL DEFAULT false,
  archived BOOLEAN NOT NULL DEFAULT false,
  marked_unread_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, thread_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.thread_states TO authenticated;
GRANT ALL ON public.thread_states TO service_role;
ALTER TABLE public.thread_states ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own thread state" ON public.thread_states FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_thread_states_updated BEFORE UPDATE ON public.thread_states FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Watchlist per-listing notification toggle
ALTER TABLE public.ws_watchlists ADD COLUMN IF NOT EXISTS notify BOOLEAN NOT NULL DEFAULT true;
