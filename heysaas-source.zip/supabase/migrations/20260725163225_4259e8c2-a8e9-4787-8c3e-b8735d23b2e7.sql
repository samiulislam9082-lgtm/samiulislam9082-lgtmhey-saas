DROP POLICY IF EXISTS "Auth read listing images" ON storage.objects;

CREATE POLICY "Owner read listing images"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = ANY (ARRAY['covers'::text, 'logos'::text, 'screenshots'::text])
  AND (storage.foldername(name))[1] = (auth.uid())::text
);