
CREATE OR REPLACE FUNCTION public.completed_swaps_count()
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::bigint FROM public.swap_requests WHERE status = 'completed';
$$;

REVOKE EXECUTE ON FUNCTION public.completed_swaps_count() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.completed_swaps_count() TO anon, authenticated;
