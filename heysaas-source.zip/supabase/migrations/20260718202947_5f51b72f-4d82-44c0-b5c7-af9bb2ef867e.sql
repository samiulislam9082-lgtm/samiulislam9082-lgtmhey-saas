
-- =========================================================================
-- WebSwap Phase 1 — all objects prefixed ws_ ; isolated from HeySaaS
-- =========================================================================

-- ---------- ENUMS ----------
CREATE TYPE public.ws_listing_type AS ENUM ('for_sale', 'open_to_swap', 'open_to_both');
CREATE TYPE public.ws_listing_status AS ENUM ('draft', 'pending_verification', 'live', 'paused', 'sold', 'removed');
CREATE TYPE public.ws_dns_status AS ENUM ('pending', 'verified', 'failed', 'expired');
CREATE TYPE public.ws_offer_type AS ENUM ('cash', 'swap', 'cash_plus_swap');
CREATE TYPE public.ws_offer_status AS ENUM ('pending', 'accepted', 'rejected', 'countered', 'withdrawn', 'expired');

-- =========================================================================
-- ws_profile_extensions
-- =========================================================================
CREATE TABLE public.ws_profile_extensions (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  verified_seller boolean NOT NULL DEFAULT false,
  stripe_account_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ws_profile_extensions TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_profile_extensions TO authenticated;
GRANT ALL ON public.ws_profile_extensions TO service_role;
ALTER TABLE public.ws_profile_extensions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_profile_ext public read"
  ON public.ws_profile_extensions FOR SELECT
  USING (true);

CREATE POLICY "ws_profile_ext owner manage"
  ON public.ws_profile_extensions FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "ws_profile_ext admin manage"
  ON public.ws_profile_extensions FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER ws_profile_extensions_updated_at
  BEFORE UPDATE ON public.ws_profile_extensions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================================
-- ws_listings
-- =========================================================================
CREATE TABLE public.ws_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  website_url text NOT NULL,
  domain text NOT NULL,
  title text NOT NULL,
  description text,
  niche text,
  category_slug text,
  listing_type public.ws_listing_type NOT NULL DEFAULT 'for_sale',
  asking_price_usd numeric(12,2),
  currency text NOT NULL DEFAULT 'USD',
  -- self-reported (Phase 1)
  monthly_revenue_usd numeric(12,2),
  monthly_traffic integer,
  site_age_months integer,
  -- Phase 2 hooks (nullable, unused in P1)
  verified_revenue_usd numeric(12,2),
  verified_traffic integer,
  verified_at timestamptz,
  verified_sources jsonb NOT NULL DEFAULT '{}'::jsonb,
  --
  tech_stack text[] NOT NULL DEFAULT ARRAY[]::text[],
  reason_for_selling text,
  included_assets jsonb NOT NULL DEFAULT '{}'::jsonb,
  screenshots text[] NOT NULL DEFAULT ARRAY[]::text[],
  status public.ws_listing_status NOT NULL DEFAULT 'draft',
  ownership_verified boolean NOT NULL DEFAULT false,
  ai_generated_draft boolean NOT NULL DEFAULT false,
  estimated_value_low numeric(12,2),
  estimated_value_high numeric(12,2),
  views_count integer NOT NULL DEFAULT 0,
  featured boolean NOT NULL DEFAULT false,
  promoted_until timestamptz,
  search_tsv tsvector,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX ws_listings_seller_idx ON public.ws_listings(seller_id);
CREATE INDEX ws_listings_status_idx ON public.ws_listings(status);
CREATE INDEX ws_listings_domain_idx ON public.ws_listings(domain);
CREATE INDEX ws_listings_type_idx ON public.ws_listings(listing_type);
CREATE INDEX ws_listings_search_idx ON public.ws_listings USING gin(search_tsv);
CREATE INDEX ws_listings_tech_idx ON public.ws_listings USING gin(tech_stack);

GRANT SELECT ON public.ws_listings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_listings TO authenticated;
GRANT ALL ON public.ws_listings TO service_role;
ALTER TABLE public.ws_listings ENABLE ROW LEVEL SECURITY;

-- Public can only see live + verified
CREATE POLICY "ws_listings public read live"
  ON public.ws_listings FOR SELECT
  USING (status = 'live' AND ownership_verified = true);

-- Seller sees own regardless of status
CREATE POLICY "ws_listings seller read own"
  ON public.ws_listings FOR SELECT
  TO authenticated
  USING (auth.uid() = seller_id);

CREATE POLICY "ws_listings seller insert own"
  ON public.ws_listings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "ws_listings seller update own"
  ON public.ws_listings FOR UPDATE
  TO authenticated
  USING (auth.uid() = seller_id)
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "ws_listings seller delete own"
  ON public.ws_listings FOR DELETE
  TO authenticated
  USING (auth.uid() = seller_id);

CREATE POLICY "ws_listings admin all"
  ON public.ws_listings FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- tsvector trigger
CREATE OR REPLACE FUNCTION public.ws_listings_tsv_update()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  NEW.search_tsv :=
    setweight(to_tsvector('simple', coalesce(NEW.title,'')), 'A') ||
    setweight(to_tsvector('simple', coalesce(NEW.niche,'')), 'B') ||
    setweight(to_tsvector('simple', coalesce(NEW.domain,'')), 'B') ||
    setweight(to_tsvector('simple', array_to_string(NEW.tech_stack,' ')), 'B') ||
    setweight(to_tsvector('simple', coalesce(NEW.description,'')), 'C');
  RETURN NEW;
END; $$;

CREATE TRIGGER ws_listings_tsv_trg
  BEFORE INSERT OR UPDATE ON public.ws_listings
  FOR EACH ROW EXECUTE FUNCTION public.ws_listings_tsv_update();

CREATE TRIGGER ws_listings_updated_at
  BEFORE UPDATE ON public.ws_listings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enforce: no listing can flip to 'live' unless ownership_verified = true
CREATE OR REPLACE FUNCTION public.ws_listings_enforce_verified()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.status = 'live' AND NEW.ownership_verified = false THEN
    RAISE EXCEPTION 'Listing cannot be live without ownership verification';
  END IF;
  IF NEW.status = 'live' AND (OLD.status IS DISTINCT FROM 'live') THEN
    NEW.published_at := now();
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER ws_listings_enforce_verified_trg
  BEFORE INSERT OR UPDATE ON public.ws_listings
  FOR EACH ROW EXECUTE FUNCTION public.ws_listings_enforce_verified();

-- =========================================================================
-- ws_dns_verifications
-- =========================================================================
CREATE TABLE public.ws_dns_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.ws_listings(id) ON DELETE CASCADE,
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  domain text NOT NULL,
  txt_token text NOT NULL UNIQUE,
  status public.ws_dns_status NOT NULL DEFAULT 'pending',
  last_checked_at timestamptz,
  verified_at timestamptz,
  attempts integer NOT NULL DEFAULT 0,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ws_dns_listing_idx ON public.ws_dns_verifications(listing_id);
CREATE INDEX ws_dns_seller_idx ON public.ws_dns_verifications(seller_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_dns_verifications TO authenticated;
GRANT ALL ON public.ws_dns_verifications TO service_role;
ALTER TABLE public.ws_dns_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_dns seller manage own"
  ON public.ws_dns_verifications FOR ALL
  TO authenticated
  USING (auth.uid() = seller_id)
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "ws_dns admin all"
  ON public.ws_dns_verifications FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER ws_dns_updated_at
  BEFORE UPDATE ON public.ws_dns_verifications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================================
-- ws_threads
-- =========================================================================
CREATE TABLE public.ws_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.ws_listings(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  last_message_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (listing_id, buyer_id)
);
CREATE INDEX ws_threads_buyer_idx ON public.ws_threads(buyer_id);
CREATE INDEX ws_threads_seller_idx ON public.ws_threads(seller_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_threads TO authenticated;
GRANT ALL ON public.ws_threads TO service_role;
ALTER TABLE public.ws_threads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_threads participants read"
  ON public.ws_threads FOR SELECT
  TO authenticated
  USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE POLICY "ws_threads buyer insert"
  ON public.ws_threads FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = buyer_id);

CREATE POLICY "ws_threads participants update"
  ON public.ws_threads FOR UPDATE
  TO authenticated
  USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE TRIGGER ws_threads_updated_at
  BEFORE UPDATE ON public.ws_threads
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================================
-- ws_messages
-- =========================================================================
CREATE TABLE public.ws_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.ws_threads(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL,
  attachments jsonb NOT NULL DEFAULT '[]'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ws_messages_thread_idx ON public.ws_messages(thread_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_messages TO authenticated;
GRANT ALL ON public.ws_messages TO service_role;
ALTER TABLE public.ws_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_messages participants read"
  ON public.ws_messages FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.ws_threads t
    WHERE t.id = ws_messages.thread_id
      AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
  ));

CREATE POLICY "ws_messages sender insert"
  ON public.ws_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.ws_threads t
      WHERE t.id = ws_messages.thread_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
  );

CREATE POLICY "ws_messages recipient mark read"
  ON public.ws_messages FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.ws_threads t
    WHERE t.id = ws_messages.thread_id
      AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
  ));

-- =========================================================================
-- ws_offers
-- =========================================================================
CREATE TABLE public.ws_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.ws_listings(id) ON DELETE CASCADE,
  thread_id uuid REFERENCES public.ws_threads(id) ON DELETE SET NULL,
  buyer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  offer_type public.ws_offer_type NOT NULL DEFAULT 'cash',
  amount_usd numeric(12,2),
  cash_component_usd numeric(12,2),
  swap_listing_id uuid REFERENCES public.ws_listings(id) ON DELETE SET NULL,
  message text,
  status public.ws_offer_status NOT NULL DEFAULT 'pending',
  parent_offer_id uuid REFERENCES public.ws_offers(id) ON DELETE SET NULL,
  expires_at timestamptz,
  responded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ws_offers_listing_idx ON public.ws_offers(listing_id);
CREATE INDEX ws_offers_buyer_idx ON public.ws_offers(buyer_id);
CREATE INDEX ws_offers_seller_idx ON public.ws_offers(seller_id);
CREATE INDEX ws_offers_thread_idx ON public.ws_offers(thread_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_offers TO authenticated;
GRANT ALL ON public.ws_offers TO service_role;
ALTER TABLE public.ws_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_offers participants read"
  ON public.ws_offers FOR SELECT
  TO authenticated
  USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE POLICY "ws_offers buyer insert"
  ON public.ws_offers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = buyer_id);

CREATE POLICY "ws_offers participants update"
  ON public.ws_offers FOR UPDATE
  TO authenticated
  USING (auth.uid() = buyer_id OR auth.uid() = seller_id)
  WITH CHECK (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE TRIGGER ws_offers_updated_at
  BEFORE UPDATE ON public.ws_offers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================================
-- ws_watchlists
-- =========================================================================
CREATE TABLE public.ws_watchlists (
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  listing_id uuid NOT NULL REFERENCES public.ws_listings(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, listing_id)
);
CREATE INDEX ws_watchlists_user_idx ON public.ws_watchlists(user_id);

GRANT SELECT, INSERT, DELETE ON public.ws_watchlists TO authenticated;
GRANT ALL ON public.ws_watchlists TO service_role;
ALTER TABLE public.ws_watchlists ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_watchlists owner manage"
  ON public.ws_watchlists FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- =========================================================================
-- ws_saved_searches
-- =========================================================================
CREATE TABLE public.ws_saved_searches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  filters jsonb NOT NULL DEFAULT '{}'::jsonb,
  notify_email boolean NOT NULL DEFAULT true,
  last_notified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ws_saved_searches_user_idx ON public.ws_saved_searches(user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ws_saved_searches TO authenticated;
GRANT ALL ON public.ws_saved_searches TO service_role;
ALTER TABLE public.ws_saved_searches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ws_saved_searches owner manage"
  ON public.ws_saved_searches FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER ws_saved_searches_updated_at
  BEFORE UPDATE ON public.ws_saved_searches
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
