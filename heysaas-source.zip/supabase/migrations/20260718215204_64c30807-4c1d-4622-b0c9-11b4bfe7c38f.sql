
-- 1. Shareable slugs on saved_searches
ALTER TABLE public.saved_searches
  ADD COLUMN IF NOT EXISTS share_slug text UNIQUE;

DROP POLICY IF EXISTS "Anon can view shared saved searches" ON public.saved_searches;
CREATE POLICY "Anon can view shared saved searches"
  ON public.saved_searches FOR SELECT
  TO anon, authenticated
  USING (share_slug IS NOT NULL);

GRANT SELECT ON public.saved_searches TO anon;

-- 2. Version history for saved_searches
CREATE TABLE IF NOT EXISTS public.saved_search_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  saved_search_id uuid NOT NULL REFERENCES public.saved_searches(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  version_number int NOT NULL,
  snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ssv_saved_search ON public.saved_search_versions(saved_search_id, version_number DESC);

GRANT SELECT, INSERT, DELETE ON public.saved_search_versions TO authenticated;
GRANT ALL ON public.saved_search_versions TO service_role;

ALTER TABLE public.saved_search_versions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users manage own preset versions" ON public.saved_search_versions;
CREATE POLICY "Users manage own preset versions"
  ON public.saved_search_versions FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.saved_searches_snapshot_version()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  next_ver int;
BEGIN
  IF (OLD.name IS DISTINCT FROM NEW.name)
     OR (OLD.q IS DISTINCT FROM NEW.q)
     OR (OLD.category_id IS DISTINCT FROM NEW.category_id)
     OR (OLD.mrr_ranges IS DISTINCT FROM NEW.mrr_ranges)
     OR (OLD.tech_stack IS DISTINCT FROM NEW.tech_stack)
     OR (OLD.countries IS DISTINCT FROM NEW.countries)
     OR (OLD.pricing_models IS DISTINCT FROM NEW.pricing_models)
     OR (OLD.looking_for IS DISTINCT FROM NEW.looking_for)
     OR (OLD.sort IS DISTINCT FROM NEW.sort)
     OR (OLD.email_notify IS DISTINCT FROM NEW.email_notify)
  THEN
    SELECT COALESCE(MAX(version_number), 0) + 1 INTO next_ver
      FROM public.saved_search_versions WHERE saved_search_id = OLD.id;
    INSERT INTO public.saved_search_versions (saved_search_id, user_id, version_number, snapshot)
    VALUES (OLD.id, OLD.user_id, next_ver, jsonb_build_object(
      'name', OLD.name,
      'q', OLD.q,
      'category_id', OLD.category_id,
      'mrr_ranges', OLD.mrr_ranges,
      'tech_stack', OLD.tech_stack,
      'countries', OLD.countries,
      'pricing_models', OLD.pricing_models,
      'looking_for', OLD.looking_for,
      'sort', OLD.sort,
      'email_notify', OLD.email_notify
    ));
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_saved_searches_snapshot ON public.saved_searches;
CREATE TRIGGER trg_saved_searches_snapshot
  BEFORE UPDATE ON public.saved_searches
  FOR EACH ROW EXECUTE FUNCTION public.saved_searches_snapshot_version();

-- 3. Explore preferences on profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS explore_preferences jsonb NOT NULL DEFAULT '{}'::jsonb;

-- Users can update their own explore_preferences (profiles already has policies; ensure self-update exists)
DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;
CREATE POLICY "Users update own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- 4. Audit log for bulk message actions
CREATE TABLE IF NOT EXISTS public.message_action_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  action text NOT NULL,
  thread_ids uuid[] NOT NULL DEFAULT '{}',
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_maa_user_created ON public.message_action_audit(user_id, created_at DESC);

GRANT SELECT, INSERT, DELETE ON public.message_action_audit TO authenticated;
GRANT ALL ON public.message_action_audit TO service_role;

ALTER TABLE public.message_action_audit ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users manage own message action audit" ON public.message_action_audit;
CREATE POLICY "Users manage own message action audit"
  ON public.message_action_audit FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
