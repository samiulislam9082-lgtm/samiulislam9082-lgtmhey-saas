
ALTER TABLE public.support_webhook_deliveries
  ADD COLUMN IF NOT EXISTS attempt_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_attempts integer NOT NULL DEFAULT 6,
  ADD COLUMN IF NOT EXISTS next_attempt_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_attempt_at timestamptz,
  ADD COLUMN IF NOT EXISTS payload jsonb,
  ADD COLUMN IF NOT EXISTS target text;

CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_next_attempt
  ON public.support_webhook_deliveries (next_attempt_at)
  WHERE status IN ('pending','retrying');
