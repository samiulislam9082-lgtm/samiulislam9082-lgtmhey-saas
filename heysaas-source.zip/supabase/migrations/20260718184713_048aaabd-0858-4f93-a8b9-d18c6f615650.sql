
-- 1. Storage: split attachments SELECT away from the shared images policy
DROP POLICY IF EXISTS "Auth read listing images" ON storage.objects;

CREATE POLICY "Auth read listing images"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = ANY (ARRAY['covers','logos','screenshots']));

CREATE POLICY "Owner read attachments"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'attachments'
  AND (storage.foldername(name))[1] = (auth.uid())::text
);

-- 2. interests: restrict SELECT to authenticated users
DROP POLICY IF EXISTS "Anyone views interest count" ON public.interests;
CREATE POLICY "Authenticated views interests"
ON public.interests FOR SELECT TO authenticated
USING (true);

-- 3. platform_config: admin-only reads
DROP POLICY IF EXISTS "Config readable by authenticated" ON public.platform_config;
CREATE POLICY "Config readable by admins"
ON public.platform_config FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- 4. newsletter_subscribers: replace with_check true with real validation
DROP POLICY IF EXISTS "Anyone subscribes" ON public.newsletter_subscribers;
CREATE POLICY "Anyone subscribes with valid email"
ON public.newsletter_subscribers FOR INSERT TO anon, authenticated
WITH CHECK (
  email IS NOT NULL
  AND char_length(email) BETWEEN 5 AND 254
  AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
);
