
ALTER TABLE public.support_tickets
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS attachment_path text,
  ADD COLUMN IF NOT EXISTS attachment_name text,
  ADD COLUMN IF NOT EXISTS attachment_size integer,
  ADD COLUMN IF NOT EXISTS attachment_mime text;

ALTER TABLE public.support_tickets
  DROP CONSTRAINT IF EXISTS support_tickets_priority_check;
ALTER TABLE public.support_tickets
  ADD CONSTRAINT support_tickets_priority_check
  CHECK (priority IN ('low','normal','high','urgent'));

-- Trigger: on new ticket, insert a notification for every admin
CREATE OR REPLACE FUNCTION public.notify_admins_new_ticket()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (user_id, type, title, body, link, metadata)
  SELECT ur.user_id,
         'support_ticket',
         'New support ticket: ' || NEW.subject,
         'From ' || NEW.name || ' <' || NEW.email || '> — priority ' || NEW.priority,
         '/dashboard/admin/support',
         jsonb_build_object(
           'ticket_id', NEW.id,
           'priority', NEW.priority,
           'source', NEW.source,
           'has_attachment', NEW.attachment_path IS NOT NULL
         )
    FROM public.user_roles ur
   WHERE ur.role = 'admin'::app_role;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS support_tickets_notify_admins ON public.support_tickets;
CREATE TRIGGER support_tickets_notify_admins
AFTER INSERT ON public.support_tickets
FOR EACH ROW EXECUTE FUNCTION public.notify_admins_new_ticket();

-- Storage policies for support-attachments bucket
DROP POLICY IF EXISTS "Anyone upload support attachments" ON storage.objects;
CREATE POLICY "Anyone upload support attachments"
ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (bucket_id = 'support-attachments');

DROP POLICY IF EXISTS "Admins read support attachments" ON storage.objects;
CREATE POLICY "Admins read support attachments"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'support-attachments' AND public.has_role(auth.uid(), 'admin'::app_role));
