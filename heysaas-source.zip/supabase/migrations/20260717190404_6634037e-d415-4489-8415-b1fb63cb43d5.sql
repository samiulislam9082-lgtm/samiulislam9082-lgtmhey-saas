
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS cover_url text,
  ADD COLUMN IF NOT EXISTS country text,
  ADD COLUMN IF NOT EXISTS linkedin_handle text,
  ADD COLUMN IF NOT EXISTS verified boolean NOT NULL DEFAULT false;

-- Only admins may flip the verified flag; regular users can update everything else about their own profile
-- via the existing "Users update own profile" policy, but that policy would also let them self-verify.
-- Replace it with a stricter version that forbids self-verification.
DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;

CREATE POLICY "Users update own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND verified = (SELECT verified FROM public.profiles WHERE id = auth.uid()));

CREATE POLICY "Admins update any profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Public founder-page lookup by username should be fast
CREATE INDEX IF NOT EXISTS profiles_username_idx ON public.profiles (username);
