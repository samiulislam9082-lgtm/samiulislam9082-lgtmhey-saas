
-- Storage policies for covers/logos/screenshots/attachments
-- Read: authenticated (signed URLs distribute wider); owner-scoped writes.
CREATE POLICY "Auth read listing images" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id IN ('covers','logos','screenshots','attachments'));

CREATE POLICY "Public read listing images" ON storage.objects FOR SELECT TO anon
  USING (bucket_id IN ('covers','logos','screenshots'));

CREATE POLICY "Owner upload listing images" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('covers','logos','screenshots','attachments')
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Owner update listing images" ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id IN ('covers','logos','screenshots','attachments')
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Owner delete listing images" ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id IN ('covers','logos','screenshots','attachments')
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
