-- 1) Limit anonymous (public) access to profiles to display-safe columns only
DROP POLICY IF EXISTS "Profiles are publicly viewable" ON public.profiles;

CREATE POLICY "Public can view display profile fields"
ON public.profiles FOR SELECT TO anon USING (true);

CREATE POLICY "Authenticated can view profiles"
ON public.profiles FOR SELECT TO authenticated USING (true);

REVOKE SELECT ON public.profiles FROM anon;
GRANT SELECT (
  id, username, display_name, avatar_url, bio, website_url,
  twitter_handle, github_handle, linkedin_handle, cover_url,
  verified, created_at, updated_at
) ON public.profiles TO anon;

-- 2) Admin motion snapshot policies should cover all users' rows
DROP POLICY IF EXISTS "Admins write their own motion snapshots" ON public.motion_probe_snapshots;
DROP POLICY IF EXISTS "Admins update their own motion snapshots" ON public.motion_probe_snapshots;
DROP POLICY IF EXISTS "Admins delete their own motion snapshots" ON public.motion_probe_snapshots;

CREATE POLICY "Admins insert motion snapshots"
ON public.motion_probe_snapshots FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update motion snapshots"
ON public.motion_probe_snapshots FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins delete motion snapshots"
ON public.motion_probe_snapshots FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));