ALTER TABLE public.saved_searches
  ADD COLUMN IF NOT EXISTS pricing_models text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS looking_for text[] NOT NULL DEFAULT '{}';