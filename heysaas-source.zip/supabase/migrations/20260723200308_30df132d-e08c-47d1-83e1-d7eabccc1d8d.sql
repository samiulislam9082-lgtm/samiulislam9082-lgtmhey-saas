
CREATE TABLE public.support_webhook_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel text NOT NULL CHECK (channel IN ('slack','teams')),
  kind text NOT NULL CHECK (kind IN ('ticket','alert','test')),
  status text NOT NULL CHECK (status IN ('sent','failed','not_configured')),
  http_status int,
  error text,
  ticket_id uuid,
  alert_id uuid,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_swd_created_at ON public.support_webhook_deliveries (created_at DESC);
CREATE INDEX idx_swd_channel ON public.support_webhook_deliveries (channel);
CREATE INDEX idx_swd_status ON public.support_webhook_deliveries (status);

GRANT SELECT ON public.support_webhook_deliveries TO authenticated;
GRANT ALL ON public.support_webhook_deliveries TO service_role;

ALTER TABLE public.support_webhook_deliveries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view webhook deliveries"
  ON public.support_webhook_deliveries FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
