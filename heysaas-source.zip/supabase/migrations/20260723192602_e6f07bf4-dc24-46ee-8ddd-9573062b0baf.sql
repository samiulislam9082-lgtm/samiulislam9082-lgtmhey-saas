
CREATE TABLE public.support_message_feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id TEXT NOT NULL,
  conversation_id UUID REFERENCES public.support_conversations(id) ON DELETE CASCADE,
  message_index INTEGER NOT NULL,
  message_excerpt TEXT,
  user_question TEXT,
  topic TEXT,
  rating TEXT NOT NULL CHECK (rating IN ('up','down')),
  reason TEXT,
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_support_feedback_conv ON public.support_message_feedback(conversation_id);
CREATE INDEX idx_support_feedback_session ON public.support_message_feedback(session_id);
CREATE INDEX idx_support_feedback_created ON public.support_message_feedback(created_at DESC);

GRANT SELECT, INSERT ON public.support_message_feedback TO authenticated;
GRANT INSERT ON public.support_message_feedback TO anon;
GRANT ALL ON public.support_message_feedback TO service_role;

ALTER TABLE public.support_message_feedback ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit feedback"
  ON public.support_message_feedback FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    length(coalesce(comment,'')) <= 2000
    AND length(coalesce(reason,'')) <= 100
  );

CREATE POLICY "Users can view their own feedback"
  ON public.support_message_feedback FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all feedback"
  ON public.support_message_feedback FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
