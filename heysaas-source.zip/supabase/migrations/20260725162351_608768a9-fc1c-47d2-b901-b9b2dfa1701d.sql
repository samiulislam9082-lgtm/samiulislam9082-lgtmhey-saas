
-- 1. Restrict public reads on SaaS listing images to files referenced by live listings
DROP POLICY IF EXISTS "Public read listing images" ON storage.objects;
CREATE POLICY "Public read live listing images"
ON storage.objects FOR SELECT
USING (
  bucket_id = ANY (ARRAY['covers'::text, 'logos'::text, 'screenshots'::text])
  AND EXISTS (
    SELECT 1 FROM public.saas_listings sl
    WHERE sl.status = 'live'
      AND (
        sl.logo_url = storage.objects.name
        OR sl.cover_url = storage.objects.name
        OR sl.screenshots ? storage.objects.name
      )
  )
);

-- 2. Restrict ws-listing-screenshots public reads to live & verified listings
DROP POLICY IF EXISTS "ws screenshots public read" ON storage.objects;
CREATE POLICY "ws screenshots public read live"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'ws-listing-screenshots'
  AND EXISTS (
    SELECT 1 FROM public.ws_listings wl
    WHERE wl.status = 'live'
      AND wl.ownership_verified = true
      AND storage.objects.name = ANY (wl.screenshots)
  )
);

-- 3. Support attachments: require authenticated user and folder-scoped ownership
DROP POLICY IF EXISTS "Anyone upload support attachments" ON storage.objects;
CREATE POLICY "Users upload own support attachments"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'support-attachments'
  AND (storage.foldername(name))[1] = (auth.uid())::text
);

-- 4. Lock down permissive INSERT on support_chat_events
DROP POLICY IF EXISTS "Anyone can insert support chat events" ON public.support_chat_events;
CREATE POLICY "Users insert own support chat events"
ON public.support_chat_events FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());
