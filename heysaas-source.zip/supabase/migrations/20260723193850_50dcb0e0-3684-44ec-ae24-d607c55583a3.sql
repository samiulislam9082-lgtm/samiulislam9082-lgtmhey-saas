
-- ============ TOPICS & RULES ============
CREATE TABLE IF NOT EXISTS public.support_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  label text NOT NULL,
  description text,
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 100,
  suggested_flow text NOT NULL DEFAULT 'chat',
  eta_hours integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.support_topics TO anon, authenticated;
GRANT ALL ON public.support_topics TO service_role;
GRANT INSERT, UPDATE, DELETE ON public.support_topics TO authenticated;
ALTER TABLE public.support_topics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "topics readable by all" ON public.support_topics FOR SELECT USING (active OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "topics admin write" ON public.support_topics FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER support_topics_updated_at BEFORE UPDATE ON public.support_topics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.support_topic_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_slug text NOT NULL REFERENCES public.support_topics(slug) ON DELETE CASCADE ON UPDATE CASCADE,
  pattern text NOT NULL,
  priority integer NOT NULL DEFAULT 100,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_topic_rules_topic ON public.support_topic_rules(topic_slug);
GRANT SELECT ON public.support_topic_rules TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.support_topic_rules TO authenticated;
GRANT ALL ON public.support_topic_rules TO service_role;
ALTER TABLE public.support_topic_rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "rules readable" ON public.support_topic_rules FOR SELECT USING (active OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "rules admin write" ON public.support_topic_rules FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER support_topic_rules_updated_at BEFORE UPDATE ON public.support_topic_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed default topics
INSERT INTO public.support_topics (slug, label, description, sort_order, suggested_flow, eta_hours) VALUES
  ('refunds','Refunds & billing disputes','Refund requests, chargebacks',10,'ticket',24),
  ('safety_fee','Safety fee ($19)','Questions about the $19 swap safety fee',20,'chat',null),
  ('swaps','Swaps & trades','Trading, matching, offers',30,'chat',null),
  ('listing','Listings & wizard','Creating or publishing listings',40,'chat',null),
  ('verification','Verification & KYC','Identity, LinkedIn, DNS verification',50,'ticket',12),
  ('payments','Payments & receipts','Stripe, invoices, receipts',60,'chat',null),
  ('messaging','Messaging & threads','Inbox, threads, notifications',70,'chat',null),
  ('account','Account & privacy','Delete account, GDPR export',80,'ticket',24),
  ('webswap','WebSwap','Website marketplace questions',90,'chat',null),
  ('pricing','Pricing & fees','Platform pricing questions',100,'chat',null),
  ('bug_report','Bug report','Something is broken',110,'ticket',12),
  ('other','Other','Anything else',999,'chat',null)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.support_topic_rules (topic_slug, pattern, priority) VALUES
  ('refunds','(refund|charge ?back|money back)',10),
  ('safety_fee','(safety fee|\$?19\s*(dollar|\$)?)',10),
  ('swaps','(swap|trade|exchange)',20),
  ('listing','(list|listing|wizard|publish|create)',30),
  ('verification','(verify|verification|dns|kyc|identity|linkedin)',20),
  ('payments','(pay|payment|stripe|invoice|receipt|billing)',30),
  ('messaging','(message|inbox|thread)',40),
  ('account','(delete account|remove account|close account|gdpr|export data)',20),
  ('webswap','(website|webswap|domain|traffic)',40),
  ('pricing','(price|pricing|cost|fee)',60),
  ('bug_report','(bug|error|broken|not working|crash|issue)',50)
ON CONFLICT DO NOTHING;

-- ============ TICKET LIFECYCLE ============
ALTER TABLE public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_status_check;
ALTER TABLE public.support_tickets ADD CONSTRAINT support_tickets_status_check CHECK (status IN ('new','open','pending','resolved'));

CREATE TABLE IF NOT EXISTS public.support_ticket_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES public.support_tickets(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  event_type text NOT NULL,
  from_status text,
  to_status text,
  note text,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_ticket_events_ticket ON public.support_ticket_events(ticket_id, created_at DESC);
GRANT SELECT, INSERT ON public.support_ticket_events TO authenticated;
GRANT ALL ON public.support_ticket_events TO service_role;
ALTER TABLE public.support_ticket_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ticket events viewable by owner/admin" ON public.support_ticket_events FOR SELECT TO authenticated USING (
  public.has_role(auth.uid(),'admin') OR EXISTS (
    SELECT 1 FROM public.support_tickets t WHERE t.id = ticket_id AND t.user_id = auth.uid()
  )
);
CREATE POLICY "ticket events admin insert" ON public.support_ticket_events FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin') AND actor_id = auth.uid());

-- Trigger: when ticket status changes, log event & notify submitter
CREATE OR REPLACE FUNCTION public.log_ticket_status_change() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF TG_OP='UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.support_ticket_events (ticket_id, actor_id, event_type, from_status, to_status)
    VALUES (NEW.id, auth.uid(), 'status_changed', OLD.status, NEW.status);
    IF NEW.user_id IS NOT NULL THEN
      INSERT INTO public.notifications (user_id, type, title, body, link, metadata)
      VALUES (NEW.user_id, 'ticket_update',
        'Your ticket is now ' || NEW.status,
        NEW.subject,
        '/dashboard/tickets/' || NEW.id,
        jsonb_build_object('ticket_id', NEW.id, 'status', NEW.status, 'previous', OLD.status));
    END IF;
  END IF;
  RETURN NEW;
END;$$;
DROP TRIGGER IF EXISTS support_tickets_status_log ON public.support_tickets;
CREATE TRIGGER support_tickets_status_log AFTER UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.log_ticket_status_change();

-- Trigger: log creation event
CREATE OR REPLACE FUNCTION public.log_ticket_created() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  INSERT INTO public.support_ticket_events (ticket_id, actor_id, event_type, to_status, note)
  VALUES (NEW.id, NEW.user_id, 'created', NEW.status, 'Ticket submitted');
  RETURN NEW;
END;$$;
DROP TRIGGER IF EXISTS support_tickets_created_log ON public.support_tickets;
CREATE TRIGGER support_tickets_created_log AFTER INSERT ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.log_ticket_created();

-- ============ FEEDBACK ENRICHMENT ============
ALTER TABLE public.support_message_feedback
  ADD COLUMN IF NOT EXISTS resolved_at timestamptz,
  ADD COLUMN IF NOT EXISTS resolved_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS is_report boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS report_explanation text,
  ADD COLUMN IF NOT EXISTS escalated_ticket_id uuid REFERENCES public.support_tickets(id) ON DELETE SET NULL;

DROP POLICY IF EXISTS "Admins can update feedback" ON public.support_message_feedback;
CREATE POLICY "Admins can update feedback" ON public.support_message_feedback FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
GRANT UPDATE ON public.support_message_feedback TO authenticated;

-- ============ ALERTS ============
CREATE TABLE IF NOT EXISTS public.support_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL,
  count integer NOT NULL,
  threshold integer NOT NULL,
  window_minutes integer NOT NULL,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  acknowledged_at timestamptz,
  acknowledged_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_alerts_created ON public.support_alerts(created_at DESC);
GRANT SELECT, UPDATE ON public.support_alerts TO authenticated;
GRANT ALL ON public.support_alerts TO service_role;
ALTER TABLE public.support_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "alerts admin read" ON public.support_alerts FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "alerts admin update" ON public.support_alerts FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Seed default threshold config
INSERT INTO public.platform_config (key, value) VALUES
  ('support_alert_threshold', jsonb_build_object('errors', 5, 'window_minutes', 10, 'cooldown_minutes', 30))
ON CONFLICT (key) DO NOTHING;

-- Alert check function: called periodically
CREATE OR REPLACE FUNCTION public.check_support_error_threshold() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE
  cfg jsonb;
  thr int;
  win int;
  cool int;
  err_count int;
  last_alert timestamptz;
  alert_id uuid;
BEGIN
  SELECT value INTO cfg FROM public.platform_config WHERE key='support_alert_threshold';
  IF cfg IS NULL THEN RETURN; END IF;
  thr := COALESCE((cfg->>'errors')::int, 5);
  win := COALESCE((cfg->>'window_minutes')::int, 10);
  cool := COALESCE((cfg->>'cooldown_minutes')::int, 30);

  SELECT count(*) INTO err_count FROM public.support_chat_events
    WHERE event_type='chat_error'
      AND error_code IN ('rate_limited','credits_exhausted')
      AND created_at > now() - (win || ' minutes')::interval;

  IF err_count < thr THEN RETURN; END IF;

  SELECT created_at INTO last_alert FROM public.support_alerts
    WHERE kind='error_spike' ORDER BY created_at DESC LIMIT 1;
  IF last_alert IS NOT NULL AND last_alert > now() - (cool || ' minutes')::interval THEN RETURN; END IF;

  INSERT INTO public.support_alerts (kind, count, threshold, window_minutes, meta)
  VALUES ('error_spike', err_count, thr, win, jsonb_build_object('cooldown_minutes', cool))
  RETURNING id INTO alert_id;

  INSERT INTO public.notifications (user_id, type, title, body, link, metadata)
  SELECT ur.user_id, 'support_alert',
    'Support error spike: ' || err_count || ' errors in ' || win || ' min',
    'Rate-limit or credit errors exceeded threshold (' || thr || '). Review recent chats.',
    '/dashboard/admin/support',
    jsonb_build_object('alert_id', alert_id, 'count', err_count, 'threshold', thr, 'window_minutes', win)
  FROM public.user_roles ur WHERE ur.role='admin';
END;$$;
GRANT EXECUTE ON FUNCTION public.check_support_error_threshold() TO authenticated;

-- Schedule via pg_cron (every 5 min)
CREATE EXTENSION IF NOT EXISTS pg_cron;
DO $$ BEGIN
  PERFORM cron.unschedule('support-error-threshold-check');
EXCEPTION WHEN OTHERS THEN NULL; END $$;
SELECT cron.schedule('support-error-threshold-check','*/5 * * * *', $$SELECT public.check_support_error_threshold();$$);

-- ============ RATE LIMIT HELPERS FOR TICKETS ============
-- rate_limits table already exists; we'll use it from application code.
