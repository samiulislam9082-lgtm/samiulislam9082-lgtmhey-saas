
ALTER TABLE public.ws_messages
  ADD COLUMN IF NOT EXISTS edited_at timestamptz,
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz,
  ADD COLUMN IF NOT EXISTS reply_to_id uuid REFERENCES public.ws_messages(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'text',
  ADD COLUMN IF NOT EXISTS client_flags jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE INDEX IF NOT EXISTS ws_messages_reply_to_idx ON public.ws_messages(reply_to_id);
CREATE INDEX IF NOT EXISTS ws_messages_body_fts_idx
  ON public.ws_messages USING gin (to_tsvector('simple', coalesce(body,'')));

ALTER TABLE public.ws_threads
  ADD COLUMN IF NOT EXISTS buyer_last_read_at timestamptz,
  ADD COLUMN IF NOT EXISTS seller_last_read_at timestamptz,
  ADD COLUMN IF NOT EXISTS buyer_muted boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS seller_muted boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS public.ws_message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES public.ws_messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  emoji text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (message_id, user_id, emoji)
);
GRANT SELECT, INSERT, DELETE ON public.ws_message_reactions TO authenticated;
GRANT ALL ON public.ws_message_reactions TO service_role;
ALTER TABLE public.ws_message_reactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws_reactions participants read" ON public.ws_message_reactions
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.ws_messages m
    JOIN public.ws_threads t ON t.id = m.thread_id
    WHERE m.id = ws_message_reactions.message_id
      AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
  ));
CREATE POLICY "ws_reactions self insert" ON public.ws_message_reactions
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.ws_messages m
      JOIN public.ws_threads t ON t.id = m.thread_id
      WHERE m.id = ws_message_reactions.message_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
  );
CREATE POLICY "ws_reactions self delete" ON public.ws_message_reactions
  FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.ws_message_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES public.ws_messages(id) ON DELETE CASCADE,
  thread_id uuid NOT NULL REFERENCES public.ws_threads(id) ON DELETE CASCADE,
  uploader_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  mime text NOT NULL,
  size integer NOT NULL,
  width integer,
  height integer,
  kind text NOT NULL DEFAULT 'file',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ws_attachments_message_idx ON public.ws_message_attachments(message_id);
GRANT SELECT, INSERT, DELETE ON public.ws_message_attachments TO authenticated;
GRANT ALL ON public.ws_message_attachments TO service_role;
ALTER TABLE public.ws_message_attachments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws_attach participants read" ON public.ws_message_attachments
  FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.ws_threads t
    WHERE t.id = ws_message_attachments.thread_id
      AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
  ));
CREATE POLICY "ws_attach uploader insert" ON public.ws_message_attachments
  FOR INSERT TO authenticated
  WITH CHECK (
    uploader_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.ws_threads t
      WHERE t.id = ws_message_attachments.thread_id
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
  );
CREATE POLICY "ws_attach uploader delete" ON public.ws_message_attachments
  FOR DELETE TO authenticated USING (uploader_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.ws_link_previews (
  url text PRIMARY KEY,
  title text,
  description text,
  image_url text,
  site_name text,
  fetched_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ws_link_previews TO authenticated;
GRANT ALL ON public.ws_link_previews TO service_role;
ALTER TABLE public.ws_link_previews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws_link_previews read" ON public.ws_link_previews
  FOR SELECT TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS public.ws_thread_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.ws_threads(id) ON DELETE CASCADE,
  reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reported_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  message_id uuid REFERENCES public.ws_messages(id) ON DELETE SET NULL,
  reason text NOT NULL,
  details text,
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.ws_thread_reports TO authenticated;
GRANT ALL ON public.ws_thread_reports TO service_role;
ALTER TABLE public.ws_thread_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws_reports reporter insert" ON public.ws_thread_reports
  FOR INSERT TO authenticated WITH CHECK (reporter_id = auth.uid());
CREATE POLICY "ws_reports reporter or admin read" ON public.ws_thread_reports
  FOR SELECT TO authenticated
  USING (reporter_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "ws_reports admin update" ON public.ws_thread_reports
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE IF NOT EXISTS public.ws_rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bucket text NOT NULL,
  count integer NOT NULL DEFAULT 0,
  window_start timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, bucket)
);
GRANT ALL ON public.ws_rate_limits TO service_role;
ALTER TABLE public.ws_rate_limits ENABLE ROW LEVEL SECURITY;

ALTER PUBLICATION supabase_realtime ADD TABLE public.ws_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.ws_threads;
ALTER PUBLICATION supabase_realtime ADD TABLE public.ws_message_reactions;

DROP POLICY IF EXISTS "ws_messages sender update" ON public.ws_messages;
CREATE POLICY "ws_messages sender update" ON public.ws_messages
  FOR UPDATE TO authenticated
  USING (sender_id = auth.uid())
  WITH CHECK (sender_id = auth.uid());

DROP POLICY IF EXISTS "ws attach participants read" ON storage.objects;
CREATE POLICY "ws attach participants read" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'ws-message-attachments'
    AND EXISTS (
      SELECT 1 FROM public.ws_threads t
      WHERE t.id::text = split_part(name, '/', 1)
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "ws attach participants insert" ON storage.objects;
CREATE POLICY "ws attach participants insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'ws-message-attachments'
    AND EXISTS (
      SELECT 1 FROM public.ws_threads t
      WHERE t.id::text = split_part(name, '/', 1)
        AND (t.buyer_id = auth.uid() OR t.seller_id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "ws attach uploader delete" ON storage.objects;
CREATE POLICY "ws attach uploader delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'ws-message-attachments'
    AND owner = auth.uid()
  );
