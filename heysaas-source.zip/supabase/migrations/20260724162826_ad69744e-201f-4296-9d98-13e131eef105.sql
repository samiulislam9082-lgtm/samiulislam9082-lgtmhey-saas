CREATE TABLE public.motion_probe_snapshots (
  id text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ran_at timestamptz NOT NULL,
  pathname text NOT NULL,
  selector text NOT NULL,
  kind text NOT NULL,
  total integer NOT NULL,
  rows jsonb NOT NULL DEFAULT '[]'::jsonb,
  device_label text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.motion_probe_snapshots TO authenticated;
GRANT ALL ON public.motion_probe_snapshots TO service_role;

ALTER TABLE public.motion_probe_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read all motion snapshots"
  ON public.motion_probe_snapshots FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins write their own motion snapshots"
  ON public.motion_probe_snapshots FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update their own motion snapshots"
  ON public.motion_probe_snapshots FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (auth.uid() = user_id AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins delete their own motion snapshots"
  ON public.motion_probe_snapshots FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX motion_probe_snapshots_user_ran_at_idx
  ON public.motion_probe_snapshots (user_id, ran_at DESC);
