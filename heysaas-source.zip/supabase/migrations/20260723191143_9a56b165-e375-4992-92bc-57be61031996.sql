
CREATE TABLE public.support_chat_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  session_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  topic TEXT,
  message TEXT,
  error_code TEXT,
  status INT,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX support_chat_events_session_idx ON public.support_chat_events (session_id, created_at);
CREATE INDEX support_chat_events_type_idx ON public.support_chat_events (event_type, created_at DESC);
CREATE INDEX support_chat_events_error_idx ON public.support_chat_events (error_code) WHERE error_code IS NOT NULL;

GRANT INSERT ON public.support_chat_events TO anon, authenticated;
GRANT SELECT ON public.support_chat_events TO authenticated;
GRANT ALL ON public.support_chat_events TO service_role;

ALTER TABLE public.support_chat_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert support chat events"
  ON public.support_chat_events FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Admins can read all support chat events"
  ON public.support_chat_events FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
