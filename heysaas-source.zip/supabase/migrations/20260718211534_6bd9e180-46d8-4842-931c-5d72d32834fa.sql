DROP POLICY IF EXISTS "ws_profile_ext public read" ON public.ws_profile_extensions;
DROP POLICY IF EXISTS "Follows publicly readable" ON public.follows;
CREATE POLICY "Follows readable by authenticated" ON public.follows FOR SELECT TO authenticated USING (true);