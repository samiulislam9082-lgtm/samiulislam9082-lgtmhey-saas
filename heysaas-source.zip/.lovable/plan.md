
# HeySaaS — 9-Part Polish & Fix Plan

Grouped by your numbered items. I'll ship them in this order because later items depend on earlier ones (theme lock before UI polish, search wiring before UI polish).

---

## 1. Sign-in / Sign-up page (`/auth`)
Make it a real marketing surface on desktop, lean on mobile.

- **Desktop (≥ lg)**: split-screen. Left = auth form (email/password + Google). Right = editorial panel with:
  - Rotating platform highlights (Verified founders, $19 flat safety fee, No brokers, Real swaps closed)
  - Live counters pulled from DB (listings live, swaps completed, founders verified)
  - Testimonial quote + avatar strip
  - Abyssal Teal gradient background, soft grain, orbital glow
- **Mobile (< lg)**: single column, form-first. Marketing collapses to a compact 3-item trust row above the form. No heavy animation, no counters query on mobile to keep it fast.
- Google button gets official logo chip treatment; email form gets floating labels + inline validation.
- Same visual system on `/reset-password`.

## 2. Hero icon grid fix (landing)
Only the floating background icon tiles — nothing else on the hero changes.

- Replace every tile with a real, recognizable SaaS/tool SVG (GitHub, Discord, Notion, Zapier, Figma, Linear, Slack, Stripe, Vercel, Supabase, Framer, Loom, Cal, Raycast, Arc, Perplexity — ~16 icons, no blanks).
- Bump tile size ~15% (from ~44px to ~52px), icon glyph ~20px.
- Keep scatter layout, keep edge-blur / center-sharp falloff, keep teal glow + dark glassy tile.
- Ensure z-index stays behind headline and Swap Proposal card.

## 3. Messages redesign (Messenger-style)
Applies to `/dashboard/messages` and `/websites/dashboard/messages/*`.

- Remove the two separate action strips. Consolidate into **one 3-dot menu** per thread (mobile) and per header (desktop) containing: mute, block/unblock, report, view profile, clear chat, notification toggle.
- Chat header: avatar + name + presence dot + "Active now / Last seen X". Right side = single 3-dot menu only.
- Add a **gear icon** in the thread list header opening a small settings sheet:
  - Appear online toggle (persists to profile)
  - Blocked users count + "Manage blocked" link
  - Read receipts toggle
  - Sound / desktop notifications toggle
- Typing indicator: fix throttle so it clears immediately on send and after 3s idle; show "Name is typing" in list, animated dots in thread.
- Message send: optimistic bubble + status ticks (sending → sent → delivered → read).
- Consistent bubble spacing, tail rounding, and reduced icon-button clutter around the composer.

## 4. Desktop/Mobile parity
Same information architecture on both, adapted layout — not a stripped mobile.

- Audit every dashboard route: replace `hidden md:block` content-hiding with responsive reflow (stack, collapse into tabs, or drawer).
- Standardize the responsive header pattern from the docs: `grid-cols-[minmax(0,1fr)_auto]` on mobile, `flex` at `sm:`, `min-w-0` + `truncate` everywhere.
- Sidebar becomes a bottom-sheet drawer on mobile with the same items.
- Tables get card-stack fallback under `md`.

## 5. My SaaS + Swaps cards
Stop the "click makes the whole thing huge" behavior.

- Convert current expanding accordion cards into **fixed-height summary cards** showing: cover, title, key stat (MRR / status), 2 action buttons.
- Click on a card = navigate to detail route, not inline expand.
- Buttons on the card do their action inline (Publish / Pause / Message) without changing card size.

## 6. Dark mode only
Remove theme toggle entirely.

- Delete `ThemeToggle` usages and force `dark` class on `<html>`.
- Strip light-mode CSS variables from `src/styles.css` (keep only the `.dark` / `:root` dark tokens).
- Remove `next-themes`-style provider if present. No user setting, no system preference — always dark.

## 7. Security hardening pass
Run the scanner + manual RLS review, fix everything, no user permissions required.

- Run `security--run_security_scan`, resolve every finding (RLS gaps, exposed columns, missing GRANTs, storage policies).
- Enable HIBP leaked-password check on auth.
- Re-audit `profiles`, `ws_*`, `saas_*`, `messages`, `notifications`, `support_*` tables — every table gets: RLS on, explicit policies, GRANTs matched to policies, `auth.uid()` scoping.
- Storage buckets: verify per-folder `auth.uid()` prefix policies for `avatars`, `attachments`, `message-media`, `ws-message-attachments`, `support-attachments`.
- Add rate limiting to public-facing server functions (message send, report, listing create).
- CSP + security headers in `public/_headers`.

## 8. Global search
Currently non-functional. Rebuild as a real search.

- New `wsGlobalSearch` server function: searches across profiles (username, display_name), `saas_listings`, `ws_listings`, and help/support topics. Uses existing `search_tsv` where present, `ilike` fallback for usernames.
- Wire into the `CommandPalette` (⌘K) and into the search input in the header/notification page you described.
- Results grouped: **People**, **SaaS listings**, **Websites**, **Help articles**. Each result clickable to its canonical route (`/@username`, `/saas/$slug`, `/websites/$id`, `/how-it-works#anchor`).
- Empty state + keyboard nav (↑↓ Enter Esc).
- Debounced 200ms, capped 8 per group.

## 9. Image reference audit
I'll re-open the attached image set and cross-check every fix above against them before shipping, so numbers, labels, and icons in the final UI match what you showed.

---

## Technical notes

- No new dependencies expected except a small SVG icon set (inlined, not a package) for the hero grid.
- All migrations gated through the migration tool with GRANTs.
- `MessageComposer` and `dashboard.messages.tsx` will be refactored, not rewritten — preserving voice/attachment/reactions logic already built.
- Theme removal touches `src/styles.css`, `src/routes/__root.tsx`, and any `ThemeToggle` imports.
- Security fixes will be applied as SQL migrations + policy edits; findings marked fixed via `security--manage_security_finding` only after verification.

## Order of execution

1. #6 Dark-mode lock (unblocks visual work)
2. #7 Security scan + fixes (parallel with UI)
3. #2 Hero icon grid
4. #1 Auth pages
5. #5 My SaaS / Swaps cards
6. #3 Messages redesign
7. #8 Global search
8. #4 Responsive parity sweep
9. #9 Final image cross-check

Approve and I'll start at #6.
