#!/usr/bin/env python3
"""
Full SEO CI audit — combines four checks and emits an HTML report:

  1. robots.txt & sitemap.xml — reachability (HTTP 200), cross-reference,
     conflicting Allow/Disallow rules, redirect chains/loops, sitemap URLs
     resolvable and not blocked by robots.
  2. Canonical + hreflang — per public page: single canonical, absolute
     URL, self-reference sanity, hreflang bidirectionality when present.
  3. Open Graph / Twitter — title/description/image presence and
     title↔og:title / description↔og:description consistency.
  4. JSON-LD — reuses validators from seo-jsonld-validate.py.

Writes /tmp/seo-report/report.html and prints a summary. Exit 1 on any
ERROR-level finding.

Usage:
    python scripts/ci/seo-audit-report.py
    BASE_URL=https://heysaas.lovable.app python scripts/ci/seo-audit-report.py
"""
from __future__ import annotations

import asyncio, html, json, os, re, sys, urllib.parse, importlib.util
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse, urljoin

import requests
from playwright.async_api import async_playwright

BASE_URL = os.environ.get("BASE_URL", "https://heysaas.lovable.app").rstrip("/")
OUT_DIR = Path(os.environ.get("REPORT_DIR", "/tmp/seo-report"))
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Reuse JSON-LD validators from the sibling script.
_here = Path(__file__).parent
spec = importlib.util.spec_from_file_location("jsonld_v", _here / "seo-jsonld-validate.py")
jsonld_v = importlib.util.module_from_spec(spec); spec.loader.exec_module(jsonld_v)  # type: ignore

ROUTES = ["/", "/how-it-works", "/about", "/pricing", "/websites",
          "/explore", "/leaderboard", "/blog", "/compare", "/status",
          "/legal/terms", "/legal/privacy"]

RED = "\033[31m"; YEL = "\033[33m"; GRN = "\033[32m"; DIM = "\033[2m"; RST = "\033[0m"


@dataclass
class Finding:
    severity: str        # ERROR | WARNING | INFO
    category: str
    where: str
    message: str
    fix: str = ""


@dataclass
class Report:
    findings: list[Finding] = field(default_factory=list)

    def add(self, sev, cat, where, msg, fix=""):
        self.findings.append(Finding(sev, cat, where, msg, fix))

    def by_sev(self, s): return [f for f in self.findings if f.severity == s]


# ---------- 1. robots.txt & sitemap.xml -----------------------------------

def follow(url, max_hops=5):
    """Return (final_response, [status codes], loop_detected)."""
    chain, seen = [], set()
    for _ in range(max_hops):
        if url in seen:
            return None, chain, True
        seen.add(url)
        r = requests.get(url, allow_redirects=False, timeout=15)
        chain.append((url, r.status_code))
        if r.is_redirect or r.status_code in (301, 302, 303, 307, 308):
            loc = r.headers.get("Location")
            if not loc: return r, chain, False
            url = urljoin(url, loc); continue
        return r, chain, False
    return None, chain, True  # exceeded hops


def parse_robots(txt: str):
    """Return list of (agent, [ (rule, path) ]) and list of sitemap URLs."""
    groups, current_agents, current, sitemaps = [], [], [], []
    for raw in txt.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line: continue
        if ":" not in line: continue
        k, v = [s.strip() for s in line.split(":", 1)]
        kl = k.lower()
        if kl == "user-agent":
            if current and current_agents:
                for a in current_agents: groups.append((a, list(current)))
                current = []
            current_agents = current_agents + [v] if current else [v]
            if not current: current_agents = [v]
            # simpler: reset if previous group flushed
        elif kl in ("allow", "disallow"):
            current.append((kl, v))
        elif kl == "sitemap":
            sitemaps.append(v)
    if current and current_agents:
        for a in current_agents: groups.append((a, list(current)))
    return groups, sitemaps


def robots_allows(rules: list[tuple[str, str]], path: str) -> bool:
    """Longest-match wins; Allow beats Disallow on tie (Google behaviour)."""
    best = ("allow", "")
    for rule, pat in rules:
        if not pat: continue
        # convert robots pattern (with * and $) to regex
        rx = "^" + re.escape(pat).replace(r"\*", ".*")
        if pat.endswith("$"): rx = rx[:-2] + "$"
        if re.match(rx, path):
            if len(pat) > len(best[1]) or (len(pat) == len(best[1]) and rule == "allow"):
                best = (rule, pat)
    return best[0] == "allow"


def check_robots_sitemap(rep: Report):
    r_url, s_url = f"{BASE_URL}/robots.txt", f"{BASE_URL}/sitemap.xml"

    # robots.txt
    r_resp, r_chain, r_loop = follow(r_url)
    if r_loop:
        rep.add("ERROR", "robots", r_url, f"redirect loop: {r_chain}",
                "Point /robots.txt at a terminal 200 response.")
        return
    if not r_resp or r_resp.status_code != 200:
        rep.add("ERROR", "robots", r_url,
                f"HTTP {r_resp.status_code if r_resp else 'no-response'}",
                "Serve /robots.txt with HTTP 200 from the app root.")
        return
    rep.add("INFO", "robots", r_url, f"200 OK ({len(r_resp.text)} bytes)")
    groups, sitemaps = parse_robots(r_resp.text)

    star_rules = [rules for a, rules in groups if a == "*"]
    star = star_rules[0] if star_rules else []

    # sitewide block
    if any(rule == "disallow" and pat == "/" for rule, pat in star):
        rep.add("ERROR", "robots", r_url, "`Disallow: /` under User-agent: * blocks the entire site",
                "Remove the wildcard Disallow: / rule.")

    # sitemap directive present + matches expected. When auditing a non-production
    # origin (e.g. localhost preview), the committed robots.txt correctly points
    # at the production sitemap, so a URL mismatch is expected — downgrade to INFO.
    is_local = urlparse(BASE_URL).hostname in {"localhost", "127.0.0.1", "0.0.0.0"}
    if not sitemaps:
        rep.add("WARNING", "robots", r_url, "no `Sitemap:` directive",
                f"Add `Sitemap: {s_url}` to robots.txt.")
    elif s_url not in sitemaps:
        level = "INFO" if is_local else "WARNING"
        rep.add(level, "robots", r_url,
                f"Sitemap directive `{sitemaps[0]}` does not match {s_url}"
                + (" (expected for local audit)" if is_local else ""),
                f"Update the Sitemap: directive to {s_url}." if not is_local else "")


    # sitemap.xml
    s_resp, s_chain, s_loop = follow(s_url)
    if s_loop:
        rep.add("ERROR", "sitemap", s_url, f"redirect loop: {s_chain}", "")
        return
    if not s_resp or s_resp.status_code != 200:
        rep.add("ERROR", "sitemap", s_url,
                f"HTTP {s_resp.status_code if s_resp else 'no-response'}", "")
        return
    ct = (s_resp.headers.get("Content-Type") or "").lower()
    if "xml" not in ct:
        rep.add("WARNING", "sitemap", s_url,
                f"Content-Type `{ct}` is not XML",
                "Serve sitemap.xml with Content-Type: application/xml.")

    # extract locs and cross-check against robots
    locs = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", s_resp.text)
    if not locs:
        rep.add("ERROR", "sitemap", s_url, "sitemap contains no <loc> entries", "")
        return
    rep.add("INFO", "sitemap", s_url, f"200 OK, {len(locs)} URLs")

    dups = {u for u in locs if locs.count(u) > 1}
    for d in dups:
        rep.add("WARNING", "sitemap", d, "duplicate <loc> entry",
                "Deduplicate entries when generating the sitemap.")

    # each URL: robots-allowed, resolves, no redirect loop
    for loc in locs[:60]:  # cap for CI speed
        p = urlparse(loc).path or "/"
        if star and not robots_allows(star, p):
            rep.add("ERROR", "sitemap", loc,
                    "URL is disallowed by robots.txt yet listed in sitemap",
                    f"Either remove {p} from the sitemap or unblock it in robots.txt.")
        # HEAD-follow local URLs only to keep CI fast
        if urlparse(loc).netloc == urlparse(BASE_URL).netloc or loc.startswith(BASE_URL):
            check_url = loc.replace("https://heysaas.lovable.app", BASE_URL)
            try:
                resp, chain, loop = follow(check_url)
                if loop:
                    rep.add("ERROR", "sitemap", loc, f"redirect loop: {chain}", "")
                elif not resp or resp.status_code >= 400:
                    rep.add("ERROR", "sitemap", loc,
                            f"HTTP {resp.status_code if resp else 'no-response'}",
                            "Remove dead URL from sitemap or fix the route.")
            except Exception as e:
                rep.add("WARNING", "sitemap", loc, f"request failed: {e}", "")


# ---------- 2/3. per-page head audit --------------------------------------

async def audit_pages(rep: Report):
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context(viewport={"width": 1280, "height": 1800})
        page = await ctx.new_page()

        canonicals: dict[str, str] = {}
        hreflang_map: dict[str, dict[str, str]] = {}  # page -> {lang: href}

        for path in ROUTES:
            url = BASE_URL + path
            try:
                resp = await page.goto(url, wait_until="domcontentloaded", timeout=25000)
            except Exception as e:
                rep.add("ERROR", "page", url, f"navigation failed: {e}", "")
                continue
            if not resp or resp.status >= 400:
                rep.add("ERROR", "page", url,
                        f"HTTP {resp.status if resp else 'no-response'}", "")
                continue

            data = await page.evaluate("""() => ({
              title: document.title || '',
              desc: (document.querySelector('meta[name=description]') || {}).content || '',
              canon: Array.from(document.querySelectorAll('link[rel=canonical]')).map(l => l.href),
              hreflang: Array.from(document.querySelectorAll('link[rel=alternate][hreflang]'))
                        .map(l => ({ lang: l.hreflang, href: l.href })),
              og: Object.fromEntries(Array.from(document.querySelectorAll('meta[property^="og:"]'))
                    .map(m => [m.getAttribute('property'), m.content])),
              tw: Object.fromEntries(Array.from(document.querySelectorAll('meta[name^="twitter:"]'))
                    .map(m => [m.getAttribute('name'), m.content])),
              jsonld: Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
                        .map(s => s.textContent || ''),
            })""")

            # --- canonical ---
            if len(data["canon"]) == 0:
                rep.add("WARNING", "canonical", url, "no <link rel=canonical>",
                        "Add a self-referencing canonical in the route head().")
            elif len(data["canon"]) > 1:
                rep.add("ERROR", "canonical", url,
                        f"multiple canonicals: {data['canon']}",
                        "Emit exactly one canonical per page; move canonical off __root.")
            else:
                c = data["canon"][0]
                canonicals[path] = c
                if not c.startswith(("http://", "https://")):
                    rep.add("ERROR", "canonical", url, f"canonical `{c}` is not absolute",
                            "Use an absolute URL in canonical.")
                elif urlparse(c).path.rstrip("/") != path.rstrip("/") and path != "/":
                    rep.add("WARNING", "canonical", url,
                            f"canonical points to {urlparse(c).path} rather than {path}",
                            "Point canonical at the page's own URL.")

            # --- hreflang collect ---
            if data["hreflang"]:
                hreflang_map[path] = {h["lang"]: h["href"] for h in data["hreflang"]}
                if "x-default" not in hreflang_map[path]:
                    rep.add("WARNING", "hreflang", url,
                            "hreflang set present but missing `x-default`",
                            "Add <link rel=alternate hreflang=\"x-default\" ...>.")

            # --- OG ---
            og = data["og"]; tw = data["tw"]
            for req in ("og:title", "og:description", "og:type", "og:url"):
                if not og.get(req):
                    rep.add("WARNING", "og", url, f"missing {req}",
                            f"Add {req} in the route head().")
            if og.get("og:image") and not og["og:image"].startswith(("http://", "https://")):
                rep.add("ERROR", "og", url,
                        f"og:image `{og['og:image']}` is not absolute",
                        "Use an absolute https URL for og:image.")
            if og.get("og:title") and data["title"] and og["og:title"] != data["title"]:
                rep.add("WARNING", "og", url,
                        f"og:title `{og['og:title']}` differs from <title> `{data['title']}`",
                        "Keep og:title and <title> in sync.")
            if og.get("og:description") and data["desc"] and og["og:description"] != data["desc"]:
                rep.add("WARNING", "og", url,
                        "og:description differs from meta description",
                        "Keep og:description and meta description in sync.")

            # --- Twitter ---
            if not tw.get("twitter:card"):
                rep.add("WARNING", "twitter", url, "missing twitter:card",
                        "Add <meta name=twitter:card content=\"summary_large_image\">.")
            for name, og_name in (("twitter:title", "og:title"),
                                  ("twitter:description", "og:description"),
                                  ("twitter:image", "og:image")):
                if tw.get(name) and og.get(og_name) and tw[name] != og[og_name]:
                    rep.add("WARNING", "twitter", url,
                            f"{name} differs from {og_name}",
                            f"Align {name} with {og_name}, or omit and let OG serve as fallback.")

            # --- JSON-LD via shared validators ---
            for i, raw in enumerate(data["jsonld"], 1):
                try: parsed = json.loads(raw)
                except json.JSONDecodeError as e:
                    rep.add("ERROR", "jsonld", url, f"block #{i} invalid JSON: {e}",
                            "Ensure JSON.stringify() output for JSON-LD.")
                    continue
                for node in jsonld_v.walk_graph(parsed):
                    types = jsonld_v.as_list(node.get("@type"))
                    for t in types:
                        v = jsonld_v.VALIDATORS.get(t)
                        if not v: continue
                        for sev, msg in v(node):
                            rep.add(sev, "jsonld", f"{url} ({t})", msg, "")

        await browser.close()

        # --- hreflang bidirectionality ---
        for path, m in hreflang_map.items():
            for lang, href in m.items():
                if lang == "x-default": continue
                # href must exist and, if it is another audited page, link back
                other_path = urlparse(href).path
                if other_path in hreflang_map:
                    if path not in [urlparse(h).path for h in hreflang_map[other_path].values()]:
                        rep.add("ERROR", "hreflang", BASE_URL + path,
                                f"hreflang `{lang}` → {other_path} is not reciprocated",
                                f"Add a reciprocal hreflang from {other_path} back to {path}.")


# ---------- HTML report ---------------------------------------------------

def render_html(rep: Report) -> str:
    errs, warns, infos = rep.by_sev("ERROR"), rep.by_sev("WARNING"), rep.by_sev("INFO")
    def rows(items):
        if not items:
            return '<tr><td colspan="4" class="dim">— none —</td></tr>'
        return "\n".join(
            f'<tr class="{f.severity.lower()}"><td>{html.escape(f.category)}</td>'
            f'<td class="mono">{html.escape(f.where)}</td>'
            f'<td>{html.escape(f.message)}</td>'
            f'<td class="fix">{html.escape(f.fix)}</td></tr>' for f in items)
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>SEO CI Report — {html.escape(BASE_URL)}</title>
<style>
:root{{--bg:#08131a;--panel:#0d1f2b;--fg:#e6f4f1;--dim:#6b8a8a;--teal:#5cbdb9;--gold:#e0b256;--red:#e5484d;--yel:#f5a524;--grn:#30a46c}}
*{{box-sizing:border-box}}body{{margin:0;font-family:ui-sans-serif,system-ui;background:var(--bg);color:var(--fg);padding:32px}}
h1{{font-family:'Instrument Serif',serif;font-weight:400;font-size:36px;margin:0 0 4px}}
h2{{font-size:18px;margin:32px 0 12px;letter-spacing:.02em;text-transform:uppercase;color:var(--teal)}}
.meta{{color:var(--dim);font-size:13px;margin-bottom:24px}}
.cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px}}
.card{{background:var(--panel);border:1px solid #123;padding:16px;border-radius:10px}}
.card .n{{font-size:32px;font-family:'Instrument Serif',serif}}
.card.err .n{{color:var(--red)}}.card.warn .n{{color:var(--yel)}}.card.ok .n{{color:var(--grn)}}
table{{width:100%;border-collapse:collapse;background:var(--panel);border-radius:10px;overflow:hidden;font-size:13px}}
th,td{{padding:10px 12px;text-align:left;vertical-align:top;border-bottom:1px solid #0b1a24}}
th{{background:#0a1a24;color:var(--dim);font-weight:500;text-transform:uppercase;font-size:11px;letter-spacing:.06em}}
tr.error td:first-child{{border-left:3px solid var(--red)}}
tr.warning td:first-child{{border-left:3px solid var(--yel)}}
tr.info td:first-child{{border-left:3px solid var(--teal)}}
.mono{{font-family:ui-monospace,monospace;color:var(--teal);word-break:break-all}}
.fix{{color:var(--gold);font-style:italic}}
.dim{{color:var(--dim);text-align:center;padding:24px}}
</style></head>
<body>
<h1>SEO CI Report</h1>
<div class="meta">Base URL <span class="mono">{html.escape(BASE_URL)}</span> · Routes {len(ROUTES)} · Findings {len(rep.findings)}</div>
<div class="cards">
  <div class="card err"><div class="n">{len(errs)}</div>Errors — must fix</div>
  <div class="card warn"><div class="n">{len(warns)}</div>Warnings — recommended</div>
  <div class="card ok"><div class="n">{len(infos)}</div>Info — passing checks</div>
</div>
<h2>Errors</h2><table><thead><tr><th>Category</th><th>Where</th><th>Issue</th><th>Suggested fix</th></tr></thead><tbody>{rows(errs)}</tbody></table>
<h2>Warnings</h2><table><thead><tr><th>Category</th><th>Where</th><th>Issue</th><th>Suggested fix</th></tr></thead><tbody>{rows(warns)}</tbody></table>
<h2>Info</h2><table><thead><tr><th>Category</th><th>Where</th><th>Detail</th><th></th></tr></thead><tbody>{rows(infos)}</tbody></table>
</body></html>"""


async def main() -> int:
    rep = Report()
    print(f"→ SEO CI audit against {BASE_URL}")
    check_robots_sitemap(rep)
    await audit_pages(rep)

    out = OUT_DIR / "report.html"
    out.write_text(render_html(rep))

    errs = len(rep.by_sev("ERROR")); warns = len(rep.by_sev("WARNING"))
    color = RED if errs else (YEL if warns else GRN)
    print(f"{color}{errs} errors · {warns} warnings · {len(rep.by_sev('INFO'))} info{RST}")
    print(f"report → {out}")

    # print top 20 non-info findings for CI logs
    for f in (rep.by_sev("ERROR") + rep.by_sev("WARNING"))[:20]:
        c = RED if f.severity == "ERROR" else YEL
        print(f"  {c}{f.severity:7}{RST} [{f.category}] {f.where}\n           {f.message}")
    # CI policy: warnings fail the build too, so regressions surface immediately.
    # Override with SEO_STRICT=0 to accept warnings (errors still fail).
    strict = os.environ.get("SEO_STRICT", "1") != "0"
    if errs:
        return 1
    if warns and strict:
        print(f"{YEL}CI failing on {warns} warning(s) (SEO_STRICT=1). Set SEO_STRICT=0 to allow.{RST}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
