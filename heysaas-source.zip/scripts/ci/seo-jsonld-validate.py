#!/usr/bin/env python3
"""
Rich-results-style JSON-LD validator.

Loads each target route in headless Chromium (so TanStack head() scripts
are rendered), extracts every <script type="application/ld+json">, parses
each block, and validates against Google's documented required/recommended
properties for these schema types:

  - Organization       (https://developers.google.com/search/docs/appearance/structured-data/logo)
  - WebSite            (with optional SearchAction — sitelinks searchbox)
  - HowTo              (https://developers.google.com/search/docs/appearance/structured-data/how-to)
  - Article / BlogPosting
                       (https://developers.google.com/search/docs/appearance/structured-data/article)

Output mirrors Google's Rich Results Test: ERROR (blocks the rich result),
WARNING (recommended field missing), and INFO (parsed and clean).

Usage:
    python scripts/ci/seo-jsonld-validate.py
    BASE_URL=https://heysaas.lovable.app python scripts/ci/seo-jsonld-validate.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from typing import Any
from playwright.async_api import async_playwright

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080").rstrip("/")

ROUTES = ["/", "/how-it-works", "/about", "/pricing", "/websites"]

RED = "\033[31m"; YEL = "\033[33m"; GRN = "\033[32m"; DIM = "\033[2m"; RST = "\033[0m"

Issue = tuple[str, str]  # (severity, message) severity ∈ {ERROR, WARNING, INFO}


def as_list(v: Any) -> list:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def check_url(v: Any) -> bool:
    return isinstance(v, str) and v.startswith(("http://", "https://"))


def validate_organization(node: dict) -> list[Issue]:
    out: list[Issue] = []
    if not node.get("name"):
        out.append(("ERROR", "Organization: missing required `name`"))
    if not check_url(node.get("url")):
        out.append(("ERROR", "Organization: `url` missing or not absolute"))
    logo = node.get("logo")
    if not logo:
        out.append(("WARNING", "Organization: `logo` recommended for Google logo feature"))
    elif isinstance(logo, str) and not check_url(logo):
        out.append(("ERROR", "Organization: `logo` must be an absolute URL"))
    elif isinstance(logo, dict) and not check_url(logo.get("url", "")):
        out.append(("ERROR", "Organization.logo: `url` must be an absolute URL"))
    if "sameAs" in node:
        for s in as_list(node["sameAs"]):
            if not check_url(s):
                out.append(("WARNING", f"Organization.sameAs: `{s}` is not an absolute URL"))
    return out


def validate_website(node: dict) -> list[Issue]:
    out: list[Issue] = []
    if not node.get("name"):
        out.append(("ERROR", "WebSite: missing required `name`"))
    if not check_url(node.get("url")):
        out.append(("ERROR", "WebSite: `url` missing or not absolute"))
    action = node.get("potentialAction")
    if action:
        acts = as_list(action)
        for a in acts:
            if a.get("@type") != "SearchAction":
                continue
            target = a.get("target")
            t_url = target.get("urlTemplate") if isinstance(target, dict) else target
            if not isinstance(t_url, str) or "{" not in t_url:
                out.append(("ERROR", "SearchAction.target must contain a `{search_term_string}` placeholder"))
            elif "search_term_string" not in t_url:
                out.append(("WARNING", "SearchAction.target should use the `search_term_string` variable"))
            if a.get("query-input") is None and a.get("queryInput") is None:
                out.append(("ERROR", "SearchAction: missing `query-input` (required for sitelinks searchbox)"))
    return out


def validate_howto(node: dict) -> list[Issue]:
    out: list[Issue] = []
    if not node.get("name"):
        out.append(("ERROR", "HowTo: missing required `name`"))
    steps = as_list(node.get("step"))
    if len(steps) < 2:
        out.append(("ERROR", f"HowTo: needs at least 2 steps (found {len(steps)})"))
    for i, s in enumerate(steps, 1):
        if not isinstance(s, dict) or s.get("@type") not in ("HowToStep", "HowToSection"):
            out.append(("ERROR", f"HowTo.step[{i}]: `@type` must be HowToStep or HowToSection"))
            continue
        if not (s.get("text") or s.get("itemListElement")):
            out.append(("ERROR", f"HowTo.step[{i}]: needs `text` (or nested itemListElement)"))
        if not s.get("name"):
            out.append(("WARNING", f"HowTo.step[{i}]: `name` recommended"))
    if not node.get("totalTime"):
        out.append(("WARNING", "HowTo: `totalTime` recommended (ISO 8601 duration)"))
    return out


def validate_article(node: dict) -> list[Issue]:
    out: list[Issue] = []
    if not node.get("headline"):
        out.append(("ERROR", "Article: missing required `headline`"))
    if not node.get("author"):
        out.append(("ERROR", "Article: missing required `author`"))
    else:
        for a in as_list(node["author"]):
            if not isinstance(a, dict) or a.get("@type") not in ("Person", "Organization"):
                out.append(("WARNING", "Article.author entries should have @type Person or Organization"))
            elif not a.get("name"):
                out.append(("ERROR", "Article.author: missing `name`"))
    if not node.get("datePublished"):
        out.append(("WARNING", "Article: `datePublished` recommended"))
    if not node.get("image"):
        out.append(("WARNING", "Article: `image` recommended for rich result"))
    return out


VALIDATORS = {
    "Organization": validate_organization,
    "WebSite": validate_website,
    "HowTo": validate_howto,
    "Article": validate_article,
    "BlogPosting": validate_article,
    "NewsArticle": validate_article,
}


def walk_graph(root: Any):
    """Yield every JSON-LD node, following @graph."""
    for n in as_list(root):
        if not isinstance(n, dict):
            continue
        if "@graph" in n:
            yield from walk_graph(n["@graph"])
        else:
            yield n


async def extract_ld(page, url: str):
    resp = await page.goto(url, wait_until="domcontentloaded", timeout=20000)
    if not resp or resp.status >= 400:
        return None, f"HTTP {resp.status if resp else '???'}"
    try:
        await page.wait_for_selector('script[type="application/ld+json"]', timeout=4000)
    except Exception:
        pass
    blocks = await page.evaluate(
        """() => Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
            .map(s => s.textContent || '')"""
    )
    return blocks, None


async def main() -> int:
    print(f"→ validating JSON-LD across {len(ROUTES)} routes at {BASE_URL}\n")
    total_errors = 0
    total_warnings = 0

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context(viewport={"width": 1280, "height": 1800})
        page = await ctx.new_page()

        for path in ROUTES:
            url = BASE_URL + path
            print(f"{DIM}── {path}{RST}")
            blocks, err = await extract_ld(page, url)
            if err:
                print(f"  {RED}ERROR{RST} {err}\n")
                total_errors += 1
                continue
            if not blocks:
                print(f"  {YEL}WARN{RST}  no JSON-LD blocks found\n")
                total_warnings += 1
                continue

            for i, raw in enumerate(blocks, 1):
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError as e:
                    print(f"  {RED}ERROR{RST} block #{i} invalid JSON: {e}")
                    total_errors += 1
                    continue
                for node in walk_graph(data):
                    types = as_list(node.get("@type"))
                    matched = [t for t in types if t in VALIDATORS]
                    if not matched:
                        if types:
                            print(f"  {DIM}skip{RST}  @type={types[0]} (no validator)")
                        continue
                    for t in matched:
                        issues = VALIDATORS[t](node)
                        errors = [m for s, m in issues if s == "ERROR"]
                        warns = [m for s, m in issues if s == "WARNING"]
                        total_errors += len(errors)
                        total_warnings += len(warns)
                        if not issues:
                            print(f"  {GRN}OK{RST}    {t}")
                        else:
                            tag = RED + "FAIL" + RST if errors else YEL + "WARN" + RST
                            print(f"  {tag}  {t}  {len(errors)} err / {len(warns)} warn")
                            for m in errors:
                                print(f"          {RED}·{RST} {m}")
                            for m in warns:
                                print(f"          {YEL}·{RST} {m}")
            print()

        await browser.close()

    color = RED if total_errors else (YEL if total_warnings else GRN)
    print(f"{color}Summary: {total_errors} errors, {total_warnings} warnings{RST}")
    return 1 if total_errors else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
