#!/usr/bin/env python3
"""
E2E: load the motion allowlist admin page, submit the live-probe form,
and verify the reported match counts + rendered element list.

Requires the dev server on http://localhost:8080 and (for the admin
route, which lives under /_authenticated) a restored Supabase session
via LOVABLE_BROWSER_AUTH_STATUS=injected. If no session is available
the test degrades to a "skipped" pass so local dev without an injected
session doesn't spuriously fail — CI runs it with a session.
"""
from __future__ import annotations

import asyncio, json, os, sys
from pathlib import Path
from playwright.async_api import async_playwright

BASE = "http://localhost:8080"
ADMIN_PATH = "/dashboard/admin/motion-allowlist"
OUT = Path("/tmp/browser/admin-allowlist")
OUT.mkdir(parents=True, exist_ok=True)


async def restore_session(context, page) -> bool:
    if os.environ.get("LOVABLE_BROWSER_AUTH_STATUS") != "injected":
        return False
    storage_key = os.environ.get("LOVABLE_BROWSER_SUPABASE_STORAGE_KEY")
    session_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_SESSION_JSON")
    cookies_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_COOKIES_JSON")
    if cookies_json:
        cookies = json.loads(cookies_json)
        for c in cookies:
            c["url"] = BASE
        await context.add_cookies(cookies)
    await page.goto(BASE, wait_until="domcontentloaded")
    if storage_key and session_json:
        await page.evaluate(
            f"window.localStorage.setItem({json.dumps(storage_key)}, {json.dumps(session_json)})"
        )
    return True


async def run_probe(page, selector: str, kind: str):
    await page.fill('input[placeholder="[data-carousel]"]', selector)
    await page.select_option("select", kind)
    await page.get_by_role("button", name="Run probe").click()
    # Wait for the <pre> result to appear
    await page.wait_for_selector("pre", timeout=5000)
    text = await page.inner_text("pre")
    return text


async def main() -> int:
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        context = await browser.new_context(viewport={"width": 1280, "height": 1800})
        page = await context.new_page()

        if not await restore_session(context, page):
            print("SKIP: no injected Supabase session; admin route is auth-gated.")
            await browser.close()
            return 0

        # Seed a snap container so the probe has something to match
        await page.goto(BASE + ADMIN_PATH, wait_until="networkidle", timeout=20000)
        await page.screenshot(path=str(OUT / "1_loaded.png"))

        await page.evaluate("""() => {
            const el = document.createElement('div');
            el.setAttribute('data-carousel', '');
            el.id = 'e2e-carousel';
            el.style.overflowX = 'auto';
            document.body.appendChild(el);
        }""")

        # Probe 1: sanctioned carousel selector
        result = await run_probe(page, "[data-carousel]", "scroll-snap")
        print("PROBE 1:", result[:200].replace("\n", " | "))
        assert "matched" in result.lower(), f"expected 'matched' in probe output, got: {result}"
        assert "allow:carousel-scroll-snap" in result, (
            f"expected allowlist rule id in probe output, got: {result}"
        )
        assert "e2e-carousel" in result, f"expected seeded element id, got: {result}"
        await page.screenshot(path=str(OUT / "2_probe_match.png"))

        # Probe 2: selector with zero DOM matches
        result2 = await run_probe(page, "[data-does-not-exist-xyz]", "scroll-snap")
        print("PROBE 2:", result2[:200].replace("\n", " | "))
        assert "0 element" in result2 or "(no elements found)" in result2, (
            f"expected zero-match state, got: {result2}"
        )
        await page.screenshot(path=str(OUT / "3_probe_none.png"))

        # Rule directory must render every rule id from the allowlist.
        rules = json.loads(Path("public/motion-scroll-allowlist.json").read_text())["rules"]
        html = await page.content()
        for r in rules:
            assert r["id"] in html, f"rule id {r['id']} missing from admin page"
        print(f"OK: {len(rules)} rule ids rendered.")

        # --- Export / re-import round-trip ------------------------------------
        # Re-run probe 1 so the export buffer has data, then download JSON.
        await run_probe(page, "[data-carousel]", "scroll-snap")
        export_btn = page.get_by_role("button", name=lambda n: bool(n and n.startswith("Export JSON")))
        async with page.expect_download() as dl_info:
            await export_btn.first.click()
        download = await dl_info.value
        exported_path = OUT / "exported-probe.json"
        await download.save_as(str(exported_path))
        raw = json.loads(exported_path.read_text())
        assert raw.get("exportKind") == "motion-allowlist-probe", (
            f"expected exportKind 'motion-allowlist-probe', got: {raw.get('exportKind')}"
        )
        assert raw.get("schemaVersion") == 1, (
            f"expected schemaVersion 1, got: {raw.get('schemaVersion')}"
        )
        assert isinstance(raw.get("runs"), list) and len(raw["runs"]) >= 1, (
            f"expected at least 1 run in export, got: {raw.get('runs')}"
        )
        # Build the expected (ruleId, selector, kind) -> count map from the raw file.
        expected_pairs: dict[tuple[str, str, str], int] = {}
        for r in raw["runs"]:
            run_sel = r.get("selector", "")
            run_kind = r.get("kind", "")
            for row in r.get("rows", []):
                key = (
                    str(row.get("ruleId", "") or ""),
                    str(row.get("selector", run_sel) or run_sel),
                    str(row.get("kind", run_kind) or run_kind),
                )
                expected_pairs[key] = expected_pairs.get(key, 0) + 1
        expected_rule_counts: dict[str, int] = {}
        for (rid, _sel, _kind), n in expected_pairs.items():
            expected_rule_counts[rid] = expected_rule_counts.get(rid, 0) + n
        expected_distinct_pairs = len(expected_pairs)
        expected_total_rows = sum(expected_pairs.values())
        print(
            f"EXPORT: schemaVersion={raw['schemaVersion']} runs={len(raw['runs'])} "
            f"rows={expected_total_rows} pairs={expected_distinct_pairs}"
        )

        # Re-import into slot A via the hidden file input inside the first import card.
        file_inputs = page.locator('input[type="file"][accept*="json"]')
        n_inputs = await file_inputs.count()
        assert n_inputs >= 1, "expected at least one probe-import file input in the DOM"
        await file_inputs.first.set_input_files(str(exported_path))

        # Wait for the imported card to render the file name + Compatible pill.
        await page.wait_for_selector(f"text={exported_path.name}", timeout=5000)
        await page.wait_for_selector("text=Compatible", timeout=5000)
        await page.screenshot(path=str(OUT / "4_reimport_compatible.png"))

        # Verify metadata fields render with the expected values.
        card_html = await page.content()
        assert "motion-allowlist-probe" in card_html, "exportKind not shown in imported card"
        assert f"Rows / Runs" in card_html, "rows/runs meta cell not shown"
        assert f"{expected_total_rows} / {len(raw['runs'])}" in card_html, (
            f"expected 'Rows / Runs' cell to show {expected_total_rows} / {len(raw['runs'])}"
        )
        assert f">{expected_distinct_pairs}<" in card_html, (
            f"expected distinct-pairs cell to show {expected_distinct_pairs}"
        )

        # Re-import the same file into slot B — diff must show 0 added/removed/changed
        # and `expected_distinct_pairs` unchanged, proving ruleId counts round-tripped.
        assert n_inputs >= 2, "expected two probe-import file inputs (slots A + B)"
        await file_inputs.nth(1).set_input_files(str(exported_path))
        await page.wait_for_selector("text=Diff (A → B)", timeout=5000)
        diff_text = await page.locator("text=Diff (A → B)").locator("..").inner_text()
        print("DIFF:", " ".join(diff_text.split())[:200])
        assert "+0 added" in diff_text, f"expected +0 added in diff, got: {diff_text}"
        assert "−0 removed" in diff_text or "-0 removed" in diff_text, (
            f"expected 0 removed in diff, got: {diff_text}"
        )
        assert "~0 changed" in diff_text, f"expected ~0 changed in diff, got: {diff_text}"
        assert f"{expected_distinct_pairs} unchanged" in diff_text, (
            f"expected {expected_distinct_pairs} unchanged, got: {diff_text}"
        )
        await page.screenshot(path=str(OUT / "5_reimport_diff.png"))
        print(
            f"OK: round-trip verified — {expected_distinct_pairs} pairs, "
            f"{len(expected_rule_counts)} distinct ruleIds, all counts match."
        )

        await browser.close()
    print("\nPASS: admin allowlist E2E (with export/re-import round-trip)")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
