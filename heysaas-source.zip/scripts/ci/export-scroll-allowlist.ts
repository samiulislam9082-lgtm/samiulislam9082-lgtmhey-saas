/**
 * Freeze `src/config/motion-scroll-allowlist.ts` into a versioned JSON
 * artifact at `public/motion-scroll-allowlist.json` so Python scanners
 * and CI jobs can consume it without a TypeScript toolchain.
 *
 * Run:  bun run scripts/ci/export-scroll-allowlist.ts
 * Emits: public/motion-scroll-allowlist.json  (checked into repo)
 */
import { createHash } from "node:crypto";
import { writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { scrollAllowlist } from "../../src/config/motion-scroll-allowlist";

const SCHEMA_VERSION = 1;

// Deterministic ordering so the hash is stable across runs.
const rules = [...scrollAllowlist]
  .map((r) => ({
    id: r.id,
    kind: r.kind,
    selector: r.selector,
    reason: r.reason,
    routes: r.routes ?? null,
    requireHtmlAttr: r.requireHtmlAttr ?? null,
  }))
  .sort((a, b) => a.id.localeCompare(b.id));

const body = JSON.stringify(rules);
const contentHash = createHash("sha256").update(body).digest("hex").slice(0, 12);

const payload = {
  schemaVersion: SCHEMA_VERSION,
  version: `${SCHEMA_VERSION}.${rules.length}.${contentHash}`,
  generatedAt: new Date().toISOString(),
  ruleCount: rules.length,
  contentHash,
  rules,
};

const out = resolve(process.cwd(), "public/motion-scroll-allowlist.json");
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, JSON.stringify(payload, null, 2) + "\n");
console.log(`wrote ${out} — version=${payload.version} rules=${rules.length}`);
