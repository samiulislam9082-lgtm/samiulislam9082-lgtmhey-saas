#!/usr/bin/env python3
"""
Automated heading-hierarchy check for every public route.

For each URL we load the rendered page in headless Chromium, extract every
heading in DOM order, and flag:

  * missing H1
  * more than one H1 (duplicate top-level)
  * skipped level (e.g. H2 → H4)
  * empty heading text

Public routes are derived from src/routes/sitemap[.]xml.ts and cross-checked
against robots.txt disallows.

Usage:
    python scripts/ci/a11y-heading-audit.py            # localhost:8080
    BASE_URL=https://heysaas.lovable.app python scripts/ci/a11y-heading-audit.py

Exit code 0 = all clean, 1 = at least one route has an issue.
"""
from __future__ import annotations

import asyncio
import os
import sys
from playwright.async_api import async_playwright

BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080").rstrip("/")

# Public routes (mirrors sitemap.xml + a few dynamic sample slugs).
ROUTES: list[str] = [
    "/",
    "/about",
    "/how-it-works",
    "/pricing",
    "/explore",
    "/leaderboard",
    "/compare",
    "/status",
    "/blog",
    "/guidelines",
    "/legal/privacy",
    "/legal/terms",
    "/legal/safety-fee-policy",
    "/websites",
    "/websites/browse",
]

GREEN = "\033[32m"; RED = "\033[31m"; YELLOW = "\033[33m"; DIM = "\033[2m"; RESET = "\033[0m"


async def audit(page, path: str) -> list[str]:
    url = BASE_URL + path
    issues: list[str] = []
    try:
        resp = await page.goto(url, wait_until="domcontentloaded", timeout=15000)
    except Exception as e:
        return [f"navigation failed: {e}"]
    if not resp or resp.status >= 400:
        return [f"HTTP {resp.status if resp else '???'}"]

    # give client-only content a moment to render headings
    try:
        await page.wait_for_selector("h1, h2, h3, h4, h5, h6", timeout=4000)
    except Exception:
        return ["no headings rendered"]

    headings = await page.evaluate(
        """() => Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6'))
            .filter(el => el.offsetParent !== null || el.getClientRects().length)
            .map(el => ({
              level: Number(el.tagName[1]),
              text: (el.innerText || el.textContent || '').trim().slice(0, 80),
            }))"""
    )

    if not headings:
        return ["no visible headings"]

    h1s = [h for h in headings if h["level"] == 1]
    if len(h1s) == 0:
        issues.append("missing H1")
    elif len(h1s) > 1:
        issues.append(f"duplicate H1 ({len(h1s)}): " + " | ".join(h['text'] for h in h1s))

    prev = 0
    for h in headings:
        lvl = h["level"]
        if not h["text"]:
            issues.append(f"empty H{lvl}")
        if prev and lvl > prev + 1:
            issues.append(f"skip H{prev}→H{lvl} at “{h['text']}”")
        prev = lvl

    return issues


async def main() -> int:
    print(f"→ auditing {len(ROUTES)} routes against {BASE_URL}\n")
    failed = 0
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        ctx = await browser.new_context(viewport={"width": 1280, "height": 1800})
        page = await ctx.new_page()
        page.on("console", lambda m: None)  # silence
        width = max(len(r) for r in ROUTES)
        for path in ROUTES:
            issues = await audit(page, path)
            if issues:
                failed += 1
                print(f"  {RED}FAIL{RESET}  {path.ljust(width)}  {issues[0]}")
                for extra in issues[1:]:
                    print(f"        {' ' * width}  {DIM}{extra}{RESET}")
            else:
                print(f"  {GREEN}PASS{RESET}  {path.ljust(width)}")
        await browser.close()

    total = len(ROUTES)
    print(f"\n{total - failed}/{total} routes clean ({failed} with issues)")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
