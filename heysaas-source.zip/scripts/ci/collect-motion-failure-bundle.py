"""
Collect a failure bundle for the motion-guard CI step.

Invoked from `.github/workflows/motion-and-theme.yml` only when the
`Motion guard` step fails. Produces a self-contained directory at
`/tmp/motion-guard-failure-bundle/` that CI uploads as an artifact:

  motion-guard-failure-bundle/
    motion-debug-events.json   # last 200 events from window.__motionDebugEvents
    motion-debug-failures.json # strict-mode window.__motionDebugFailures
    guard-report.json          # copy of motion-guard's own report.json
    guard-stdout.log           # captured stdout/stderr from the failed step
    screenshots/               # per-route screenshots with data-motion=reduced
      <slug>.png
      <slug>.dom.html

The collector re-visits every public route with `?motionDebug=strict`
and reduced-motion emulated, drives the `MotionDebugIndicator` runtime
hooks the app already installs, and snapshots the resulting state. Any
leak that fires during the visit is captured with its stack trace and
callsite hint, giving reviewers the exact same JSON they would get from
the in-app "Download JSON" button plus visual evidence.

Runs against `http://localhost:8080` (the dev server started by the CI
workflow). Never fails — the goal is to gather diagnostics, not to
re-assert. Exit code is always 0 so it does not mask the original
motion-guard failure.
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
from pathlib import Path

from playwright.async_api import async_playwright

BASE = os.environ.get("MOTION_BUNDLE_BASE_URL", "http://localhost:8080")
BUNDLE = Path(os.environ.get("MOTION_BUNDLE_DIR", "/tmp/motion-guard-failure-bundle"))
SCREENSHOTS = BUNDLE / "screenshots"

# Routes we walk to accumulate motion debug events. Mirrors the surface
# covered by motion-guard / motion-public-ssr so a leak reported by the
# guard is very likely reproduced here too.
ROUTES = [
    "/",
    "/about",
    "/how-it-works",
    "/pricing",
    "/explore",
    "/leaderboard",
    "/blog",
    "/guidelines",
    "/compare",
    "/legal/terms",
    "/legal/privacy",
    "/websites",
    "/websites/browse",
    "/auth",
]

# Cap matches the in-app ring buffer.
MAX_EVENTS = 200


def slugify(route: str) -> str:
    return route.strip("/").replace("/", "_") or "root"


def copy_if_exists(src: Path, dst: Path) -> None:
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


async def collect() -> None:
    BUNDLE.mkdir(parents=True, exist_ok=True)
    SCREENSHOTS.mkdir(parents=True, exist_ok=True)

    # Aggregate across routes so the bundle mirrors the "last 200 events"
    # the in-app indicator would expose.
    all_events: list[dict] = []
    all_failures: list[dict] = []

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={"width": 1280, "height": 1800},
            reduced_motion="reduce",
            color_scheme="dark",
        )

        for route in ROUTES:
            page = await context.new_page()
            try:
                url = f"{BASE}{route}?motionDebug=strict"
                await page.goto(url, wait_until="domcontentloaded", timeout=20_000)
                try:
                    await page.wait_for_load_state("networkidle", timeout=6_000)
                except Exception:
                    pass  # not fatal — we still want the snapshot

                state = await page.evaluate(
                    """() => {
                      const raw = typeof window.__motionDebugEvents === 'function'
                        ? window.__motionDebugEvents()
                        : (Array.isArray(window.__motionDebugEvents) ? window.__motionDebugEvents : []);
                      return {
                        events: (Array.isArray(raw) ? raw : []).slice(-200),
                        failures: Array.isArray(window.__motionDebugFailures) ? window.__motionDebugFailures : [],
                        route: location.pathname + location.search,
                        dataMotion: document.documentElement.dataset.motion,
                        themeClass: document.documentElement.className,
                      };
                    }"""
                )
                for e in state["events"]:
                    e["route"] = state["route"]
                    all_events.append(e)
                for f in state["failures"]:
                    f["route"] = state["route"]
                    all_failures.append(f)

                slug = slugify(route)
                await page.screenshot(path=str(SCREENSHOTS / f"{slug}.png"))
                html = await page.content()
                (SCREENSHOTS / f"{slug}.dom.html").write_text(html, encoding="utf-8")
            except Exception as exc:  # noqa: BLE001 — diagnostics only
                (SCREENSHOTS / f"{slugify(route)}.error.txt").write_text(
                    f"{type(exc).__name__}: {exc}\n", encoding="utf-8"
                )
            finally:
                await page.close()

        await context.close()
        await browser.close()

    # Trim to the ring-buffer size after aggregation so the JSON matches
    # what the in-app "Download JSON" button would produce.
    trimmed_events = all_events[-MAX_EVENTS:]

    (BUNDLE / "motion-debug-events.json").write_text(
        json.dumps(
            {"base": BASE, "captured": len(trimmed_events), "events": trimmed_events},
            indent=2,
            default=str,
        )
    )
    (BUNDLE / "motion-debug-failures.json").write_text(
        json.dumps(
            {"base": BASE, "failures": all_failures},
            indent=2,
            default=str,
        )
    )

    # Best-effort copy of upstream artifacts so reviewers have everything
    # in one download.
    copy_if_exists(Path("/tmp/browser/motion-guard/report.json"), BUNDLE / "guard-report.json")
    copy_if_exists(Path("/tmp/motion-guard.log"), BUNDLE / "guard-stdout.log")
    copy_if_exists(Path("/tmp/dev.log"), BUNDLE / "dev.log")

    print(
        f"[motion-guard-bundle] wrote {len(trimmed_events)} events, "
        f"{len(all_failures)} strict failures to {BUNDLE}"
    )


if __name__ == "__main__":
    try:
        asyncio.run(collect())
    except Exception as exc:  # noqa: BLE001
        # Never fail — this is a diagnostics collector.
        print(f"[motion-guard-bundle] collector error (ignored): {exc}", file=sys.stderr)
    sys.exit(0)
