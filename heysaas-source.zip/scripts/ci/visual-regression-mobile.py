"""
Visual regression checks for chart, sparkline, and icon legibility at
MOBILE (390×844) and TABLET (820×1180) breakpoints across light and dark
themes on key HeySaaS and WebSwap dashboard/listing routes.

For each (route, theme, breakpoint) combo the runner:
  1. Sets the theme + motion preference via localStorage before load so SSR
     and hydration match the audited state (no FOUC).
  2. Optionally restores the injected Supabase session for authenticated
     routes (LOVABLE_BROWSER_AUTH_STATUS=injected).
  3. Waits for network idle + `[data-kpi-value]` / `svg` presence.
  4. Screenshots the viewport into /tmp/browser/visual-regression-mobile/screenshots/.
  5. Audits every rendered SVG (charts, sparklines, icons):
       - stroke/fill contrast against the resolved background using WCAG APCA
         fallback (relative luminance ratio) — must be ≥ 3.0 for non-text
         graphical objects (WCAG 1.4.11).
       - effective stroke width in CSS px must be ≥ 1.25 (icons) / ≥ 1.0
         (sparklines flagged via data-sparkline or role="img" ariaLabel).
       - warns if any SVG collapses below 12px in either dimension at the
         current breakpoint (illegible).
  6. Writes report.json + human summary. Exits 1 on any hard failure.

Auth-only routes are skipped (with a logged notice) when
LOVABLE_BROWSER_AUTH_STATUS != 'injected'.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from playwright.async_api import async_playwright

BASE = "http://localhost:8080"
OUT = Path("/tmp/browser/visual-regression-mobile")
SHOTS = OUT / "screenshots"
SHOTS.mkdir(parents=True, exist_ok=True)

BREAKPOINTS = [
    ("mobile", 390, 844),
    ("tablet", 820, 1180),
]
THEMES = ["light", "dark"]

# Route → requires_auth. WebSwap public routes are dark-only per design spec;
# they are still audited to confirm dark legibility holds at small widths.
ROUTES = [
    ("/", False, False),                      # HeySaaS landing (KPI ribbon + sparklines)
    ("/explore", False, False),               # Listing grid + card KPIs
    ("/dev/kpi-preview", False, False),       # Canonical KPI/sparkline gallery
    ("/websites", False, True),               # WebSwap landing (dark-only)
    ("/websites/browse", False, True),        # WebSwap listing grid
    ("/dashboard", True, False),              # HeySaaS dashboard KPIs
    ("/dashboard/analytics", True, False),    # Charts
    ("/websites/dashboard", True, True),      # WebSwap dashboard sparklines
]


def rel_luminance(rgb: tuple[float, float, float]) -> float:
    def chan(c: float) -> float:
        c = c / 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * chan(r) + 0.7152 * chan(g) + 0.0722 * chan(b)


def contrast_ratio(fg: tuple[float, float, float], bg: tuple[float, float, float]) -> float:
    l1 = rel_luminance(fg)
    l2 = rel_luminance(bg)
    lighter, darker = max(l1, l2), min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)


AUDIT_JS = r"""
() => {
  const parseColor = (s) => {
    if (!s) return null;
    const m = s.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const p = m[1].split(',').map((x) => parseFloat(x.trim()));
    if (p.length < 3) return null;
    return { r: p[0], g: p[1], b: p[2], a: p[3] ?? 1 };
  };
  const resolvedBg = (el) => {
    let cur = el;
    while (cur && cur !== document.documentElement) {
      const cs = getComputedStyle(cur);
      const c = parseColor(cs.backgroundColor);
      if (c && c.a > 0.5) return c;
      cur = cur.parentElement;
    }
    const rootBg = parseColor(getComputedStyle(document.body).backgroundColor);
    return rootBg || { r: 255, g: 255, b: 255, a: 1 };
  };
  const svgs = Array.from(document.querySelectorAll('svg'));
  const results = [];
  for (const svg of svgs) {
    const rect = svg.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) continue;
    // classify
    const ariaLabel = (svg.getAttribute('aria-label') || '').toLowerCase();
    const isSpark = svg.hasAttribute('data-sparkline') ||
                    ariaLabel.includes('trend') ||
                    ariaLabel.includes('spark');
    const isChart = svg.closest('[data-chart], .recharts-wrapper') != null;
    const kind = isSpark ? 'sparkline' : (isChart ? 'chart' : 'icon');
    // sample strokes/fills
    const paints = new Set();
    const nodes = Array.from(svg.querySelectorAll('path, line, polyline, rect, circle, polygon'));
    let minStrokeCss = Infinity;
    for (const n of nodes) {
      const cs = getComputedStyle(n);
      if (cs.stroke && cs.stroke !== 'none') paints.add(cs.stroke);
      if (cs.fill && cs.fill !== 'none' && cs.fill !== 'rgba(0, 0, 0, 0)') paints.add(cs.fill);
      const sw = parseFloat(cs.strokeWidth);
      if (!Number.isNaN(sw) && sw > 0) {
        // convert SVG user units to CSS px using bbox ratio
        const svgRect = svg.getBoundingClientRect();
        const vb = svg.viewBox && svg.viewBox.baseVal;
        const scale = vb && vb.width ? svgRect.width / vb.width : 1;
        minStrokeCss = Math.min(minStrokeCss, sw * scale);
      }
    }
    const bg = resolvedBg(svg);
    results.push({
      kind,
      width: Math.round(rect.width),
      height: Math.round(rect.height),
      ariaLabel: svg.getAttribute('aria-label') || null,
      paints: Array.from(paints),
      minStrokeCss: minStrokeCss === Infinity ? null : Number(minStrokeCss.toFixed(2)),
      bg,
      dataMotion: document.documentElement.getAttribute('data-motion'),
      themeClass: document.documentElement.className,
    });
  }
  return results;
};
"""


def parse_rgba(s: str) -> tuple[float, float, float] | None:
    import re
    m = re.match(r"rgba?\(([^)]+)\)", s)
    if not m:
        return None
    parts = [float(x.strip()) for x in m.group(1).split(",")]
    if len(parts) < 3:
        return None
    return (parts[0], parts[1], parts[2])


def audit_svgs(svgs: list[dict]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    for svg in svgs:
        bg = (svg["bg"]["r"], svg["bg"]["g"], svg["bg"]["b"])
        min_ratio = float("inf")
        worst_paint = None
        for p in svg["paints"]:
            fg = parse_rgba(p)
            if not fg:
                continue
            r = contrast_ratio(fg, bg)
            if r < min_ratio:
                min_ratio, worst_paint = r, p
        label = f'{svg["kind"]}({svg["width"]}×{svg["height"]}, aria={svg["ariaLabel"]!r})'
        if min_ratio != float("inf") and min_ratio < 3.0:
            errors.append(
                f'{label}: contrast {min_ratio:.2f}:1 against bg rgb{bg} (paint={worst_paint}) '
                f'— WCAG 1.4.11 requires ≥ 3:1'
            )
        # stroke width thresholds (1.0px is the legibility floor for hairlines)
        if svg["minStrokeCss"] is not None:
            threshold = 1.0
            # allow a 5% tolerance for sub-pixel rounding on odd CSS scales
            if svg["minStrokeCss"] < threshold - 0.05:
                errors.append(
                    f'{label}: minStrokeCss={svg["minStrokeCss"]}px < {threshold}px'
                )
        # illegibly small
        if svg["kind"] == "icon" and (svg["width"] < 12 or svg["height"] < 12):
            warnings.append(f'{label}: renders below 12px at this breakpoint')
    return errors, warnings


async def restore_session(context, page):
    status = os.environ.get("LOVABLE_BROWSER_AUTH_STATUS")
    if status != "injected":
        return False
    storage_key = os.environ.get("LOVABLE_BROWSER_SUPABASE_STORAGE_KEY")
    session_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_SESSION_JSON")
    cookies_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_COOKIES_JSON")
    if cookies_json:
        cookies = json.loads(cookies_json)
        for c in cookies:
            c["url"] = BASE
        await context.add_cookies(cookies)
    await page.goto(BASE, wait_until="domcontentloaded")
    if storage_key and session_json:
        await page.evaluate(
            f"window.localStorage.setItem({json.dumps(storage_key)}, {json.dumps(session_json)})"
        )
    return True


async def probe(playwright, route, requires_auth, ws_dark_only, theme, bp_name, w, h):
    browser = await playwright.chromium.launch(headless=True)
    context = await browser.new_context(viewport={"width": w, "height": h})
    page = await context.new_page()

    authed = False
    if requires_auth:
        authed = await restore_session(context, page)
        if not authed:
            await browser.close()
            return {"route": route, "theme": theme, "bp": bp_name, "skipped": "no-session"}
    else:
        await page.goto(BASE, wait_until="domcontentloaded")

    # Set theme + full motion before nav to eliminate FOUC + isolate viz audit.
    effective_theme = "dark" if ws_dark_only else theme
    await page.evaluate(
        """([t]) => {
          try { localStorage.setItem('theme', t); } catch(_) {}
          try { localStorage.setItem('motion-preference', 'full'); } catch(_) {}
          document.documentElement.classList.remove('light','dark');
          document.documentElement.classList.add(t);
          document.documentElement.setAttribute('data-motion','full');
        }""",
        [effective_theme],
    )

    try:
        await page.goto(f"{BASE}{route}", wait_until="networkidle", timeout=20000)
    except Exception as e:
        await browser.close()
        return {"route": route, "theme": theme, "bp": bp_name, "error": f"nav: {e}"}
    try:
        await page.wait_for_selector("svg, [data-kpi-value]", timeout=5000)
    except Exception:
        pass

    slug = route.strip("/").replace("/", "_") or "root"
    shot_path = SHOTS / f"{slug}__{effective_theme}__{bp_name}.png"
    await page.screenshot(path=str(shot_path))

    svgs = await page.evaluate(AUDIT_JS)
    errors, warnings = audit_svgs(svgs)
    result = {
        "route": route,
        "theme": effective_theme,
        "requested_theme": theme,
        "bp": bp_name,
        "viewport": [w, h],
        "svg_count": len(svgs),
        "errors": errors,
        "warnings": warnings,
        "screenshot": str(shot_path),
        "authed": authed,
    }
    await browser.close()
    return result


async def main():
    results = []
    async with async_playwright() as pw:
        for route, requires_auth, ws_dark_only in ROUTES:
            themes = ["dark"] if ws_dark_only else THEMES
            for theme in themes:
                for bp_name, w, h in BREAKPOINTS:
                    r = await probe(pw, route, requires_auth, ws_dark_only, theme, bp_name, w, h)
                    results.append(r)
                    tag = f'{r["route"]} [{r.get("theme","?")}/{r["bp"]}]'
                    if "skipped" in r:
                        print(f"SKIP  {tag}: {r['skipped']}")
                    elif "error" in r:
                        print(f"ERR   {tag}: {r['error']}")
                    else:
                        print(f"OK    {tag}: svgs={r['svg_count']} "
                              f"errors={len(r['errors'])} warns={len(r['warnings'])}")
                        for e in r["errors"]:
                            print(f"        E: {e}")
                        for w_ in r["warnings"]:
                            print(f"        W: {w_}")
    report = {"results": results}
    (OUT / "report.json").write_text(json.dumps(report, indent=2))
    hard_fail = any(r.get("errors") or r.get("error") for r in results)
    if hard_fail:
        print("\nFAIL: visual regression violations detected.")
        sys.exit(1)
    print("\nPASS: mobile + tablet visual regression clean.")


if __name__ == "__main__":
    asyncio.run(main())
