#!/usr/bin/env python3
"""
Local CLI wrapper around the allowlist coverage check.

Usage:
  python scripts/ci/allowlist-coverage-cli.py                # default routes
  python scripts/ci/allowlist-coverage-cli.py -r / /explore  # custom route list
  python scripts/ci/allowlist-coverage-cli.py --routes-file routes.txt
  python scripts/ci/allowlist-coverage-cli.py --base http://localhost:5173

Exits non-zero if any allowlist rule has zero matches across all audited
routes so you can catch dead selectors before pushing.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from playwright.async_api import async_playwright

DEFAULT_ROUTES = [
    "/",
    "/explore",
    "/dev/kpi-preview",
    "/websites",
    "/websites/browse",
]
ALLOWLIST = Path("public/motion-scroll-allowlist.json")


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-r", "--routes", nargs="+", help="Explicit route list (space-separated).")
    ap.add_argument("--routes-file", type=Path, help="File with one route per line.")
    ap.add_argument("--base", default="http://localhost:8080", help="Base URL (default: http://localhost:8080).")
    ap.add_argument("--allowlist", type=Path, default=ALLOWLIST, help="Path to the JSON allowlist artifact.")
    ap.add_argument("--timeout", type=int, default=15000, help="Per-route nav timeout in ms.")
    return ap.parse_args()


def resolve_routes(args: argparse.Namespace) -> list[str]:
    if args.routes:
        return args.routes
    if args.routes_file and args.routes_file.exists():
        return [ln.strip() for ln in args.routes_file.read_text().splitlines() if ln.strip() and not ln.startswith("#")]
    return DEFAULT_ROUTES


async def main() -> int:
    args = parse_args()
    routes = resolve_routes(args)
    if not args.allowlist.exists():
        print(f"ERR: {args.allowlist} missing. Run: bun run scripts/ci/export-scroll-allowlist.ts")
        return 2
    payload = json.loads(args.allowlist.read_text())
    rules = payload["rules"]
    print(f"Base: {args.base}")
    print(f"Routes ({len(routes)}): {', '.join(routes)}")
    print(f"Checking coverage for {len(rules)} rules (version={payload['version']})\n")

    coverage: dict[str, list[tuple[str, int]]] = {r["id"]: [] for r in rules}

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        context = await browser.new_context(viewport={"width": 1280, "height": 1800})
        page = await context.new_page()
        for route in routes:
            try:
                await page.goto(f"{args.base}{route}", wait_until="networkidle", timeout=args.timeout)
            except Exception as e:
                print(f"nav fail {route}: {e}")
                continue
            counts = await page.evaluate(
                """(rules) => {
                    const out = {};
                    for (const r of rules) {
                      try { out[r.id] = document.querySelectorAll(r.selector).length; }
                      catch { out[r.id] = -1; }
                    }
                    return out;
                }""",
                rules,
            )
            for rid, n in counts.items():
                if n > 0:
                    coverage[rid].append((route, n))
                elif n == -1:
                    print(f"  ! invalid selector for rule {rid} on {route}")
        await browser.close()

    unreachable: list[str] = []
    for r in rules:
        hits = coverage[r["id"]]
        if hits:
            summary = ", ".join(f"{p}({n})" for p, n in hits)
            print(f"OK  {r['id']:<28} → {summary}")
        else:
            unreachable.append(r["id"])
            print(f"ERR {r['id']:<28} → no matches across {len(routes)} route(s)"
                  f" (selector: {r['selector']!r})")

    if unreachable:
        print(f"\nFAIL: {len(unreachable)} unreachable rule(s): {unreachable}")
        return 1
    print("\nPASS: every allowlist rule matches at least one audited route.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
