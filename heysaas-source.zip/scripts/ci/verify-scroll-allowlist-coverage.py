"""
CI guard: every rule in `public/motion-scroll-allowlist.json` must be
demonstrably reachable — its selector must match at least one element
in at least one audited route. Dead rules are a maintenance hazard
(silent regressions) and fail the build here.

The route list mirrors visual-regression-mobile.py to keep audit
coverage aligned.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

from playwright.async_api import async_playwright

BASE = "http://localhost:8080"
ALLOWLIST = Path("public/motion-scroll-allowlist.json")

# Same route set as the visual-regression suite (public + auth mix).
ROUTES = [
    "/",
    "/explore",
    "/dev/kpi-preview",
    "/websites",
    "/websites/browse",
    "/dashboard",
    "/dashboard/analytics",
    "/websites/dashboard",
]

AUTH_ROUTES = {"/dashboard", "/dashboard/analytics", "/websites/dashboard"}


async def restore_session(context, page) -> bool:
    if os.environ.get("LOVABLE_BROWSER_AUTH_STATUS") != "injected":
        return False
    storage_key = os.environ.get("LOVABLE_BROWSER_SUPABASE_STORAGE_KEY")
    session_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_SESSION_JSON")
    cookies_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_COOKIES_JSON")
    if cookies_json:
        cookies = json.loads(cookies_json)
        for c in cookies:
            c["url"] = BASE
        await context.add_cookies(cookies)
    await page.goto(BASE, wait_until="domcontentloaded")
    if storage_key and session_json:
        await page.evaluate(
            f"window.localStorage.setItem({json.dumps(storage_key)}, {json.dumps(session_json)})"
        )
    return True


async def main() -> int:
    if not ALLOWLIST.exists():
        print(f"ERR: {ALLOWLIST} missing. Run: bun run scripts/ci/export-scroll-allowlist.ts")
        return 2
    payload = json.loads(ALLOWLIST.read_text())
    rules = payload["rules"]
    print(f"Checking coverage for {len(rules)} rules (version={payload['version']})")

    # rule_id -> list[(route, count)]
    coverage: dict[str, list[tuple[str, int]]] = {r["id"]: [] for r in rules}

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        for route in ROUTES:
            context = await browser.new_context(viewport={"width": 1280, "height": 1800})
            page = await context.new_page()
            authed = False
            if route in AUTH_ROUTES:
                authed = await restore_session(context, page)
                if not authed:
                    print(f"skip auth route {route} (no session)")
                    await context.close()
                    continue
            else:
                await page.goto(BASE, wait_until="domcontentloaded")
            try:
                await page.goto(f"{BASE}{route}", wait_until="networkidle", timeout=20000)
            except Exception as e:
                print(f"nav fail {route}: {e}")
                await context.close()
                continue
            counts = await page.evaluate(
                """(rules) => {
                    const out = {};
                    for (const r of rules) {
                      try { out[r.id] = document.querySelectorAll(r.selector).length; }
                      catch { out[r.id] = -1; }
                    }
                    return out;
                }""",
                rules,
            )
            for rid, n in counts.items():
                if n > 0:
                    coverage[rid].append((route, n))
                elif n == -1:
                    print(f"  ! invalid selector for rule {rid} on {route}")
            await context.close()
        await browser.close()

    unreachable = [rid for rid, hits in coverage.items() if not hits]
    for r in rules:
        hits = coverage[r["id"]]
        if hits:
            summary = ", ".join(f"{p}({n})" for p, n in hits)
            print(f"OK  {r['id']:<28} → {summary}")
        else:
            print(f"ERR {r['id']:<28} → no matches across {len(ROUTES)} audited routes"
                  f" (selector: {r['selector']!r})")

    if unreachable:
        print(f"\nFAIL: {len(unreachable)} unreachable rule(s): {unreachable}")
        return 1
    print("\nPASS: every allowlist rule matches at least one audited route.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
