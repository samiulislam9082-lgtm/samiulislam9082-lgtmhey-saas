#!/usr/bin/env python3
"""
E2E: run a live probe in the admin allowlist page and verify that
Export JSON and Export CSV downloads contain the expected rule ids,
countsByRule summary, matched selectors, and status columns.

Skips (exit 0) when no injected Supabase session is available.
"""
from __future__ import annotations

import asyncio, csv, io, json, os, sys
from pathlib import Path
from playwright.async_api import async_playwright

BASE = "http://localhost:8080"
ADMIN_PATH = "/dashboard/admin/motion-allowlist"
OUT = Path("/tmp/browser/admin-allowlist-exports")
OUT.mkdir(parents=True, exist_ok=True)

SELECTOR = "[data-carousel]"
EXPECTED_RULE = "carousel-scroll-snap"


async def restore_session(context, page) -> bool:
    if os.environ.get("LOVABLE_BROWSER_AUTH_STATUS") != "injected":
        return False
    storage_key = os.environ.get("LOVABLE_BROWSER_SUPABASE_STORAGE_KEY")
    session_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_SESSION_JSON")
    cookies_json = os.environ.get("LOVABLE_BROWSER_SUPABASE_COOKIES_JSON")
    if cookies_json:
        cookies = json.loads(cookies_json)
        for c in cookies:
            c["url"] = BASE
        await context.add_cookies(cookies)
    await page.goto(BASE, wait_until="domcontentloaded")
    if storage_key and session_json:
        await page.evaluate(
            f"window.localStorage.setItem({json.dumps(storage_key)}, {json.dumps(session_json)})"
        )
    return True


async def download_to(page, button_label: str, out_path: Path) -> Path:
    async with page.expect_download(timeout=10_000) as dl_info:
        # Buttons render as "Export JSON (N)" / "Export CSV (N)" — use partial match.
        await page.get_by_role("button", name=button_label).click()
    download = await dl_info.value
    await download.save_as(str(out_path))
    return out_path


async def main() -> int:
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={"width": 1280, "height": 1800},
            accept_downloads=True,
        )
        page = await context.new_page()

        if not await restore_session(context, page):
            print("SKIP: no injected Supabase session; admin route is auth-gated.")
            await browser.close()
            return 0

        await page.goto(BASE + ADMIN_PATH, wait_until="networkidle", timeout=20_000)

        # Seed two elements: one sanctioned, one that will register as a leak
        # (no matching allowlist rule) so we can exercise the "both" export mode.
        await page.evaluate("""() => {
            const good = document.createElement('div');
            good.setAttribute('data-carousel', '');
            good.id = 'e2e-carousel';
            document.body.appendChild(good);
            const leak = document.createElement('div');
            leak.setAttribute('data-e2e-leak', '');
            leak.id = 'e2e-leak';
            document.body.appendChild(leak);
        }""")

        # Run probe for the sanctioned selector.
        await page.fill('input[placeholder="[data-carousel]"]', SELECTOR)
        await page.select_option("select", "scroll-snap")
        await page.get_by_role("button", name="Run probe").click()
        await page.wait_for_selector("pre", timeout=5_000)
        await page.screenshot(path=str(OUT / "1_after_probe.png"))

        # Buttons include the row count, so use regex-style partial matches.
        import re
        json_btn = page.get_by_role("button", name=re.compile(r"^Export JSON"))
        csv_btn = page.get_by_role("button", name=re.compile(r"^Export CSV"))
        assert await json_btn.is_enabled(), "Export JSON button should be enabled after probe"
        assert await csv_btn.is_enabled(), "Export CSV button should be enabled after probe"

        # --- Download + verify JSON ---
        json_path = await download_to(page, re.compile(r"^Export JSON"), OUT / "export.json")
        payload = json.loads(json_path.read_text())
        assert payload.get("schemaVersion") == 1, f"JSON schemaVersion missing/wrong: {payload.get('schemaVersion')}"
        assert payload.get("exportKind") == "motion-allowlist-probe"
        assert isinstance(payload.get("exportedAt"), str) and payload["exportedAt"].endswith("Z"), (
            f"JSON exportedAt must be ISO Z timestamp, got {payload.get('exportedAt')!r}"
        )
        assert payload["totalRows"] >= 1, f"JSON totalRows unexpectedly 0: {payload}"
        assert EXPECTED_RULE in payload["countsByRule"], (
            f"expected rule '{EXPECTED_RULE}' in countsByRule, got {payload['countsByRule']}"
        )
        assert payload["countsByRule"][EXPECTED_RULE] >= 1
        assert payload["filters"]["mode"] in {"both", "sanctioned"}
        assert len(payload["runs"]) >= 1, "expected at least one run in export"
        run = payload["runs"][0]
        assert run["selector"] == SELECTOR, f"selector mismatch: {run['selector']}"
        assert run["kind"] == "scroll-snap"
        row_selectors = {r["selector"] for r in run["rows"]}
        row_rules = {r["ruleId"] for r in run["rows"]}
        assert SELECTOR in row_selectors, f"probed selector missing from rows: {row_selectors}"
        assert EXPECTED_RULE in row_rules, f"expected ruleId missing: {row_rules}"
        print(f"OK JSON: v{payload['schemaVersion']} at {payload['exportedAt']} — {payload['totalRows']} rows")

        # --- Download + verify CSV ---
        csv_path = await download_to(page, re.compile(r"^Export CSV"), OUT / "export.csv")
        raw = csv_path.read_text()
        # Header should include leading `# ...` comment lines carrying meta.
        comment_lines = [l for l in raw.splitlines() if l.startswith("#")]
        assert any("schemaVersion=1" in l for l in comment_lines), (
            f"CSV missing schemaVersion comment; got {comment_lines}"
        )
        assert any(l.startswith("# exportedAt=") for l in comment_lines), (
            f"CSV missing exportedAt comment; got {comment_lines}"
        )
        # DictReader must skip comment lines to parse the CSV cleanly.
        data_text = "\n".join(l for l in raw.splitlines() if not l.startswith("#"))
        reader = csv.DictReader(io.StringIO(data_text))
        rows = list(reader)
        assert rows, "CSV had zero data rows"
        expected_cols = {
            "schemaVersion", "exportedAt",
            "ranAt", "pathname", "selector", "kind",
            "index", "tag", "id", "classes", "ruleId", "status",
        }
        missing = expected_cols - set(reader.fieldnames or [])
        assert not missing, f"CSV missing columns: {missing}"
        assert all(r["schemaVersion"] == "1" for r in rows), "CSV schemaVersion column mismatch"
        assert len({r["exportedAt"] for r in rows}) == 1, "CSV exportedAt must be identical per export"
        assert any(r["ruleId"] == EXPECTED_RULE for r in rows), (
            f"CSV missing expected ruleId; sample={rows[:2]}"
        )
        assert all(r["selector"] == SELECTOR for r in rows), (
            f"CSV rows must carry probed selector; got selectors={ {r['selector'] for r in rows} }"
        )
        assert all(r["status"] in {"sanctioned", "leak"} for r in rows), (
            f"CSV status column malformed; sample={rows[:2]}"
        )
        assert any(r["status"] == "sanctioned" for r in rows), "no sanctioned row in CSV"
        print(f"OK CSV: v{rows[0]['schemaVersion']} at {rows[0]['exportedAt']} — {len(rows)} rows")

        # --- Switch filter to 'leaks only' and verify JSON reflects the filter ---
        await page.get_by_role("radio", name="Unsuppressed leaks only").check()
        # Row count in the button label should update; when 0, button is disabled.
        # Re-run probe against a non-sanctioned selector to guarantee a leak row.
        await page.fill('input[placeholder="[data-carousel]"]', "[data-e2e-leak]")
        await page.get_by_role("button", name="Run probe").click()
        await page.wait_for_timeout(200)
        leaks_path = await download_to(page, re.compile(r"^Export JSON"), OUT / "export-leaks.json")
        leaks = json.loads(leaks_path.read_text())
        assert leaks["filters"]["mode"] == "leaks", f"expected leaks mode, got {leaks['filters']}"
        all_leaks = [r for run in leaks["runs"] for r in run["rows"]]
        assert all_leaks, "leaks-only export produced no rows"
        assert all(r["ruleId"] is None for r in all_leaks), (
            f"leaks-only export leaked a sanctioned row: {all_leaks[:2]}"
        )
        print(f"OK JSON (leaks only): {leaks['totalRows']} rows")

        await browser.close()
    print("\nPASS: admin allowlist export E2E")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
